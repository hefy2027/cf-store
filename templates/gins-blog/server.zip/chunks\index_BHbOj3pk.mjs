globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { a as generateState, c as getGithub, s as sanitizeRedirectTarget } from "./redirect_BKbNLFHX.mjs";
import "./sequence_C6JDRbfE.mjs";
const GET = async ({
  cookies,
  redirect,
  request
}) => {
  const state = generateState();
  const url = getGithub(env).createAuthorizationURL(state, []);
  const redirectTo = sanitizeRedirectTarget(new URL(request.url).searchParams.get("redirect_to"));
  cookies.set("github_oauth_state", state, {
    path: "/",
    secure: true,
    httpOnly: true,
    maxAge: 60 * 10,
    sameSite: "lax"
  });
  cookies.set("login_redirect", redirectTo, {
    path: "/",
    secure: true,
    httpOnly: true,
    maxAge: 60 * 10,
    sameSite: "lax"
  });
  return redirect(url.toString());
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  GET
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

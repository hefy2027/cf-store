globalThis.process ??= {};
globalThis.process.env ??= {};
import { g as getLangFromUrl, $ as $$Layout, r as renderScript, u as useTranslations } from "./Layout_B4Am03Vw.mjs";
import { c as createComponent } from "./astro-component_BvYacKii.mjs";
import { aj as renderTemplate, a6 as maybeRenderHead, aw as addAttribute } from "./sequence_C6JDRbfE.mjs";
import { r as renderComponent } from "./worker-entry_CI_WUTHH.mjs";
const $$404 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$404;
  const lang = getLangFromUrl(Astro2.url);
  const t = useTranslations(lang);
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": t("404.title"), "description": t("404.description") }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="min-h-[70vh] flex flex-col items-center justify-center text-center px-4"> <!-- Glitch Effect Container --> <div class="relative mb-8"> <h1 class="text-9xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-white/10 opacity-20 select-none">
404
</h1> <div class="absolute inset-0 flex items-center justify-center"> <h2 id="not-found-title" class="text-4xl md:text-6xl font-bold font-display text-brand-accent drop-shadow-[0_0_15px_rgba(244,114,182,0.5)] animate-pulse"> ${t("404.hero")} </h2> </div> </div> <div class="glass-panel p-8 rounded-3xl max-w-lg w-full border border-white/10 backdrop-blur-xl"> <p id="not-found-text" class="text-xl md:text-2xl font-medium text-white mb-4"> ${t("404.text")} </p> <p id="not-found-subtitle" class="text-gray-400 mb-8 font-mono text-sm leading-relaxed"> ${t("404.subtitle")} </p> <a id="back-home-btn"${addAttribute(lang === "en-SG" ? "/" : lang === "zh" ? "/zh/" : `/${lang}/`, "href")} class="group relative inline-flex items-center gap-3 px-8 py-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-brand-accent/50 transition-all duration-300"> <div class="absolute inset-0 rounded-xl bg-brand-accent/10 opacity-0 group-hover:opacity-100 transition-opacity blur-lg"></div> <span class="i-heroicons-home text-brand-accent group-hover:scale-110 transition-transform"></span> <span id="back-home-text" class="font-bold text-white group-hover:text-brand-accent transition-colors">${t("404.home")}</span> </a> </div> </div> ` })} ${renderScript($$result, "D:/coding/claude/_ginsbuild/src/pages/404.astro?astro&type=script&index=0&lang.ts")}`;
}, "D:/coding/claude/_ginsbuild/src/pages/404.astro", void 0);
const $$file = "D:/coding/claude/_ginsbuild/src/pages/404.astro";
const $$url = "/404";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$404,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

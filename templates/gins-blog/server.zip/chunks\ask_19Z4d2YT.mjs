globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
const GET = async ({
  request
}) => {
  const env$1 = env;
  const url = new URL(request.url);
  const q = url.searchParams.get("q");
  if (!q) {
    return new Response("Query required", {
      status: 400
    });
  }
  try {
    const embeddingResponse = await env$1.AI.run("@cf/baai/bge-base-en-v1.5", {
      text: [q]
    });
    const queryVector = embeddingResponse.data[0];
    const matches = await env$1.VECTOR_INDEX.query(queryVector, {
      topK: 5,
      returnMetadata: true
    });
    const context = matches.matches.map((match) => `Title: ${match.metadata.title}
Content Snippet: ...
Source: /blog/${match.metadata.slug}`).join("\n\n");
    if (!context) {
      return new Response("I couldn't find any relevant posts to answer your question.", {
        headers: {
          "Content-Type": "text/plain"
        }
      });
    }
    const systemPrompt = `You are Ichimaru Gin's AI Assistant. You answer questions based ONLY on the provided context from his blog.
        
        Rules:
        - Use a helpful, slightly technical, and cyber-aesthetic tone.
        - Answer concisely.
        - ALWAYS cite the source blog post title when you state a fact.
        - If the answer is not in the context, say "I don't have that information in my memory banks."
        
        Context:
        ${context}`;
    const response = await env$1.AI.run("@cf/meta/llama-3-8b-instruct", {
      messages: [{
        role: "system",
        content: systemPrompt
      }, {
        role: "user",
        content: q
      }],
      stream: true
    });
    return new Response(response, {
      headers: {
        "Content-Type": "text/event-stream"
      }
    });
  } catch (e) {
    console.error(e);
    return new Response("Neural Link Failure", {
      status: 500
    });
  }
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  GET
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

globalThis.process ??= {};
globalThis.process.env ??= {};
import { c as createComponent } from "./astro-component_BvYacKii.mjs";
import { ak as createRenderInstruction, aw as addAttribute, aj as renderTemplate, a6 as maybeRenderHead, bL as renderHead, bM as createTransitionScope, a9 as renderSlot } from "./sequence_C6JDRbfE.mjs";
import { r as renderComponent } from "./worker-entry_CI_WUTHH.mjs";
async function renderScript(result, id) {
  const inlined = result.inlinedScripts.get(id);
  let content = "";
  if (inlined != null) {
    if (inlined) {
      content = `<script type="module">${inlined}<\/script>`;
    }
  } else {
    const resolved = await result.resolve(id);
    content = `<script type="module" src="${result.userAssetsBase ? (result.base === "/" ? "" : result.base) + result.userAssetsBase : ""}${resolved}"><\/script>`;
  }
  return createRenderInstruction({ type: "script", id, content });
}
const languages = {
  "en-SG": "English",
  zh: "中文（简体）"
};
const defaultLang = "en-SG";
const ui = {
  "en-SG": {
    "nav.home": "Home",
    "nav.blog": "Blog",
    "nav.about": "About",
    "nav.search": "Search...",
    "nav.login": "LOGIN",
    "hero.title": "Gin's Blog",
    "hero.subtitle": "Full Stack Development, Tech, and Life observations.",
    "footer.rights": "All Systems Nominal.",
    "about.fullstack": "FULL STACK",
    "about.ai": "AI ENTHUSIAST",
    "about.description": "Striving to write clean and efficient code. Passionate about learning new technologies and building applications. Currently mastering TypeScript and JavaScript.",
    "about.connect": "Connect",
    "about.chronicle": "Chronicle",
    "blog.latest_thoughts": "Latest",
    "blog.thoughts_highlight": "Thoughts",
    "blog.musings": "Musings on architecture, crypto, and the bleeding edge.",
    "blog.back": "Back to Overview",
    "blog.prev": "Previous Post",
    "blog.next": "Next Post",
    "chronicle.deno_jsr": "Migration to pnpm & JSR",
    "chronicle.deno_jsr_desc": "Fully unified local development by migrating package management to pnpm and integrated JSR for high-performance dependency resolution.",
    "chronicle.mcp_agent": "Agentic AI & MCP Integration",
    "chronicle.mcp_agent_desc": "Added llms.txt, OpenClaw deployment support, and a full Model Context Protocol (MCP) Server for autonomous content management.",
    "chronicle.biome_fmt": "Standardized with Biome",
    "chronicle.biome_fmt_desc": "Migrated the entire codebase to Biome for unified formatting and linting, replacing Prettier and ESLint.",
    "chronicle.ai_search": "AI Search Redesign",
    "chronicle.ai_search_desc": "Implemented RAG-based intelligent Q&A system integrated with Vectorize vector database.",
    "chronicle.blog_launch": "Blog 2.0 Launch",
    "chronicle.blog_launch_desc": "Refactored with Astro + Cloudflare Pages, introducing the new Neo-Aesthetics design language.",
    "chronicle.inception": "Inception",
    "chronicle.inception_desc": "Hello, World. Gin's Blog was established.",
    "home.system_status": "System Status",
    "home.operational": "Operational",
    "home.all_systems_normal": "All Systems Normal",
    "home.recent_posts": "Recent Posts",
    "home.no_signals": "Still thinking what to write lah...",
    "home.view_archive": "View Archive",
    "home.gallery": "Gallery",
    "home.projects": "Projects",
    "profile.title": "Your Profile",
    "profile.upload_hint": "Click to upload new avatar",
    "profile.change_avatar": "Change",
    "profile.username": "Username",
    "profile.bio": "Bio",
    "profile.bio_placeholder": "Tell us about yourself...",
    "profile.social_links": "Social Links",
    "profile.save": "Save Changes",
    "profile.linked_accounts": "Linked Accounts",
    "profile.connect_github": "Connect GitHub",
    "profile.github_connected": "GitHub Connected",
    "profile.connect_google": "Connect Google",
    "profile.google_connected": "Google Connected",
    "profile.connect_discord": "Connect Discord",
    "profile.discord_connected": "Discord Connected",
    "profile.display_settings": "Display Settings",
    "profile.display_settings_desc": "Choose which provider's username and avatar to display across the site",
    "profile.apply_selection": "Apply Selection",
    "profile.sign_out": "Sign Out",
    "login.title": "Welcome Back",
    "login.subtitle": "Sign in to access the bleeding edge.",
    "login.github": "Continue with GitHub",
    "login.google": "Continue with Google",
    "login.discord": "Continue with Discord",
    "login.terms": "By clicking continue, you agree to our Terms of Service and Privacy Policy.",
    "404.title": "404 - Aiyo!",
    "404.hero": "Aiyo!",
    "404.description": "Nothing to see here lah!",
    "404.text": "Page not found lah!",
    "404.subtitle": "You lost or what? This signal is transmission dead. Valid coordinates are required for teleportation.",
    "404.home": "Balik Kampung (Home)",
    "profile.sessions": "Active Sessions",
    "profile.sessions_desc": "Manage devices where you're currently logged in",
    "profile.sessions_loading": "Loading sessions...",
    "profile.sessions_none": "No active sessions found",
    "profile.sessions_revoke": "Revoke",
    "profile.sessions_current": "Current",
    "profile.sessions_first_login": "First login",
    "profile.sessions_last_active": "Last active",
    "profile.sessions_confirm_revoke": "Are you sure you want to revoke this session? You will be logged out on that device.",
    "profile.sessions_error_load": "Failed to load sessions",
    "profile.sessions_error_revoke": "Failed to revoke session"
  },
  zh: {
    "nav.home": "首页",
    "nav.blog": "博客",
    "nav.about": "关于",
    "nav.search": "搜索...",
    "nav.login": "登录",
    "hero.title": "Gin的博客",
    "hero.subtitle": "全栈开发、技术探索与生活随笔。",
    "footer.rights": "系统运行正常。",
    "about.fullstack": "全栈开发",
    "about.ai": "AI 爱好者",
    "about.description": "致力于编写简洁高效的代码，热衷于学习新技术与构建应用。正在深入学习 TypeScript 和 JavaScript。",
    "about.connect": "联系方式",
    "about.chronicle": "编年史",
    "blog.latest_thoughts": "最新",
    "blog.thoughts_highlight": "文章",
    "blog.musings": "关于架构、Web3 和前沿技术的思考。",
    "blog.back": "返回列表",
    "blog.prev": "上一篇",
    "blog.next": "下一篇",
    "chronicle.deno_jsr": "全量迁移至 pnpm 与 JSR 生态",
    "chronicle.deno_jsr_desc": "统一本地开发环境，将包管理器彻底迁移至更高效的 pnpm，并接入高性能的 JSR 包管理平台以优化依赖解析。",
    "chronicle.mcp_agent": "Agentic AI & MCP 集成",
    "chronicle.mcp_agent_desc": "新增 llms.txt 支持、OpenClaw 部署管理，并实现了完整的 MCP (Model Context Protocol) Server 以支持自主内容管理。",
    "chronicle.biome_fmt": "Biome 格式化标准化",
    "chronicle.biome_fmt_desc": "全站代码库迁移至 Biome，统一了格式化和 Lint 规则，替代了 Prettier 和 ESLint。",
    "chronicle.ai_search": "AI 搜索重构",
    "chronicle.ai_search_desc": "实现了基于 RAG 的智能问答系统，集成了 Vectorize 向量数据库。",
    "chronicle.blog_launch": "博客 2.0 发布",
    "chronicle.blog_launch_desc": "使用 Astro + Cloudflare Pages 重构，引入了全新的新美学设计语言。",
    "chronicle.inception": "起源",
    "chronicle.inception_desc": "Hello, World. Gin 的博客建立了。",
    "home.system_status": "系统状态",
    "home.operational": "运行正常",
    "home.all_systems_normal": "所有系统指标正常",
    "home.recent_posts": "最近更新",
    "home.no_signals": "还在想写什么...",
    "home.view_archive": "查看归档",
    "home.gallery": "图库",
    "home.projects": "项目",
    "profile.title": "个人资料",
    "profile.upload_hint": "点击上传新头像",
    "profile.change_avatar": "更换",
    "profile.username": "用户名",
    "profile.bio": "简介",
    "profile.bio_placeholder": "介绍一下你自己...",
    "profile.social_links": "社交链接",
    "profile.save": "保存更改",
    "profile.linked_accounts": "关联账户",
    "profile.connect_github": "连接 GitHub",
    "profile.github_connected": "GitHub 已连接",
    "profile.connect_google": "连接 Google",
    "profile.google_connected": "Google 已连接",
    "profile.connect_discord": "连接 Discord",
    "profile.discord_connected": "Discord 已连接",
    "profile.display_settings": "显示设置",
    "profile.display_settings_desc": "选择在全站显示的头像和用户名来源",
    "profile.apply_selection": "应用选择",
    "profile.sign_out": "退出登录",
    "login.title": "欢迎回来",
    "login.subtitle": "登录以探索前沿内容。",
    "login.github": "通过 GitHub 继续",
    "login.google": "通过 Google 继续",
    "login.discord": "通过 Discord 继续",
    "login.terms": "点击继续即表示您同意我们的服务条款和隐私政策。",
    "404.title": "404 - 哎哟!",
    "404.hero": "哎哟!",
    "404.description": "这里什么都没有啦!",
    "404.text": "页面未找到",
    "404.subtitle": "你在此迷失了吗？信号中断。传送需要有效的坐标。",
    "404.home": "返回首页",
    "profile.sessions": "活跃会话",
    "profile.sessions_desc": "管理您当前登录的设备",
    "profile.sessions_loading": "正在加载会话...",
    "profile.sessions_none": "暂无活跃会话",
    "profile.sessions_revoke": "注销",
    "profile.sessions_current": "当前设备",
    "profile.sessions_first_login": "首次登录",
    "profile.sessions_last_active": "最近活跃",
    "profile.sessions_confirm_revoke": "您确定要注销此会话吗？您将在该设备上退出登录。",
    "profile.sessions_error_load": "加载会话失败",
    "profile.sessions_error_revoke": "注销会话失败"
  }
};
function getLangFromUrl(url) {
  const [, lang] = url.pathname.split("/");
  if (lang === "zh") return "zh";
  if (lang in ui) return lang;
  return defaultLang;
}
function useTranslations(lang) {
  return function t(key) {
    return ui[lang][key] || ui[defaultLang][key];
  };
}
function getRouteFromUrl(url, targetLang) {
  const currentLang = getLangFromUrl(url);
  let path = url.pathname;
  const search = url.search;
  if (currentLang === "zh") {
    path = path.replace(/^\/zh/, "") || "/";
  } else if (currentLang !== defaultLang) {
    path = path.replace(`/${currentLang}`, "") || "/";
  }
  if (!path.startsWith("/")) {
    path = `/${path}`;
  }
  if (targetLang === defaultLang) {
    return path + search;
  }
  return `/zh${path === "/" ? "" : path}${search}`;
}
const $$ClientRouter = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$ClientRouter;
  const { fallback = "animate" } = Astro2.props;
  return renderTemplate`<meta name="astro-view-transitions-enabled" content="true"><meta name="astro-view-transitions-fallback"${addAttribute(fallback, "content")}>${renderScript($$result, "D:/coding/claude/_ginsbuild/node_modules/.pnpm/astro@6.1.6_@types+node@25._7c358c33f45f7aec8576c9699eee3898/node_modules/astro/components/ClientRouter.astro?astro&type=script&index=0&lang.ts")}`;
}, "D:/coding/claude/_ginsbuild/node_modules/.pnpm/astro@6.1.6_@types+node@25._7c358c33f45f7aec8576c9699eee3898/node_modules/astro/components/ClientRouter.astro", void 0);
const $$Footer = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$Footer;
  const lang = getLangFromUrl(Astro2.url);
  const t = useTranslations(lang);
  return renderTemplate`${maybeRenderHead()}<footer class="py-8 pb-24 md:pb-8 mt-12 mb-4 border-t border-white/5 bg-black/80 backdrop-blur-md w-full"> <div class="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6"> <div class="text-gray-500 text-sm font-mono">
&copy; ${(/* @__PURE__ */ new Date()).getFullYear()} IchimaruGin728. ${t("footer.rights")} </div> <div class="flex gap-6 text-gray-400"> <a href="https://github.com/IchimaruGin728" target="_blank" class="hover:text-brand-accent transition-colors hover:scale-110 transform duration-200" title="GitHub"> <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"> <path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.88 16.5c-1.22.6-2.68.9-4.22.9-1.9 0-3.5-.6-4.8-1.8a7.28 7.28 0 0 1-2.1-5.1c0-1.9.6-3.5 1.9-4.8C9.9 4.6 11.5 4 13.5 4c1.6 0 3 .3 4.2.9v11.6z" fill-rule="evenodd" clip-rule="evenodd" opacity="0"></path> <!-- Using simpler path or the one from ShareButtons --> <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"></path> </svg> </a> <a href="https://x.com/IchimaruGin728" target="_blank" class="hover:text-brand-accent transition-colors hover:scale-110 transform duration-200" title="X (Twitter)"> <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"> <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path> </svg> </a> <a href="https://discord.com/users/IchimaruGin728" target="_blank" title="Discord" class="hover:text-brand-accent transition-colors hover:scale-110 transform duration-200"> <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"> <path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z"></path> </svg> </a> <a${addAttribute(lang === "en-SG" ? "/rss.xml" : `/${lang}/rss.xml`, "href")} target="_blank" title="RSS Feed" class="hover:text-brand-accent transition-colors hover:scale-110 transform duration-200"> <span class="i-heroicons-rss w-5 h-5 bg-current inline-block"></span> </a> </div> </div> </footer>`;
}, "D:/coding/claude/_ginsbuild/src/components/Footer.astro", void 0);
const $$LanguagePicker = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$LanguagePicker;
  const url = Astro2.url;
  const currentLang = getLangFromUrl(url);
  return renderTemplate`${maybeRenderHead()}<div class="relative group z-50"> <button class="flex items-center gap-1 text-sm font-medium text-gray-400 hover:text-white transition-colors"> <span class="i-heroicons-language w-5 h-5"></span> <span class="hidden md:inline">${languages[currentLang]}</span> </button> <div class="absolute right-0 top-full mt-2 w-32 py-2 bg-black/80 backdrop-blur-md rounded-xl border border-white/10 shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 transform origin-top-right"> ${Object.entries(languages).map(([lang, label]) => renderTemplate`<a${addAttribute(getRouteFromUrl(url, lang), "href")} data-astro-prefetch${addAttribute(`block px-4 py-2 text-sm hover:bg-white/10 transition-colors ${currentLang === lang ? "text-brand-accent" : "text-gray-300"}`, "class")}> ${label} </a>`)} </div> </div>`;
}, "D:/coding/claude/_ginsbuild/src/components/LanguagePicker.astro", void 0);
const $$Header = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$Header;
  const lang = getLangFromUrl(Astro2.url);
  const t = useTranslations(lang);
  return renderTemplate`${maybeRenderHead()}<nav class="fixed top-0 w-full z-50 px-6 py-4" style="padding-top: max(1rem, env(safe-area-inset-top)); padding-left: max(1.5rem, env(safe-area-inset-left)); padding-right: max(1.5rem, env(safe-area-inset-right));"> <div class="max-w-7xl mx-auto glass-panel rounded-full px-6 py-3 min-h-[3.5rem] flex justify-between items-center"> <a${addAttribute(lang === "en-SG" ? "/" : `/${lang}/`, "href")} class="text-xl md:text-xl font-display font-bold bg-clip-text text-transparent bg-gradient-to-r from-brand-accent to-brand-primary z-50 relative leading-none flex items-center">
Gin's Blog
</a> <div class="hidden md:flex absolute left-1/2 -translate-x-1/2 items-center gap-1 p-1 bg-white/5 rounded-full backdrop-blur-3xl shadow-lg transition-all duration-500 ease-[cubic-bezier(0.23,1,0.32,1)] group/dock z-50"> <nav class="flex items-center gap-1 px-2 transition-all duration-500 ease-[cubic-bezier(0.23,1,0.32,1)] group-hover/search:opacity-50 group-hover/search:scale-95 group-hover/search:blur-[1px]"> <a${addAttribute(lang === "en-SG" ? "/" : `/${lang}/`, "href")} data-astro-prefetch class="px-4 py-2 text-sm font-medium text-gray-400 hover:text-white rounded-full transition-all">${t("nav.home")}</a> <a${addAttribute(lang === "en-SG" ? "/blog" : `/${lang}/blog/`, "href")} data-astro-prefetch class="px-4 py-2 text-sm font-medium text-gray-400 hover:text-white rounded-full transition-all">${t("nav.blog")}</a> <a${addAttribute(lang === "en-SG" ? "/docs" : `/${lang}/docs/`, "href")} data-astro-prefetch class="px-4 py-2 text-sm font-medium text-gray-400 hover:text-white rounded-full transition-all">${lang === "zh" ? "文档" : "Docs"}</a> <a${addAttribute(lang === "en-SG" ? "/about" : `/${lang}/about/`, "href")} data-astro-prefetch class="px-4 py-2 text-sm font-medium text-gray-400 hover:text-white rounded-full transition-all">${t("nav.about")}</a> </nav> <button id="search-trigger-btn" class="group/search relative flex items-center justify-center h-8 w-8 bg-white/10 hover:bg-brand-primary/20 hover:w-48 border border-white/5 hover:border-brand-primary/30 rounded-full transition-all duration-500 ease-[cubic-bezier(0.23,1,0.32,1)] overflow-hidden cursor-text"> <svg class="absolute left-2 w-4 h-4 z-10 transition-all duration-300 group-hover/search:scale-110" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"> <defs> <linearGradient id="searchGradient" x1="0%" y1="0%" x2="100%" y2="100%"> <stop offset="0%" style="stop-color:#a855f7;stop-opacity:1"></stop> <stop offset="100%" style="stop-color:#ec4899;stop-opacity:1"></stop> </linearGradient> </defs> <!-- Search Circle --> <circle cx="10" cy="10" r="6" stroke="url(#searchGradient)" stroke-width="2"></circle> <!-- Inner Glow --> <circle cx="10" cy="10" r="3" fill="url(#searchGradient)" opacity="0.2" class="group-hover/search:opacity-30 transition-opacity"></circle> <!-- Handle --> <line x1="14.5" y1="14.5" x2="20" y2="20" stroke="url(#searchGradient)" stroke-width="2" stroke-linecap="round"></line> </svg> <div class="flex items-center gap-2 pl-8 opacity-0 group-hover/search:opacity-100 translate-x-4 group-hover/search:translate-x-0 transition-all duration-500 delay-75 whitespace-nowrap"> <span class="text-xs text-gray-200">${t("nav.search")}</span> <kbd class="px-1.5 py-0.5 text-[10px] text-brand-primary bg-brand-primary/10 border border-brand-primary/20 rounded font-mono">⌘K</kbd> </div> </button> </div> <div class="flex items-center gap-4 z-50 relative"> ${renderComponent($$result, "LanguagePicker", $$LanguagePicker, {})} <a${addAttribute(lang === "en-SG" ? "/rss.xml" : `/${lang}/rss.xml`, "href")} target="_blank" class="hidden md:flex items-center justify-center w-8 h-8 rounded-full hover:bg-white/10 text-gray-400 hover:text-brand-accent transition-all border border-transparent hover:border-white/10" title="RSS Feed"> <span class="i-heroicons-rss-20-solid w-5 h-5"></span> </a> ${Astro2.locals.user ? renderTemplate`<a${addAttribute(
    lang === "en-SG" ? "/profile" : `/${lang}/profile`,
    "href"
  )} data-astro-prefetch class="flex items-center gap-3 hover:opacity-80 transition-opacity"> <span class="text-xs font-mono hidden md:block text-gray-300"> ${Astro2.locals.user.username} </span> <img${addAttribute(
    Astro2.locals.user.avatar || `https://ui-avatars.com/api/?name=${Astro2.locals.user.username}`,
    "src"
  )} class="w-8 h-8 rounded-full border border-white/10 shadow-sm" alt="Avatar"> </a>` : renderTemplate`<a${addAttribute(
    lang === "en-SG" ? "/login" : `/${lang}/login`,
    "href"
  )} data-astro-prefetch class="px-4 md:px-5 py-2.5 md:py-2 rounded-full bg-white/5 hover:bg-white/10 text-xs md:text-xs font-bold tracking-wide transition-all border border-white/10 hover:border-white/20 hover:scale-105 active:scale-95 flex items-center leading-none"> ${t("nav.login")} </a>`} </div> </div> ${renderScript($$result, "D:/coding/claude/_ginsbuild/src/components/Header.astro?astro&type=script&index=0&lang.ts")} </nav>`;
}, "D:/coding/claude/_ginsbuild/src/components/Header.astro", void 0);
const $$MobileNav = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$MobileNav;
  const lang = getLangFromUrl(Astro2.url);
  const t = useTranslations(lang);
  const getPathWithoutLocale = (path) => {
    if (path.startsWith("/zh/")) {
      return path.replace("/zh", "") || "/";
    }
    if (path === "/zh") {
      return "/";
    }
    return path;
  };
  const normalizedPath = getPathWithoutLocale(Astro2.url.pathname);
  const isActive = (path) => {
    if (path === "/") {
      return normalizedPath === "/";
    }
    return normalizedPath.startsWith(path);
  };
  return renderTemplate`${maybeRenderHead()}<nav class="md:hidden fixed bottom-0 left-0 right-0 z-50" style="padding-bottom: max(1rem, env(safe-area-inset-bottom)); padding-left: max(1rem, env(safe-area-inset-left)); padding-right: max(1rem, env(safe-area-inset-right));"> <div id="mobile-nav-panel" class="mx-4 mb-4 glass-panel rounded-2xl px-6 py-3 border border-white/10 backdrop-blur-xl shadow-2xl transition-all duration-500 ease-in-out"> <div class="flex justify-around items-center gap-1"> <a${addAttribute(lang === "en-SG" ? "/" : `/${lang}/`, "href")} data-astro-prefetch${addAttribute(`group relative flex flex-col items-center gap-1 px-3 py-2 rounded-2xl transition-all duration-300 ease-out ${isActive("/") ? "bg-brand-accent/20 scale-110" : "hover:bg-white/5 active:scale-90 active:bg-white/10"}`, "class")}> <svg${addAttribute(`w-6 h-6 transition-all duration-300 ${isActive("/") ? "text-brand-accent scale-110" : "text-gray-400 group-hover:text-white group-hover:scale-105"}`, "class")} fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path> </svg> <span${addAttribute(`nav-label text-xs font-medium transition-all duration-300 ease-out ${isActive("/") ? "text-brand-accent font-bold" : "text-gray-500 group-hover:text-gray-300"}`, "class")} style="white-space: nowrap;"> ${t("nav.home")} </span> ${isActive("/") && renderTemplate`<div class="absolute -top-1 w-1 h-1 bg-brand-accent rounded-full animate-pulse"></div>`} </a> <!-- Blog --> <a${addAttribute(lang === "en-SG" ? "/blog" : `/${lang}/blog/`, "href")} data-astro-prefetch${addAttribute(`group relative flex flex-col items-center gap-1 px-3 py-2 rounded-2xl transition-all duration-300 ease-out ${isActive("/blog") ? "bg-brand-accent/20 scale-110" : "hover:bg-white/5 active:scale-90 active:bg-white/10"}`, "class")}> <svg${addAttribute(`w-6 h-6 transition-all duration-300 ${isActive("/blog") ? "text-brand-accent scale-110" : "text-gray-400 group-hover:text-white group-hover:scale-105"}`, "class")} fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z"></path> </svg> <span${addAttribute(`nav-label text-xs font-medium transition-all duration-300 ease-out ${isActive("/blog") ? "text-brand-accent font-bold" : "text-gray-500 group-hover:text-gray-300"}`, "class")} style="white-space: nowrap;"> ${t("nav.blog")} </span> ${isActive("/blog") && renderTemplate`<div class="absolute -top-1 w-1 h-1 bg-brand-accent rounded-full animate-pulse"></div>`} </a> <!-- Docs --> <a${addAttribute(lang === "en-SG" ? "/docs" : `/${lang}/docs/`, "href")} data-astro-prefetch${addAttribute(`group relative flex flex-col items-center gap-1 px-3 py-2 rounded-2xl transition-all duration-300 ease-out ${isActive("/docs") ? "bg-brand-accent/20 scale-110" : "hover:bg-white/5 active:scale-90 active:bg-white/10"}`, "class")}> <svg${addAttribute(`w-6 h-6 transition-all duration-300 ${isActive("/docs") ? "text-brand-accent scale-110" : "text-gray-400 group-hover:text-white group-hover:scale-105"}`, "class")} fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path> </svg> <span${addAttribute(`nav-label text-xs font-medium transition-all duration-300 ease-out ${isActive("/docs") ? "text-brand-accent font-bold" : "text-gray-500 group-hover:text-gray-300"}`, "class")} style="white-space: nowrap;"> ${lang === "zh" ? "文档" : "Docs"} </span> ${isActive("/docs") && renderTemplate`<div class="absolute -top-1 w-1 h-1 bg-brand-accent rounded-full animate-pulse"></div>`} </a> <!-- Search --> <button id="mobile-search-btn" class="group relative flex flex-col items-center gap-1 px-3 py-2 rounded-2xl transition-all duration-300 ease-out hover:bg-white/5 active:scale-90 active:bg-white/10"> <svg class="w-6 h-6 text-gray-400 group-hover:text-white group-hover:scale-105 transition-all duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path> </svg> <span class="nav-label text-xs font-medium text-gray-500 group-hover:text-gray-300 transition-all duration-300 ease-out" style="white-space: nowrap;"> ${t("nav.search")} </span> </button> <!-- About --> <a${addAttribute(lang === "en-SG" ? "/about" : `/${lang}/about/`, "href")} data-astro-prefetch${addAttribute(`group relative flex flex-col items-center gap-1 px-3 py-2 rounded-2xl transition-all duration-300 ease-out ${isActive("/about") ? "bg-brand-accent/20 scale-110" : "hover:bg-white/5 active:scale-90 active:bg-white/10"}`, "class")}> <svg${addAttribute(`w-6 h-6 transition-all duration-300 ${isActive("/about") ? "text-brand-accent scale-110" : "text-gray-400 group-hover:text-white group-hover:scale-105"}`, "class")} fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path> </svg> <span${addAttribute(`nav-label text-xs font-medium transition-all duration-300 ease-out ${isActive("/about") ? "text-brand-accent font-bold" : "text-gray-500 group-hover:text-gray-300"}`, "class")} style="white-space: nowrap;"> ${t("nav.about")} </span> ${isActive("/about") && renderTemplate`<div class="absolute -top-1 w-1 h-1 bg-brand-accent rounded-full animate-pulse"></div>`} </a> </div> </div> </nav> ${renderScript($$result, "D:/coding/claude/_ginsbuild/src/components/MobileNav.astro?astro&type=script&index=0&lang.ts")}`;
}, "D:/coding/claude/_ginsbuild/src/components/MobileNav.astro", void 0);
const $$Layout = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$Layout;
  const lang = getLangFromUrl(Astro2.url);
  const {
    title,
    description = "Gin's bleeding edge blog exploring AI, software engineering, and technology.",
    image,
    type = "website",
    publishedTime,
    author = "IchimaruGin728",
    keywords = "blog, tech, ai, software engineering, ichimarugin728"
  } = Astro2.props;
  const canonicalURL = new URL(
    Astro2.url.pathname,
    Astro2.site || Astro2.url.origin
  );
  const ogImage = image || (Astro2.url.pathname.startsWith("/blog/") ? `/og${Astro2.url.pathname.replace("/blog", "")}.png` : "/og-default.png");
  const fullOgImage = new URL(ogImage, Astro2.site || Astro2.url.origin).href;
  const fullTitle = title === "Home" ? "Gin's Blog - AI, Tech & Engineering" : `${title} | Gin's Blog`;
  return renderTemplate`<html${addAttribute(lang, "lang")} class="dark"> <head>${renderComponent($$result, "ClientRouter", $$ClientRouter, {})}<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover, maximum-scale=1.0, user-scalable=no"><!-- Favicons & PWA --><link rel="icon" type="image/svg+xml" href="/favicon.svg"><link rel="icon" type="image/png" href="/favicon.png"><link rel="manifest" href="/manifest.json"><meta name="theme-color" content="#8b5cf6"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta name="apple-mobile-web-app-title" content="GinBlog"><link rel="apple-touch-icon" href="/pwa-192x192.png"><!-- SEO Meta Tags --><link rel="canonical"${addAttribute(canonicalURL, "href")}><meta name="generator"${addAttribute(Astro2.generator, "content")}><meta name="description"${addAttribute(description, "content")}><meta name="author"${addAttribute(author, "content")}><meta name="keywords"${addAttribute(keywords, "content")}><meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1"><!-- Open Graph / Facebook --><meta property="og:type"${addAttribute(type, "content")}><meta property="og:url"${addAttribute(canonicalURL, "content")}><meta property="og:title"${addAttribute(fullTitle, "content")}><meta property="og:description"${addAttribute(description, "content")}><meta property="og:image"${addAttribute(fullOgImage, "content")}><meta property="og:site_name" content="Gin's Blog"><meta property="og:locale"${addAttribute(lang.replace("-", "_"), "content")}>${publishedTime && renderTemplate`<meta property="article:published_time"${addAttribute(publishedTime, "content")}>`}${author && renderTemplate`<meta property="article:author"${addAttribute(author, "content")}>`}<!-- Twitter Card --><meta name="twitter:card" content="summary_large_image"><meta name="twitter:url"${addAttribute(canonicalURL, "content")}><meta name="twitter:title"${addAttribute(fullTitle, "content")}><meta name="twitter:description"${addAttribute(description, "content")}><meta name="twitter:image"${addAttribute(fullOgImage, "content")}><meta name="twitter:creator" content="@IchimaruGin728"><!-- Hreflang Tags for SEO --><link rel="alternate" hreflang="en-SG"${addAttribute(new URL(
    getRouteFromUrl(Astro2.url, "en-SG"),
    Astro2.site || Astro2.url.origin
  ).href, "href")}><link rel="alternate" hreflang="zh"${addAttribute(new URL(
    getRouteFromUrl(Astro2.url, "zh"),
    Astro2.site || Astro2.url.origin
  ).href, "href")}><link rel="alternate" hreflang="x-default"${addAttribute(new URL(
    getRouteFromUrl(Astro2.url, "en-SG"),
    Astro2.site || Astro2.url.origin
  ).href, "href")}><title>${fullTitle}</title>${renderHead()}</head> <body class="bg-[#050505] text-white min-h-screen font-sans flex flex-col"> <!-- Background Elements --> <div class="fixed inset-0 z-0 pointer-events-none overflow-hidden" style="transform: translateZ(0); backface-visibility: hidden; will-change: transform;"${addAttribute(createTransitionScope($$result, "y7dbjv5y"), "data-astro-transition-persist")}> <div class="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] bg-brand-primary/10 rounded-full blur-[80px]"></div> <div class="absolute bottom-[-20%] left-[-10%] w-[600px] h-[600px] bg-brand-accent/5 rounded-full blur-[80px]"></div> </div> ${renderComponent($$result, "Header", $$Header, {})} <main class="relative z-10 pt-32 px-6 max-w-7xl mx-auto w-full flex-grow pb-24 md:pb-0 main-content"> ${renderSlot($$result, $$slots["default"])} </main> <div class="hidden"> <!-- Hidden hydration trigger for Islands if needed --> </div> ${renderComponent($$result, "MobileNav", $$MobileNav, {})} ${renderComponent($$result, "Footer", $$Footer, {})} ${renderComponent($$result, "SearchModal", null, { "client:only": "preact", "client:component-hydration": "only", "client:component-path": "D:/coding/claude/_ginsbuild/src/components/SearchModal.tsx", "client:component-export": "default" })} <!-- Device Info Collector (Runs once per session) --> ${renderScript($$result, "D:/coding/claude/_ginsbuild/src/layouts/Layout.astro?astro&type=script&index=0&lang.ts")} </body> </html>`;
}, "D:/coding/claude/_ginsbuild/src/layouts/Layout.astro", "self");
export {
  $$Layout as $,
  getLangFromUrl as g,
  renderScript as r,
  useTranslations as u
};

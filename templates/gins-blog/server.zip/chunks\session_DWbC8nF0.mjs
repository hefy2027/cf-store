globalThis.process ??= {};
globalThis.process.env ??= {};
import { s as sha256 } from "./sha512_BMZIG4lt.mjs";
import { bG as encodeHexLowerCase, bJ as encodeBase32LowerCaseNoPadding } from "./sequence_C6JDRbfE.mjs";
import { s as sessions, e as eq, u as users, a as and } from "./db_XAr9wiDM.mjs";
function generateSessionToken() {
  const bytes = new Uint8Array(20);
  crypto.getRandomValues(bytes);
  return encodeBase32LowerCaseNoPadding(bytes);
}
async function createSession(token, userId, db, env, request, deviceInfo) {
  const sessionId = encodeHexLowerCase(sha256(new TextEncoder().encode(token)));
  const now = Date.now();
  const userAgent = request.headers.get("User-Agent") || void 0;
  const ipAddress = request.headers.get("CF-Connecting-IP") || void 0;
  const cf = request.cf;
  const getCfString = (value) => typeof value === "string" ? value : null;
  const getCfNumber = (value) => typeof value === "number" ? value : null;
  if (userAgent && ipAddress) {
    const duplicateSessions = await db.select().from(sessions).where(and(eq(sessions.userId, userId), eq(sessions.userAgent, userAgent), eq(sessions.ipAddress, ipAddress))).all();
    for (const dup of duplicateSessions) {
      await db.delete(sessions).where(eq(sessions.id, dup.id));
      await env.GIN_KV.delete(`session:${dup.id}`);
    }
  }
  const session = {
    id: sessionId,
    userId,
    expiresAt: now + 1e3 * 60 * 60 * 24 * 30,
    userAgent: userAgent || null,
    ipAddress: ipAddress || null,
    // Basic Geo
    country: getCfString(cf?.country),
    city: getCfString(cf?.city),
    // Network & ISP
    asn: getCfNumber(cf?.asn),
    asOrganization: getCfString(cf?.asOrganization),
    colo: getCfString(cf?.colo),
    continent: getCfString(cf?.continent),
    timezone: getCfString(cf?.timezone),
    // Enhanced Geolocation
    latitude: getCfString(cf?.latitude),
    longitude: getCfString(cf?.longitude),
    postalCode: getCfString(cf?.postalCode),
    region: getCfString(cf?.region),
    regionCode: getCfString(cf?.regionCode),
    // Connection Details
    httpProtocol: getCfString(cf?.httpProtocol),
    tlsVersion: getCfString(cf?.tlsVersion),
    tlsCipher: getCfString(cf?.tlsCipher),
    clientTcpRtt: getCfNumber(cf?.clientTcpRtt),
    // Security & Trust
    clientTrustScore: null,
    isEUCountry: cf?.isEUCountry === true ? 1 : 0,
    // Device Information (client-collected)
    screenResolution: deviceInfo?.screenResolution || null,
    deviceMemory: deviceInfo?.deviceMemory || null,
    cpuCores: deviceInfo?.cpuCores || null,
    connectionType: deviceInfo?.connectionType || null,
    osVerified: null,
    createdAt: now,
    lastActive: now
  };
  await db.insert(sessions).values(session);
  await env.GIN_KV.put(`session:${sessionId}`, JSON.stringify(session), {
    expiration: Math.floor(session.expiresAt / 1e3)
  });
  return session;
}
async function hydrateLegacySession(session, sessionId, request, db, env) {
  const userAgent = request.headers.get("user-agent");
  const ipAddress = request.headers.get("cf-connecting-ip");
  if (!userAgent || !ipAddress) return false;
  session.userAgent = userAgent;
  session.ipAddress = ipAddress;
  session.lastActive = Date.now();
  await db.update(sessions).set({
    userAgent,
    ipAddress,
    lastActive: session.lastActive
  }).where(eq(sessions.id, session.id));
  await env.GIN_KV.put(`session:${sessionId}`, JSON.stringify(session), {
    expiration: Math.floor(session.expiresAt / 1e3)
  });
  return true;
}
async function refreshSession(session, sessionId, db, env) {
  const now = Date.now();
  if (now >= session.expiresAt - 1e3 * 60 * 60 * 24 * 15) {
    session.expiresAt = now + 1e3 * 60 * 60 * 24 * 30;
    session.lastActive = now;
    await env.GIN_KV.put(`session:${sessionId}`, JSON.stringify(session), {
      expiration: Math.floor(session.expiresAt / 1e3)
    });
    await db.update(sessions).set({
      expiresAt: session.expiresAt,
      lastActive: session.lastActive
    }).where(eq(sessions.id, session.id));
  } else if (now - (session.lastActive || 0) > 6e4) {
    session.lastActive = now;
    await env.GIN_KV.put(`session:${sessionId}`, JSON.stringify(session), {
      expiration: Math.floor(session.expiresAt / 1e3)
    });
    await db.update(sessions).set({
      lastActive: session.lastActive
    }).where(eq(sessions.id, session.id));
  }
}
async function validateSessionToken(token, db, env, request) {
  const sessionId = encodeHexLowerCase(sha256(new TextEncoder().encode(token)));
  const cachedSessionStr = await env.GIN_KV.get(`session:${sessionId}`);
  if (cachedSessionStr) {
    const session2 = JSON.parse(cachedSessionStr);
    if (Date.now() >= session2.expiresAt) {
      await env.GIN_KV.delete(`session:${sessionId}`);
      await db.delete(sessions).where(eq(sessions.id, session2.id));
      return {
        session: null,
        user: null
      };
    }
    if ((!session2.userAgent || !session2.ipAddress) && request) {
      const ok = await hydrateLegacySession(session2, sessionId, request, db, env);
      if (!ok) {
        await env.GIN_KV.delete(`session:${sessionId}`);
        await db.delete(sessions).where(eq(sessions.id, session2.id));
        return {
          session: null,
          user: null
        };
      }
    }
    await refreshSession(session2, sessionId, db, env);
    const user2 = await db.select().from(users).where(eq(users.id, session2.userId)).get();
    if (!user2) return {
      session: null,
      user: null
    };
    return {
      session: session2,
      user: user2
    };
  }
  const result = await db.select({
    user: users,
    session: sessions
  }).from(sessions).innerJoin(users, eq(sessions.userId, users.id)).where(eq(sessions.id, sessionId)).get();
  if (!result) return {
    session: null,
    user: null
  };
  const {
    user,
    session
  } = result;
  if (Date.now() >= session.expiresAt) {
    await db.delete(sessions).where(eq(sessions.id, session.id));
    return {
      session: null,
      user: null
    };
  }
  if ((!session.userAgent || !session.ipAddress) && request) {
    const ok = await hydrateLegacySession(session, sessionId, request, db, env);
    if (!ok) {
      await db.delete(sessions).where(eq(sessions.id, session.id));
      return {
        session: null,
        user: null
      };
    }
  }
  await refreshSession(session, sessionId, db, env);
  await env.GIN_KV.put(`session:${sessionId}`, JSON.stringify(session), {
    expiration: Math.floor(session.expiresAt / 1e3)
  });
  return {
    session,
    user
  };
}
async function invalidateSession(sessionId, db, env) {
  await env.GIN_KV.delete(`session:${sessionId}`);
  await db.delete(sessions).where(eq(sessions.id, sessionId));
}
export {
  createSession as c,
  generateSessionToken as g,
  invalidateSession as i,
  validateSessionToken as v
};

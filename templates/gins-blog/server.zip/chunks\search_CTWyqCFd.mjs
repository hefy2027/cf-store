globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { g as getDb, p as posts, a as and, i as inArray, j as isNotNull } from "./db_XAr9wiDM.mjs";
import { q as querySimilarPosts } from "./vectorize_9dtyaGPn.mjs";
const GET = async ({
  request
}) => {
  const env$1 = env;
  const url = new URL(request.url);
  const q = url.searchParams.get("q");
  if (!q) {
    return new Response(JSON.stringify([]), {
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
  try {
    const vectorMatches = await querySimilarPosts(env$1.AI, env$1.VECTOR_INDEX, q, 20);
    const matchIds = vectorMatches.map((m) => m.id);
    if (matchIds.length === 0) {
      return new Response(JSON.stringify([]), {
        headers: {
          "Content-Type": "application/json"
        }
      });
    }
    const db = getDb(env$1);
    const validPosts = await db.select({
      id: posts.id,
      title: posts.title,
      slug: posts.slug,
      publishedAt: posts.publishedAt
    }).from(posts).where(and(inArray(posts.id, matchIds), isNotNull(posts.publishedAt))).all();
    const results = validPosts.map((post) => {
      const vectorMatch = vectorMatches.find((m) => m.id === post.id);
      const score = vectorMatch ? vectorMatch.score : 0;
      return {
        metadata: {
          title: post.title,
          slug: post.slug
        },
        score
      };
    }).sort((a, b) => b.score - a.score).slice(0, 5);
    return new Response(JSON.stringify(results), {
      headers: {
        "Content-Type": "application/json"
      }
    });
  } catch (e) {
    console.error("AI Hybrid Search failed", e);
    return new Response(JSON.stringify({
      error: "AI Search failed",
      details: e.message || String(e)
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  GET
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

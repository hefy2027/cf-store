globalThis.process ??= {};
globalThis.process.env ??= {};
import { bS as encodeBase64urlNoPadding, bT as encodeBase64 } from "./sequence_C6JDRbfE.mjs";
import { s as sha256 } from "./sha512_BMZIG4lt.mjs";
class OAuth2Tokens {
  data;
  constructor(data) {
    this.data = data;
  }
  tokenType() {
    if ("token_type" in this.data && typeof this.data.token_type === "string") {
      return this.data.token_type;
    }
    throw new Error("Missing or invalid 'token_type' field");
  }
  accessToken() {
    if ("access_token" in this.data && typeof this.data.access_token === "string") {
      return this.data.access_token;
    }
    throw new Error("Missing or invalid 'access_token' field");
  }
  accessTokenExpiresInSeconds() {
    if ("expires_in" in this.data && typeof this.data.expires_in === "number") {
      return this.data.expires_in;
    }
    throw new Error("Missing or invalid 'expires_in' field");
  }
  accessTokenExpiresAt() {
    return new Date(Date.now() + this.accessTokenExpiresInSeconds() * 1e3);
  }
  hasRefreshToken() {
    return "refresh_token" in this.data && typeof this.data.refresh_token === "string";
  }
  refreshToken() {
    if ("refresh_token" in this.data && typeof this.data.refresh_token === "string") {
      return this.data.refresh_token;
    }
    throw new Error("Missing or invalid 'refresh_token' field");
  }
  hasScopes() {
    return "scope" in this.data && typeof this.data.scope === "string";
  }
  scopes() {
    if ("scope" in this.data && typeof this.data.scope === "string") {
      return this.data.scope.split(" ");
    }
    throw new Error("Missing or invalid 'scope' field");
  }
  idToken() {
    if ("id_token" in this.data && typeof this.data.id_token === "string") {
      return this.data.id_token;
    }
    throw new Error("Missing or invalid field 'id_token'");
  }
}
function createS256CodeChallenge(codeVerifier) {
  const codeChallengeBytes = sha256(new TextEncoder().encode(codeVerifier));
  return encodeBase64urlNoPadding(codeChallengeBytes);
}
function generateCodeVerifier() {
  const randomValues = new Uint8Array(32);
  crypto.getRandomValues(randomValues);
  return encodeBase64urlNoPadding(randomValues);
}
function generateState() {
  const randomValues = new Uint8Array(32);
  crypto.getRandomValues(randomValues);
  return encodeBase64urlNoPadding(randomValues);
}
function createOAuth2Request(endpoint, body) {
  const bodyBytes = new TextEncoder().encode(body.toString());
  const request = new Request(endpoint, {
    method: "POST",
    body: bodyBytes
  });
  request.headers.set("Content-Type", "application/x-www-form-urlencoded");
  request.headers.set("Accept", "application/json");
  request.headers.set("User-Agent", "arctic");
  request.headers.set("Content-Length", bodyBytes.byteLength.toString());
  return request;
}
function encodeBasicCredentials(username, password) {
  const bytes = new TextEncoder().encode(`${username}:${password}`);
  return encodeBase64(bytes);
}
async function sendTokenRequest$1(request) {
  let response;
  try {
    response = await fetch(request);
  } catch (e) {
    throw new ArcticFetchError(e);
  }
  if (response.status === 400 || response.status === 401) {
    let data;
    try {
      data = await response.json();
    } catch {
      throw new UnexpectedResponseError(response.status);
    }
    if (typeof data !== "object" || data === null) {
      throw new UnexpectedErrorResponseBodyError(response.status, data);
    }
    let error;
    try {
      error = createOAuth2RequestError(data);
    } catch {
      throw new UnexpectedErrorResponseBodyError(response.status, data);
    }
    throw error;
  }
  if (response.status === 200) {
    let data;
    try {
      data = await response.json();
    } catch {
      throw new UnexpectedResponseError(response.status);
    }
    if (typeof data !== "object" || data === null) {
      throw new UnexpectedErrorResponseBodyError(response.status, data);
    }
    const tokens = new OAuth2Tokens(data);
    return tokens;
  }
  if (response.body !== null) {
    await response.body.cancel();
  }
  throw new UnexpectedResponseError(response.status);
}
async function sendTokenRevocationRequest(request) {
  let response;
  try {
    response = await fetch(request);
  } catch (e) {
    throw new ArcticFetchError(e);
  }
  if (response.status === 400 || response.status === 401) {
    let data;
    try {
      data = await response.json();
    } catch {
      throw new UnexpectedErrorResponseBodyError(response.status, null);
    }
    if (typeof data !== "object" || data === null) {
      throw new UnexpectedErrorResponseBodyError(response.status, data);
    }
    let error;
    try {
      error = createOAuth2RequestError(data);
    } catch {
      throw new UnexpectedErrorResponseBodyError(response.status, data);
    }
    throw error;
  }
  if (response.status === 200) {
    if (response.body !== null) {
      await response.body.cancel();
    }
    return;
  }
  if (response.body !== null) {
    await response.body.cancel();
  }
  throw new UnexpectedResponseError(response.status);
}
function createOAuth2RequestError(result) {
  let code;
  if ("error" in result && typeof result.error === "string") {
    code = result.error;
  } else {
    throw new Error("Invalid error response");
  }
  let description = null;
  let uri = null;
  let state = null;
  if ("error_description" in result) {
    if (typeof result.error_description !== "string") {
      throw new Error("Invalid data");
    }
    description = result.error_description;
  }
  if ("error_uri" in result) {
    if (typeof result.error_uri !== "string") {
      throw new Error("Invalid data");
    }
    uri = result.error_uri;
  }
  if ("state" in result) {
    if (typeof result.state !== "string") {
      throw new Error("Invalid data");
    }
    state = result.state;
  }
  const error = new OAuth2RequestError(code, description, uri, state);
  return error;
}
class ArcticFetchError extends Error {
  constructor(cause) {
    super("Failed to send request", {
      cause
    });
  }
}
class OAuth2RequestError extends Error {
  code;
  description;
  uri;
  state;
  constructor(code, description, uri, state) {
    super(`OAuth request error: ${code}`);
    this.code = code;
    this.description = description;
    this.uri = uri;
    this.state = state;
  }
}
class UnexpectedResponseError extends Error {
  status;
  constructor(responseStatus) {
    super("Unexpected error response");
    this.status = responseStatus;
  }
}
class UnexpectedErrorResponseBodyError extends Error {
  status;
  data;
  constructor(status, data) {
    super("Unexpected error response body");
    this.status = status;
    this.data = data;
  }
}
class OAuth2Client {
  clientId;
  clientPassword;
  redirectURI;
  constructor(clientId, clientPassword, redirectURI) {
    this.clientId = clientId;
    this.clientPassword = clientPassword;
    this.redirectURI = redirectURI;
  }
  createAuthorizationURL(authorizationEndpoint2, state, scopes) {
    const url = new URL(authorizationEndpoint2);
    url.searchParams.set("response_type", "code");
    url.searchParams.set("client_id", this.clientId);
    if (this.redirectURI !== null) {
      url.searchParams.set("redirect_uri", this.redirectURI);
    }
    url.searchParams.set("state", state);
    if (scopes.length > 0) {
      url.searchParams.set("scope", scopes.join(" "));
    }
    return url;
  }
  createAuthorizationURLWithPKCE(authorizationEndpoint2, state, codeChallengeMethod, codeVerifier, scopes) {
    const url = new URL(authorizationEndpoint2);
    url.searchParams.set("response_type", "code");
    url.searchParams.set("client_id", this.clientId);
    if (this.redirectURI !== null) {
      url.searchParams.set("redirect_uri", this.redirectURI);
    }
    url.searchParams.set("state", state);
    if (codeChallengeMethod === CodeChallengeMethod.S256) {
      const codeChallenge = createS256CodeChallenge(codeVerifier);
      url.searchParams.set("code_challenge_method", "S256");
      url.searchParams.set("code_challenge", codeChallenge);
    } else if (codeChallengeMethod === CodeChallengeMethod.Plain) {
      url.searchParams.set("code_challenge_method", "plain");
      url.searchParams.set("code_challenge", codeVerifier);
    }
    if (scopes.length > 0) {
      url.searchParams.set("scope", scopes.join(" "));
    }
    return url;
  }
  async validateAuthorizationCode(tokenEndpoint2, code, codeVerifier) {
    const body = new URLSearchParams();
    body.set("grant_type", "authorization_code");
    body.set("code", code);
    if (this.redirectURI !== null) {
      body.set("redirect_uri", this.redirectURI);
    }
    if (codeVerifier !== null) {
      body.set("code_verifier", codeVerifier);
    }
    if (this.clientPassword === null) {
      body.set("client_id", this.clientId);
    }
    const request = createOAuth2Request(tokenEndpoint2, body);
    if (this.clientPassword !== null) {
      const encodedCredentials = encodeBasicCredentials(this.clientId, this.clientPassword);
      request.headers.set("Authorization", `Basic ${encodedCredentials}`);
    }
    const tokens = await sendTokenRequest$1(request);
    return tokens;
  }
  async refreshAccessToken(tokenEndpoint2, refreshToken, scopes) {
    const body = new URLSearchParams();
    body.set("grant_type", "refresh_token");
    body.set("refresh_token", refreshToken);
    if (this.clientPassword === null) {
      body.set("client_id", this.clientId);
    }
    if (scopes.length > 0) {
      body.set("scope", scopes.join(" "));
    }
    const request = createOAuth2Request(tokenEndpoint2, body);
    if (this.clientPassword !== null) {
      const encodedCredentials = encodeBasicCredentials(this.clientId, this.clientPassword);
      request.headers.set("Authorization", `Basic ${encodedCredentials}`);
    }
    const tokens = await sendTokenRequest$1(request);
    return tokens;
  }
  async revokeToken(tokenRevocationEndpoint2, token) {
    const body = new URLSearchParams();
    body.set("token", token);
    if (this.clientPassword === null) {
      body.set("client_id", this.clientId);
    }
    const request = createOAuth2Request(tokenRevocationEndpoint2, body);
    if (this.clientPassword !== null) {
      const encodedCredentials = encodeBasicCredentials(this.clientId, this.clientPassword);
      request.headers.set("Authorization", `Basic ${encodedCredentials}`);
    }
    await sendTokenRevocationRequest(request);
  }
}
var CodeChallengeMethod;
(function(CodeChallengeMethod2) {
  CodeChallengeMethod2[CodeChallengeMethod2["S256"] = 0] = "S256";
  CodeChallengeMethod2[CodeChallengeMethod2["Plain"] = 1] = "Plain";
})(CodeChallengeMethod || (CodeChallengeMethod = {}));
var EncodingPadding$1;
(function(EncodingPadding2) {
  EncodingPadding2[EncodingPadding2["Include"] = 0] = "Include";
  EncodingPadding2[EncodingPadding2["None"] = 1] = "None";
})(EncodingPadding$1 || (EncodingPadding$1 = {}));
var DecodingPadding$1;
(function(DecodingPadding2) {
  DecodingPadding2[DecodingPadding2["Required"] = 0] = "Required";
  DecodingPadding2[DecodingPadding2["Ignore"] = 1] = "Ignore";
})(DecodingPadding$1 || (DecodingPadding$1 = {}));
var EncodingPadding;
(function(EncodingPadding2) {
  EncodingPadding2[EncodingPadding2["Include"] = 0] = "Include";
  EncodingPadding2[EncodingPadding2["None"] = 1] = "None";
})(EncodingPadding || (EncodingPadding = {}));
var DecodingPadding;
(function(DecodingPadding2) {
  DecodingPadding2[DecodingPadding2["Required"] = 0] = "Required";
  DecodingPadding2[DecodingPadding2["Ignore"] = 1] = "Ignore";
})(DecodingPadding || (DecodingPadding = {}));
const authorizationEndpoint$2 = "https://discord.com/oauth2/authorize";
const tokenEndpoint$2 = "https://discord.com/api/oauth2/token";
const tokenRevocationEndpoint$1 = "https://discord.com/api/oauth2/token/revoke";
class Discord {
  client;
  constructor(clientId, clientSecret, redirectURI) {
    this.client = new OAuth2Client(clientId, clientSecret, redirectURI);
  }
  createAuthorizationURL(state, codeVerifier, scopes) {
    let url;
    if (codeVerifier !== null) {
      url = this.client.createAuthorizationURLWithPKCE(authorizationEndpoint$2, state, CodeChallengeMethod.S256, codeVerifier, scopes);
    } else {
      url = this.client.createAuthorizationURL(authorizationEndpoint$2, state, scopes);
    }
    return url;
  }
  async validateAuthorizationCode(code, codeVerifier) {
    const tokens = await this.client.validateAuthorizationCode(tokenEndpoint$2, code, codeVerifier);
    return tokens;
  }
  async refreshAccessToken(refreshToken) {
    const tokens = await this.client.refreshAccessToken(tokenEndpoint$2, refreshToken, []);
    return tokens;
  }
  async revokeToken(token) {
    await this.client.revokeToken(tokenRevocationEndpoint$1, token);
  }
}
const authorizationEndpoint$1 = "https://github.com/login/oauth/authorize";
const tokenEndpoint$1 = "https://github.com/login/oauth/access_token";
class GitHub {
  clientId;
  clientSecret;
  redirectURI;
  constructor(clientId, clientSecret, redirectURI) {
    this.clientId = clientId;
    this.clientSecret = clientSecret;
    this.redirectURI = redirectURI;
  }
  createAuthorizationURL(state, scopes) {
    const url = new URL(authorizationEndpoint$1);
    url.searchParams.set("response_type", "code");
    url.searchParams.set("client_id", this.clientId);
    url.searchParams.set("state", state);
    if (scopes.length > 0) {
      url.searchParams.set("scope", scopes.join(" "));
    }
    if (this.redirectURI !== null) {
      url.searchParams.set("redirect_uri", this.redirectURI);
    }
    return url;
  }
  async validateAuthorizationCode(code) {
    const body = new URLSearchParams();
    body.set("grant_type", "authorization_code");
    body.set("code", code);
    if (this.redirectURI !== null) {
      body.set("redirect_uri", this.redirectURI);
    }
    const request = createOAuth2Request(tokenEndpoint$1, body);
    const encodedCredentials = encodeBasicCredentials(this.clientId, this.clientSecret);
    request.headers.set("Authorization", `Basic ${encodedCredentials}`);
    const tokens = await sendTokenRequest(request);
    return tokens;
  }
  async refreshAccessToken(refreshToken) {
    const body = new URLSearchParams();
    body.set("grant_type", "refresh_token");
    body.set("refresh_token", refreshToken);
    const request = createOAuth2Request(tokenEndpoint$1, body);
    const encodedCredentials = encodeBasicCredentials(this.clientId, this.clientSecret);
    request.headers.set("Authorization", `Basic ${encodedCredentials}`);
    const tokens = await sendTokenRequest(request);
    return tokens;
  }
}
async function sendTokenRequest(request) {
  let response;
  try {
    response = await fetch(request);
  } catch (e) {
    throw new ArcticFetchError(e);
  }
  if (response.status !== 200) {
    if (response.body !== null) {
      await response.body.cancel();
    }
    throw new UnexpectedResponseError(response.status);
  }
  let data;
  try {
    data = await response.json();
  } catch {
    throw new UnexpectedResponseError(response.status);
  }
  if (typeof data !== "object" || data === null) {
    throw new UnexpectedErrorResponseBodyError(response.status, data);
  }
  if ("error" in data && typeof data.error === "string") {
    let error;
    try {
      error = createOAuth2RequestError(data);
    } catch {
      throw new UnexpectedErrorResponseBodyError(response.status, data);
    }
    throw error;
  }
  const tokens = new OAuth2Tokens(data);
  return tokens;
}
const authorizationEndpoint = "https://accounts.google.com/o/oauth2/v2/auth";
const tokenEndpoint = "https://oauth2.googleapis.com/token";
const tokenRevocationEndpoint = "https://oauth2.googleapis.com/revoke";
class Google {
  client;
  constructor(clientId, clientSecret, redirectURI) {
    this.client = new OAuth2Client(clientId, clientSecret, redirectURI);
  }
  createAuthorizationURL(state, codeVerifier, scopes) {
    const url = this.client.createAuthorizationURLWithPKCE(authorizationEndpoint, state, CodeChallengeMethod.S256, codeVerifier, scopes);
    return url;
  }
  async validateAuthorizationCode(code, codeVerifier) {
    const tokens = await this.client.validateAuthorizationCode(tokenEndpoint, code, codeVerifier);
    return tokens;
  }
  async refreshAccessToken(refreshToken) {
    const tokens = await this.client.refreshAccessToken(tokenEndpoint, refreshToken, []);
    return tokens;
  }
  async revokeToken(token) {
    await this.client.revokeToken(tokenRevocationEndpoint, token);
  }
}
const getGithub = (env) => {
  const clientId = (env.GITHUB_CLIENT_ID ?? void 0)?.trim();
  const clientSecret = (env.GITHUB_CLIENT_SECRET ?? void 0)?.trim();
  const redirectUri = (env.GITHUB_REDIRECT_URI ?? void 0 ?? "http://localhost:4321/login/github/callback")?.trim();
  if (!clientId || !clientSecret) {
    throw new Error("Missing GITHUB_CLIENT_ID or GITHUB_CLIENT_SECRET");
  }
  return new GitHub(clientId, clientSecret, redirectUri);
};
const getGoogle = (env) => {
  const clientId = (env.GOOGLE_CLIENT_ID ?? void 0)?.trim();
  const clientSecret = (env.GOOGLE_CLIENT_SECRET ?? void 0)?.trim();
  const redirectUri = (env.GOOGLE_REDIRECT_URI ?? void 0 ?? "http://localhost:4321/login/google/callback")?.trim();
  if (!clientId || !clientSecret) {
    throw new Error("Missing GOOGLE_CLIENT_ID or GOOGLE_CLIENT_SECRET");
  }
  return new Google(clientId, clientSecret, redirectUri);
};
const getDiscord = (env) => {
  const clientId = (env.DISCORD_CLIENT_ID ?? void 0)?.trim();
  const clientSecret = (env.DISCORD_CLIENT_SECRET ?? void 0)?.trim();
  const redirectUri = (env.DISCORD_REDIRECT_URI ?? void 0 ?? "http://localhost:4321/login/discord/callback")?.trim();
  if (!clientId || !clientSecret) {
    throw new Error("Missing DISCORD_CLIENT_ID or DISCORD_CLIENT_SECRET");
  }
  return new Discord(clientId, clientSecret, redirectUri);
};
function sanitizeRedirectTarget(target, fallback = "/") {
  if (!target) return fallback;
  try {
    if (!target.startsWith("/") || target.startsWith("//")) {
      return fallback;
    }
    const url = new URL(target, "https://blog.ichimarugin728.com");
    if (url.origin !== "https://blog.ichimarugin728.com") {
      return fallback;
    }
    return `${url.pathname}${url.search}${url.hash}`;
  } catch {
    return fallback;
  }
}
export {
  generateState as a,
  generateCodeVerifier as b,
  getGithub as c,
  getGoogle as d,
  getDiscord as g,
  sanitizeRedirectTarget as s
};

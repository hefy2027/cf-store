globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { g as getDb, b as likes, a as and, e as eq } from "./db_XAr9wiDM.mjs";
const POST = async ({
  request,
  locals
}) => {
  const env$1 = env;
  const user = locals.user;
  if (!user) return new Response(JSON.stringify({
    error: "Unauthorized"
  }), {
    status: 401
  });
  try {
    const body = await request.json();
    const {
      commentId,
      value
    } = body;
    if (!commentId || value !== 0 && value !== 1) {
      return new Response(JSON.stringify({
        error: "commentId and value (0 or 1) are required"
      }), {
        status: 400
      });
    }
    const db = getDb(env$1);
    if (value === 0) {
      await db.delete(likes).where(and(eq(likes.userId, user.id), eq(likes.commentId, commentId)));
    } else {
      await db.insert(likes).values({
        userId: user.id,
        commentId,
        value: 1
      }).onConflictDoNothing();
    }
    return new Response(JSON.stringify({
      success: true
    }), {
      status: 200
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({
      error: "Server Error"
    }), {
      status: 500
    });
  }
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { g as getDb, u as users, e as eq } from "./db_XAr9wiDM.mjs";
import { g as getDiscord, s as sanitizeRedirectTarget } from "./redirect_BKbNLFHX.mjs";
import { v as validateSessionToken, g as generateSessionToken, c as createSession } from "./session_DWbC8nF0.mjs";
const GET = async ({
  request,
  cookies,
  redirect
}) => {
  const env$1 = env;
  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const storedState = cookies.get("discord_oauth_state")?.value ?? null;
  const codeVerifier = cookies.get("discord_code_verifier")?.value ?? null;
  if (!code || !state || !storedState || state !== storedState || !codeVerifier) {
    return new Response(null, {
      status: 400
    });
  }
  try {
    console.log("Validating Discord code...");
    const tokens = await getDiscord(env$1).validateAuthorizationCode(code, codeVerifier);
    const accessToken = tokens.accessToken();
    console.log("Tokens received:", accessToken ? "Present" : "Missing");
    let discordUser;
    try {
      console.log("Fetching Discord user...");
      const discordUserResponse = await fetch("https://discord.com/api/users/@me", {
        headers: {
          Authorization: `Bearer ${accessToken.trim()}`
        }
      });
      if (!discordUserResponse.ok) {
        const errorText = await discordUserResponse.text();
        throw new Error(`Discord API returned ${discordUserResponse.status}: ${errorText.slice(0, 200)}`);
      }
      discordUser = await discordUserResponse.json();
      console.log("Discord User fetched:", discordUser.username);
    } catch (fetchError) {
      throw new Error(`Failed to fetch Discord user: ${fetchError.message}`);
    }
    const db = getDb(env$1);
    const existingSessionToken = cookies.get("session")?.value;
    let currentUserId = null;
    if (existingSessionToken) {
      const sessionResult = await validateSessionToken(existingSessionToken, db, env$1);
      if (sessionResult.session && sessionResult.user) {
        currentUserId = sessionResult.user.id;
        console.log("User is already logged in, linking Discord account to user:", currentUserId);
      }
    }
    const existingUser = await db.select().from(users).where(eq(users.discordId, discordUser.id)).get();
    let userId = "";
    if (currentUserId) {
      if (existingUser && existingUser.id !== currentUserId) {
        throw new Error("This Discord account is already linked to another user account.");
      }
      await db.update(users).set({
        discordId: discordUser.id,
        discordUsername: discordUser.username,
        discordAvatar: `https://cdn.discordapp.com/avatars/${discordUser.id}/${discordUser.avatar}.png`
      }).where(eq(users.id, currentUserId));
      userId = currentUserId;
      console.log("Discord account linked to existing user:", userId);
    } else if (existingUser) {
      userId = existingUser.id;
      console.log("Logging in as existing Discord user:", userId);
    } else {
      userId = crypto.randomUUID();
      await db.insert(users).values({
        id: userId,
        discordId: discordUser.id,
        username: discordUser.username,
        avatar: `https://cdn.discordapp.com/avatars/${discordUser.id}/${discordUser.avatar}.png`,
        createdAt: Date.now(),
        discordUsername: discordUser.username,
        discordAvatar: `https://cdn.discordapp.com/avatars/${discordUser.id}/${discordUser.avatar}.png`
      });
      console.log("Created new user with Discord:", userId);
    }
    console.log("Creating session, userId:", userId);
    const token = generateSessionToken();
    const session = await createSession(token, userId, db, env$1, request);
    console.log("Setting session cookie...");
    cookies.set("session", token, {
      path: "/",
      httpOnly: true,
      sameSite: "lax",
      secure: true,
      expires: new Date(session.expiresAt)
    });
    const redirectUrl = sanitizeRedirectTarget(cookies.get("login_redirect")?.value);
    cookies.delete("discord_oauth_state", {
      path: "/"
    });
    cookies.delete("discord_code_verifier", {
      path: "/"
    });
    cookies.delete("login_redirect", {
      path: "/"
    });
    return redirect(redirectUrl);
  } catch (e) {
    console.error(e);
    cookies.delete("discord_oauth_state", {
      path: "/"
    });
    cookies.delete("discord_code_verifier", {
      path: "/"
    });
    cookies.delete("login_redirect", {
      path: "/"
    });
    return new Response("Login failed", {
      status: 500
    });
  }
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  GET
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

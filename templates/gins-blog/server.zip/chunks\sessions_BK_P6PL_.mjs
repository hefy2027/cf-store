globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { g as getDb, s as sessions } from "./db_XAr9wiDM.mjs";
const prerender = false;
const DELETE = async () => {
  const env$1 = env;
  const db = getDb(env$1);
  try {
    await db.delete(sessions);
    let cursor;
    let listComplete = false;
    while (!listComplete) {
      const list = await env$1.GIN_KV.list({
        prefix: "session:",
        cursor
      });
      if (list.keys.length > 0) {
        await Promise.all(list.keys.map((key) => env$1.GIN_KV.delete(key.name)));
      }
      listComplete = list.list_complete;
      cursor = list.cursor;
    }
    return new Response(JSON.stringify({
      success: true,
      message: "All sessions terminated."
    }), {
      status: 200
    });
  } catch (e) {
    console.error("Failed to terminate sessions:", e);
    return new Response(JSON.stringify({
      error: e.message
    }), {
      status: 500
    });
  }
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  DELETE,
  prerender
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

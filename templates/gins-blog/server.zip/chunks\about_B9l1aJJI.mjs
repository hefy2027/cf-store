globalThis.process ??= {};
globalThis.process.env ??= {};
import { g as getLangFromUrl, $ as $$Layout, r as renderScript, u as useTranslations } from "./Layout_B4Am03Vw.mjs";
import { c as createComponent } from "./astro-component_BvYacKii.mjs";
import { aj as renderTemplate, a6 as maybeRenderHead } from "./sequence_C6JDRbfE.mjs";
import { r as renderComponent } from "./worker-entry_CI_WUTHH.mjs";
import { env } from "cloudflare:workers";
import { $ as $$CloudflareImage, S as SocialLinks } from "./CloudflareImage_B0p4SY25.mjs";
const $$About = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$About;
  const env$1 = env;
  const cfAvatarId = env$1.PUBLIC_CF_AVATAR_ID;
  const lang = getLangFromUrl(Astro2.url);
  const t = useTranslations(lang);
  const socialLinks = [
    {
      label: "Threads",
      url: "https://www.threads.net/@ichimarugin728",
      icon: "i-simple-icons-threads"
    },
    {
      label: "Twitter",
      url: "https://twitter.com/IchimaruGin728",
      icon: "i-simple-icons-x"
    },
    {
      label: "Tiktok",
      url: "https://www.tiktok.com/@ichimarugin728",
      icon: "i-simple-icons-tiktok"
    },
    {
      label: "GitHub",
      url: "https://github.com/IchimaruGin728",
      icon: "i-simple-icons-github"
    }
  ];
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": `${t("nav.about")} - ${t("hero.title")}`, "data-astro-cid-kh7btl4r": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="flex flex-col items-center justify-center min-h-[60vh]" data-astro-cid-kh7btl4r> <div class="glass-panel p-12 rounded-[2rem] max-w-4xl w-full relative overflow-hidden group" data-astro-cid-kh7btl4r> <div class="absolute top-0 right-0 w-64 h-64 bg-brand-primary/20 blur-[100px] rounded-full -translate-y-1/2 translate-x-1/2 group-hover:bg-brand-primary/30 transition-all duration-700" data-astro-cid-kh7btl4r></div> <div class="relative z-10 flex flex-col md:flex-row items-center gap-8" data-astro-cid-kh7btl4r> <div class="relative" data-astro-cid-kh7btl4r> <div class="w-32 h-32 rounded-full p-1 bg-gradient-to-br from-brand-accent to-brand-primary avatar-protected overflow-hidden" data-astro-cid-kh7btl4r> ${cfAvatarId ? renderTemplate`${renderComponent($$result2, "CloudflareImage", $$CloudflareImage, { "imageId": cfAvatarId, "variant": "avatar", "alt": "Ichimaru Gin", "class": "w-full h-full rounded-full object-cover shadow-2xl shadow-brand-primary/50", "loading": "eager", "data-astro-cid-kh7btl4r": true })}` : renderTemplate`<div class="w-full h-full rounded-full bg-brand-primary/20 flex items-center justify-center" data-astro-cid-kh7btl4r> <span class="text-brand-accent font-bold text-xl uppercase" data-astro-cid-kh7btl4r>
Gin
</span> </div>`} </div> <div class="absolute bottom-1 right-1 w-6 h-6 bg-green-500 rounded-full border-4 border-black animate-pulse" title="Online" data-astro-cid-kh7btl4r></div> </div> <div class="text-center md:text-left" data-astro-cid-kh7btl4r> <h1 class="text-4xl font-display font-bold mb-2" data-astro-cid-kh7btl4r>Ichimaru Gin</h1> <div class="flex gap-2 justify-center md:justify-start mb-4" data-astro-cid-kh7btl4r> <span class="px-3 py-1 rounded-full bg-brand-primary/20 border border-brand-primary/30 text-xs font-mono text-brand-accent" data-astro-cid-kh7btl4r>${t("about.fullstack")}</span> <span class="px-3 py-1 rounded-full bg-brand-secondary/20 border border-brand-secondary/30 text-xs font-mono text-brand-secondary" data-astro-cid-kh7btl4r>${t("about.ai")}</span> </div> <p class="text-gray-300 leading-relaxed mb-6" data-astro-cid-kh7btl4r> ${t("about.description")} </p> ${renderComponent($$result2, "SocialLinks", SocialLinks, { "client:idle": true, "initialLinks": socialLinks, "client:component-hydration": "idle", "client:component-path": "D:/coding/claude/_ginsbuild/src/components/SocialLinks.tsx", "client:component-export": "default", "data-astro-cid-kh7btl4r": true })} </div> </div> </div> <div class="max-w-4xl w-full mt-24 px-4" data-astro-cid-kh7btl4r> <h2 class="text-2xl font-display font-bold text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-500" data-astro-cid-kh7btl4r> ${t("about.chronicle")} </h2> <div class="relative border-l border-white/10 ml-6 md:ml-12 space-y-12" data-astro-cid-kh7btl4r> <!-- Deno & JSR Migration --> <div class="relative pl-8 md:pl-12" data-astro-cid-kh7btl4r> <span class="absolute -left-[5px] top-2 w-2.5 h-2.5 rounded-full bg-blue-400 shadow-[0_0_10px_rgba(96,165,250,0.5)] animate-pulse" data-astro-cid-kh7btl4r></span> <div class="glass-panel p-6 rounded-2xl hover:bg-white/5 transition-colors group border border-blue-500/20" data-astro-cid-kh7btl4r> <span class="text-sm font-mono text-blue-400/70 mb-2 block" data-astro-cid-kh7btl4r>2026.03.06</span> <h3 class="text-lg font-bold text-white mb-2 group-hover:text-blue-400 transition-colors" data-astro-cid-kh7btl4r> ${t("chronicle.deno_jsr")} </h3> <p class="text-gray-400 text-sm leading-relaxed" data-astro-cid-kh7btl4r> ${t("chronicle.deno_jsr_desc")} </p> </div> </div> <!-- Media Bundle Integration --> <div class="relative pl-8 md:pl-12" data-astro-cid-kh7btl4r> <span class="absolute -left-[5px] top-2 w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.5)]" data-astro-cid-kh7btl4r></span> <div class="glass-panel p-6 rounded-2xl hover:bg-white/5 transition-colors group" data-astro-cid-kh7btl4r> <span class="text-sm font-mono text-cyan-400/70 mb-2 block" data-astro-cid-kh7btl4r>2026.02.27</span> <h3 class="text-lg font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors" data-astro-cid-kh7btl4r>
Edge-Native Media Architecture
</h3> <p class="text-gray-400 text-sm leading-relaxed" data-astro-cid-kh7btl4r>
Completely overhauled standard static hosting with Cloudflare's
              edge-native Images and Stream APIs. Replaced heavy Gravatar
              dependencies with zero-latency <code data-astro-cid-kh7btl4r>&lt;CloudflareImage /&gt;</code> and <code data-astro-cid-kh7btl4r>&lt;CloudflareVideo /&gt;</code> components, and built a
              dedicated Zero-Trust workspace to pipe uploads directly to the global
              edge network.
</p> </div> </div> <div class="relative pl-8 md:pl-12" data-astro-cid-kh7btl4r> <span class="absolute -left-[5px] top-2 w-2.5 h-2.5 rounded-full bg-purple-500 shadow-[0_0_10px_rgba(168,85,247,0.5)]" data-astro-cid-kh7btl4r></span> <div class="glass-panel p-6 rounded-2xl hover:bg-white/5 transition-colors group" data-astro-cid-kh7btl4r> <span class="text-sm font-mono text-purple-400/70 mb-2 block" data-astro-cid-kh7btl4r>2026.02.11</span> <h3 class="text-lg font-bold text-white mb-2 group-hover:text-purple-400 transition-colors" data-astro-cid-kh7btl4r> ${t("chronicle.mcp_agent")} </h3> <p class="text-gray-400 text-sm leading-relaxed" data-astro-cid-kh7btl4r> ${t("chronicle.mcp_agent_desc")} </p> </div> </div> <div class="relative pl-8 md:pl-12" data-astro-cid-kh7btl4r> <span class="absolute -left-[5px] top-2 w-2.5 h-2.5 rounded-full bg-orange-400 shadow-[0_0_10px_rgba(251,146,60,0.5)]" data-astro-cid-kh7btl4r></span> <div class="glass-panel p-6 rounded-2xl hover:bg-white/5 transition-colors group" data-astro-cid-kh7btl4r> <span class="text-sm font-mono text-orange-400/70 mb-2 block" data-astro-cid-kh7btl4r>2026.02.01</span> <h3 class="text-lg font-bold text-white mb-2 group-hover:text-orange-400 transition-colors" data-astro-cid-kh7btl4r> ${t("chronicle.biome_fmt")} </h3> <p class="text-gray-400 text-sm leading-relaxed" data-astro-cid-kh7btl4r> ${t("chronicle.biome_fmt_desc")} </p> </div> </div> <div class="relative pl-8 md:pl-12" data-astro-cid-kh7btl4r> <span class="absolute -left-[5px] top-2 w-2.5 h-2.5 rounded-full bg-brand-accent shadow-[0_0_10px_rgba(139,92,246,0.5)]" data-astro-cid-kh7btl4r></span> <div class="glass-panel p-6 rounded-2xl hover:bg-white/5 transition-colors group" data-astro-cid-kh7btl4r> <span class="text-sm font-mono text-brand-accent/70 mb-2 block" data-astro-cid-kh7btl4r>2026.01.27</span> <h3 class="text-lg font-bold text-white mb-2 group-hover:text-brand-accent transition-colors" data-astro-cid-kh7btl4r> ${t("chronicle.ai_search")} </h3> <p class="text-gray-400 text-sm leading-relaxed" data-astro-cid-kh7btl4r> ${t("chronicle.ai_search_desc")} </p> </div> </div> <div class="relative pl-8 md:pl-12" data-astro-cid-kh7btl4r> <span class="absolute -left-[5px] top-2 w-2.5 h-2.5 rounded-full bg-brand-secondary shadow-[0_0_10px_rgba(236,72,153,0.5)]" data-astro-cid-kh7btl4r></span> <div class="glass-panel p-6 rounded-2xl hover:bg-white/5 transition-colors group" data-astro-cid-kh7btl4r> <span class="text-sm font-mono text-brand-secondary/70 mb-2 block" data-astro-cid-kh7btl4r>2026.01.25</span> <h3 class="text-lg font-bold text-white mb-2 group-hover:text-brand-secondary transition-colors" data-astro-cid-kh7btl4r> ${t("chronicle.blog_launch")} </h3> <p class="text-gray-400 text-sm leading-relaxed" data-astro-cid-kh7btl4r> ${t("chronicle.blog_launch_desc")} </p> </div> </div> <div class="relative pl-8 md:pl-12" data-astro-cid-kh7btl4r> <span class="absolute -left-[5px] top-2 w-2.5 h-2.5 rounded-full bg-blue-500/50" data-astro-cid-kh7btl4r></span> <div class="glass-panel p-6 rounded-2xl hover:bg-white/5 transition-colors group" data-astro-cid-kh7btl4r> <span class="text-sm font-mono text-blue-400/70 mb-2 block" data-astro-cid-kh7btl4r>2024.09.23</span> <h3 class="text-lg font-bold text-white mb-2 group-hover:text-blue-400 transition-colors" data-astro-cid-kh7btl4r> ${t("chronicle.inception")} </h3> <p class="text-gray-400 text-sm leading-relaxed" data-astro-cid-kh7btl4r> ${t("chronicle.inception_desc")} </p> </div> </div> </div> </div> </div> ` })}  ${renderScript($$result, "D:/coding/claude/_ginsbuild/src/pages/about.astro?astro&type=script&index=0&lang.ts")}`;
}, "D:/coding/claude/_ginsbuild/src/pages/about.astro", void 0);
const $$file = "D:/coding/claude/_ginsbuild/src/pages/about.astro";
const $$url = "/about";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$About,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

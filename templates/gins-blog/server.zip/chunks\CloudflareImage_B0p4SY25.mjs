globalThis.process ??= {};
globalThis.process.env ??= {};
import { d, y, u } from "./jsxRuntime.module_Da5I1MgL.mjs";
import { c as createComponent } from "./astro-component_BvYacKii.mjs";
import { a6 as maybeRenderHead, aw as addAttribute, aj as renderTemplate } from "./sequence_C6JDRbfE.mjs";
import { env } from "cloudflare:workers";
const gravatarHash = "60eb98ab51a815a519feeca028e08573";
function SocialLinks({
  initialLinks
}) {
  const [links, setLinks] = d(initialLinks);
  y(() => {
    const fetchGravatar = async () => {
      try {
        const res = await fetch(`https://en.gravatar.com/${gravatarHash}.json`, {
          // Using no-cors might be needed if CORS is an issue, but standard fetch often works for simple GETs from browser
          // Gravatar supports JSONP or CORS usually. Let's try standard fetch first.
        });
        if (res.ok) {
          const data = await res.json();
          const entry = data.entry?.[0];
          if (!entry) return;
          const newLinks = [];
          const getServiceIcon = (service) => {
            const map = {
              github: "i-simple-icons-github",
              twitter: "i-simple-icons-x",
              facebook: "i-simple-icons-facebook",
              instagram: "i-simple-icons-instagram",
              linkedin: "i-simple-icons-linkedin",
              discord: "i-simple-icons-discord",
              youtube: "i-simple-icons-youtube",
              reddit: "i-simple-icons-reddit",
              medium: "i-simple-icons-medium",
              stackoverflow: "i-simple-icons-stackoverflow",
              twitch: "i-simple-icons-twitch",
              steam: "i-simple-icons-steam",
              telegram: "i-simple-icons-telegram"
            };
            return map[service] || "i-heroicons-link";
          };
          if (entry.accounts) {
            entry.accounts.forEach((acc) => {
              newLinks.push({
                label: acc.display || acc.username || acc.shortname || acc.url,
                url: acc.url,
                icon: getServiceIcon(acc.shortname || ""),
                color: "hover:text-white"
              });
            });
          }
          if (entry.urls) {
            entry.urls.forEach((link) => {
              let icon = "i-heroicons-globe-alt";
              const label = link.title;
              const url = link.value;
              if (url.includes("github.com")) icon = "i-simple-icons-github";
              else if (url.includes("twitter.com") || url.includes("x.com")) icon = "i-simple-icons-x";
              else if (url.includes("linkedin.com")) icon = "i-simple-icons-linkedin";
              else if (url.includes("threads.net")) icon = "i-simple-icons-threads";
              else if (url.includes("tiktok.com")) icon = "i-simple-icons-tiktok";
              newLinks.push({
                label,
                url,
                icon
              });
            });
          }
          if (newLinks.length > 0) {
            setLinks(newLinks);
          }
        }
      } catch (e) {
        console.error("Failed to fetch Gravatar profile client-side", e);
      }
    };
    fetchGravatar();
  }, []);
  return u("div", {
    class: "mt-8",
    children: [u("h3", {
      class: "text-[10px] font-mono font-bold text-gray-500 uppercase tracking-widest mb-4",
      children: "Connect"
    }), u("div", {
      class: "flex flex-wrap gap-3 justify-center md:justify-start",
      children: links.map((link) => u("a", {
        href: link.url,
        target: "_blank",
        rel: "noopener noreferrer",
        class: "group flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/10 transition-all hover:-translate-y-0.5",
        children: [u("span", {
          class: `${link.icon} text-sm group-hover:text-white transition-colors`
        }), u("span", {
          class: "text-xs font-bold text-gray-400 group-hover:text-white transition-colors",
          children: link.label
        })]
      }, link.url))
    })]
  });
}
const $$CloudflareImage = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$CloudflareImage;
  const {
    imageId,
    variant = "public",
    alt,
    width,
    height,
    class: className,
    loading = "lazy",
    fetchpriority = "auto"
  } = Astro2.props;
  const env$1 = env;
  const accountHash = env$1.CLOUDFLARE_ACCOUNT_HASH || process.env.CLOUDFLARE_ACCOUNT_HASH || "MISSING_HASH";
  const assetsDomain = env$1.PUBLIC_ASSETS_DOMAIN || process.env.PUBLIC_ASSETS_DOMAIN;
  let src;
  if (assetsDomain && imageId.includes("/")) {
    const params = [];
    if (width) params.push(`width=${width}`);
    if (height) params.push(`height=${height}`);
    if (variant === "avatar") params.push("fit=crop");
    params.push("format=auto");
    src = `https://${assetsDomain}/cdn-cgi/image/${params.join(",")}/${imageId}`;
  } else {
    src = `https://imagedelivery.net/${accountHash}/${imageId}/${variant}`;
  }
  return renderTemplate`${maybeRenderHead()}<img${addAttribute(src, "src")}${addAttribute(alt, "alt")}${addAttribute(width, "width")}${addAttribute(height, "height")}${addAttribute(className, "class")}${addAttribute(loading, "loading")}${addAttribute(fetchpriority, "fetchpriority")}>`;
}, "D:/coding/claude/_ginsbuild/src/components/CloudflareImage.astro", void 0);
export {
  $$CloudflareImage as $,
  SocialLinks as S
};

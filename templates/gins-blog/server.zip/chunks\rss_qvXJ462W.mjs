globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { g as getRssResponse } from "./index_DZDB2Acg.mjs";
import { g as getDb, p as posts, l as lte, f as desc } from "./db_XAr9wiDM.mjs";
async function GET(context) {
  const db = getDb(env);
  let blogPosts = [];
  try {
    blogPosts = await db.select().from(posts).where(lte(posts.publishedAt, Date.now())).orderBy(desc(posts.publishedAt)).all();
  } catch (error) {
    console.error("Failed to build ZH RSS feed:", error);
  }
  return getRssResponse({
    title: "Gin的博客",
    description: "全栈开发、技术探索与生活随笔。",
    site: context.site,
    items: blogPosts.map((post) => ({
      title: post.title,
      pubDate: new Date(post.publishedAt || post.createdAt),
      description: post.content ? `${post.content.substring(0, 200)}...` : "",
      link: `/zh/blog/${post.slug}`
    })),
    customData: `<language>zh</language>`
  });
}
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  GET
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

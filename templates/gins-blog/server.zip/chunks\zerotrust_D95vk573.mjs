globalThis.process ??= {};
globalThis.process.env ??= {};
function getZeroTrustUser(request) {
  const token = request.headers.get("Cf-Access-Jwt-Assertion");
  const email = request.headers.get("Cf-Access-Authenticated-User-Email");
  if (!token && !email) {
    return null;
  }
  return {
    email: email || "cf-access-user",
    id: "cf-access-user"
  };
}
export {
  getZeroTrustUser as g
};

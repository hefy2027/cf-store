globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { g as getDb, s as sessions, u as users } from "./db_XAr9wiDM.mjs";
const POST = async () => {
  const db = getDb(env);
  try {
    await db.delete(sessions);
    await db.delete(users);
    return new Response(JSON.stringify({
      success: true,
      message: "All users and sessions deleted successfully"
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error deleting users:", error);
    return new Response(JSON.stringify({
      error: "Failed to delete users",
      details: error.message
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

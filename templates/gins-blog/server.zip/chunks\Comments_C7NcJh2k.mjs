globalThis.process ??= {};
globalThis.process.env ??= {};
import { c as createComponent } from "./astro-component_BvYacKii.mjs";
import { aj as renderTemplate, bN as defineScriptVars, aw as addAttribute, a6 as maybeRenderHead } from "./sequence_C6JDRbfE.mjs";
import { d, y, u } from "./jsxRuntime.module_Da5I1MgL.mjs";
var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$ShareButtons = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$ShareButtons;
  const { url, title, description = "" } = Astro2.props;
  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title);
  const encodedText = encodeURIComponent(`${title} - ${description}`.trim());
  const shareUrls = {
    x: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`,
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
    telegram: `https://t.me/share/url?url=${encodedUrl}&text=${encodedTitle}`,
    whatsapp: `https://wa.me/?text=${encodedText}%20${encodedUrl}`,
    reddit: `https://reddit.com/submit?url=${encodedUrl}&title=${encodedTitle}`
  };
  return renderTemplate(_a || (_a = __template(["", '<div class="my-12 glass-panel rounded-2xl p-6 border border-white/10"> <h3 class="text-lg font-bold mb-4 text-gray-200">Share this post</h3> <div class="flex flex-wrap gap-3"> <!-- X (Twitter) --> <a', ' target="_blank" rel="noopener noreferrer" class="group relative flex items-center justify-center w-12 h-12 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-[#1DA1F2]/50 transition-all duration-300 hover:scale-110 active:scale-95" title="Share on X"> <svg class="w-5 h-5 text-gray-400 group-hover:text-[#1DA1F2] transition-colors" fill="currentColor" viewBox="0 0 24 24"> <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path> </svg> </a> <!-- Facebook --> <a', ' target="_blank" rel="noopener noreferrer" class="group relative flex items-center justify-center w-12 h-12 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-[#1877F2]/50 transition-all duration-300 hover:scale-110 active:scale-95" title="Share on Facebook"> <svg class="w-5 h-5 text-gray-400 group-hover:text-[#1877F2] transition-colors" fill="currentColor" viewBox="0 0 24 24"> <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"></path> </svg> </a> <!-- Telegram --> <a', ' target="_blank" rel="noopener noreferrer" class="group relative flex items-center justify-center w-12 h-12 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-[#0088cc]/50 transition-all duration-300 hover:scale-110 active:scale-95" title="Share on Telegram"> <svg class="w-5 h-5 text-gray-400 group-hover:text-[#0088cc] transition-colors" fill="currentColor" viewBox="0 0 24 24"> <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"></path> </svg> </a> <!-- WhatsApp --> <a', ' target="_blank" rel="noopener noreferrer" class="group relative flex items-center justify-center w-12 h-12 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-[#25D366]/50 transition-all duration-300 hover:scale-110 active:scale-95" title="Share on WhatsApp"> <svg class="w-5 h-5 text-gray-400 group-hover:text-[#25D366] transition-colors" fill="currentColor" viewBox="0 0 24 24"> <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"></path> </svg> </a> <!-- Reddit --> <a', ' target="_blank" rel="noopener noreferrer" class="group relative flex items-center justify-center w-12 h-12 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-[#FF4500]/50 transition-all duration-300 hover:scale-110 active:scale-95" title="Share on Reddit"> <svg class="w-5 h-5 text-gray-400 group-hover:text-[#FF4500] transition-colors" fill="currentColor" viewBox="0 0 24 24"> <path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.35.35 0 0 1 .238-.042l2.906.617a1.214 1.214 0 0 1 1.108-.701zM9.25 12C8.561 12 8 12.562 8 13.25c0 .687.561 1.248 1.25 1.248.687 0 1.248-.561 1.248-1.249 0-.688-.561-1.249-1.249-1.249zm5.5 0c-.687 0-1.248.561-1.248 1.25 0 .687.561 1.248 1.249 1.248.688 0 1.249-.561 1.249-1.249 0-.687-.562-1.249-1.25-1.249zm-5.466 3.99a.327.327 0 0 0-.231.094.33.33 0 0 0 0 .463c.842.842 2.484.913 2.961.913.477 0 2.105-.056 2.961-.913a.361.361 0 0 0 .029-.463.33.33 0 0 0-.464 0c-.547.533-1.684.73-2.512.73-.828 0-1.979-.196-2.512-.73a.326.326 0 0 0-.232-.095z"></path> </svg> </a> <!-- Discord (Copy Link) --> <button id="share-discord" class="group relative flex items-center justify-center w-12 h-12 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-[#5865F2]/50 transition-all duration-300 hover:scale-110 active:scale-95" title="Copy link for Discord"> <svg class="w-5 h-5 text-gray-400 group-hover:text-[#5865F2] transition-colors" fill="currentColor" viewBox="0 0 24 24"> <path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z"></path> </svg> </button> <!-- WeChat (Copy Link with QR) --> <button id="share-wechat" class="group relative flex items-center justify-center w-12 h-12 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-[#09B83E]/50 transition-all duration-300 hover:scale-110 active:scale-95" title="Copy link for WeChat"> <svg class="w-5 h-5 text-gray-400 group-hover:text-[#09B83E] transition-colors" fill="currentColor" viewBox="0 0 24 24"> <path d="M16.5 14.5c0-3.03-3.13-5.5-7-5.5s-7 2.47-7 5.5c0 1.63.92 3.09 2.42 4.09.28.18.36.56.23.86l-.68 1.83a.47.47 0 0 0 .61.59l2.12-.66c.15-.05.31-.03.46.04.59.27 1.22.42 1.87.42.09 0 .19 0 .28-.01-.06-.32-.1-.66-.1-1 0-3.59 3.06-6.5 6.79-6.16zM15 16.5a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3-6.5c4.14 0 7.5 2.69 7.5 6s-3.36 6-7.5 6c-.7 0-1.37-.07-2.01-.21-.16-.03-.33-.02-.49.03l-2.28.71a.5.5 0 0 1-.64-.62l.73-1.95c.13-.34.04-.73-.24-.95-1.57-1.2-2.57-2.91-2.57-4.8 0-3.31 3.36-6 7.5-6zm-1.5 5a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm4 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"></path> </svg> </button> <!-- Copy Link --> <button id="share-copy" class="group relative flex items-center gap-2 px-4 h-12 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-brand-accent/50 transition-all duration-300 hover:scale-105 active:scale-95" title="Copy link"> <svg class="w-5 h-5 text-gray-400 group-hover:text-brand-accent transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path> </svg> <span class="text-xs font-medium text-gray-400 group-hover:text-brand-accent transition-colors">Copy</span> </button> </div> <!-- Toast notification --> <div id="copy-toast" class="hidden fixed bottom-24 left-1/2 -translate-x-1/2 px-4 py-2 bg-brand-accent/90 text-white text-sm rounded-lg shadow-lg backdrop-blur-sm z-50 animate-[slideUp_0.3s_ease-out]">\n✓ Link copied to clipboard!\n</div> </div> <script>(function(){', '\n  function copyToClipboard() {\n    navigator.clipboard.writeText(url).then(() => {\n      const toast = document.getElementById("copy-toast");\n      if (toast) {\n        toast.classList.remove("hidden");\n        setTimeout(() => {\n          toast.classList.add("hidden");\n        }, 2000);\n      }\n    });\n  }\n\n  // Copy link button\n  const copyBtn = document.getElementById("share-copy");\n  if (copyBtn) {\n    copyBtn.addEventListener("click", copyToClipboard);\n  }\n\n  // Discord (copy link)\n  const discordBtn = document.getElementById("share-discord");\n  if (discordBtn) {\n    discordBtn.addEventListener("click", copyToClipboard);\n  }\n\n  // WeChat (copy link)\n  const wechatBtn = document.getElementById("share-wechat");\n  if (wechatBtn) {\n    wechatBtn.addEventListener("click", copyToClipboard);\n  }\n})();<\/script>'])), maybeRenderHead(), addAttribute(shareUrls.x, "href"), addAttribute(shareUrls.facebook, "href"), addAttribute(shareUrls.telegram, "href"), addAttribute(shareUrls.whatsapp, "href"), addAttribute(shareUrls.reddit, "href"), defineScriptVars({ url }));
}, "D:/coding/claude/_ginsbuild/src/components/ShareButtons.astro", void 0);
const messages = {
  "en-SG": {
    title: "Transmissions",
    loginToLike: "Please login to like",
    placeholder: "Broadcast a response...",
    sending: "Sending...",
    submit: "Transmit",
    loginPrompt: "Identify yourself to join the frequency.",
    loginButton: "Login to Comment",
    loading: "Scanning frequencies..."
  },
  zh: {
    title: "评论",
    loginToLike: "请先登录后点赞",
    placeholder: "写点什么吧...",
    sending: "发送中...",
    submit: "发送",
    loginPrompt: "登录后即可参与评论。",
    loginButton: "登录后评论",
    loading: "正在加载评论..."
  }
};
function Comments({
  postId,
  lang = "en-SG",
  currentUser
}) {
  const [comments, setComments] = d([]);
  const [loading, setLoading] = d(true);
  const [newComment, setNewComment] = d("");
  const [submitting, setSubmitting] = d(false);
  const copy = messages[lang];
  y(() => {
    fetchComments();
  }, [postId]);
  async function fetchComments() {
    try {
      const res = await fetch(`/api/comments?postId=${postId}`);
      const data = await res.json();
      setComments(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }
  async function handleSubmit(e) {
    e.preventDefault();
    if (!newComment.trim()) return;
    setSubmitting(true);
    try {
      const res = await fetch("/api/comments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          postId,
          content: newComment
        })
      });
      if (res.ok) {
        setNewComment("");
        fetchComments();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  }
  async function handleLike(commentId, currentLiked) {
    if (!currentUser) return alert(copy.loginToLike);
    setComments(comments.map((c) => {
      if (c.id === commentId) {
        return {
          ...c,
          likes: currentLiked ? c.likes - 1 : c.likes + 1,
          likedByUser: !currentLiked
        };
      }
      return c;
    }));
    try {
      await fetch("/api/likes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          commentId,
          value: currentLiked ? 0 : 1
        })
        // 0 to remove like (simplified logic)
      });
    } catch (err) {
      console.error(err);
      fetchComments();
    }
  }
  return u("div", {
    class: "mt-12 border-t border-white/10 pt-8",
    children: [u("h3", {
      class: "text-2xl font-bold font-display mb-6",
      children: [copy.title, " (", comments.length, ")"]
    }), currentUser ? u("form", {
      onSubmit: handleSubmit,
      class: "mb-8",
      children: u("div", {
        class: "flex gap-4",
        children: [u("img", {
          src: currentUser.avatar || `https://ui-avatars.com/api/?name=${currentUser.username}`,
          alt: `${currentUser.username} avatar`,
          class: "w-10 h-10 rounded-full border border-white/10"
        }), u("div", {
          class: "flex-1",
          children: [u("textarea", {
            value: newComment,
            onInput: (e) => setNewComment(e.target.value),
            class: "w-full bg-black/40 border border-white/10 rounded-xl p-4 focus:outline-none focus:border-brand-accent text-white resize-none",
            rows: 3,
            placeholder: copy.placeholder
          }), u("div", {
            class: "flex justify-end mt-2",
            children: u("button", {
              type: "submit",
              disabled: submitting || !newComment.trim(),
              class: "px-6 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold text-sm transition-colors disabled:opacity-50",
              children: submitting ? copy.sending : copy.submit
            })
          })]
        })]
      })
    }) : u("div", {
      class: "bg-white/5 rounded-xl p-6 text-center mb-8",
      children: [u("p", {
        class: "text-gray-400 mb-4",
        children: copy.loginPrompt
      }), u("a", {
        href: lang === "zh" ? "/zh/login" : "/login",
        class: "px-6 py-2 rounded-full bg-white text-black font-bold text-sm hover:bg-gray-200 transition-colors",
        children: copy.loginButton
      })]
    }), loading ? u("div", {
      class: "text-center text-gray-500 py-8",
      children: copy.loading
    }) : u("div", {
      class: "space-y-6",
      children: comments.map((comment) => u("div", {
        class: "group animate-fade-in",
        children: u("div", {
          class: "flex gap-4",
          children: [u("div", {
            class: "shrink-0",
            children: u("img", {
              src: comment.user.avatar || `https://ui-avatars.com/api/?name=${comment.user.username}`,
              alt: `${comment.user.username} avatar`,
              class: "w-10 h-10 rounded-full border border-white/10"
            })
          }), u("div", {
            class: "flex-1",
            children: [u("div", {
              class: "flex items-center gap-2 mb-1",
              children: [u("span", {
                class: "font-bold text-white text-sm",
                children: comment.user.username
              }), u("span", {
                class: "text-xs text-gray-500",
                children: new Date(comment.createdAt).toLocaleDateString()
              })]
            }), u("div", {
              class: "text-gray-300 text-sm leading-relaxed mb-2",
              children: comment.content
            }), u("div", {
              class: "flex items-center gap-4",
              children: u("button", {
                type: "button",
                onClick: () => handleLike(comment.id, comment.likedByUser),
                class: `flex items-center gap-1 text-xs font-bold transition-colors ${comment.likedByUser ? "text-pink-500" : "text-gray-500 hover:text-white"}`,
                children: [u("span", {
                  class: comment.likedByUser ? "i-heroicons-heart-solid" : "i-heroicons-heart"
                }), comment.likes]
              })
            })]
          })]
        })
      }, comment.id))
    })]
  });
}
export {
  $$ShareButtons as $,
  Comments as C
};

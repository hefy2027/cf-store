globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { g as getDb, u as users, e as eq } from "./db_XAr9wiDM.mjs";
const POST = async ({
  locals,
  request
}) => {
  const env$1 = env;
  const user = locals.user;
  if (!user) {
    return new Response(JSON.stringify({
      error: "Unauthorized"
    }), {
      status: 401,
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
  const db = getDb(env$1);
  try {
    const body = await request.json();
    const {
      provider
    } = body;
    const currentUser = await db.select().from(users).where(eq(users.id, user.id)).get();
    if (!currentUser) {
      return new Response(JSON.stringify({
        error: "User not found"
      }), {
        status: 404,
        headers: {
          "Content-Type": "application/json"
        }
      });
    }
    let newUsername = currentUser.username;
    let newAvatar = currentUser.avatar;
    switch (provider) {
      case "github":
        if (!currentUser.githubUsername) {
          return new Response(JSON.stringify({
            error: "GitHub account not linked"
          }), {
            status: 400,
            headers: {
              "Content-Type": "application/json"
            }
          });
        }
        newUsername = currentUser.githubUsername;
        newAvatar = currentUser.githubAvatar;
        break;
      case "google":
        if (!currentUser.googleUsername) {
          return new Response(JSON.stringify({
            error: "Google account not linked"
          }), {
            status: 400,
            headers: {
              "Content-Type": "application/json"
            }
          });
        }
        newUsername = currentUser.googleUsername;
        newAvatar = currentUser.googleAvatar;
        break;
      case "discord":
        if (!currentUser.discordUsername) {
          return new Response(JSON.stringify({
            error: "Discord account not linked"
          }), {
            status: 400,
            headers: {
              "Content-Type": "application/json"
            }
          });
        }
        newUsername = currentUser.discordUsername;
        newAvatar = currentUser.discordAvatar;
        break;
      case "custom":
        return new Response(JSON.stringify({
          success: true,
          message: "Switched to custom mode. You can now edit your profile manually.",
          username: newUsername,
          avatar: newAvatar
        }), {
          status: 200,
          headers: {
            "Content-Type": "application/json"
          }
        });
    }
    await db.update(users).set({
      username: newUsername,
      avatar: newAvatar
    }).where(eq(users.id, user.id));
    return new Response(JSON.stringify({
      success: true,
      username: newUsername,
      avatar: newAvatar
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Error switching provider info:", error);
    return new Response(JSON.stringify({
      error: "Failed to switch provider info",
      details: error.message
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

globalThis.process ??= {};
globalThis.process.env ??= {};
import { $ as $$Layout } from "./Layout_B4Am03Vw.mjs";
import { c as createComponent } from "./astro-component_BvYacKii.mjs";
import { a6 as maybeRenderHead, aw as addAttribute, aj as renderTemplate } from "./sequence_C6JDRbfE.mjs";
import { r as renderComponent } from "./worker-entry_CI_WUTHH.mjs";
import { g as getCollection, $ as $$DocsFeatureCard } from "./_astro_content_uaURmYnY.mjs";
const $$DocsSidebarZh = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$DocsSidebarZh;
  const docsZh = (await getCollection("docsZh")).sort((a, b) => {
    const orderA = a.data.order ?? 999;
    const orderB = b.data.order ?? 999;
    if (orderA !== orderB) {
      return orderA - orderB;
    }
    return a.data.title.localeCompare(b.data.title);
  });
  return renderTemplate`${maybeRenderHead()}<div class="pr-6"> <h2 class="text-xs font-bold text-brand-accent uppercase tracking-widest mb-4 font-mono">
官方文档
</h2> <nav class="space-y-1"> ${docsZh.map((doc) => {
    const routeSlug = doc.id.replace(/^docs-zh\//, "");
    const href = `/zh/docs/${routeSlug === "index" ? "" : routeSlug}`;
    const isActive = Astro2.url.pathname.replace(/\/$/, "") === href.replace(/\/$/, "");
    return renderTemplate`<a${addAttribute(href, "href")}${addAttribute([
      "block px-3 py-2 rounded-lg text-sm transition-all duration-200",
      isActive ? "bg-brand-primary/20 text-brand-accent font-bold border-l-2 border-brand-accent" : "text-gray-400 hover:bg-white/5 hover:text-white border-l-2 border-transparent"
    ], "class:list")}> ${doc.data.title} </a>`;
  })} </nav> <div class="mt-8 pt-8 border-t border-white/10"> <h2 class="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4 font-mono">
相关资源
</h2> <nav class="space-y-2"> <a href="https://github.com/IchimaruGin728" target="_blank" rel="noopener noreferrer" class="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors"> <span class="i-simple-icons-github text-lg"></span>
GitHub
</a> <a href="https://x.com/IchimaruGin728" target="_blank" rel="noopener noreferrer" class="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors"> <span class="i-simple-icons-x text-lg"></span>
Twitter
</a> </nav> </div> </div>`;
}, "D:/coding/claude/_ginsbuild/src/components/DocsSidebarZh.astro", void 0);
const $$Index = createComponent(($$result, $$props, $$slots) => {
  const features = [
    {
      title: "边缘原生渲染",
      items: [
        "告别传统服务器的冷启动延迟",
        "在离用户最近的边缘节点完成页面渲染",
        "基于 Cloudflare Workers 构建的分布式架构"
      ],
      icon: "i-heroicons-globe-alt",
      color: "from-blue-500/20 to-cyan-500/20",
      iconColor: "text-cyan-400"
    },
    {
      title: "动态拟态视觉",
      items: [
        "利用 GPU 硬件加速的玻璃拟态组件",
        "跟随鼠标轨迹的 3D 悬浮交互反馈",
        "结合原生 API 实现的平滑路由过渡"
      ],
      icon: "i-heroicons-sparkles",
      color: "from-purple-500/20 to-pink-500/20",
      iconColor: "text-pink-400"
    },
    {
      title: "内置零信任保护",
      items: [
        "基于 Cloudflare Access 构建身份验证网关",
        "原生无缝支持 WebAuthn 与 Passkey 登录",
        "在边缘层自动替你拦截恶意扫描与异常请求"
      ],
      icon: "i-heroicons-shield-check",
      color: "from-emerald-500/20 to-green-500/20",
      iconColor: "text-emerald-400"
    },
    {
      title: "Serverless 数据库",
      items: [
        "摆脱传统 TCP 数据库连接池的并发限制",
        "基于 Cloudflare D1 分布式 SQLite 引擎",
        "搭配 Drizzle ORM 构建端到端的类型安全"
      ],
      icon: "i-heroicons-circle-stack",
      color: "from-orange-500/20 to-amber-500/20",
      iconColor: "text-orange-400"
    },
    {
      title: "原生 AI 集成",
      items: [
        "依托边缘算力实现低延迟的语义向量检索",
        "无缝连接大语言模型，构建知识问答体系",
        "预留 MCP 协议接口以支持 Agent 智能体"
      ],
      icon: "i-heroicons-cpu-chip",
      color: "from-indigo-500/20 to-violet-500/20",
      iconColor: "text-indigo-400"
    },
    {
      title: "轻量化边缘 API",
      items: [
        "采用 Hono 框架打造低内存占用的驱动核心",
        "通过 Zod 在请求入口处完成严格的数据校验",
        "提供统一类型定义的 RPC 前后端调用接口"
      ],
      icon: "i-heroicons-bolt",
      color: "from-yellow-500/20 to-lime-500/20",
      iconColor: "text-yellow-400"
    }
  ];
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "文档中心" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="flex gap-8"> <aside class="hidden md:block w-64 shrink-0 overflow-y-auto sticky top-32 max-h-[calc(100vh-10rem)]"> ${renderComponent($$result2, "DocsSidebarZh", $$DocsSidebarZh, {})} </aside> <article class="flex-1 min-w-0 main-content"> <div class="glass-panel p-6 md:p-10 rounded-3xl mb-8"> <div class="mb-12"> <div class="inline-block px-4 py-1.5 rounded-full bg-brand-primary/10 text-brand-accent font-mono text-xs font-bold mb-6 border border-brand-primary/30 shadow-[0_0_15px_rgba(88,28,135,0.5)]">
v1.0.0 NUCLEUS
</div> <h1 class="text-2xl md:text-4xl font-display font-bold mb-6 tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-gray-200 to-gray-500">
Gins-Blog 内核架构
</h1> <p class="text-lg text-gray-400 max-w-2xl leading-relaxed">
除了阅读代码，您也可以在这里了解 Gins-Blog 背后的边缘计算架构、部署规范，以及我在开发过程中的实践经验。
</p> </div> <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"> ${features.map((feature) => renderTemplate`<a href="/zh/docs/introduction" class="block h-full"> ${renderComponent($$result2, "DocsFeatureCard", $$DocsFeatureCard, { "title": feature.title, "items": feature.items, "icon": feature.icon, "color": feature.color, "iconColor": feature.iconColor })} </a>`)} </div> <div class="mt-16 pt-12 border-t border-white/10 flex flex-col md:flex-row gap-6 items-center justify-between"> <div> <h3 class="text-xl font-bold font-display mb-2">准备好部署了吗？</h3> <p class="text-gray-400 text-sm">
通过我提供的自动化脚本，您可以轻松在自己的 Cloudflare 账户中拉起一套完整的基础设施。
</p> </div> <a href="/zh/docs/deployment" class="px-8 py-4 rounded-xl bg-white text-black font-bold flex items-center gap-2 hover:bg-gray-200 transition-all hover:scale-105 shadow-[0_0_20px_rgba(255,255,255,0.2)]">
使用引导脚本 <span class="i-heroicons-arrow-right"></span> </a> </div> </div> </article> </div> ` })}`;
}, "D:/coding/claude/_ginsbuild/src/pages/zh/docs/index.astro", void 0);
const $$file = "D:/coding/claude/_ginsbuild/src/pages/zh/docs/index.astro";
const $$url = "/zh/docs";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { g as getDb, p as posts } from "./db_XAr9wiDM.mjs";
const POST = async () => {
  const env$1 = env;
  const db = getDb(env$1);
  const allPosts = await db.select().from(posts).all();
  let indexedCount = 0;
  const errors = [];
  for (const post of allPosts) {
    try {
      const textToEmbed = `Title: ${post.title}

Content: ${post.content.slice(0, 1500)}`;
      const embeddingResponse = await env$1.AI.run("@cf/baai/bge-base-en-v1.5", {
        text: [textToEmbed]
      });
      const embedding = embeddingResponse.data[0];
      await env$1.VECTOR_INDEX.upsert([{
        id: post.id,
        values: embedding,
        metadata: {
          title: post.title,
          slug: post.slug,
          publishedAt: post.publishedAt?.toString() || ""
        }
      }]);
      indexedCount++;
    } catch (e) {
      console.error(`Failed to index post ${post.slug}`, e);
      errors.push({
        slug: post.slug,
        error: e.message || String(e),
        stack: e.stack
      });
    }
  }
  return new Response(JSON.stringify({
    success: true,
    indexed: indexedCount,
    total: allPosts.length,
    errors
  }), {
    headers: {
      "Content-Type": "application/json"
    }
  });
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

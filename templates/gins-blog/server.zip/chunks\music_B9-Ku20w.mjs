globalThis.process ??= {};
globalThis.process.env ??= {};
import { $ as $$Layout, r as renderScript } from "./Layout_B4Am03Vw.mjs";
import { c as createComponent } from "./astro-component_BvYacKii.mjs";
import { aj as renderTemplate, a6 as maybeRenderHead } from "./sequence_C6JDRbfE.mjs";
import { r as renderComponent } from "./worker-entry_CI_WUTHH.mjs";
const $$Music = createComponent(async ($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Music Manager - Ichimaru Gin" }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="max-w-7xl mx-auto"> <!-- Header --> <header class="mb-12 flex justify-between items-center"> <div> <h1 class="text-4xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
Music Manager
</h1> <p class="text-purple-300/60 mt-2">
Curate the sonic atmosphere of your digital space.
</p> </div> <a href="/IchimaruGin728/admin" class="px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 transition-colors text-sm flex items-center gap-2"> <span class="i-heroicons-arrow-left"></span>
Back to Dashboard
</a> </header> <div class="grid grid-cols-1 lg:grid-cols-3 gap-8"> <!-- Upload Column --> <div class="lg:col-span-2 glass-panel p-8 rounded-3xl border border-white/5"> <div class="flex items-center gap-3 mb-6"> <div class="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center text-purple-400"> <span class="i-heroicons-plus text-lg"></span> </div> <h2 class="text-xl font-bold text-white">New Track Upload</h2> </div> <form id="music-upload-form" class="space-y-6"> <div class="grid grid-cols-2 gap-6"> <div> <label class="block text-xs font-bold text-purple-300/50 mb-2 uppercase tracking-widest">Track Title</label> <input type="text" name="title" placeholder="e.g. Neon Nights" required class="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-purple-500 transition-colors text-white"> </div> <div> <label class="block text-xs font-bold text-purple-300/50 mb-2 uppercase tracking-widest">Artist</label> <input type="text" name="artist" placeholder="e.g. Synthwave Boy" required class="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-purple-500 transition-colors text-white"> </div> </div> <!-- Audio Dropzone --> <div> <label class="block text-xs font-bold text-purple-300/50 mb-2 uppercase tracking-widest">Audio File (MP3, WAV, FLAC, AAC, Dolby)</label> <div id="audio-dropzone" class="border-2 border-dashed border-white/10 rounded-2xl p-8 flex flex-col items-center justify-center gap-4 hover:border-purple-500/50 hover:bg-white/5 transition-all cursor-pointer group h-40"> <input type="file" name="audio" id="audio-input" accept="audio/*, .flac, .wav, .aac, .alac, .m4a, .ac3, .ec3, .mp3" class="hidden" required> <div class="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center group-hover:scale-110 transition-transform"> <span class="i-heroicons-musical-note text-2xl text-gray-400 group-hover:text-purple-400"></span> </div> <p class="text-sm text-gray-400 group-hover:text-white transition-colors">
Drag & Drop or Click to Select MP3
</p> <p id="audio-filename" class="text-xs text-purple-400 font-mono hidden"></p> </div> </div> <!-- Cover Art --> <div> <label class="block text-xs font-bold text-purple-300/50 mb-2 uppercase tracking-widest">Cover Art (Optional)</label> <div id="cover-dropzone" class="border border-white/10 rounded-xl p-4 flex items-center gap-4 hover:bg-white/5 transition-colors cursor-pointer"> <input type="file" name="cover" id="cover-input" accept="image/*" class="hidden"> <div class="w-12 h-12 rounded-lg bg-black/50 border border-white/10 flex items-center justify-center overflow-hidden"> <span class="i-heroicons-photo text-gray-400" id="cover-icon"></span> <img id="cover-preview" class="w-full h-full object-cover hidden"> </div> <span class="text-sm text-gray-400" id="cover-text">Select cover image...</span> </div> </div> <!-- Submit --> <button type="submit" id="submit-btn" class="w-full py-4 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:opacity-90 text-white font-bold tracking-wider transition-all shadow-lg shadow-purple-900/20 flex items-center justify-center gap-2"> <span class="i-heroicons-arrow-up-tray"></span>
Upload to Global Playlist
</button> <div id="status" class="hidden p-3 rounded-lg text-center text-sm"></div> </form> </div> <!-- Playlist Column (Live) --> <div class="glass-panel p-6 rounded-3xl border border-white/5 flex flex-col h-full min-h-[400px]"> <div class="flex items-center justify-between mb-6"> <div class="flex items-center gap-2"> <span class="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span> <h2 class="text-lg font-bold text-white">Live Playlist</h2> </div> <button id="refresh-btn" class="text-gray-400 hover:text-white transition-colors"> <span class="i-heroicons-arrow-path"></span> </button> </div> <!-- Track List --> <div id="track-list" class="flex-1 overflow-y-auto space-y-3 pr-2"> <div class="h-full flex flex-col items-center justify-center text-gray-500/50 gap-4"> <div class="w-8 h-8 border-2 border-purple-500/30 border-t-purple-500 rounded-full animate-spin"></div> <span class="text-xs tracking-widest uppercase">Syncing...</span> </div> </div> </div> </div> </div> ` })} ${renderScript($$result, "D:/coding/claude/_ginsbuild/src/pages/IchimaruGin728/admin/music.astro?astro&type=script&index=0&lang.ts")}`;
}, "D:/coding/claude/_ginsbuild/src/pages/IchimaruGin728/admin/music.astro", void 0);
const $$file = "D:/coding/claude/_ginsbuild/src/pages/IchimaruGin728/admin/music.astro";
const $$url = "/IchimaruGin728/admin/music";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$Music,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

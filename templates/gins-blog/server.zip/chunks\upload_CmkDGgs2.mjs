globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { b as validateGenericUpload, s as sanitizeFilename } from "./uploads_DmsrrkgO.mjs";
import { g as getZeroTrustUser } from "./zerotrust_D95vk573.mjs";
const PUT = async ({
  request
}) => {
  if (!getZeroTrustUser(request)) {
    return new Response("Forbidden", {
      status: 403
    });
  }
  const env$1 = env;
  const url = new URL(request.url);
  const filename = url.searchParams.get("filename");
  if (!filename) {
    return new Response("Missing filename", {
      status: 400
    });
  }
  const validationError = validateGenericUpload(filename, request.headers.get("Content-Type"), request.headers.get("Content-Length"));
  if (validationError) {
    return new Response(validationError, {
      status: 400
    });
  }
  try {
    const safeFilename = sanitizeFilename(filename);
    if (!safeFilename) {
      return new Response("Invalid filename", {
        status: 400
      });
    }
    const uniqueFilename = `${Date.now()}-${safeFilename}`;
    if (!request.body) {
      return new Response("Missing request body", {
        status: 400
      });
    }
    await env$1.BUCKET.put(uniqueFilename, request.body);
    return new Response(JSON.stringify({
      success: true,
      key: uniqueFilename,
      // Should be replaced with actual R2 Public URL or Worker route
      url: `/cdn/${uniqueFilename}`
    }), {
      headers: {
        "Content-Type": "application/json"
      }
    });
  } catch (e) {
    console.error(e);
    return new Response("Upload failed", {
      status: 500
    });
  }
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  PUT
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

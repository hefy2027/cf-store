globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { g as getDb, p as posts } from "./db_XAr9wiDM.mjs";
function slugify(text) {
  return text.toString().toLowerCase().trim().replace(/\s+/g, "-").replace(/[^\w-]+/g, "").replace(/--+/g, "-");
}
function parseFrontmatter(content) {
  const frontmatterRegex = /^---\n([\s\S]*?)\n---/;
  const match = content.match(frontmatterRegex);
  if (!match) {
    return {
      frontmatter: {},
      body: content
    };
  }
  const frontmatterBlock = match[1];
  const body = content.replace(match[0], "").trim();
  const frontmatter = {};
  frontmatterBlock.split("\n").forEach((line) => {
    const [key, ...valueParts] = line.split(":");
    if (key && valueParts.length) {
      frontmatter[key.trim()] = valueParts.join(":").trim().replace(/^['"](.*)['"]$/, "$1");
    }
  });
  return {
    frontmatter,
    body
  };
}
function parseRTF(content) {
  return content.replace(/\\par[d]?/g, "\n").replace(/\{.*?\}/g, "").replace(/\\[a-z]+-?[0-9]* ?/g, "").trim();
}
const POST = async ({
  request,
  locals
}) => {
  const env$1 = env;
  if (!locals.user) {
    return new Response(JSON.stringify({
      error: "Unauthorized"
    }), {
      status: 401
    });
  }
  try {
    const formData = await request.formData();
    const file = formData.get("file");
    if (!file) {
      return new Response(JSON.stringify({
        error: "No file provided"
      }), {
        status: 400
      });
    }
    const text = await file.text();
    const filename = file.name;
    const extension = filename.split(".").pop()?.toLowerCase();
    let title = filename.replace(/\.(md|markdown|rtf|txt)$/i, "");
    let slug = slugify(title);
    let content = text;
    let publishedAt = Date.now();
    if (extension === "md" || extension === "markdown") {
      const parsed = parseFrontmatter(text);
      content = parsed.body;
      if (parsed.frontmatter.title) title = parsed.frontmatter.title;
      if (parsed.frontmatter.slug) slug = parsed.frontmatter.slug;
      if (parsed.frontmatter.date) publishedAt = new Date(parsed.frontmatter.date).getTime();
    } else if (extension === "rtf") {
      content = parseRTF(text);
    }
    const db = getDb(env$1);
    const postData = {
      id: crypto.randomUUID(),
      title,
      slug,
      content,
      publishedAt,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    await db.insert(posts).values(postData);
    try {
      if (env$1.GINS_CACHE) {
        await env$1.GINS_CACHE.delete("home_recent_posts_en");
        await env$1.GINS_CACHE.delete("home_recent_posts_zh");
      }
    } catch (e) {
      console.warn("Failed to clear cache", e);
    }
    return new Response(JSON.stringify({
      success: true,
      slug,
      post: postData
    }), {
      status: 200
    });
  } catch (e) {
    console.error("Upload Error:", e);
    if (e.message.includes("UNIQUE constraint failed")) {
      return new Response(JSON.stringify({
        error: "Slug already exists. Change title or slug in frontmatter."
      }), {
        status: 409
      });
    }
    return new Response(JSON.stringify({
      error: e.message || "Server Error"
    }), {
      status: 500
    });
  }
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

globalThis.process ??= {};
globalThis.process.env ??= {};
import { g as getLangFromUrl, $ as $$Layout, u as useTranslations, r as renderScript } from "./Layout_B4Am03Vw.mjs";
import { c as createComponent } from "./astro-component_BvYacKii.mjs";
import { aj as renderTemplate, a6 as maybeRenderHead } from "./sequence_C6JDRbfE.mjs";
import { r as renderComponent } from "./worker-entry_CI_WUTHH.mjs";
const $$Index = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$Index;
  const lang = getLangFromUrl(Astro2.url);
  const t = useTranslations(lang);
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": `${t("nav.login")} - ${t("hero.title")}` }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="flex flex-col items-center justify-center min-h-[50vh]"> <div class="glass-panel p-8 rounded-3xl w-full max-w-md text-center"> <h1 class="text-3xl font-display font-bold mb-2">${t("login.title")}</h1> <p class="text-gray-400 mb-8">${t("login.subtitle")}</p> <!-- Login Buttons Container (Disabled by default) --> <div id="login-buttons" class="opacity-50 pointer-events-none transition-all duration-300"> <a href="/login/github" class="flex items-center justify-center gap-3 w-full py-3 rounded-full bg-[#24292e] text-white font-bold hover:bg-[#2b3137] transition-colors border border-white/10 group"> <span class="i-simple-icons-github text-xl w-5 h-5 group-hover:scale-110 transition-transform"></span> <span>${t("login.github")}</span> </a> <a href="/login/google" class="flex items-center justify-center gap-3 w-full py-3 rounded-full bg-white text-gray-900 font-bold hover:bg-gray-100 transition-colors mt-3 group"> <span class="i-logos-google-icon text-xl w-5 h-5 group-hover:scale-110 transition-transform"></span> <span>${t("login.google")}</span> </a> <a href="/login/discord" class="flex items-center justify-center gap-3 w-full py-3 rounded-full bg-[#5865F2] text-white font-bold hover:bg-[#4752c4] transition-colors mt-3 group"> <span class="i-simple-icons-discord text-xl w-5 h-5 group-hover:scale-110 transition-transform"></span> <span>${t("login.discord")}</span> </a> </div> <!-- Privacy Consent Checkbox --> <div class="mt-8 flex flex-col items-center gap-3 text-xs text-gray-500"> <label class="flex items-center gap-3 cursor-pointer select-none group"> <div class="relative"> <input type="checkbox" id="privacy-agree" class="peer sr-only"> <div class="w-5 h-5 rounded-md border-2 border-white/20 bg-white/5 peer-checked:bg-brand-primary peer-checked:border-brand-primary transition-all duration-200"></div> <span class="i-heroicons-check w-3.5 h-3.5 text-white absolute top-[3px] left-[3px] opacity-0 peer-checked:opacity-100 transition-opacity scale-50 peer-checked:scale-100 duration-200"></span> </div> <span class="text-gray-400 group-hover:text-gray-300 transition-colors text-left leading-relaxed">
我已阅读并同意 <a href="/zh/privacy" target="_blank" class="text-brand-accent hover:text-white underline underline-offset-4">隐私政策</a> </span> </label> </div> ${renderScript($$result2, "D:/coding/claude/_ginsbuild/src/pages/zh/login/index.astro?astro&type=script&index=0&lang.ts")} </div> </div> ` })}`;
}, "D:/coding/claude/_ginsbuild/src/pages/zh/login/index.astro", void 0);
const $$file = "D:/coding/claude/_ginsbuild/src/pages/zh/login/index.astro";
const $$url = "/zh/login";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

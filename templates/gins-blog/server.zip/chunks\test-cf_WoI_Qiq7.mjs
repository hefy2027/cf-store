globalThis.process ??= {};
globalThis.process.env ??= {};
import { $ as $$Layout } from "./Layout_B4Am03Vw.mjs";
import { c as createComponent } from "./astro-component_BvYacKii.mjs";
import { a6 as maybeRenderHead, aw as addAttribute, aj as renderTemplate } from "./sequence_C6JDRbfE.mjs";
import { r as renderComponent } from "./worker-entry_CI_WUTHH.mjs";
const $$CFImage = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$CFImage;
  const {
    src,
    alt,
    width,
    height,
    fit = "scale-down",
    quality = 80,
    format = "auto",
    class: className,
    loading = "lazy",
    decoding = "async"
  } = Astro2.props;
  const isLocal = src.startsWith("/");
  const isRemote = src.startsWith("http");
  !isLocal && !isRemote && !src.includes("/");
  let finalSrc = src;
  {
    const options = [
      `width=${width || ""}`,
      `height=${height || ""}`,
      `fit=${fit}`,
      `quality=${quality}`,
      `format=${format}`
    ].filter((o) => !o.endsWith("=")).join(",");
    if (isLocal) {
      finalSrc = `/cdn-cgi/image/${options}${src}`;
    } else if (isRemote) {
      finalSrc = `/cdn-cgi/image/${options}/${src}`;
    }
  }
  return renderTemplate`${maybeRenderHead()}<img${addAttribute(finalSrc, "src")}${addAttribute(alt, "alt")}${addAttribute(className, "class")}${addAttribute(width, "width")}${addAttribute(height, "height")}${addAttribute(loading, "loading")}${addAttribute(decoding, "decoding")}>`;
}, "D:/coding/claude/_ginsbuild/src/components/CFImage.astro", void 0);
const $$StreamPlayer = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$StreamPlayer;
  const {
    videoId,
    title = "Video",
    poster,
    controls = true,
    autoplay = false,
    loop = false,
    muted = false,
    preload = "metadata",
    customerCode
  } = Astro2.props;
  const streamDomain = customerCode ? `customer-${customerCode}.cloudflarestream.com` : "iframe.videodelivery.net";
  const srcUrl = new URL(`https://${streamDomain}/${videoId}`);
  srcUrl.searchParams.set("preload", preload);
  if (poster) srcUrl.searchParams.set("poster", poster);
  if (autoplay) srcUrl.searchParams.set("autoplay", "true");
  if (loop) srcUrl.searchParams.set("loop", "true");
  if (muted) srcUrl.searchParams.set("muted", "true");
  if (!controls) srcUrl.searchParams.set("controls", "false");
  return renderTemplate`${maybeRenderHead()}<div class="relative w-full aspect-video rounded-xl overflow-hidden shadow-lg border border-white/10 my-8"> <iframe${addAttribute(srcUrl.toString(), "src")} style="border: none" height="100%" width="100%" allow="accelerometer; gyroscope; autoplay; encrypted-media; picture-in-picture;" allowfullscreen="true"${addAttribute(title, "title")}></iframe> </div>`;
}, "D:/coding/claude/_ginsbuild/src/components/StreamPlayer.astro", void 0);
const $$TestCf = createComponent(($$result, $$props, $$slots) => {
  const testImageId = "placeholder-image-id";
  const testVideoId = "placeholder-video-id";
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Cloudflare Integration Test" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="container mx-auto px-4 py-12"> <h1 class="text-4xl font-bold mb-8">Cloudflare Integration Test</h1> <section class="mb-12"> <h2 class="text-2xl font-semibold mb-4">1. Cloudflare Image (CFImage)</h2> <p class="mb-4">Standard rendering with placeholder ID:</p> <div class="max-w-md"> ${renderComponent($$result2, "CFImage", $$CFImage, { "src": testImageId, "alt": "Test Cloudflare Image", "width": 400, "height": 300, "class": "rounded-lg shadow-md" })} </div> <p class="mt-4 text-sm text-gray-500">
HTML Output Inspection Required: Check if src points to
        \`imagedelivery.net\`.
</p> </section> <section class="mb-12"> <h2 class="text-2xl font-semibold mb-4">
2. Cloudflare Stream (StreamPlayer)
</h2> <p class="mb-4">Stream Player Embed:</p> <div class="max-w-2xl"> ${renderComponent($$result2, "StreamPlayer", $$StreamPlayer, { "videoId": testVideoId, "title": "Test Video" })} </div> </section> </div> ` })}`;
}, "D:/coding/claude/_ginsbuild/src/pages/test-cf.astro", void 0);
const $$file = "D:/coding/claude/_ginsbuild/src/pages/test-cf.astro";
const $$url = "/test-cf";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$TestCf,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

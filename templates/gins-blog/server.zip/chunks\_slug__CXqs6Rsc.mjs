globalThis.process ??= {};
globalThis.process.env ??= {};
import { $ as $$Layout } from "./Layout_B4Am03Vw.mjs";
import { c as createComponent } from "./astro-component_BvYacKii.mjs";
import { aj as renderTemplate, bF as unescapeHTML, aw as addAttribute, bI as renderTransition, a6 as maybeRenderHead } from "./sequence_C6JDRbfE.mjs";
import { r as renderComponent } from "./worker-entry_CI_WUTHH.mjs";
import { env } from "cloudflare:workers";
import { C as Comments, $ as $$ShareButtons } from "./Comments_C7NcJh2k.mjs";
import { g as getDb, p as posts, a as and, l as lte, e as eq, k as lt, f as desc, n as gt } from "./db_XAr9wiDM.mjs";
var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$slug = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$slug;
  const { slug } = Astro2.params;
  if (!slug) {
    return Astro2.redirect("/404");
  }
  const env$1 = env;
  const CACHE_KEY = `post:${slug}`;
  let result = null;
  try {
    const cached = await env$1.GINS_CACHE.get(CACHE_KEY, "json");
    if (cached) {
      result = cached;
    }
  } catch (e) {
    console.warn("KV Cache Miss/Error:", e);
  }
  if (!result) {
    const db2 = getDb(env$1);
    result = await db2.select().from(posts).where(and(eq(posts.slug, slug), lte(posts.publishedAt, Date.now()))).get();
    if (result) {
      try {
        await env$1.GINS_CACHE.put(CACHE_KEY, JSON.stringify(result), {
          expirationTtl: 60 * 60 * 24 * 7
          // 7 Days Cache
        });
      } catch (e) {
        console.warn("Failed to write to KV:", e);
      }
    }
  }
  if (!result) {
    return Astro2.redirect("/404");
  }
  const db = getDb(env$1);
  const currentPublishedAt = result.publishedAt || 0;
  const prevPost = await db.select({ title: posts.title, slug: posts.slug }).from(posts).where(
    and(
      lt(posts.publishedAt, currentPublishedAt),
      lte(posts.publishedAt, Date.now())
    )
  ).orderBy(desc(posts.publishedAt)).limit(1).get();
  const nextPost = await db.select({ title: posts.title, slug: posts.slug }).from(posts).where(
    and(
      gt(posts.publishedAt, currentPublishedAt),
      lte(posts.publishedAt, Date.now())
    )
  ).orderBy(posts.publishedAt).limit(1).get();
  const contentPreview = `${result.content.replace(/<[^>]*>/g, "").slice(0, 160).trim()}...`;
  const publishedTime = new Date(
    result.publishedAt || result.createdAt
  ).toISOString();
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: result.title,
    description: contentPreview,
    author: {
      "@type": "Person",
      name: "IchimaruGin728",
      url: "https://blog.ichimarugin728.com/about"
    },
    datePublished: publishedTime,
    dateModified: new Date(result.updatedAt).toISOString(),
    publisher: {
      "@type": "Organization",
      name: "Gin's Blog",
      logo: {
        "@type": "ImageObject",
        url: "https://blog.ichimarugin728.com/favicon.png"
      }
    },
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": `https://blog.ichimarugin728.com/blog/${slug}`
    }
  };
  Astro2.response.headers.set(
    "Cache-Control",
    "public, max-age=0, s-maxage=3600, stale-while-revalidate=86400"
  );
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": result.title, "description": contentPreview, "type": "article", "publishedTime": publishedTime }, { "default": async ($$result2) => renderTemplate(_a || (_a = __template([" ", '<article class="max-w-3xl mx-auto"> <header class="mb-12 text-center"> <div class="inline-block px-4 py-1 rounded-full bg-brand-primary/10 text-brand-accent font-mono text-sm mb-6 border border-brand-primary/20"> ', ' </div> <h1 class="text-5xl font-display font-bold mb-6 leading-tight"', "> ", ' </h1> </header> <div class="glass-panel rounded-3xl p-8 md:p-12 prose prose-invert prose-lg max-w-none text-gray-300"> <div>', '</div> </div> <!-- Share Buttons --> <div class="mt-8"> ', ' </div> <!-- Post Navigation --> <div class="mt-12 grid grid-cols-1 md:grid-cols-2 gap-4"> ', " ", ' </div> <!-- Comments Section --> <div class="mt-16"> ', ' </div> <div class="mt-12 text-center"> <a href="/blog" class="inline-flex items-center gap-2 text-brand-accent hover:text-white transition-colors"> <span class="i-heroicons-arrow-left"></span>\nBack to Overview\n</a> </div> </article>  <script type="application/ld+json">', "<\/script> "])), maybeRenderHead(), new Date(result.publishedAt || result.createdAt).toLocaleDateString(), addAttribute(renderTransition($$result2, "2kw73nlz", "", `title-${slug}`), "data-astro-transition-scope"), result.title, unescapeHTML(result.content), renderComponent($$result2, "ShareButtons", $$ShareButtons, { "url": Astro2.url.href, "title": result.title, "description": result.content.substring(0, 160) }), prevPost ? renderTemplate`<a${addAttribute(`/blog/${prevPost.slug}`, "href")} class="group glass-panel p-6 rounded-2xl border border-white/5 hover:border-white/20 transition-all text-left"> <div class="text-xs font-mono text-gray-500 mb-2 group-hover:text-brand-accent transition-colors">
← Previous Post
</div> <div class="font-bold text-lg leading-tight group-hover:text-white transition-colors line-clamp-2"> ${prevPost.title} </div> </a>` : renderTemplate`<div></div>`, nextPost ? renderTemplate`<a${addAttribute(`/blog/${nextPost.slug}`, "href")} class="group glass-panel p-6 rounded-2xl border border-white/5 hover:border-white/20 transition-all text-right"> <div class="text-xs font-mono text-gray-500 mb-2 group-hover:text-brand-accent transition-colors">
Next Post →
</div> <div class="font-bold text-lg leading-tight group-hover:text-white transition-colors line-clamp-2"> ${nextPost.title} </div> </a>` : renderTemplate`<div></div>`, renderComponent($$result2, "Comments", Comments, { "client:visible": true, "postId": result.id, "lang": "en-SG", "currentUser": Astro2.locals.user || void 0, "client:component-hydration": "visible", "client:component-path": "D:/coding/claude/_ginsbuild/src/components/Comments.tsx", "client:component-export": "default" }), unescapeHTML(JSON.stringify(structuredData))) })}`;
}, "D:/coding/claude/_ginsbuild/src/pages/blog/[slug].astro", "self");
const $$file = "D:/coding/claude/_ginsbuild/src/pages/blog/[slug].astro";
const $$url = "/blog/[slug]";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$slug,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

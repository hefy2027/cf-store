globalThis.process ??= {};
globalThis.process.env ??= {};
class Cache {
  kv;
  constructor(kv) {
    this.kv = kv;
  }
  async get(key) {
    const value = await this.kv.get(key, "json");
    return value;
  }
  async set(key, value, ttlSeconds = 300) {
    await this.kv.put(key, JSON.stringify(value), {
      expirationTtl: ttlSeconds
    });
  }
  async getOrSet(key, fetchFn, ttlSeconds = 300) {
    const cached = await this.get(key);
    if (cached) {
      return cached;
    }
    const value = await fetchFn();
    if (value) {
      await this.set(key, value, ttlSeconds);
    }
    return value;
  }
}
function getCache(env) {
  if (!env.GINS_CACHE) {
    throw new Error("GINS_CACHE KV binding not found");
  }
  return new Cache(env.GINS_CACHE);
}
export {
  getCache as g
};

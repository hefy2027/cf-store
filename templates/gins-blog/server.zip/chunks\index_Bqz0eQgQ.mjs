globalThis.process ??= {};
globalThis.process.env ??= {};
import { $ as $$Layout } from "./Layout_B4Am03Vw.mjs";
import { c as createComponent } from "./astro-component_BvYacKii.mjs";
import { a6 as maybeRenderHead, aw as addAttribute, aj as renderTemplate } from "./sequence_C6JDRbfE.mjs";
import { r as renderComponent } from "./worker-entry_CI_WUTHH.mjs";
import { g as getCollection, $ as $$DocsFeatureCard } from "./_astro_content_uaURmYnY.mjs";
const $$DocsSidebar = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$DocsSidebar;
  const docs = (await getCollection("docs")).sort((a, b) => {
    const orderA = a.data.order ?? 999;
    const orderB = b.data.order ?? 999;
    if (orderA !== orderB) {
      return orderA - orderB;
    }
    return a.data.title.localeCompare(b.data.title);
  });
  return renderTemplate`${maybeRenderHead()}<div class="pr-6"> <h2 class="text-xs font-bold text-brand-accent uppercase tracking-widest mb-4 font-mono">
Documentation
</h2> <nav class="space-y-1"> ${docs.map((doc) => {
    const routeSlug = doc.id.replace(/^docs\//, "");
    const href = `/docs/${routeSlug === "index" ? "" : routeSlug}`;
    const isActive = Astro2.url.pathname.replace(/\/$/, "") === href.replace(/\/$/, "");
    return renderTemplate`<a${addAttribute(href, "href")}${addAttribute([
      "block px-3 py-2 rounded-lg text-sm transition-all duration-200",
      isActive ? "bg-brand-primary/20 text-brand-accent font-bold border-l-2 border-brand-accent" : "text-gray-400 hover:bg-white/5 hover:text-white border-l-2 border-transparent"
    ], "class:list")}> ${doc.data.title} </a>`;
  })} </nav> <div class="mt-8 pt-8 border-t border-white/10"> <h2 class="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4 font-mono">
Resources
</h2> <nav class="space-y-2"> <a href="https://github.com/IchimaruGin728" target="_blank" rel="noopener noreferrer" class="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors"> <span class="i-simple-icons-github text-lg"></span>
GitHub
</a> <a href="https://x.com/IchimaruGin728" target="_blank" rel="noopener noreferrer" class="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors"> <span class="i-simple-icons-x text-lg"></span>
Twitter
</a> </nav> </div> </div>`;
}, "D:/coding/claude/_ginsbuild/src/components/DocsSidebar.astro", void 0);
const $$Index = createComponent(($$result, $$props, $$slots) => {
  const features = [
    {
      title: "Edge-Native Rendering",
      items: [
        "Eliminates traditional server cold start latency",
        "Renders pages on edge nodes closest to the user",
        "Built natively on the Cloudflare Workers ecosystem"
      ],
      icon: "i-heroicons-globe-alt",
      color: "from-blue-500/20 to-cyan-500/20",
      iconColor: "text-cyan-400"
    },
    {
      title: "Dynamic Visuals",
      items: [
        "Hardware-accelerated glassmorphism components",
        "Interactive 3D hover effects with cursor tracking",
        "Smooth route transitions powered by modern APIs"
      ],
      icon: "i-heroicons-sparkles",
      color: "from-purple-500/20 to-pink-500/20",
      iconColor: "text-pink-400"
    },
    {
      title: "Zero Trust Ready",
      items: [
        "Integrates with Cloudflare Access enterprise gateways",
        "Native support for WebAuthn and Passkey logins",
        "Implements granular rate limiting at the edge layer"
      ],
      icon: "i-heroicons-shield-check",
      color: "from-emerald-500/20 to-green-500/20",
      iconColor: "text-emerald-400"
    },
    {
      title: "Serverless Database",
      items: [
        "Bypasses traditional TCP connection pool limits",
        "Powered by Cloudflare D1 distributed SQLite",
        "Ensures end-to-end type safety via Drizzle ORM"
      ],
      icon: "i-heroicons-circle-stack",
      color: "from-orange-500/20 to-amber-500/20",
      iconColor: "text-orange-400"
    },
    {
      title: "Native AI Integration",
      items: [
        "Low-latency semantic text search via edge vectors",
        "LLM connectivity for dynamic knowledge retrieval",
        "Includes MCP Agentic endpoints for advanced AI tooling"
      ],
      icon: "i-heroicons-cpu-chip",
      color: "from-indigo-500/20 to-violet-500/20",
      iconColor: "text-indigo-400"
    },
    {
      title: "Lightweight Edge API",
      items: [
        "Driven by the low-footprint Hono web framework",
        "Strict incoming data validation powered by Zod",
        "Provides a unified, type-safe RPC calling experience"
      ],
      icon: "i-heroicons-bolt",
      color: "from-yellow-500/20 to-lime-500/20",
      iconColor: "text-yellow-400"
    }
  ];
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Documentation Home" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="flex gap-8"> <aside class="hidden md:block w-64 shrink-0 overflow-y-auto sticky top-32 max-h-[calc(100vh-10rem)]"> ${renderComponent($$result2, "DocsSidebar", $$DocsSidebar, {})} </aside> <article class="flex-1 min-w-0 main-content"> <div class="glass-panel p-6 md:p-10 rounded-3xl mb-8"> <div class="mb-12"> <div class="inline-block px-4 py-1.5 rounded-full bg-brand-primary/10 text-brand-accent font-mono text-xs font-bold mb-6 border border-brand-primary/30 shadow-[0_0_15px_rgba(88,28,135,0.5)]">
v1.0.0 NUCLEUS
</div> <h1 class="text-2xl md:text-4xl font-display font-bold mb-6 tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-gray-200 to-gray-500">
Gins-Blog Architecture
</h1> <p class="text-lg text-gray-400 max-w-2xl leading-relaxed">
Beyond the source code, explore the architectural patterns, deployment
            workflows, and engineering practices that power the Gins-Blog ecosystem.
</p> </div> <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"> ${features.map((feature) => renderTemplate`<a href="/docs/introduction" class="block h-full"> ${renderComponent($$result2, "DocsFeatureCard", $$DocsFeatureCard, { "title": feature.title, "items": feature.items, "icon": feature.icon, "color": feature.color, "iconColor": feature.iconColor })} </a>`)} </div> <div class="mt-16 pt-12 border-t border-white/10 flex flex-col md:flex-row gap-6 items-center justify-between"> <div> <h3 class="text-xl font-bold font-display mb-2">Ready to deploy?</h3> <p class="text-gray-400 text-sm">
Use my automated setup scripts to quickly provision a complete
              edge-native infrastructure within your Cloudflare account.
</p> </div> <a href="/docs/deployment" class="px-8 py-4 rounded-xl bg-white text-black font-bold flex items-center gap-2 hover:bg-gray-200 transition-all hover:scale-105 shadow-[0_0_20px_rgba(255,255,255,0.2)]">
View Setup Guide <span class="i-heroicons-arrow-right"></span> </a> </div> </div> </article> </div> ` })}`;
}, "D:/coding/claude/_ginsbuild/src/pages/docs/index.astro", void 0);
const $$file = "D:/coding/claude/_ginsbuild/src/pages/docs/index.astro";
const $$url = "/docs";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { s as sha256 } from "./sha512_BMZIG4lt.mjs";
import { bG as encodeHexLowerCase } from "./sequence_C6JDRbfE.mjs";
import { g as getDb, s as sessions, e as eq } from "./db_XAr9wiDM.mjs";
const GET = async ({
  locals,
  request,
  cookies
}) => {
  const env$1 = env;
  const {
    user
  } = locals;
  if (!user) {
    return new Response(JSON.stringify({
      error: "Unauthorized"
    }), {
      status: 401,
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
  const db = getDb(env$1);
  const userSessions = await db.select().from(sessions).where(eq(sessions.userId, user.id)).all();
  const sessionCookie = cookies.get("session");
  const currentSessionId = sessionCookie?.value ? encodeHexLowerCase(sha256(new TextEncoder().encode(sessionCookie.value))) : null;
  const currentId = currentSessionId;
  const sessionsWithInfo = userSessions.map((session) => {
    const ua = session.userAgent || "";
    let browser = "Unknown";
    let os = "Unknown";
    if (ua.includes("Chrome")) browser = "Chrome";
    else if (ua.includes("Safari") && !ua.includes("Chrome")) browser = "Safari";
    else if (ua.includes("Firefox")) browser = "Firefox";
    else if (ua.includes("Edge")) browser = "Edge";
    if (ua.includes("Windows")) os = "Windows";
    else if (ua.includes("Mac")) os = "macOS";
    else if (ua.includes("Linux")) os = "Linux";
    else if (ua.includes("Android")) os = "Android";
    else if (ua.includes("iOS") || ua.includes("iPhone") || ua.includes("iPad")) os = "iOS";
    if (session.osVerified) {
      os = session.osVerified;
    }
    return {
      id: session.id,
      browser,
      os,
      createdAt: session.createdAt,
      lastActive: session.lastActive,
      isCurrent: session.id === currentId,
      // Only include sensitive data for admin
      ...request.url.includes("/admin") ? {
        ipAddress: session.ipAddress,
        userAgent: session.userAgent
      } : {}
    };
  });
  return new Response(JSON.stringify(sessionsWithInfo), {
    headers: {
      "Content-Type": "application/json"
    }
  });
};
const DELETE = async ({
  locals,
  request,
  cookies
}) => {
  const env$1 = env;
  const {
    user
  } = locals;
  if (!user) {
    return new Response(JSON.stringify({
      error: "Unauthorized"
    }), {
      status: 401,
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
  const url = new URL(request.url);
  const sessionId = url.searchParams.get("id");
  if (!sessionId) {
    return new Response(JSON.stringify({
      error: "Session ID required"
    }), {
      status: 400,
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
  const db = getDb(env$1);
  const session = await db.select().from(sessions).where(eq(sessions.id, sessionId)).get();
  if (!session || session.userId !== user.id) {
    return new Response(JSON.stringify({
      error: "Session not found"
    }), {
      status: 404,
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
  const sessionCookie = cookies.get("session");
  if (sessionCookie?.value) {
    const currentSessionId = encodeHexLowerCase(sha256(new TextEncoder().encode(sessionCookie.value)));
    if (sessionId === currentSessionId) {
      return new Response(JSON.stringify({
        error: "Cannot revoke current session"
      }), {
        status: 400,
        headers: {
          "Content-Type": "application/json"
        }
      });
    }
  }
  await db.delete(sessions).where(eq(sessions.id, sessionId));
  await env$1.GIN_KV.delete(`session:${sessionId}`);
  return new Response(JSON.stringify({
    success: true
  }), {
    headers: {
      "Content-Type": "application/json"
    }
  });
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  DELETE,
  GET
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

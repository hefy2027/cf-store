globalThis.process ??= {};
globalThis.process.env ??= {};
import "cloudflare:workers";
import { w } from "./chunks/worker-entry_CI_WUTHH.mjs";
export {
  w as default
};

globalThis.process ??= {};
globalThis.process.env ??= {};
import { g as getLangFromUrl, $ as $$Layout, u as useTranslations } from "./Layout_B4Am03Vw.mjs";
import { c as createComponent } from "./astro-component_BvYacKii.mjs";
import { aj as renderTemplate, a6 as maybeRenderHead, aw as addAttribute, bI as renderTransition } from "./sequence_C6JDRbfE.mjs";
import { r as renderComponent } from "./worker-entry_CI_WUTHH.mjs";
import { env } from "cloudflare:workers";
import { g as getDb, p as posts, l as lte, f as desc } from "./db_XAr9wiDM.mjs";
import { g as getCache } from "./cache_BvGm7QnY.mjs";
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$Index;
  const lang = getLangFromUrl(Astro2.url);
  const t = useTranslations(lang);
  const env$1 = env;
  let cache;
  try {
    cache = getCache(env$1);
  } catch (e) {
    console.error("Cache initialization failed:", e);
  }
  let recentPosts = [];
  const CACHE_KEY = "home_recent_posts_en";
  const CACHE_TTL = 300;
  try {
    recentPosts = [];
    if (env$1.DB) {
      const fetchPosts = async () => {
        const db = getDb(env$1);
        return await db.select().from(posts).where(lte(posts.publishedAt, Date.now())).orderBy(desc(posts.publishedAt)).limit(3);
      };
      if (cache) {
        recentPosts = await cache.getOrSet(CACHE_KEY, fetchPosts, CACHE_TTL);
      } else {
        recentPosts = await fetchPosts();
      }
    }
  } catch (e) {
    console.error("Failed to fetch posts:", e);
  }
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": t("hero.title"), "data-astro-cid-j7pv25f6": true }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="grid grid-cols-1 md:grid-cols-3 gap-6 auto-rows-[minmax(180px,auto)] mb-12" data-astro-cid-j7pv25f6> <div class="md:col-span-2 glass-panel p-6 md:p-10 flex flex-col justify-center rounded-3xl relative overflow-hidden group animate-fade-in-up" data-astro-cid-j7pv25f6> <div class="absolute inset-0 bg-gradient-to-br from-purple-900/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700" data-astro-cid-j7pv25f6></div> <div class="relative z-10" data-astro-cid-j7pv25f6> <h1 class="text-3xl md:text-5xl font-display font-bold mb-2 md:mb-4 tracking-tight" data-astro-cid-j7pv25f6> <span class="bg-clip-text text-transparent bg-gradient-to-r from-white via-gray-200 to-gray-400" data-astro-cid-j7pv25f6> ${t("hero.title")} </span> </h1> <p class="text-gray-400 text-sm md:text-lg" data-astro-cid-j7pv25f6> ${t("hero.subtitle")} </p> </div> </div> <div class="glass-panel p-8 flex flex-col justify-between rounded-3xl relative overflow-hidden animate-fade-in-up animate-delay-100" data-astro-cid-j7pv25f6> <div data-astro-cid-j7pv25f6> <div class="font-mono text-xs text-brand-accent mb-4 tracking-widest uppercase" data-astro-cid-j7pv25f6> ${t("home.system_status")} </div> <div class="text-3xl font-display font-bold" data-astro-cid-j7pv25f6> ${t("home.operational")} </div> </div> <div class="flex items-center gap-2" data-astro-cid-j7pv25f6> <div class="w-2 h-2 rounded-full bg-green-500 animate-pulse" data-astro-cid-j7pv25f6></div> <span class="text-xs text-gray-500 font-mono" data-astro-cid-j7pv25f6>${t("home.all_systems_normal")}</span> </div> </div> <div class="glass-panel p-8 rounded-3xl flex flex-col justify-between relative overflow-hidden group md:row-span-2 max-h-[500px] animate-fade-in-up animate-delay-200" data-astro-cid-j7pv25f6> <h2 class="text-xl font-bold mb-6" data-astro-cid-j7pv25f6>${t("home.recent_posts")}</h2> <div class="flex flex-col gap-4 overflow-y-auto pr-2 custom-scrollbar" data-astro-cid-j7pv25f6> ${recentPosts.length > 0 ? recentPosts.map((post) => renderTemplate`<a${addAttribute(`/blog/${post.slug}`, "href")} data-astro-prefetch class="block group/item hover:bg-white/5 p-4 rounded-xl transition-colors border border-transparent hover:border-white/5" data-astro-cid-j7pv25f6> <h3 class="font-bold text-sm text-gray-200 group-hover/item:text-brand-accent transition-colors line-clamp-2" data-astro-cid-j7pv25f6${addAttribute(renderTransition($$result2, "t3dkdnf3", "", `title-${post.slug}`), "data-astro-transition-scope")}> ${post.title} </h3> <span class="text-xs text-gray-500 mt-2 block font-mono" data-astro-cid-j7pv25f6> ${new Date(
    post.publishedAt || post.createdAt
  ).toLocaleDateString()} </span> </a>`) : renderTemplate`<div class="text-gray-500 text-sm italic" data-astro-cid-j7pv25f6> ${t("home.no_signals")} </div>`} </div> <div class="mt-4 pt-4 border-t border-white/5" data-astro-cid-j7pv25f6> <a href="/blog" data-astro-prefetch class="text-xs text-gray-400 hover:text-white flex items-center gap-2 transition-colors" data-astro-cid-j7pv25f6> ${t("home.view_archive")} <span class="i-heroicons-arrow-right text-xs" data-astro-cid-j7pv25f6></span> </a> </div> </div> <a href="/gallery" data-astro-prefetch class="glass-panel p-8 flex flex-col justify-between rounded-3xl group hover:bg-white/5 transition-colors relative overflow-hidden animate-fade-in-up animate-delay-300" data-astro-cid-j7pv25f6> <div class="absolute -right-4 -bottom-4 text-9xl text-white/5 i-heroicons-photo rotate-12 group-hover:rotate-6 transition-transform duration-500" data-astro-cid-j7pv25f6></div> <div class="mt-auto relative z-10" data-astro-cid-j7pv25f6> <h2 class="text-xl font-bold" data-astro-cid-j7pv25f6>${t("home.gallery")}</h2> </div> </a> <a href="/projects" data-astro-prefetch class="glass-panel p-8 flex flex-col justify-between rounded-3xl group hover:bg-white/5 transition-colors relative overflow-hidden animate-fade-in-up animate-delay-400" data-astro-cid-j7pv25f6> <div class="absolute -right-4 -bottom-4 text-9xl text-white/5 i-heroicons-beaker rotate-12 group-hover:rotate-6 transition-transform duration-500" data-astro-cid-j7pv25f6></div> <div class="mt-auto relative z-10" data-astro-cid-j7pv25f6> <h2 class="text-xl font-bold" data-astro-cid-j7pv25f6>${t("home.projects")}</h2> </div> </a> <div class="md:col-span-3 h-32 flex items-center justify-center opacity-30 mt-8" data-astro-cid-j7pv25f6> <span class="i-heroicons-chevron-down text-3xl animate-bounce" data-astro-cid-j7pv25f6></span> </div> </div> ` })}`;
}, "D:/coding/claude/_ginsbuild/src/pages/index.astro", "self");
const $$file = "D:/coding/claude/_ginsbuild/src/pages/index.astro";
const $$url = "";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

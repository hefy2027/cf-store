globalThis.process ??= {};
globalThis.process.env ??= {};
import { bn as createActionsProxy, p as pipelineSymbol, A as AstroError, h as ActionCalledFromServerError, bo as object, bp as string } from "./sequence_C6JDRbfE.mjs";
import { d as defineAction } from "./worker-entry_CI_WUTHH.mjs";
createActionsProxy({
  handleAction: async (param, path, context) => {
    const pipeline = context ? Reflect.get(context, pipelineSymbol) : void 0;
    if (!pipeline) {
      throw new AstroError(ActionCalledFromServerError);
    }
    const action = await pipeline.getAction(path);
    if (!action) throw new Error(`Action not found: ${path}`);
    return action.bind(context)(param);
  }
});
const server = {
  getGreeting: defineAction({
    input: object({
      name: string()
    }),
    handler: async (input) => {
      return `Hello, ${input.name}! This is from Astro Actions.`;
    }
  })
};
export {
  server
};

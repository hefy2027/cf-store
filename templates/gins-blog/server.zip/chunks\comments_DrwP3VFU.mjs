globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { g as getDb, p as posts, a as and, l as lte, e as eq, u as users, c as comments, b as likes, d as sql, f as desc } from "./db_XAr9wiDM.mjs";
const MAX_COMMENT_LENGTH = 2e3;
const GET = async ({
  request,
  locals
}) => {
  const env$1 = env;
  const url = new URL(request.url);
  const postId = url.searchParams.get("postId");
  if (!postId) return new Response(JSON.stringify([]), {
    status: 200
  });
  const db = getDb(env$1);
  const currentUser = locals.user;
  let targetPostId = postId;
  const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(postId);
  const postRecord = await db.select({
    id: posts.id
  }).from(posts).where(isUuid ? and(eq(posts.id, postId), lte(posts.publishedAt, Date.now())) : and(eq(posts.slug, postId), lte(posts.publishedAt, Date.now()))).get();
  if (!postRecord) return new Response(JSON.stringify([]), {
    status: 200
  });
  targetPostId = postRecord.id;
  const allComments = await db.select({
    id: comments.id,
    content: comments.content,
    createdAt: comments.createdAt,
    user: {
      username: users.username,
      avatar: users.avatar
    },
    likesCount: sql`count(${likes.userId})`
    // We'd ideally check if *current user* liked it here too, but simple count first
  }).from(comments).innerJoin(users, eq(comments.userId, users.id)).leftJoin(likes, eq(comments.id, likes.commentId)).where(eq(comments.postId, targetPostId)).groupBy(comments.id).orderBy(desc(comments.createdAt)).all();
  let enrichedComments = allComments.map((c) => ({
    ...c,
    likes: Number(c.likesCount),
    // SQLite returns number/string
    likedByUser: false
  }));
  if (currentUser) {
    const userLikes = await db.select({
      commentId: likes.commentId
    }).from(likes).where(and(eq(likes.userId, currentUser.id), eq(likes.value, 1))).all();
    const likedSet = new Set(userLikes.map((l) => l.commentId));
    enrichedComments = enrichedComments.map((c) => ({
      ...c,
      likedByUser: likedSet.has(c.id)
    }));
  }
  return new Response(JSON.stringify(enrichedComments), {
    status: 200
  });
};
const POST = async ({
  request,
  locals
}) => {
  const env$1 = env;
  const user = locals.user;
  if (!user) return new Response(JSON.stringify({
    error: "Unauthorized"
  }), {
    status: 401
  });
  try {
    const body = await request.json();
    const {
      postId,
      content
    } = body;
    const trimmedContent = typeof content === "string" ? content.trim() : "";
    if (!postId || !trimmedContent) {
      return new Response(JSON.stringify({
        error: "postId and non-empty content are required"
      }), {
        status: 400
      });
    }
    if (trimmedContent.length > MAX_COMMENT_LENGTH) {
      return new Response(JSON.stringify({
        error: "Comment exceeds length limit"
      }), {
        status: 400
      });
    }
    const db = getDb(env$1);
    let targetPostId = postId;
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(postId);
    const postRecord = await db.select({
      id: posts.id
    }).from(posts).where(isUuid ? and(eq(posts.id, postId), lte(posts.publishedAt, Date.now())) : and(eq(posts.slug, postId), lte(posts.publishedAt, Date.now()))).get();
    if (!postRecord) return new Response(JSON.stringify({
      error: "Post not found"
    }), {
      status: 404
    });
    targetPostId = postRecord.id;
    await db.insert(comments).values({
      id: crypto.randomUUID(),
      userId: user.id,
      postId: targetPostId,
      content: trimmedContent,
      createdAt: Date.now()
    });
    return new Response(JSON.stringify({
      success: true
    }), {
      status: 200
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({
      error: "Server Error"
    }), {
      status: 500
    });
  }
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  GET,
  POST
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { g as getDb, u as users, e as eq } from "./db_XAr9wiDM.mjs";
import { d as getGoogle, s as sanitizeRedirectTarget } from "./redirect_BKbNLFHX.mjs";
import { v as validateSessionToken, g as generateSessionToken, c as createSession } from "./session_DWbC8nF0.mjs";
const GET = async ({
  request,
  cookies,
  redirect
}) => {
  const env$1 = env;
  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const storedState = cookies.get("google_oauth_state")?.value ?? null;
  const codeVerifier = cookies.get("google_code_verifier")?.value ?? null;
  if (!code || !state || !storedState || !codeVerifier || state !== storedState) {
    return new Response(null, {
      status: 400
    });
  }
  try {
    console.log("Validating Google code...");
    const tokens = await getGoogle(env$1).validateAuthorizationCode(code, codeVerifier);
    const accessToken = tokens.accessToken();
    console.log("Tokens received:", accessToken ? "Present" : "Missing");
    let googleUser;
    try {
      console.log("Fetching Google user...");
      const googleUserResponse = await fetch("https://openidconnect.googleapis.com/v1/userinfo", {
        headers: {
          Authorization: `Bearer ${accessToken.trim()}`
        }
      });
      if (!googleUserResponse.ok) {
        const errorText = await googleUserResponse.text();
        throw new Error(`Google API returned ${googleUserResponse.status}: ${errorText.slice(0, 200)}`);
      }
      googleUser = await googleUserResponse.json();
      console.log("Google User fetched:", googleUser.name);
    } catch (fetchError) {
      throw new Error(`Failed to fetch Google user: ${fetchError.message}`);
    }
    const db = getDb(env$1);
    const existingSessionToken = cookies.get("session")?.value;
    let currentUserId = null;
    if (existingSessionToken) {
      const sessionResult = await validateSessionToken(existingSessionToken, db, env$1);
      if (sessionResult.session && sessionResult.user) {
        currentUserId = sessionResult.user.id;
        console.log("User is already logged in, linking Google account to user:", currentUserId);
      }
    }
    const existingUser = await db.select().from(users).where(eq(users.googleId, googleUser.sub)).get();
    let userId = "";
    if (currentUserId) {
      if (existingUser && existingUser.id !== currentUserId) {
        throw new Error("This Google account is already linked to another user account.");
      }
      await db.update(users).set({
        googleId: googleUser.sub,
        googleUsername: googleUser.name,
        googleAvatar: googleUser.picture
      }).where(eq(users.id, currentUserId));
      userId = currentUserId;
      console.log("Google account linked to existing user:", userId);
    } else if (existingUser) {
      userId = existingUser.id;
      console.log("Logging in as existing Google user:", userId);
    } else {
      userId = crypto.randomUUID();
      await db.insert(users).values({
        id: userId,
        googleId: googleUser.sub,
        username: googleUser.name,
        avatar: googleUser.picture,
        createdAt: Date.now(),
        googleUsername: googleUser.name,
        googleAvatar: googleUser.picture
      });
      console.log("Created new user with Google:", userId);
    }
    console.log("Creating session, userId:", userId);
    const token = generateSessionToken();
    const session = await createSession(token, userId, db, env$1, request);
    console.log("Setting session cookie...");
    cookies.set("session", token, {
      path: "/",
      httpOnly: true,
      sameSite: "lax",
      secure: true,
      expires: new Date(session.expiresAt)
    });
    const redirectUrl = sanitizeRedirectTarget(cookies.get("login_redirect")?.value);
    cookies.delete("google_oauth_state", {
      path: "/"
    });
    cookies.delete("google_code_verifier", {
      path: "/"
    });
    cookies.delete("login_redirect", {
      path: "/"
    });
    return redirect(redirectUrl);
  } catch (e) {
    console.error(e);
    cookies.delete("google_oauth_state", {
      path: "/"
    });
    cookies.delete("google_code_verifier", {
      path: "/"
    });
    cookies.delete("login_redirect", {
      path: "/"
    });
    return new Response("Login failed", {
      status: 500
    });
  }
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  GET
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

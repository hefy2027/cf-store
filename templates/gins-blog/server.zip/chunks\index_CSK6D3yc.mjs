globalThis.process ??= {};
globalThis.process.env ??= {};
import { $ as $$Layout, r as renderScript } from "./Layout_B4Am03Vw.mjs";
import { c as createComponent } from "./astro-component_BvYacKii.mjs";
import { a6 as maybeRenderHead, aj as renderTemplate, aw as addAttribute, a8 as Fragment } from "./sequence_C6JDRbfE.mjs";
import { r as renderComponent } from "./worker-entry_CI_WUTHH.mjs";
import { env } from "cloudflare:workers";
const $$AdminDashboardOverview = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$AdminDashboardOverview;
  const { postCount, userCount, activeSessionCount, performanceSummary } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<div class="max-w-7xl mx-auto"> <!-- Header --> <header class="mb-12 flex flex-col md:flex-row justify-between items-center gap-6"> <div class="flex items-center gap-8 w-full md:w-auto"> <div> <h1 class="text-4xl font-display font-bold text-transparent bg-clip-text bg-linear-to-r from-brand-accent to-brand-primary">
Analytics Center
</h1> <p class="text-gray-400 mt-2">Real-time data stream.</p> </div> <!-- Admin Search Box --> <div class="hidden md:block relative group flex-1 min-w-[300px] z-20"> <input type="text" id="admin-search-input" placeholder="Search Global Signals..." class="w-full bg-black/40 border border-white/10 rounded-full px-5 py-2.5 focus:outline-none focus:border-brand-accent focus:bg-black/60 transition-all text-white text-sm"> <div id="admin-search-results" class="absolute top-full left-0 mt-2 w-full glass-panel rounded-2xl p-2 hidden z-50"> <!-- Results injected here --> </div> </div> </div> <div class="flex items-center gap-4"> <a href="/IchimaruGin728/admin/music" class="px-4 py-2 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/30 text-purple-300 transition-colors text-sm flex items-center gap-2"> <span class="i-heroicons-musical-note"></span>
Music Manager
</a> <a href="/" class="px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 transition-colors text-sm">
Back to Site
</a> </div> </header> <!-- Analytics Grid --> <div class="grid grid-cols-1 md:grid-cols-5 gap-6 mb-12"> <div class="glass-panel p-6 rounded-2xl"> <div class="text-xs font-mono text-gray-400 uppercase tracking-widest mb-2">
Total Signals
</div> <div class="text-4xl font-bold font-display">${postCount}</div> </div> <!-- Users Card (Clickable) --> <div class="glass-panel p-6 rounded-2xl cursor-pointer hover:bg-white/5 transition-colors group relative" onclick="openInspector('users')"> <div class="absolute top-4 right-4 text-gray-500 group-hover:text-white transition-colors"> <span class="i-heroicons-users w-5 h-5"></span> </div> <div class="text-xs font-mono text-gray-400 uppercase tracking-widest mb-2">
Total Users
</div> <div class="text-4xl font-bold font-display group-hover:text-brand-accent transition-colors"> ${userCount} </div> <div class="text-xs text-gray-500 mt-2 flex items-center gap-1 group-hover:text-brand-accent/70 transition-colors"> <span>View Details</span> <span class="i-heroicons-arrow-right w-3 h-3"></span> </div> </div> <!-- Sessions Card (Clickable) --> <div class="glass-panel p-6 rounded-2xl cursor-pointer hover:bg-white/5 transition-colors group relative" onclick="openInspector('sessions')"> <div class="absolute top-4 right-4 text-gray-500 group-hover:text-white transition-colors"> <span class="i-heroicons-globe-alt w-5 h-5"></span> </div> <div class="text-xs font-mono text-gray-400 uppercase tracking-widest mb-2">
Active Sessions
</div> <div class="text-4xl font-bold font-display group-hover:text-green-400 transition-colors"> ${activeSessionCount} </div> <div class="text-xs text-gray-500 mt-2 flex items-center gap-1 group-hover:text-green-400/70 transition-colors"> <span>Inspect Traffic</span> <span class="i-heroicons-arrow-right w-3 h-3"></span> </div> </div> <!-- Edge Analytics Card (Clickable) --> <div class="glass-panel p-6 rounded-2xl cursor-pointer hover:bg-white/5 transition-colors group relative" onclick="openInspector('edge')"> <div class="absolute top-4 right-4 text-gray-500 group-hover:text-white transition-colors"> <span class="i-heroicons-server w-5 h-5"></span> </div> <div class="text-xs font-mono text-gray-400 uppercase tracking-widest mb-2">
Edge Nodes
</div> <div class="text-4xl font-bold font-display group-hover:text-blue-400 transition-colors"> ${performanceSummary?.active_nodes || 0} </div> <div class="text-xs text-gray-500 mt-2 flex items-center gap-1 group-hover:text-blue-400/70 transition-colors"> <span>Avg ${Math.round(Number(performanceSummary?.global_avg_rtt || 0))}ms</span> </div> </div> <div class="glass-panel p-6 rounded-2xl bg-linear-to-br from-brand-primary/20 to-transparent border-brand-primary/30"> <div class="text-xs font-mono text-gray-400 uppercase tracking-widest mb-2">
System Status
</div> <div class="flex items-center gap-2 text-green-400 font-bold"> <span class="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
OPERATIONAL
</div> </div> </div> </div>`;
}, "D:/coding/claude/_ginsbuild/src/components/admin/AdminDashboardOverview.astro", void 0);
const $$AdminSignalLog = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$AdminSignalLog;
  const { recentPosts } = Astro2.props;
  return renderTemplate`<!-- Signal Log List -->${maybeRenderHead()}<div class="glass-panel p-8 rounded-3xl mb-12"> <div class="flex items-center justify-between mb-6"> <h2 class="text-2xl font-bold">Signal Log</h2> <div id="signal-log-count" class="text-xs font-mono text-gray-400">
Showing Recent 10
</div> </div> <div class="overflow-x-auto"> <table class="w-full text-left border-collapse" id="signal-log-table"> <thead> <tr class="text-gray-400 border-b border-white/10 text-xs uppercase tracking-wider font-mono"> <th class="py-4 font-normal">Status</th> <th class="py-4 font-normal">Title</th> <th class="py-4 font-normal">Published</th> <th class="py-4 font-normal text-right">Views</th> <th class="py-4 font-normal text-right">Action</th> </tr> </thead> <tbody class="text-sm" id="signal-log-body"> ${(recentPosts.results || []).map((post) => {
    const isPublished = Date.now() >= (post.published_at || 0);
    return renderTemplate`<tr class="border-b border-white/5 hover:bg-white/5 transition-colors group"> <td class="py-4"> <span${addAttribute(`inline-block w-2 h-2 rounded-full ${isPublished ? "bg-green-400 shadow-[0_0_8px_rgba(74,222,128,0.5)]" : "bg-yellow-400"}`, "class")}></span> </td> <td class="py-4 font-medium text-white">${post.title}</td> <td class="py-4 text-gray-400 font-mono text-xs"> ${new Date(
      post.published_at ?? post.created_at ?? 0
    ).toLocaleDateString()} </td> <td class="py-4 text-right"> <span class="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-white/5 border border-white/10 text-xs font-mono"> <span class="i-heroicons-eye w-3 h-3 text-gray-500"></span> ${post.views || 0} </span> </td> <td class="py-4 text-right flex items-center justify-end gap-2"> <button class="edit-post-btn px-3 py-1 rounded-lg bg-white/5 hover:bg-brand-primary/20 text-gray-300 hover:text-brand-accent border border-white/10 hover:border-brand-primary/50 transition-all text-xs"${addAttribute(post.slug, "data-slug")} title="Edit Post"> <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"> <path stroke-linecap="round" stroke-linejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10"></path> </svg> </button> <button class="toggle-status-btn px-3 py-1 rounded-lg bg-white/5 hover:bg-yellow-500/20 text-gray-300 hover:text-yellow-400 border border-white/10 hover:border-yellow-500/50 transition-all text-xs"${addAttribute(post.slug, "data-slug")}${addAttribute(isPublished ? "published" : "draft", "data-status")}${addAttribute(isPublished ? "Unpublish (Hide)" : "Publish (Show)", "title")}> ${isPublished ? renderTemplate`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"> <path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 0 0 1.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.451 10.451 0 0 1 12 4.5c4.756 0 8.773 3.162 10.065 7.498a10.522 10.522 0 0 1-4.293 5.774M6.228 6.228 3 3m3.228 3.228 3.65 3.65m7.894 7.894L21 21m-3.228-3.228-3.65-3.65m0 0a3 3 0 1 0-4.243-4.243m4.242 4.242L9.88 9.88"></path> </svg>` : renderTemplate`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"> <path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z"></path> <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"></path> </svg>`} </button> <button class="delete-post-btn px-3 py-1 rounded-lg bg-white/5 hover:bg-red-500/20 text-gray-300 hover:text-red-400 border border-white/10 hover:border-red-500/50 transition-all text-xs"${addAttribute(post.slug, "data-slug")} title="Delete Post"> <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"> <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"></path> </svg> </button> </td> </tr>`;
  })} </tbody> </table> </div> <div class="mt-6 flex justify-center"> <button id="load-all-signals-btn" class="px-6 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono tracking-widest uppercase transition-colors text-gray-400 hover:text-white">
Load Full Archive
</button> </div> </div>`;
}, "D:/coding/claude/_ginsbuild/src/components/admin/AdminSignalLog.astro", void 0);
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$Index;
  const env$1 = env;
  async function safeFetch(promise, fallback) {
    try {
      return await promise;
    } catch (e) {
      console.error("DB Error:", e);
      return fallback;
    }
  }
  let postCount = 0;
  let userCount = 0;
  let activeSessionCount = 0;
  let recentPosts = {
    results: [],
    success: false,
    meta: {}
  };
  let activeSessionsList = { results: [] };
  let usersList = { results: [] };
  let edgeNodeStats = { results: [] };
  let performanceSummary = null;
  try {
    const db = env$1.DB;
    if (db) {
      postCount = await safeFetch(
        db.prepare("SELECT count(*) as count FROM posts").first("count"),
        0
      );
      userCount = await safeFetch(
        db.prepare("SELECT count(*) as count FROM users").first("count"),
        0
      );
      activeSessionCount = await safeFetch(
        db.prepare(
          "SELECT count(*) as count FROM sessions WHERE expires_at > ?"
        ).bind(Date.now()).first("count"),
        0
      );
      recentPosts = await safeFetch(
        db.prepare(
          "SELECT * FROM posts ORDER BY published_at DESC LIMIT 10"
        ).all(),
        { results: [], success: false, meta: {} }
      );
      activeSessionsList = await safeFetch(
        db.prepare(
          `
        SELECT
          sessions.id as session_id,
          sessions.ip_address,
          sessions.user_agent,
          sessions.last_active,
          sessions.created_at as session_created,
          sessions.city,
          sessions.country,
          sessions.asn,
          sessions.as_organization,
          sessions.colo,
          sessions.continent,
          sessions.timezone,
          sessions.latitude,
          sessions.longitude,
          sessions.postal_code,
          sessions.region,
          sessions.region_code,
          sessions.http_protocol,
          sessions.tls_version,
          sessions.tls_cipher,
          sessions.client_tcp_rtt,
          sessions.client_trust_score,
          sessions.is_eu_country,
          sessions.screen_resolution,
          sessions.device_memory,
          sessions.cpu_cores,
          sessions.connection_type,
          users.username,
          users.avatar,
          users.id as user_id,
          users.github_username,
          users.google_username,
          users.discord_username
        FROM sessions
        LEFT JOIN users ON sessions.user_id = users.id
        WHERE sessions.expires_at > ?
        ORDER BY sessions.last_active DESC
      `
        ).bind(Date.now()).all(),
        { results: [] }
      );
      usersList = await safeFetch(
        db.prepare(
          `
        WITH RankedSessions AS (
          SELECT
            *,
            ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY last_active DESC) as rn
          FROM sessions
        )
        SELECT
          users.*,
          rs.last_active,
          rs.ip_address,
          rs.city,
          rs.country,
          rs.screen_resolution,
          rs.device_memory,
          rs.cpu_cores,
          rs.connection_type
        FROM users
        LEFT JOIN RankedSessions rs ON users.id = rs.user_id AND rs.rn = 1
        ORDER BY users.rowid DESC
        LIMIT 100
      `
        ).all(),
        { results: [] }
      );
      edgeNodeStats = await safeFetch(
        db.prepare(
          `
        SELECT
          colo,
          COUNT(*) as session_count,
          AVG(client_tcp_rtt) as avg_rtt,
          country,
          continent
        FROM sessions
        WHERE expires_at > ? AND colo IS NOT NULL
        GROUP BY colo
        ORDER BY session_count DESC
      `
        ).bind(Date.now()).all(),
        { results: [] }
      );
      performanceSummary = await safeFetch(
        db.prepare(
          `
        SELECT
          AVG(client_tcp_rtt) as global_avg_rtt,
          MIN(client_tcp_rtt) as min_rtt,
          MAX(client_tcp_rtt) as max_rtt,
          COUNT(DISTINCT colo) as active_nodes
        FROM sessions
        WHERE expires_at > ? AND client_tcp_rtt IS NOT NULL
      `
        ).bind(Date.now()).first(),
        null
      );
    }
  } catch (e) {
    console.error("CRITICAL: Admin Dashboard Data Load Failed", e);
  }
  Astro2.response.headers.set(
    "Cache-Control",
    "no-cache, no-store, must-revalidate"
  );
  Astro2.response.headers.set("Pragma", "no-cache");
  Astro2.response.headers.set("Expires", "0");
  const COLO_LOCATIONS = {
    // North America - US West
    SJC: { city: "San Jose", country: "US", region: "California", flag: "🇺🇸" },
    LAX: {
      city: "Los Angeles",
      country: "US",
      region: "California",
      flag: "🇺🇸"
    },
    SFO: {
      city: "San Francisco",
      country: "US",
      region: "California",
      flag: "🇺🇸"
    },
    SEA: { city: "Seattle", country: "US", region: "Washington", flag: "🇺🇸" },
    PDX: { city: "Portland", country: "US", region: "Oregon", flag: "🇺🇸" },
    SAN: { city: "San Diego", country: "US", region: "California", flag: "🇺🇸" },
    PHX: { city: "Phoenix", country: "US", region: "Arizona", flag: "🇺🇸" },
    LAS: { city: "Las Vegas", country: "US", region: "Nevada", flag: "🇺🇸" },
    DEN: { city: "Denver", country: "US", region: "Colorado", flag: "🇺🇸" },
    SLC: { city: "Salt Lake City", country: "US", region: "Utah", flag: "🇺🇸" },
    // US Central
    ORD: { city: "Chicago", country: "US", region: "Illinois", flag: "🇺🇸" },
    DFW: { city: "Dallas", country: "US", region: "Texas", flag: "🇺🇸" },
    IAH: { city: "Houston", country: "US", region: "Texas", flag: "🇺🇸" },
    AUS: { city: "Austin", country: "US", region: "Texas", flag: "🇺🇸" },
    MSP: {
      city: "Minneapolis",
      country: "US",
      region: "Minnesota",
      flag: "🇺🇸"
    },
    MCI: { city: "Kansas City", country: "US", region: "Missouri", flag: "🇺🇸" },
    DTW: { city: "Detroit", country: "US", region: "Michigan", flag: "🇺🇸" },
    CMH: { city: "Columbus", country: "US", region: "Ohio", flag: "🇺🇸" },
    BNA: { city: "Nashville", country: "US", region: "Tennessee", flag: "🇺🇸" },
    // US East
    IAD: { city: "Ashburn", country: "US", region: "Virginia", flag: "🇺🇸" },
    EWR: { city: "Newark", country: "US", region: "New Jersey", flag: "🇺🇸" },
    BOS: { city: "Boston", country: "US", region: "Massachusetts", flag: "🇺🇸" },
    PHL: {
      city: "Philadelphia",
      country: "US",
      region: "Pennsylvania",
      flag: "🇺🇸"
    },
    ATL: { city: "Atlanta", country: "US", region: "Georgia", flag: "🇺🇸" },
    MIA: { city: "Miami", country: "US", region: "Florida", flag: "🇺🇸" },
    MCO: { city: "Orlando", country: "US", region: "Florida", flag: "🇺🇸" },
    CLT: {
      city: "Charlotte",
      country: "US",
      region: "N. Carolina",
      flag: "🇺🇸"
    },
    // Canada
    YYZ: { city: "Toronto", country: "CA", region: "Ontario", flag: "🇨🇦" },
    YVR: { city: "Vancouver", country: "CA", region: "BC", flag: "🇨🇦" },
    YUL: { city: "Montreal", country: "CA", region: "Quebec", flag: "🇨🇦" },
    // Mexico
    MEX: { city: "Mexico City", country: "MX", region: "CDMX", flag: "🇲🇽" },
    GDL: { city: "Guadalajara", country: "MX", region: "Jalisco", flag: "🇲🇽" },
    MTY: { city: "Monterrey", country: "MX", region: "Nuevo León", flag: "🇲🇽" },
    // Europe - West
    LHR: { city: "London", country: "GB", region: "England", flag: "🇬🇧" },
    MAN: { city: "Manchester", country: "GB", region: "England", flag: "🇬🇧" },
    DUB: { city: "Dublin", country: "IE", region: "Leinster", flag: "🇮🇪" },
    AMS: {
      city: "Amsterdam",
      country: "NL",
      region: "North Holland",
      flag: "🇳🇱"
    },
    BRU: { city: "Brussels", country: "BE", region: "Brussels", flag: "🇧🇪" },
    CDG: { city: "Paris", country: "FR", region: "Île-de-France", flag: "🇫🇷" },
    MRS: { city: "Marseille", country: "FR", region: "PACA", flag: "🇫🇷" },
    LYS: { city: "Lyon", country: "FR", region: "Auvergne", flag: "🇫🇷" },
    FRA: { city: "Frankfurt", country: "DE", region: "Hesse", flag: "🇩🇪" },
    MUC: { city: "Munich", country: "DE", region: "Bavaria", flag: "🇩🇪" },
    HAM: { city: "Hamburg", country: "DE", region: "Hamburg", flag: "🇩🇪" },
    ZRH: { city: "Zurich", country: "CH", region: "Zurich", flag: "🇨🇭" },
    // Europe - South
    MAD: { city: "Madrid", country: "ES", region: "Madrid", flag: "🇪🇸" },
    BCN: { city: "Barcelona", country: "ES", region: "Catalonia", flag: "🇪🇸" },
    LIS: { city: "Lisbon", country: "PT", region: "Lisbon", flag: "🇵🇹" },
    MXP: { city: "Milan", country: "IT", region: "Lombardy", flag: "🇮🇹" },
    FCO: { city: "Rome", country: "IT", region: "Lazio", flag: "🇮🇹" },
    ATH: { city: "Athens", country: "GR", region: "Attica", flag: "🇬🇷" },
    // Europe - North & East
    ARN: { city: "Stockholm", country: "SE", region: "Stockholm", flag: "🇸🇪" },
    CPH: { city: "Copenhagen", country: "DK", region: "Capital", flag: "🇩🇰" },
    OSL: { city: "Oslo", country: "NO", region: "Oslo", flag: "🇳🇴" },
    HEL: { city: "Helsinki", country: "FI", region: "Uusimaa", flag: "🇫🇮" },
    VIE: { city: "Vienna", country: "AT", region: "Vienna", flag: "🇦🇹" },
    WAW: { city: "Warsaw", country: "PL", region: "Mazovia", flag: "🇵🇱" },
    PRG: { city: "Prague", country: "CZ", region: "Prague", flag: "🇨🇿" },
    BUD: { city: "Budapest", country: "HU", region: "Budapest", flag: "🇭🇺" },
    SOF: { city: "Sofia", country: "BG", region: "Sofia", flag: "🇧🇬" },
    DME: { city: "Moscow", country: "RU", region: "Moscow", flag: "🇷🇺" },
    LED: {
      city: "St. Petersburg",
      country: "RU",
      region: "Leningrad",
      flag: "🇷🇺"
    },
    IST: { city: "Istanbul", country: "TR", region: "Istanbul", flag: "🇹🇷" },
    // Asia - East Asia
    NRT: { city: "Tokyo", country: "JP", region: "Kanto", flag: "🇯🇵" },
    KIX: { city: "Osaka", country: "JP", region: "Kansai", flag: "🇯🇵" },
    ICN: { city: "Seoul", country: "KR", region: "Seoul", flag: "🇰🇷" },
    HKG: { city: "Hong Kong", country: "HK", region: "Hong Kong", flag: "🇭🇰" },
    TPE: { city: "Taipei", country: "TW", region: "Taipei", flag: "🇹🇼" },
    // Southeast Asia
    SIN: { city: "Singapore", country: "SG", region: "Singapore", flag: "🇸🇬" },
    KUL: {
      city: "Kuala Lumpur",
      country: "MY",
      region: "Selangor",
      flag: "🇲🇾"
    },
    BKK: { city: "Bangkok", country: "TH", region: "Bangkok", flag: "🇹🇭" },
    MNL: { city: "Manila", country: "PH", region: "Metro Manila", flag: "🇵🇭" },
    CGK: { city: "Jakarta", country: "ID", region: "Jakarta", flag: "🇮🇩" },
    HAN: { city: "Hanoi", country: "VN", region: "Hanoi", flag: "🇻🇳" },
    SGN: { city: "Ho Chi Minh", country: "VN", region: "HCMC", flag: "🇻🇳" },
    // South Asia
    BOM: { city: "Mumbai", country: "IN", region: "Maharashtra", flag: "🇮🇳" },
    DEL: { city: "Delhi", country: "IN", region: "Delhi", flag: "🇮🇳" },
    BLR: { city: "Bangalore", country: "IN", region: "Karnataka", flag: "🇮🇳" },
    HYD: { city: "Hyderabad", country: "IN", region: "Telangana", flag: "🇮🇳" },
    MAA: { city: "Chennai", country: "IN", region: "Tamil Nadu", flag: "🇮🇳" },
    // Oceania
    SYD: { city: "Sydney", country: "AU", region: "NSW", flag: "🇦🇺" },
    MEL: { city: "Melbourne", country: "AU", region: "Victoria", flag: "🇦🇺" },
    BNE: { city: "Brisbane", country: "AU", region: "Queensland", flag: "🇦🇺" },
    PER: { city: "Perth", country: "AU", region: "WA", flag: "🇦🇺" },
    AKL: { city: "Auckland", country: "NZ", region: "Auckland", flag: "🇳🇿" },
    // Middle East & Africa
    DXB: { city: "Dubai", country: "AE", region: "Dubai", flag: "🇦🇪" },
    BAH: { city: "Bahrain", country: "BH", region: "Manama", flag: "🇧🇭" },
    DOH: { city: "Doha", country: "QA", region: "Doha", flag: "🇶🇦" },
    AMM: { city: "Amman", country: "JO", region: "Amman", flag: "🇯🇴" },
    TLV: { city: "Tel Aviv", country: "IL", region: "Tel Aviv", flag: "🇮🇱" },
    CAI: { city: "Cairo", country: "EG", region: "Cairo", flag: "🇪🇬" },
    JNB: { city: "Johannesburg", country: "ZA", region: "Gauteng", flag: "🇿🇦" },
    CPT: {
      city: "Cape Town",
      country: "ZA",
      region: "Western Cape",
      flag: "🇿🇦"
    },
    NBO: { city: "Nairobi", country: "KE", region: "Nairobi", flag: "🇰🇪" },
    LOS: { city: "Lagos", country: "NG", region: "Lagos", flag: "🇳🇬" },
    // South America
    GRU: { city: "São Paulo", country: "BR", region: "São Paulo", flag: "🇧🇷" },
    GIG: { city: "Rio de Janeiro", country: "BR", region: "Rio", flag: "🇧🇷" },
    SCL: { city: "Santiago", country: "CL", region: "Santiago", flag: "🇨🇱" },
    BOG: { city: "Bogotá", country: "CO", region: "Bogotá", flag: "🇨🇴" },
    LIM: { city: "Lima", country: "PE", region: "Lima", flag: "🇵🇪" },
    EZE: {
      city: "Buenos Aires",
      country: "AR",
      region: "Buenos Aires",
      flag: "🇦🇷"
    }
  };
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Dashboard - Ichimaru Gin" }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "AdminDashboardOverview", $$AdminDashboardOverview, { "postCount": postCount, "userCount": userCount, "activeSessionCount": activeSessionCount, "performanceSummary": performanceSummary })} ${renderComponent($$result2, "AdminSignalLog", $$AdminSignalLog, { "recentPosts": recentPosts })}  ${maybeRenderHead()}<div class="glass-panel p-8 rounded-3xl"> <h2 class="text-2xl font-bold mb-6">Transmission Uplink</h2> <!-- Quick Publish via File --> <div class="mb-12 p-6 rounded-2xl bg-white/5 border border-white/10"> <h3 class="text-lg font-bold mb-4 flex items-center gap-2"> <span class="i-heroicons-document-arrow-up"></span>
Direct Uplink (File)
</h3> <p class="text-sm text-gray-400 mb-4">
Upload <code>.md</code> or <code>.rtf</code> files to publish immediately.
</p> <div class="flex items-center gap-4"> <input type="file" id="quick-publish-file" accept=".md,.markdown,.rtf,.txt" class="block w-full text-sm text-gray-400
            file:mr-4 file:py-2 file:px-4
            file:rounded-full file:border-0
            file:text-xs file:font-bold
            file:bg-brand-accent/10 file:text-brand-accent
            hover:file:bg-brand-accent/20"> <button id="quick-publish-btn" class="px-5 py-2 whitespace-nowrap rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 text-white font-medium transition-colors flex items-center gap-2"> <span class="i-heroicons-paper-airplane"></span>
Publish
</button> </div> <div id="quick-publish-status" class="mt-3 text-sm hidden"></div> </div> <form id="create-post-form" class="space-y-6"> <input type="hidden" name="id" id="post-id"> <div class="grid grid-cols-3 gap-6"> <div> <label class="block text-sm text-gray-400 mb-2 font-mono">SIGNAL_TITLE</label> <input type="text" name="title" id="title-input" required class="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-accent transition-colors text-white"> </div> <div> <label class="block text-sm text-gray-400 mb-2 font-mono">SIGNAL_SLUG</label> <input type="text" name="slug" id="slug-input" required class="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-accent transition-colors text-white"> </div> <div> <label class="block text-sm text-gray-400 mb-2 font-mono">PUBLISHED_AT</label> <input type="datetime-local" name="publishedAt" id="published-at-input" class="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-accent transition-colors text-white calendar-picker-indicator:invert"> <p class="text-xs text-gray-500 mt-1">
Set a past or future date to override publication time
</p> </div> </div> <div class="grid grid-cols-2 gap-6"> <div> <label class="block text-sm text-gray-400 mb-2 font-mono">UPDATED_AT</label> <div class="flex items-center gap-4"> <input type="datetime-local" name="updatedAt" id="updated-at-input" class="grow bg-black/40 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-brand-accent transition-colors text-white disabled:opacity-50" disabled> <label class="flex items-center gap-2 cursor-pointer group"> <input type="checkbox" id="auto-update-toggle" checked class="w-5 h-5 rounded border-white/20 bg-white/5 text-brand-accent focus:ring-brand-accent focus:ring-offset-0 transition-all"> <span class="text-xs text-gray-400 group-hover:text-gray-200 transition-colors">Auto-Update</span> </label> </div> <p class="text-xs text-gray-500 mt-1">
Manually override modification time or keep it automatic
</p> </div> </div> </form> <!-- Markdown Editor with Toolbar --> <div class="border border-white/10 rounded-xl overflow-hidden bg-black/20"> <div class="flex items-center gap-2 p-2 border-b border-white/10 bg-white/5"> <button type="button" class="p-2 hover:bg-white/10 rounded-lg text-gray-400 hover:text-white transition-colors" title="Bold">B</button> <button type="button" class="p-2 hover:bg-white/10 rounded-lg text-gray-400 hover:text-white transition-colors" title="Italic">I</button> <div class="w-px h-6 bg-white/10 mx-2"></div> <button type="button" id="upload-btn" class="flex items-center gap-2 px-3 py-1.5 hover:bg-white/10 rounded-lg text-gray-400 hover:text-white transition-colors text-sm" title="Upload to R2 (Standard)"> <span class="i-heroicons-document-arrow-up"></span>
File
</button> <button type="button" id="upload-cf-image-btn" class="flex items-center gap-2 px-3 py-1.5 hover:bg-white/10 rounded-lg text-brand-accent hover:text-brand-accent/80 transition-colors text-sm" title="Upload to Cloudflare Images"> <span class="i-heroicons-photo"></span>
CF Image
</button> <button type="button" id="upload-cf-video-btn" class="flex items-center gap-2 px-3 py-1.5 hover:bg-white/10 rounded-lg text-brand-accent hover:text-brand-accent/80 transition-colors text-sm" title="Upload to Cloudflare Stream"> <span class="i-heroicons-video-camera"></span>
CF Video
</button> <input type="file" id="file-input" class="hidden" accept="image/*, .gif, .ppt, .pptx, .doc, .docx, .xls, .xlsx, .csv"> <input type="file" id="cf-image-input" class="hidden" accept="image/*"> <input type="file" id="cf-video-input" class="hidden" accept="video/mp4,video/quicktime,video/webm"> </div> <textarea id="content-area" name="content" form="create-post-form" rows="15" required class="w-full bg-transparent p-4 focus:outline-none font-mono text-sm leading-relaxed resize-y" placeholder="Initiate transmission..."></textarea> </div> <div class="flex items-center gap-4"> <button type="submit" form="create-post-form" class="relative z-10 flex-1 py-4 rounded-xl bg-linear-to-r from-brand-primary to-brand-accent hover:opacity-90 hover:scale-[1.01] active:scale-[0.98] text-white font-bold tracking-wider transition-all cursor-pointer shadow-lg hover:shadow-brand-accent/25">
BROADCAST SIGNAL
</button> <button type="button" id="delete-current-btn" class="hidden px-6 py-4 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 font-bold tracking-wider transition-colors"> <span class="i-heroicons-trash w-5 h-5"></span> </button> </div> <div id="status" class="hidden p-4 rounded-xl text-center text-sm"></div> </div>  <div id="success-modal" class="fixed inset-0 z-50 hidden items-center justify-center p-4 bg-black/90 backdrop-blur-md opacity-0 transition-opacity duration-300 pointer-events-none"> <div class="relative w-full max-w-lg flex flex-col items-center"> <!-- Glitch/Success Effect (Like 404) --> <div class="relative mb-8 transform scale-90 md:scale-100 transition-transform duration-300 delay-100 pointer-events-none"> <h1 class="text-9xl font-display font-bold text-transparent bg-clip-text bg-linear-to-b from-white to-white/10 opacity-20 select-none">
200
</h1> <div class="absolute inset-0 flex items-center justify-center"> <h2 class="text-4xl md:text-5xl font-bold font-display text-green-400 drop-shadow-[0_0_15px_rgba(74,222,128,0.5)] animate-pulse flex items-center justify-center gap-3 whitespace-nowrap"> <span class="i-heroicons-check-circle text-5xl"></span> <span>Signal Live!</span> </h2> </div> </div> <div class="glass-panel p-8 md:p-12 rounded-3xl w-full text-center transform scale-95 transition-transform duration-300 border border-white/10 shadow-2xl"> <p class="text-xl md:text-2xl font-medium text-white mb-4">
Transmission Successful
</p> <p class="text-gray-400 font-mono text-sm leading-relaxed mb-8">
The signal has been injected into the network stream.<br>
All systems operational.
</p> <div class="flex flex-col gap-4 items-center w-full"> <a id="verify-signal-btn" href="#" target="_blank" class="group relative w-full py-4 rounded-xl bg-linear-to-r from-brand-primary to-brand-accent hover:opacity-90 text-white font-bold transition-all flex items-center justify-center gap-2 overflow-hidden shadow-[0_0_20px_rgba(139,92,246,0.3)] hover:shadow-[0_0_30px_rgba(139,92,246,0.5)]"> <div class="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div> <span class="relative z-10">Verify Signal</span> <span class="i-heroicons-arrow-top-right-on-square w-5 h-5 relative z-10 group-hover:translate-x-1 transition-transform"></span> </a> <button id="return-uplink-btn" class="group relative w-full py-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/30 text-gray-400 hover:text-white transition-all flex items-center justify-center gap-2"> <span class="i-heroicons-arrow-path w-5 h-5 group-hover:-rotate-180 transition-transform duration-500"></span> <span>Return to Uplink</span> </button> </div> </div> </div> </div>  <div id="active-sessions-modal" class="fixed inset-0 z-50 hidden items-center justify-center p-4 bg-black/60 backdrop-blur-sm opacity-0 transition-all duration-300 pointer-events-none"> <div class="glass-panel w-full max-w-6xl max-h-[85vh] flex flex-col rounded-3xl overflow-hidden border border-white/10 shadow-2xl relative transform scale-95 transition-all duration-300"> <!-- Close Button --> <button class="close-inspect-btn absolute top-4 right-4 w-6 h-6 flex items-center justify-center rounded-full bg-red-500/10 hover:bg-red-500/20 text-gray-400 hover:text-red-400 transition-all duration-200 z-20"> <span class="i-heroicons-x-mark w-6 h-6"></span> </button> <!-- Header --> <div class="p-6 border-b border-white/10 bg-black/40 flex justify-between items-center"> <div class="flex items-center gap-3"> <span class="i-heroicons-globe-alt w-6 h-6 text-green-400"></span> <h2 class="text-xl font-bold font-display">
Active Network Sessions
</h2> </div> <!-- Logout All Button --> <button id="logout-all-btn" class="mr-12 px-4 py-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 text-sm font-bold flex items-center gap-2 transition-all"> <span class="i-heroicons-power w-4 h-4"></span>
Logout All Users
</button> </div> <!-- Content --> <div class="overflow-y-auto p-0 scrollbar-hide flex-1 bg-black/20 relative" style="overscroll-behavior: contain;"> <div class="p-6 bg-brand-primary/5 border-b border-white/5 text-sm text-gray-400 font-mono">
Monitoring <span class="text-white font-bold">${(activeSessionsList.results || []).length}</span> active connections
</div> <table class="w-full text-left border-collapse"> <thead class="sticky top-0 bg-black/95 backdrop-blur-xl z-10"> <tr class="text-gray-400 text-xs uppercase tracking-wider font-mono border-b border-white/10"> <th class="p-6 font-normal">User</th> <th class="p-6 font-normal">Network & ISP</th> <th class="p-6 font-normal">Location</th> <th class="p-6 font-normal">Connection</th> <th class="p-6 font-normal text-right">Status</th> </tr> </thead> <tbody class="text-sm divide-y divide-white/5"> ${(activeSessionsList.results || []).map(
    (s) => {
      const trustScore = s.client_trust_score;
      const isLowTrust = trustScore && trustScore < 30;
      const rtt = s.client_tcp_rtt;
      const rttClass = rtt ? rtt < 50 ? "text-green-400" : rtt < 150 ? "text-yellow-400" : "text-red-400" : "text-gray-500";
      return renderTemplate`<tr class="hover:bg-white/5 transition-colors"> <td class="p-6"> <div class="flex items-center gap-3"> <img${addAttribute(
        s.avatar || `https://ui-avatars.com/api/?name=${s.username || "?"}&background=random`,
        "src"
      )} class="w-10 h-10 rounded-full border border-white/10"> <div> <div class="font-bold text-white flex items-center gap-2"> ${s.username || "Unknown"} ${isLowTrust && renderTemplate`<span class="px-2 py-0.5 rounded text-[10px] bg-red-500/20 border border-red-500/40 text-red-300 uppercase tracking-wide font-bold">
VPN?
</span>`} </div> <div class="text-xs text-gray-500 font-mono">
SID:${" "} ${s.session_id.substring(
        0,
        8
      )} </div>  <div class="ua-parser-container mt-1 text-xs"${addAttribute(
        s.user_agent,
        "data-ua"
      )}></div> </div> </div> </td> <td class="p-6"> <div class="space-y-2">  <div class="font-mono text-xs text-brand-accent bg-brand-accent/10 px-2 py-1 rounded inline-block border border-brand-accent/20"> ${s.ip_address || "Hidden"} </div>  ${s.as_organization && renderTemplate`<div class="text-xs text-white flex items-center gap-1"> <span class="i-heroicons-building-office-2 w-3 h-3 text-purple-400"></span> <span> ${s.as_organization} </span> ${s.asn && renderTemplate`<span class="text-gray-500 ml-1">
(AS${s.asn})
</span>`} </div>`}  ${s.colo && renderTemplate`<div class="text-xs text-gray-400 flex items-center gap-1"> <span class="i-heroicons-server w-3 h-3"></span> <span>
Edge: ${s.colo} </span> </div>`} </div> </td> <td class="p-6"> <div class="space-y-1 text-xs">  <div class="text-white font-medium flex items-center gap-1"> <span class="i-heroicons-map-pin w-3 h-3 text-green-400"></span> ${s.country || "??"}${" "} ${s.city && `• ${s.city}`} </div>  ${s.region && renderTemplate`<div class="text-gray-400"> ${s.region}${" "} ${s.region_code && `(${s.region_code})`} </div>`}  ${s.timezone && renderTemplate`<div class="text-gray-500 flex items-center gap-1"> <span class="i-heroicons-clock w-3 h-3"></span> ${s.timezone} </div>`}  ${s.latitude && s.longitude && renderTemplate`<div class="text-gray-600 font-mono text-[10px]"> ${s.latitude},${" "} ${s.longitude} </div>`} </div> </td> <td class="p-6"> <div class="space-y-1.5 text-xs">  ${s.http_protocol && renderTemplate`<div class="flex items-center gap-1.5"> <span class="i-heroicons-signal w-3 h-3 text-blue-400"></span> <span class="text-white font-medium"> ${s.http_protocol} </span> </div>`}  ${s.tls_version && renderTemplate`<div class="flex items-center gap-1.5"> <span class="i-heroicons-lock-closed w-3 h-3 text-green-400"></span> <span class="text-gray-400"> ${s.tls_version} </span> </div>`}  ${rtt && renderTemplate`<div${addAttribute(`flex items-center gap-1.5 ${rttClass}`, "class")}> <span class="i-heroicons-bolt w-3 h-3"></span> <span>${rtt}ms</span> </div>`}  ${trustScore && renderTemplate`<div class="text-gray-500 font-mono text-[10px]">
Trust: ${trustScore}
/99
</div>`}  ${(s.screen_resolution || s.device_memory || s.cpu_cores) && renderTemplate`<div class="pt-2 mt-2 border-t border-white/5 space-y-1"> ${s.screen_resolution && renderTemplate`<div class="flex items-center gap-1.5 text-gray-400"> <span class="i-heroicons-computer-desktop w-3 h-3"></span> <span> ${s.screen_resolution} </span> </div>`} <div class="flex items-center gap-2 text-gray-500 font-mono text-[10px]"> ${s.cpu_cores && renderTemplate`<span> ${s.cpu_cores}${" "}
Cores
</span>`} ${s.device_memory && renderTemplate`<span> ${s.device_memory}
GB RAM
</span>`} ${s.connection_type && renderTemplate`<span class="uppercase border border-white/10 px-1 rounded"> ${s.connection_type} </span>`} </div> </div>`} </div> </td> <td class="p-6 text-right"> <div class="text-white font-mono text-sm"> ${s.last_active ? new Date(
        s.last_active
      ).toLocaleTimeString(
        "en-SG",
        {
          hour12: false
        }
      ) : "N/A"} </div> <div class="text-xs text-gray-500 mt-1">
Since:${" "} ${s.session_created ? new Date(
        s.session_created
      ).toLocaleDateString() : "?"} </div> </td> </tr>`;
    }
  )} </tbody> </table> </div> </div> </div>  <div id="user-database-modal" class="fixed inset-0 z-50 hidden items-center justify-center p-4 bg-black/60 backdrop-blur-sm opacity-0 transition-all duration-300 pointer-events-none"> <div class="glass-panel w-full max-w-6xl max-h-[85vh] flex flex-col rounded-3xl overflow-hidden border border-white/10 shadow-2xl relative transform scale-95 transition-all duration-300"> <!-- Close Button --> <button class="close-inspect-btn absolute top-4 right-4 w-6 h-6 flex items-center justify-center rounded-full bg-red-500/10 hover:bg-red-500/20 text-gray-400 hover:text-red-400 transition-all duration-200 z-20"> <span class="i-heroicons-x-mark w-6 h-6"></span> </button> <!-- Header --> <div class="p-6 border-b border-white/10 bg-black/40 flex items-center gap-3"> <span class="i-heroicons-users w-6 h-6 text-brand-accent"></span> <h2 class="text-xl font-bold font-display">User Database</h2> </div> <!-- Content --> <div class="overflow-y-auto p-0 scrollbar-hide flex-1 bg-black/20 relative" style="overscroll-behavior: contain;"> <div class="p-6 bg-brand-accent/5 border-b border-white/5 text-sm text-gray-400 font-mono">
Found <span class="text-white font-bold">${(usersList.results || []).length}</span> records (showing latest 100)
</div> <table class="w-full text-left border-collapse"> <thead class="sticky top-0 bg-black/95 backdrop-blur-xl z-10 box-decoration-clone"> <tr class="text-gray-400 text-xs uppercase tracking-wider font-mono border-b border-white/10"> <th class="p-6 font-normal">User</th> <th class="p-6 font-normal">Identity Provider</th> <th class="p-6 font-normal">IDs</th> <th class="p-6 font-normal">Last Seen</th> <th class="p-6 font-normal text-right">Joined</th> </tr> </thead> <tbody class="text-sm divide-y divide-white/5"> ${(usersList.results || []).map((u) => renderTemplate`<tr class="hover:bg-white/5 transition-colors"> <td class="p-6"> <div class="flex items-center gap-3"> <img${addAttribute(
    u.avatar || `https://ui-avatars.com/api/?name=${u.username}&background=random`,
    "src"
  )} class="w-10 h-10 rounded-full object-cover border border-white/10"> <div> <div class="font-bold text-white mb-0.5"> ${u.username} </div> <div class="text-xs text-brand-accent/80 font-mono"> ${u.id.substring(0, 8)}...
</div> </div> </div> </td> <td class="p-6"> <div class="flex gap-2"> ${u.github_id && renderTemplate`<span class="px-2 py-1 rounded bg-[#24292e]/50 border border-[#24292e]/50 text-xs text-gray-300 flex items-center gap-1"> <span class="i-simple-icons-github"></span>${" "}
GitHub
</span>`} ${u.google_id && renderTemplate`<span class="px-2 py-1 rounded bg-[#DB4437]/20 border border-[#DB4437]/30 text-xs text-red-200 flex items-center gap-1"> <span class="i-simple-icons-google"></span>${" "}
Google
</span>`} ${u.discord_id && renderTemplate`<span class="px-2 py-1 rounded bg-[#5865F2]/20 border border-[#5865F2]/30 text-xs text-indigo-200 flex items-center gap-1"> <span class="i-simple-icons-discord"></span>${" "}
Discord
</span>`} </div> </td> <td class="p-6 font-mono text-xs text-gray-500 space-y-1"> ${u.github_username && renderTemplate`<div class="flex items-center gap-2"> <span class="i-simple-icons-github w-4 h-4"></span> <span>${u.github_username}</span> </div>`} ${u.google_username && renderTemplate`<div class="flex items-center gap-2"> <span class="i-simple-icons-google w-4 h-4"></span> <span>${u.google_username}</span> </div>`} ${u.discord_username && renderTemplate`<div class="flex items-center gap-2"> <span class="i-simple-icons-discord w-4 h-4"></span> <span> ${u.discord_username} </span> </div>`} </td> <td class="p-6"> <div class="space-y-2"> ${u.last_active ? renderTemplate`${renderComponent($$result2, "Fragment", Fragment, {}, { "default": async ($$result3) => renderTemplate` <div class="space-y-1 border-b border-white/5 pb-2 mb-2"> <div class="text-white font-medium text-xs"> ${new Date(
    u.last_active
  ).toLocaleString(
    "en-SG",
    {
      timeZone: "Asia/Singapore",
      hour12: false
    }
  )} </div> <div class="text-xs text-gray-400 flex items-center gap-1.5"> <span class="i-heroicons-map-pin w-3 h-3 text-brand-accent"></span> <span> ${u.city || "?"},${" "} ${u.country || "?"} </span> </div> <div class="text-[10px] font-mono text-gray-500 bg-white/5 px-1.5 py-0.5 rounded inline-block"> ${u.ip_address || "Hidden IP"} </div> ${u.as_organization && renderTemplate`<div class="text-[10px] text-gray-500 truncate max-w-[150px]"${addAttribute(
    u.as_organization,
    "title"
  )}> ${u.as_organization} </div>`}  <div class="flex flex-wrap items-center gap-2 mt-1.5">  ${u.connection_type && renderTemplate`<span class="flex items-center gap-1 text-[10px] text-blue-300 bg-blue-500/10 border border-blue-500/20 px-1.5 py-0.5 rounded font-mono uppercase tracking-wider"> <span class="i-heroicons-signal w-3 h-3"></span> ${u.connection_type} </span>`}  ${u.client_trust_score && u.client_trust_score < 30 ? renderTemplate`<span class="flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] bg-red-500/20 border border-red-500/30 text-red-300 font-bold uppercase tracking-wider"> <span class="i-heroicons-shield-exclamation w-3 h-3"></span>
VPN
</span>` : u.client_trust_score ? renderTemplate`<span class="flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] bg-green-500/10 border border-green-500/20 text-green-400 font-mono"> <span class="i-heroicons-shield-check w-3 h-3"></span>
Clean
</span>` : null}  ${u.client_tcp_rtt != null && renderTemplate`<span${addAttribute(`flex items-center gap-1 text-[10px] font-mono px-1.5 py-0.5 rounded border ${u.client_tcp_rtt < 50 ? "border-green-500/20 text-green-400 bg-green-500/5" : "border-yellow-500/20 text-yellow-400 bg-yellow-500/5"}`, "class")}> <span class="i-heroicons-bolt w-3 h-3"></span> ${u.client_tcp_rtt}
ms
</span>`}  ${u.tls_version && renderTemplate`<span class="text-[10px] text-gray-500 border border-white/10 px-1.5 py-0.5 rounded bg-white/5"> ${u.tls_version} </span>`} </div> </div> <div class="ua-parser-container hidden"${addAttribute(u.user_agent, "data-ua")}></div> ` })}` : renderTemplate`<span class="text-xs text-gray-600 italic">
Never
</span>`} </div> </td> <td class="p-6 text-right text-gray-400 font-mono text-xs"> ${(() => {
    const ownerGithubId = 181828834;
    const ownerGoogleId = "";
    const ownerDiscordId = "";
    const isOwner = u.github_id === ownerGithubId || ownerGoogleId !== "" || ownerDiscordId !== "";
    if (isOwner) {
      return renderTemplate`<span class="text-brand-accent font-bold px-2 py-0.5 rounded bg-brand-accent/10 border border-brand-accent/20">
👑 Creator
</span>`;
    }
    if (u.created_at) {
      return new Date(
        typeof u.created_at === "number" ? u.created_at : parseInt(
          u.created_at
        ) || 0
      ).toLocaleString("en-SG", {
        timeZone: "Asia/Singapore",
        dateStyle: "medium"
      });
    }
    return renderTemplate`<span class="opacity-50">
Jan 31, 2026
</span>`;
  })()} </td> </tr>`)} </tbody> </table> </div> </div> </div>  <div id="edge-analytics-modal" class="fixed inset-0 z-50 hidden items-center justify-center p-4 bg-black/90 backdrop-blur-md opacity-0 transition-opacity duration-300 pointer-events-none"> <div class="glass-panel p-0 rounded-3xl max-w-6xl w-full max-h-[90vh] overflow-hidden flex flex-col scale-95 transition-transform duration-300 relative"> <!-- Close Button (Consistent with other modals) --> <button class="close-inspect-btn absolute top-4 right-4 w-6 h-6 flex items-center justify-center rounded-full bg-red-500/10 hover:bg-red-500/20 text-gray-400 hover:text-red-400 transition-all duration-200 z-20"> <span class="i-heroicons-x-mark w-6 h-6"></span> </button> <!-- Header --> <div class="p-6 border-b border-white/10 bg-black/40"> <h2 class="text-3xl font-display font-bold flex items-center gap-3"> <span class="i-heroicons-server w-8 h-8 text-blue-400"></span>
Edge Analytics
</h2> <p class="text-gray-400 mt-1">
Cloudflare node distribution & routing
</p> </div> <!-- Content --> <div class="overflow-y-auto p-6 scrollbar-hide flex-1 bg-black/20" style="overscroll-behavior: contain;"> <div class="grid grid-cols-4 gap-4 mb-8"> <div class="glass-panel p-4 rounded-xl"> <div class="text-xs text-gray-400 mb-1">
Active Nodes
</div> <div class="text-2xl font-bold text-blue-400"> ${performanceSummary?.active_nodes || 0} </div> </div> <div class="glass-panel p-4 rounded-xl"> <div class="text-xs text-gray-400 mb-1">Avg RTT</div> <div class="text-2xl font-bold text-green-400"> ${Math.round(
    Number(
      performanceSummary?.global_avg_rtt || 0
    )
  )}ms
</div> </div> <div class="glass-panel p-4 rounded-xl"> <div class="text-xs text-gray-400 mb-1">Min RTT</div> <div class="text-2xl font-bold text-green-300"> ${Math.round(
    Number(performanceSummary?.min_rtt || 0)
  )}ms
</div> </div> <div class="glass-panel p-4 rounded-xl"> <div class="text-xs text-gray-400 mb-1">Max RTT</div> <div class="text-2xl font-bold text-orange-400"> ${Math.round(
    Number(performanceSummary?.max_rtt || 0)
  )}ms
</div> </div> </div> <div class="overflow-x-auto"> <table class="w-full"> <thead class="border-b border-white/10"> <tr class="text-left text-xs uppercase tracking-wider text-gray-400"> <th class="p-4">Node</th> <th class="p-4">Location</th> <th class="p-4 text-right">Sessions</th> <th class="p-4 text-right">Avg RTT</th> <th class="p-4 text-right">Performance</th> </tr> </thead> <tbody class="text-sm divide-y divide-white/5"> ${(edgeNodeStats.results || []).map(
    (node) => {
      const location = COLO_LOCATIONS[node.colo] || {
        city: node.colo,
        country: "??",
        flag: "🌐",
        region: ""
      };
      const avgRtt = Math.round(
        node.avg_rtt || 0
      );
      const rttColor = avgRtt < 50 ? "text-green-400" : avgRtt < 150 ? "text-yellow-400" : "text-red-400";
      const percentage = (node.session_count / (activeSessionCount ?? 1) * 100).toFixed(1);
      return renderTemplate`<tr class="hover:bg-white/5 transition-colors"> <td class="p-4"> <div class="font-mono font-bold text-blue-400"> ${node.colo} </div> </td> <td class="p-4"> <div class="flex items-center gap-2"> <span class="text-2xl"> ${location.flag} </span> <div> <div class="font-semibold"> ${location.city} </div> <div class="text-xs text-gray-500"> ${location.region}
,${" "} ${location.country} </div> </div> </div> </td> <td class="p-4 text-right"> <div class="font-bold"> ${node.session_count} </div> <div class="text-xs text-gray-500"> ${percentage}%
</div> </td> <td${addAttribute(`p-4 text-right font-mono font-bold ${rttColor}`, "class")}> ${avgRtt}ms
</td> <td class="p-4 text-right"> ${avgRtt < 50 && renderTemplate`<span class="px-2 py-1 rounded bg-green-500/20 text-green-300 text-xs">
Excellent
</span>`} ${avgRtt >= 50 && avgRtt < 150 && renderTemplate`<span class="px-2 py-1 rounded bg-yellow-500/20 text-yellow-300 text-xs">
Good
</span>`} ${avgRtt >= 150 && renderTemplate`<span class="px-2 py-1 rounded bg-red-500/20 text-red-300 text-xs">
Poor
</span>`} </td> </tr>`;
    }
  )} </tbody> </table> </div> ${(edgeNodeStats.results || []).some(
    (node) => Math.round(node.avg_rtt || 0) > 150
  ) && renderTemplate`<div class="mt-6 p-4 rounded-xl bg-orange-500/10 border border-orange-500/30"> <div class="flex items-start gap-3"> <span class="i-heroicons-exclamation-triangle w-6 h-6 text-orange-400 shrink-0 mt-0.5"></span> <div> <div class="font-bold text-orange-300 mb-1">
Routing Anomalies Detected
</div> <div class="text-sm text-gray-300">
High latency detected (&gt;150ms).
                                        Possible causes: suboptimal routing, VPN
                                        usage, or network congestion.
</div> </div> </div> </div>`} </div> </div> </div> ${renderScript($$result2, "D:/coding/claude/_ginsbuild/src/pages/IchimaruGin728/admin/index.astro?astro&type=script&index=0&lang.ts")} ` })}`;
}, "D:/coding/claude/_ginsbuild/src/pages/IchimaruGin728/admin/index.astro", void 0);
const $$file = "D:/coding/claude/_ginsbuild/src/pages/IchimaruGin728/admin/index.astro";
const $$url = "/IchimaruGin728/admin";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

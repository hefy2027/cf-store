globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { g as getDb, u as users, e as eq } from "./db_XAr9wiDM.mjs";
import { c as getGithub, s as sanitizeRedirectTarget } from "./redirect_BKbNLFHX.mjs";
import { v as validateSessionToken, g as generateSessionToken, c as createSession } from "./session_DWbC8nF0.mjs";
const GET = async ({
  request,
  cookies,
  redirect
}) => {
  const env$1 = env;
  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const storedState = cookies.get("github_oauth_state")?.value ?? null;
  if (!code || !state || !storedState || state !== storedState) {
    return new Response(null, {
      status: 400
    });
  }
  try {
    console.log("Validating GitHub code...");
    const tokens = await getGithub(env$1).validateAuthorizationCode(code);
    const accessToken = tokens.accessToken();
    console.log("Tokens received:", accessToken ? "Present" : "Missing");
    let githubUser;
    try {
      console.log("Fetching GitHub user...");
      const githubUserResponse = await fetch("https://api.github.com/user", {
        headers: {
          Authorization: `Bearer ${accessToken.trim()}`,
          "User-Agent": "Gins-Blog-OAuth-App",
          Accept: "application/vnd.github+json"
        }
      });
      if (!githubUserResponse.ok) {
        const errorText = await githubUserResponse.text();
        console.error("GitHub API error:", githubUserResponse.status, errorText);
        throw new Error(`GitHub API returned ${githubUserResponse.status}: ${errorText.slice(0, 200)}`);
      }
      githubUser = await githubUserResponse.json();
      console.log("GitHub User fetched:", githubUser.login, "Avatar:", githubUser.avatar_url);
    } catch (fetchError) {
      throw new Error(`Failed to fetch GitHub user: ${fetchError.message}`);
    }
    const db = getDb(env$1);
    const existingSessionToken = cookies.get("session")?.value;
    let currentUserId = null;
    if (existingSessionToken) {
      const sessionResult = await validateSessionToken(existingSessionToken, db, env$1);
      if (sessionResult.session && sessionResult.user) {
        currentUserId = sessionResult.user.id;
        console.log("User is already logged in, linking GitHub account to user:", currentUserId);
      }
    }
    const existingUser = await db.select().from(users).where(eq(users.githubId, githubUser.id)).get();
    let userId = "";
    if (currentUserId) {
      if (existingUser && existingUser.id !== currentUserId) {
        throw new Error("This GitHub account is already linked to another user account.");
      }
      await db.update(users).set({
        githubId: githubUser.id,
        githubUsername: githubUser.login,
        githubAvatar: githubUser.avatar_url
      }).where(eq(users.id, currentUserId));
      userId = currentUserId;
      console.log("GitHub account linked to existing user:", userId);
    } else if (existingUser) {
      userId = existingUser.id;
      console.log("Logging in as existing GitHub user:", userId);
    } else {
      userId = crypto.randomUUID();
      await db.insert(users).values({
        id: userId,
        githubId: githubUser.id,
        username: githubUser.login,
        createdAt: Date.now(),
        githubUsername: githubUser.login,
        githubAvatar: githubUser.avatar_url
      });
      console.log("Created new user with GitHub:", userId);
    }
    console.log("Creating session, userId:", userId);
    const token = generateSessionToken();
    const session = await createSession(token, userId, db, env$1, request);
    console.log("Setting session cookie...");
    cookies.set("session", token, {
      path: "/",
      httpOnly: true,
      sameSite: "lax",
      secure: true,
      expires: new Date(session.expiresAt)
    });
    const redirectUrl = sanitizeRedirectTarget(cookies.get("login_redirect")?.value);
    cookies.delete("github_oauth_state", {
      path: "/"
    });
    cookies.delete("login_redirect", {
      path: "/"
    });
    return redirect(redirectUrl);
  } catch (e) {
    console.error(e);
    cookies.delete("github_oauth_state", {
      path: "/"
    });
    cookies.delete("login_redirect", {
      path: "/"
    });
    return new Response("Login failed", {
      status: 500
    });
  }
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  GET
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

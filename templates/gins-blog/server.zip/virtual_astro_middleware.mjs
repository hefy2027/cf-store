globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { aA as defineMiddleware, aJ as sequence } from "./chunks/sequence_C6JDRbfE.mjs";
import { g as getDb } from "./chunks/db_XAr9wiDM.mjs";
import { v as validateSessionToken } from "./chunks/session_DWbC8nF0.mjs";
import { g as getZeroTrustUser } from "./chunks/zerotrust_D95vk573.mjs";
const onRequest$1 = defineMiddleware(async (context, next) => {
  context.locals.user = null;
  context.locals.session = null;
  const pathname = context.url.pathname;
  const isPrerenderedDocsRoute = pathname.startsWith("/docs") || pathname.startsWith("/zh/docs");
  if (isPrerenderedDocsRoute) {
    return next();
  }
  const token = context.cookies.get("session")?.value ?? null;
  const env$1 = env;
  if (pathname.includes("/privacy")) {
    return next();
  }
  const db = env$1?.DB ? getDb(env$1) : null;
  const isPublicGet = context.request.method === "GET" && !token && !context.url.pathname.startsWith("/IchimaruGin728") && !context.url.pathname.startsWith("/api") && !context.url.pathname.startsWith("/login");
  if (isPublicGet) {
    const cacheKey = context.url.href;
    if (env$1?.GIN_KV) {
      try {
        const cachedHtml = await env$1.GIN_KV.get(cacheKey);
        if (cachedHtml) {
          return new Response(cachedHtml, {
            headers: {
              "Content-Type": "text/html;charset=UTF-8",
              "X-Cache": "HIT"
            }
          });
        }
      } catch (e) {
        console.error("KV Cache Error:", e);
      }
    }
  }
  if (context.url.pathname.startsWith("/IchimaruGin728/admin") || context.url.pathname.startsWith("/api/admin")) {
    const ztUser = getZeroTrustUser(context.request);
    if (!ztUser) {
      return new Response("Unauthorized - Zero Trust Access Required", {
        status: 401
      });
    }
  }
  if (token === null) {
    return next();
  }
  if (!db) {
    console.warn("Middleware: DB not available, skipping session validation");
    return next();
  }
  const {
    user,
    session
  } = await validateSessionToken(token, db, env$1, context.request);
  context.locals.session = session;
  context.locals.user = user;
  return next();
});
const onRequest = sequence(
  onRequest$1
);
export {
  onRequest
};

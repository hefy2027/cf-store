globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { g as getDb, u as users, e as eq } from "./db_XAr9wiDM.mjs";
const POST = async ({
  request,
  locals
}) => {
  const env$1 = env;
  const user = locals.user;
  if (!user) {
    return new Response(JSON.stringify({
      error: "Unauthorized"
    }), {
      status: 401
    });
  }
  try {
    const body = await request.json();
    const {
      username,
      bio,
      twitter,
      github,
      avatar_url
    } = body;
    const db = getDb(env$1);
    const socialLinks = JSON.stringify({
      twitter: twitter || void 0,
      github: github || void 0
    });
    await db.update(users).set({
      username: username || void 0,
      bio: bio || void 0,
      avatar: avatar_url || void 0,
      // Only update if new url provided
      socialLinks
    }).where(eq(users.id, user.id));
    return new Response(JSON.stringify({
      success: true
    }), {
      status: 200
    });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({
      error: "Internal Server Error"
    }), {
      status: 500
    });
  }
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

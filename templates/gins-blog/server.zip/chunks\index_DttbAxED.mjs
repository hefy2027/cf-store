globalThis.process ??= {};
globalThis.process.env ??= {};
import { g as getLangFromUrl, $ as $$Layout, u as useTranslations } from "./Layout_B4Am03Vw.mjs";
import { c as createComponent } from "./astro-component_BvYacKii.mjs";
import { aj as renderTemplate, a6 as maybeRenderHead, aw as addAttribute } from "./sequence_C6JDRbfE.mjs";
import { r as renderComponent } from "./worker-entry_CI_WUTHH.mjs";
import { env } from "cloudflare:workers";
import { g as getDb, p as posts, l as lte, f as desc } from "./db_XAr9wiDM.mjs";
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$Index;
  const lang = getLangFromUrl(Astro2.url);
  const t = useTranslations(lang);
  const env$1 = env;
  let allPosts = [];
  let error = null;
  try {
    if (env$1.DB) {
      const db = getDb(env$1);
      allPosts = await db.select().from(posts).where(lte(posts.publishedAt, Date.now())).orderBy(desc(posts.publishedAt)).all();
    } else {
      console.warn("No DB binding found, serving empty blog list (ZH)");
    }
  } catch (e) {
    console.error("Failed to fetch posts:", e);
    allPosts = [];
    error = e.message;
  }
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": `${t("nav.blog")} - ${t("hero.title")}` }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="mb-12"> <h1 class="text-4xl font-display font-bold mb-4"> ${t("blog.latest_thoughts")} <span class="text-brand-accent">${t("blog.thoughts_highlight")}</span> </h1> <p class="text-gray-400"> ${t("blog.musings")} </p> </div> ${error && renderTemplate`<div class="p-4 mb-8 border border-red-500/20 bg-red-500/10 rounded-lg text-red-400"> <p class="font-bold">Database Error</p> <p class="text-sm">${error}. Ensure D1 is bound correctly.</p> </div>`}<div class="grid gap-8 md:grid-cols-2"> ${allPosts.map((post) => renderTemplate`<a${addAttribute(`/zh/blog/${post.slug}`, "href")} data-astro-prefetch class="group glass-panel rounded-3xl p-8 hover:bg-white/5 transition-all relative overflow-hidden"> <div class="absolute inset-0 bg-gradient-to-r from-brand-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div> <div class="relative z-10"> <div class="flex items-center gap-3 text-xs font-mono text-brand-accent mb-3"> <span> ${new Date(
    post.publishedAt || post.createdAt
  ).toLocaleDateString()} </span> <span class="w-1 h-1 rounded-full bg-brand-accent/50"></span> <span class="flex items-center gap-1"> <span class="i-heroicons-eye w-3 h-3"></span> ${post.views} </span> </div> <h2 class="text-2xl font-bold mb-3 group-hover:text-brand-accent transition-colors"> ${post.title} </h2> <p class="text-gray-400 line-clamp-3"> ${post.content.slice(0, 150)}...
</p> </div> </a>`)} ${allPosts.length === 0 && !error && renderTemplate`<div class="col-span-full py-20 text-center text-gray-500 bg-white/5 rounded-3xl border border-white/5 font-mono">
// NO_DATA_FOUND
</div>`} </div> ` })}`;
}, "D:/coding/claude/_ginsbuild/src/pages/zh/blog/index.astro", void 0);
const $$file = "D:/coding/claude/_ginsbuild/src/pages/zh/blog/index.astro";
const $$url = "/zh/blog";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { a as generateState, b as generateCodeVerifier, d as getGoogle, s as sanitizeRedirectTarget } from "./redirect_BKbNLFHX.mjs";
import "./sequence_C6JDRbfE.mjs";
const GET = async ({
  cookies,
  redirect,
  request
}) => {
  const state = generateState();
  const codeVerifier = generateCodeVerifier();
  const url = getGoogle(env).createAuthorizationURL(state, codeVerifier, ["profile", "email"]);
  const redirectTo = sanitizeRedirectTarget(new URL(request.url).searchParams.get("redirect_to"));
  cookies.set("google_oauth_state", state, {
    path: "/",
    secure: true,
    httpOnly: true,
    maxAge: 60 * 10,
    sameSite: "lax"
  });
  cookies.set("google_code_verifier", codeVerifier, {
    path: "/",
    secure: true,
    httpOnly: true,
    maxAge: 60 * 10,
    sameSite: "lax"
  });
  cookies.set("login_redirect", redirectTo, {
    path: "/",
    secure: true,
    httpOnly: true,
    maxAge: 60 * 10,
    sameSite: "lax"
  });
  return redirect(url.toString());
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  GET
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

globalThis.process ??= {};
globalThis.process.env ??= {};
async function generateEmbedding(ai, text) {
  const result = await ai.run("@cf/baai/bge-m3", {
    text: [text]
  });
  return result.data[0];
}
async function insertPostVector(ai, index, post) {
  const textToEmbed = `${post.title} 
 ${post.content}`;
  const values = await generateEmbedding(ai, textToEmbed);
  await index.upsert([{
    id: post.id.toString(),
    values,
    metadata: {
      title: post.title
    }
  }]);
}
async function deletePostVector(index, id) {
  await index.deleteByIds([id]);
}
async function querySimilarPosts(ai, index, query, topK = 5) {
  const values = await generateEmbedding(ai, query);
  const results = await index.query(values, {
    topK,
    returnMetadata: true
  });
  return results.matches;
}
export {
  deletePostVector as d,
  insertPostVector as i,
  querySimilarPosts as q
};

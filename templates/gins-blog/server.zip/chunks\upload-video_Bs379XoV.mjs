globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { a as validateVideoFile } from "./uploads_DmsrrkgO.mjs";
import { g as getZeroTrustUser } from "./zerotrust_D95vk573.mjs";
function getErrorMessage(error) {
  return error instanceof Error ? error.message : "Unknown error";
}
const POST = async ({
  request
}) => {
  if (!getZeroTrustUser(request)) {
    return new Response(JSON.stringify({
      error: "Forbidden"
    }), {
      status: 403,
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
  const env$1 = env;
  const accountId = env$1.CLOUDFLARE_ACCOUNT_ID;
  const apiToken = env$1.CLOUDFLARE_MEDIA_API_TOKEN || env$1.CLOUDFLARE_API_TOKEN;
  if (!accountId || !apiToken) {
    return new Response(JSON.stringify({
      error: "Missing Cloudflare media credentials in environment."
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
  try {
    const formData = await request.formData();
    const file = formData.get("file");
    if (!file) {
      return new Response(JSON.stringify({
        error: "No file provided"
      }), {
        status: 400,
        headers: {
          "Content-Type": "application/json"
        }
      });
    }
    const validationError = validateVideoFile(file);
    if (validationError) {
      return new Response(JSON.stringify({
        error: validationError
      }), {
        status: 400,
        headers: {
          "Content-Type": "application/json"
        }
      });
    }
    const cfFormData = new FormData();
    cfFormData.append("file", file);
    const cfResponse = await fetch(`https://api.cloudflare.com/client/v4/accounts/${accountId}/stream`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiToken}`
      },
      body: cfFormData
    });
    const cfData = await cfResponse.json();
    if (!cfData.success) {
      return new Response(JSON.stringify({
        error: "Cloudflare Stream Upload Failed",
        details: cfData.errors
      }), {
        status: 400,
        headers: {
          "Content-Type": "application/json"
        }
      });
    }
    return new Response(JSON.stringify({
      success: true,
      videoId: cfData.result.uid,
      preview: cfData.result.preview,
      readyToStream: cfData.result.readyToStream
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json"
      }
    });
  } catch (error) {
    console.error("Video upload error:", error);
    return new Response(JSON.stringify({
      error: "Internal Server Error",
      message: getErrorMessage(error)
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

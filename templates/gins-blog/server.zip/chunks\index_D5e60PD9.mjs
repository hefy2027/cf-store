globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { g as getDb, d as sql, p as posts, f as desc, c as comments, h as like } from "./db_XAr9wiDM.mjs";
const TOOLS = [{
  name: "search_posts",
  description: "Search for blog posts by title or content.",
  inputSchema: {
    type: "object",
    properties: {
      query: {
        type: "string",
        description: "Search term"
      },
      limit: {
        type: "number",
        description: "Max results (default 5)"
      }
    },
    required: ["query"]
  }
}, {
  name: "draft_post",
  description: "Create a new draft blog post in the database.",
  inputSchema: {
    type: "object",
    properties: {
      title: {
        type: "string",
        description: "Post title"
      },
      content: {
        type: "string",
        description: "Markdown content"
      },
      slug: {
        type: "string",
        description: "URL slug (optional, auto-generated if missing)"
      }
    },
    required: ["title", "content"]
  }
}, {
  name: "analyze_comments",
  description: "Retrieve recent comments for analysis.",
  inputSchema: {
    type: "object",
    properties: {
      limit: {
        type: "number",
        description: "Number of comments to fetch (default 10)"
      }
    }
  }
}, {
  name: "check_analytics",
  description: "Get recent view counts and analytics summary.",
  inputSchema: {
    type: "object",
    properties: {}
  }
}, {
  name: "upload_image",
  description: "Upload an image to Cloudflare Images via URL.",
  inputSchema: {
    type: "object",
    properties: {
      url: {
        type: "string",
        description: "The public URL of the image to upload"
      },
      requireSignedURLs: {
        type: "boolean",
        description: "Whether to require signed URLs (default false)"
      }
    },
    required: ["url"]
  }
}, {
  name: "upload_video",
  description: "Upload a video to Cloudflare Stream via URL.",
  inputSchema: {
    type: "object",
    properties: {
      url: {
        type: "string",
        description: "The public URL of the video to upload"
      },
      title: {
        type: "string",
        description: "Title for the video"
      }
    },
    required: ["url"]
  }
}];
function getErrorString(error) {
  return error instanceof Error ? error.message : String(error);
}
function getStringArg(value, fieldName) {
  if (typeof value !== "string" || value.trim() === "") {
    throw new Error(`Invalid or missing "${fieldName}" argument.`);
  }
  return value;
}
function getOptionalStringArg(value) {
  if (typeof value !== "string" || value.trim() === "") {
    return void 0;
  }
  return value;
}
function getNumberArg(value, fallback) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}
const POST = async ({
  request
}) => {
  const env$1 = env;
  try {
    const body = await request.json();
    const {
      method,
      params,
      id
    } = body;
    if (method === "initialize" || method === "tools/list") {
      return new Response(JSON.stringify({
        jsonrpc: "2.0",
        id,
        result: {
          tools: TOOLS
        }
      }), {
        headers: {
          "Content-Type": "application/json"
        }
      });
    }
    if (method === "tools/call") {
      const toolName = params?.name;
      const args = params?.arguments || {};
      const db = getDb(env$1);
      let resultContent = [];
      switch (toolName) {
        case "search_posts": {
          const searchQuery = getStringArg(args.query, "query");
          const resultLimit = getNumberArg(args.limit, 5);
          const results = await db.select({
            title: posts.title,
            slug: posts.slug,
            views: posts.views,
            publishedAt: posts.publishedAt
          }).from(posts).where(like(posts.title, `%${searchQuery}%`)).limit(resultLimit);
          resultContent = [{
            type: "text",
            text: JSON.stringify(results, null, 2)
          }];
          break;
        }
        case "draft_post": {
          const draftTitle = getStringArg(args.title, "title");
          const draftContent = getStringArg(args.content, "content");
          const draftSlug = getOptionalStringArg(args.slug) || draftTitle.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") + "-" + Date.now().toString().slice(-4);
          const now = Date.now();
          const newId = crypto.randomUUID();
          await db.insert(posts).values({
            id: newId,
            title: draftTitle,
            slug: draftSlug,
            content: draftContent,
            createdAt: now,
            updatedAt: now,
            publishedAt: null,
            // Draft
            views: 0
          });
          resultContent = [{
            type: "text",
            text: `Draft created successfully! ID: ${newId}, Slug: ${draftSlug}`
          }];
          break;
        }
        case "analyze_comments": {
          const resultLimit = getNumberArg(args.limit, 10);
          const recentComments = await db.select({
            content: comments.content,
            createdAt: comments.createdAt,
            postId: comments.postId
          }).from(comments).orderBy(desc(comments.createdAt)).limit(resultLimit);
          resultContent = [{
            type: "text",
            text: JSON.stringify(recentComments, null, 2)
          }];
          break;
        }
        case "check_analytics": {
          const totalViews = await db.select({
            count: sql`sum(${posts.views})`
          }).from(posts);
          const topPosts = await db.select({
            title: posts.title,
            views: posts.views
          }).from(posts).orderBy(desc(posts.views)).limit(5);
          const summary = {
            total_views: totalViews[0]?.count || 0,
            top_posts: topPosts
          };
          resultContent = [{
            type: "text",
            text: JSON.stringify(summary, null, 2)
          }];
          break;
        }
        case "upload_image": {
          const imageUrl = getStringArg(args.url, "url");
          const accountId = env$1.CLOUDFLARE_ACCOUNT_ID || "cd4ce461acea5097153abf9e2deb26ec";
          const apiToken = env$1.CLOUDFLARE_MEDIA_API_TOKEN || env$1.CF_API_TOKEN || env$1.CLOUDFLARE_API_TOKEN;
          if (!apiToken) {
            throw new Error("CLOUDFLARE_MEDIA_API_TOKEN environment variable is not set.");
          }
          const formData = new FormData();
          formData.append("url", imageUrl);
          if (args.requireSignedURLs === true) {
            formData.append("requireSignedURLs", "true");
          }
          const response = await fetch(`https://api.cloudflare.com/client/v4/accounts/${accountId}/images/v1`, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${apiToken}`
            },
            body: formData
          });
          const data = await response.json();
          if (!data.success) {
            throw new Error(`Image upload failed: ${data.errors[0]?.message || "Unknown error"}`);
          }
          const imageId = data.result.id;
          const variants = data.result.variants ?? [];
          const publicUrl = variants.find((v) => v.endsWith("/public"));
          resultContent = [{
            type: "text",
            text: `Image uploaded successfully!

ID: ${imageId}

Markdown Snippet:
\`\`\`astro
<CFImage src="${imageId}" alt="Uploaded Image" />
\`\`\`

Direct URL: ${publicUrl || variants[0]}`
          }];
          break;
        }
        case "upload_video": {
          const videoUrl = getStringArg(args.url, "url");
          const videoTitle = getOptionalStringArg(args.title);
          const accountId = env$1.CLOUDFLARE_ACCOUNT_ID || "cd4ce461acea5097153abf9e2deb26ec";
          const apiToken = env$1.CLOUDFLARE_MEDIA_API_TOKEN || env$1.CF_API_TOKEN || env$1.CLOUDFLARE_API_TOKEN;
          if (!apiToken) {
            throw new Error("CLOUDFLARE_MEDIA_API_TOKEN environment variable is not set.");
          }
          const body2 = {
            url: videoUrl
          };
          if (videoTitle) body2.meta = {
            name: videoTitle
          };
          const response = await fetch(`https://api.cloudflare.com/client/v4/accounts/${accountId}/stream/copy`, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${apiToken}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify(body2)
          });
          const data = await response.json();
          if (!data.success) {
            throw new Error(`Video upload failed: ${data.errors[0]?.message || "Unknown error"}`);
          }
          const videoId = data.result.uid;
          const thumbnail = data.result.thumbnail;
          resultContent = [{
            type: "text",
            text: `Video upload started! (Async)

ID: ${videoId}

Markdown Snippet:
\`\`\`astro
<StreamPlayer videoId="${videoId}" title="${videoTitle || "Video"}" />
\`\`\`

Thumbnail: ${thumbnail}`
          }];
          break;
        }
        default:
          return new Response(JSON.stringify({
            jsonrpc: "2.0",
            id,
            error: {
              code: -32601,
              message: "Method not found"
            }
          }), {
            status: 404
          });
      }
      return new Response(JSON.stringify({
        jsonrpc: "2.0",
        id,
        result: {
          content: resultContent
        }
      }), {
        headers: {
          "Content-Type": "application/json"
        }
      });
    }
    return new Response(JSON.stringify({
      jsonrpc: "2.0",
      id,
      error: {
        code: -32600,
        message: "Invalid request"
      }
    }), {
      status: 400
    });
  } catch (error) {
    return new Response(JSON.stringify({
      jsonrpc: "2.0",
      id: null,
      error: {
        code: -32603,
        message: "Internal error",
        data: getErrorString(error)
      }
    }), {
      status: 500
    });
  }
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

globalThis.process ??= {};
globalThis.process.env ??= {};
import { $ as $$Layout } from "./Layout_B4Am03Vw.mjs";
import { c as createComponent } from "./astro-component_BvYacKii.mjs";
import { aj as renderTemplate, a6 as maybeRenderHead } from "./sequence_C6JDRbfE.mjs";
import { r as renderComponent } from "./worker-entry_CI_WUTHH.mjs";
const $$Privacy = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Privacy Policy" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="max-w-3xl mx-auto py-12 px-6"> <div class="glass-panel p-8 md:p-12 rounded-3xl animate-fade-in-up"> <h1 class="text-3xl md:text-4xl font-display font-bold mb-6 bg-gradient-to-r from-brand-accent to-brand-primary bg-clip-text text-transparent">
Privacy Policy
</h1> <div class="prose prose-invert prose-lg max-w-none prose-headings:font-display prose-headings:text-gray-100 prose-p:text-gray-300 prose-strong:text-brand-accent prose-a:text-brand-accent hover:prose-a:text-brand-primary transition-colors"> <p class="text-sm text-gray-400 mb-8 border-b border-white/10 pb-4">
Last Updated: 2026-01-31
</p> <p>
Thank you for visiting Gin's Blog. We respect your privacy and are
          committed to protecting your personal data. This privacy policy
          explains what information we collect and how we use it.
</p> <h3>1. Information We Collect</h3> <h4>1.1 Automatically Collected Data</h4> <p>
When you visit our site, we may collect minimal technical data to
          optimize your experience and ensure security:
</p> <ul> <li> <strong>Network Info</strong>: IP address, ISP, connection type
            (e.g., WiFi/4G) for routing optimization.
</li> <li> <strong>Device Metrics</strong>: Screen resolution, device memory,
            and CPU concurrency to determine optimal content rendering quality.
</li> <li> <strong>Location Data</strong>: Approximate location (City/Country)
            derived from IP address for analytics purposes.
</li> </ul> <h4>1.2 User Account Data</h4> <p>
If you choose to log in via third-party OAuth providers (GitHub,
          Google, Discord), we store only the public information provided by
          them:
</p> <ul> <li>Username</li> <li>Public Email Address</li> <li>Avatar URL</li> <li>Third-party User ID</li> </ul> <h3>2. How We Use Your Data</h3> <ul> <li> <strong>Performance Optimization</strong>: Device metrics help us
            serve lighter content to slower connections or lower-end devices.
</li> <li> <strong>Security</strong>: IP addresses are used to detect routing
            anomalies and prevent abuse.
</li> <li> <strong>Social Features</strong>: Your account data allows you to
            post comments and interact with content.
</li> </ul> <div class="bg-brand-primary/10 border-l-4 border-brand-primary p-4 my-6 rounded-r-lg"> <p class="m-0 text-white font-medium">
We do NOT share your personal data with advertisers or third
            parties.
</p> </div> <h3>3. Data Storage</h3> <p>
Your data is stored securely on <strong>Cloudflare D1 & KV</strong> infrastructure.
          We employ industry-standard security measures including strict access controls
          (Zero Trust) and encryption.
</p> <h3>4. Your Rights</h3> <p>
You have full control over your data. Upon request, or by using the
          "Logout & Clear Session" features in the user interface, you can
          manage your session data.
</p> <h3>5. Third-Party Services</h3> <p>We use the following services which may process data:</p> <ul> <li> <strong>Cloudflare</strong>: Hosting, Security, and Edge Computing.
</li> <li> <strong>OAuth Providers</strong>: GitHub, Google, Discord (for
            authentication only).
</li> </ul> <hr class="border-white/10 my-8"> <p class="text-sm text-gray-500 italic">
This project is open source. You can audit the code at the <a href="https://github.com/IchimaruGin728/Gins-Blog" target="_blank" rel="noreferrer">GitHub Repository</a>.
</p> </div> </div> </div> ` })}`;
}, "D:/coding/claude/_ginsbuild/src/pages/privacy.astro", void 0);
const $$file = "D:/coding/claude/_ginsbuild/src/pages/privacy.astro";
const $$url = "/privacy";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$Privacy,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { g as getDb, s as sessions, e as eq } from "./db_XAr9wiDM.mjs";
const POST = async ({
  request,
  locals
}) => {
  try {
    if (!locals.user || !locals.session) {
      return new Response(JSON.stringify({
        error: "Unauthorized"
      }), {
        status: 401
      });
    }
    const env$1 = env;
    const db = getDb(env$1);
    const currentSession = locals.session;
    const body = await request.json();
    const {
      screenResolution,
      deviceMemory,
      cpuCores,
      connectionType,
      os
    } = body;
    await db.update(sessions).set({
      screenResolution: screenResolution || null,
      deviceMemory: deviceMemory ? parseInt(deviceMemory, 10) : null,
      cpuCores: cpuCores ? parseInt(cpuCores, 10) : null,
      connectionType: connectionType || null,
      osVerified: os || null
    }).where(eq(sessions.id, currentSession.id));
    const updatedSession = {
      ...currentSession,
      screenResolution: screenResolution || null,
      deviceMemory: deviceMemory ? parseInt(deviceMemory, 10) : null,
      cpuCores: cpuCores ? parseInt(cpuCores, 10) : null,
      connectionType: connectionType || null,
      osVerified: os || null
    };
    await env$1.GIN_KV.put(`session:${currentSession.id}`, JSON.stringify(updatedSession), {
      expiration: Math.floor(currentSession.expiresAt / 1e3)
    });
    return new Response(JSON.stringify({
      success: true
    }), {
      status: 200
    });
  } catch (e) {
    console.error("Failed to update device info:", e);
    return new Response(JSON.stringify({
      error: "Internal Server Error"
    }), {
      status: 500
    });
  }
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  POST
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

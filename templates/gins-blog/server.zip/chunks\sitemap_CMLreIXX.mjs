globalThis.process ??= {};
globalThis.process.env ??= {};
import { env } from "cloudflare:workers";
import { g as getDb, p as posts, l as lte } from "./db_XAr9wiDM.mjs";
const GET = async () => {
  const db = getDb(env);
  let allPosts = [];
  try {
    allPosts = await db.select({
      slug: posts.slug,
      updatedAt: posts.updatedAt
    }).from(posts).where(lte(posts.publishedAt, Date.now())).all();
  } catch (error) {
    console.error("Failed to build sitemap:", error);
  }
  const baseUrl = "https://blog.ichimarugin728.com";
  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
	<!-- Homepage (EN) -->
	<url>
		<loc>${baseUrl}/</loc>
		<changefreq>daily</changefreq>
		<priority>1.0</priority>
	</url>
	<!-- Homepage (ZH) -->
	<url>
		<loc>${baseUrl}/zh/</loc>
		<changefreq>daily</changefreq>
		<priority>1.0</priority>
	</url>
	
	<!-- About Page (EN) -->
	<url>
		<loc>${baseUrl}/about</loc>
		<changefreq>monthly</changefreq>
		<priority>0.8</priority>
	</url>
	<!-- About Page (ZH) -->
	<url>
		<loc>${baseUrl}/zh/about</loc>
		<changefreq>monthly</changefreq>
		<priority>0.8</priority>
	</url>

    <!-- Blog Index (EN) -->
	<url>
		<loc>${baseUrl}/blog</loc>
		<changefreq>daily</changefreq>
		<priority>0.9</priority>
	</url>
    <!-- Blog Index (ZH) -->
	<url>
		<loc>${baseUrl}/zh/blog</loc>
		<changefreq>daily</changefreq>
		<priority>0.9</priority>
	</url>
	
	<!-- Blog Posts (EN & ZH) -->
	${allPosts.map((post) => {
    const lastMod = new Date(post.updatedAt).toISOString();
    return `
    <url>
		<loc>${baseUrl}/blog/${post.slug}</loc>
		<lastmod>${lastMod}</lastmod>
		<changefreq>monthly</changefreq>
		<priority>0.9</priority>
	</url>
    <url>
		<loc>${baseUrl}/zh/blog/${post.slug}</loc>
		<lastmod>${lastMod}</lastmod>
		<changefreq>monthly</changefreq>
		<priority>0.9</priority>
	</url>`;
  }).join("\n")}
</urlset>`.trim();
  return new Response(sitemap, {
    headers: {
      "Content-Type": "application/xml; charset=utf-8",
      "Cache-Control": "public, max-age=3600"
    }
  });
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  GET
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};

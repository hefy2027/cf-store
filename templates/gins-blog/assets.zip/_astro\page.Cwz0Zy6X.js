import{a as s}from"./index.sOdek_fq.js";globalThis.process??={};globalThis.process.env??={};s();

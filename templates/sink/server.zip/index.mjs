globalThis._importMeta_={url:"file:///_entry.js",env:{}};import"./timing.js";globalThis.__timing__.logStart("Nitro Start");export{aS as default}from"./chunks/nitro/nitro.mjs";import"node:buffer";import"node:process";import"cloudflare:workers";import"node:events";import"node:timers";import"node:crypto";globalThis.__timing__.logEnd("Nitro Start");
//# sourceMappingURL=index.mjs.map

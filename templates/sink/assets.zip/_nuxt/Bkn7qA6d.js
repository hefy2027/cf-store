const a=()=>({legacy:!1,fallbackLocale:"en-US",fallbackWarn:!1,missingWarn:!1});export{a as default};

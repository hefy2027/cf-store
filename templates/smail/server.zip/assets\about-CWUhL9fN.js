//#region app/md/es/about.md?raw
var about_default = "## Sobre smail.pw (Correo temporal)\r\n\r\nsmail.pw es un servicio de **correo temporal** para registros de bajo riesgo, códigos OTP y verificaciones rápidas.\r\n\r\n### Para qué sirve\r\n\r\n- Probar servicios sin exponer tu correo principal\r\n- Recibir enlaces de confirmación de uso único\r\n- Reducir spam y ruido en tu bandeja personal\r\n\r\n### Lo que debes saber\r\n\r\nLos buzones son temporales y no deben usarse para cuentas críticas (banca, trabajo, gobierno o recuperación importante).\r\n\r\n### Contacto\r\n\r\nSi tienes sugerencias, usa el canal de contacto disponible en el sitio.\r\n";
//#endregion
export { about_default as default };

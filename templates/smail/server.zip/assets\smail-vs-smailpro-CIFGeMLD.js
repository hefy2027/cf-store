//#region app/md/ar/smail-vs-smailpro.md?raw
var smail_vs_smailpro_default = "## smail.pw مقابل smailpro\r\n\r\nتوضيح رسمي: **smail.pw خدمة مستقلة**.\r\n\r\n### نقاط مهمة\r\n\r\n- smail.pw ليس نفس منتج smail pro / smailpro\r\n- لا توجد علاقة تبعية مع خدمات مشابهة الاسم\r\n- الميزات والسياسات تُدار بشكل مستقل\r\n\r\n### صفحات مرتبطة\r\n\r\n- [حول smail.pw](/about)\r\n- [الأسئلة الشائعة](/faq)\r\n- [سياسة الخصوصية](/privacy)\r\n";
//#endregion
export { smail_vs_smailpro_default as default };

//#region app/md/ko/online-temporary-email.md?raw
var online_temporary_email_default = "## 온라인 임시 이메일\r\n\r\n**온라인 임시 이메일**을 사용하면 브라우저에서 즉시 인증 메일을 받을 수 있습니다.\r\n\r\n### 장점\r\n\r\n- 설치 없이 바로 사용\r\n- 받은편지함 즉시 새로고침\r\n- 개인 메일 노출 최소화\r\n\r\n### OTP가 안 올 때\r\n\r\n- 주소 오타 확인\r\n- 원본 사이트에서 재전송\r\n- 몇 분 대기 후 다시 새로고침\r\n\r\n### 관련 페이지\r\n\r\n- [24시간 임시 이메일](/temporary-email-24-hours)\r\n- [가입용 임시 이메일](/temporary-email-for-registration)\r\n- [인증용 일회용 이메일](/disposable-email-for-verification)\r\n";
//#endregion
export { online_temporary_email_default as default };

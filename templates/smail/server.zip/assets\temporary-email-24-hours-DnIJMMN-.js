//#region app/md/ko/temporary-email-24-hours.md?raw
var temporary_email_24_hours_default = "## 24시간 임시 이메일\r\n\r\nsmail.pw의 24시간 임시 메일은 확인 메일이 늦게 도착하는 가입 흐름에 적합합니다.\r\n\r\n### 24시간이 유리한 이유\r\n\r\n- 10분 메일보다 여유가 큼\r\n- 다단계 가입 흐름에 대응 가능\r\n- 몇 시간 뒤에도 확인 가능\r\n\r\n### 사용 방법\r\n\r\n1. 임시 주소 생성\r\n2. 대상 사이트에 입력\r\n3. smail.pw 수신함 확인\r\n4. 필요한 정보는 만료 전 저장\r\n\r\n### 관련 페이지\r\n\r\n- [가입 없는 임시 이메일](/temporary-email-no-registration)\r\n- [인증용 일회용 이메일](/disposable-email-for-verification)\r\n- [FAQ](/faq)\r\n\r\n### 함께 보면 좋은 흐름\r\n\r\n이 페이지는 [가입용 임시 이메일](/temporary-email-for-registration), [온라인 임시 이메일](/online-temporary-email)과 함께 사용하면 더 효율적입니다.\r\n";
//#endregion
export { temporary_email_24_hours_default as default };

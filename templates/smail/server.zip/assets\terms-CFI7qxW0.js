//#region app/md/de/terms.md?raw
var terms_default = "## Nutzungsbedingungen\r\n\r\nMit der Nutzung von smail.pw akzeptierst du diese Bedingungen.\r\n\r\n### Erlaubte Nutzung\r\n\r\n- Risikoarme Registrierung und Verifizierung\r\n- Kurzfristiger E-Mail-Empfang\r\n\r\n### Verbotene Nutzung\r\n\r\n- Spam, Betrug, Phishing\r\n- Illegale oder schädliche Aktivitäten\r\n\r\n### Einschränkung\r\n\r\nKeine Garantie für dauerhafte Zustellung oder Speicherung über 24 Stunden hinaus.\r\n";
//#endregion
export { terms_default as default };

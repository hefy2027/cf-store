//#region app/md/es/privacy.md?raw
var privacy_default = "## Política de privacidad\r\n\r\nsmail.pw es un servicio de correo temporal. Procesamos datos mínimos para entregar mensajes y proteger la plataforma frente a abuso.\r\n\r\n### Datos que pueden procesarse\r\n\r\n- Dirección temporal e emails recibidos\r\n- Datos técnicos básicos (IP, navegador, hora)\r\n\r\n### Retención\r\n\r\nEl contenido del correo se conserva hasta 24 horas y luego se elimina automáticamente.\r\n\r\n### Aviso importante\r\n\r\nNo uses correo temporal para información sensible ni cuentas críticas.\r\n";
//#endregion
export { privacy_default as default };

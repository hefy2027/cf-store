//#region app/md/de/online-temporary-email.md?raw
var online_temporary_email_default = "## Online-Temporäre E-Mail\r\n\r\nMit **Online-Temporärmail** empfängst du Verifizierungsmails direkt im Browser.\r\n\r\n### Vorteile\r\n\r\n- Sofort nutzbar ohne Installation\r\n- Schnelles Aktualisieren des Posteingangs\r\n- Schutz deiner persönlichen Hauptadresse\r\n\r\n### Wenn OTP fehlt\r\n\r\n- Adresse exakt prüfen\r\n- Code erneut anfordern\r\n- Kurz warten und erneut aktualisieren\r\n\r\n### Verwandte Seiten\r\n\r\n- [24-Stunden-Temporäre E-Mail](/temporary-email-24-hours)\r\n- [Temporäre E-Mail für Registrierung](/temporary-email-for-registration)\r\n- [Wegwerf-E-Mail für Verifizierung](/disposable-email-for-verification)\r\n";
//#endregion
export { online_temporary_email_default as default };

//#region app/md/ar/domestic-temporary-email.md?raw
var domestic_temporary_email_default = "## دليل البريد المؤقت المحلي\r\n\r\nيشرح **دليل البريد المؤقت المحلي** كيفية التعامل مع تأخر الاستلام في المنصات الإقليمية.\r\n\r\n### أسباب التأخر الشائعة\r\n\r\n- تأخر جهة الإرسال\r\n- حظر نطاقات البريد المؤقت\r\n- خطأ في كتابة العنوان\r\n\r\n### خطوات الحل\r\n\r\n1. تأكد من العنوان بدقة.\r\n2. أعد طلب إرسال الرمز.\r\n3. انتظر من 1 إلى 3 دقائق ثم حدّث.\r\n4. جرّب عنوانًا مؤقتًا جديدًا عند الحاجة.\r\n\r\n### صفحات مرتبطة\r\n\r\n- [بريد مؤقت أونلاين](/online-temporary-email)\r\n- [بريد مؤقت للتحقق ورموز OTP](/disposable-email-for-verification)\r\n- [الأسئلة الشائعة](/faq)\r\n";
//#endregion
export { domestic_temporary_email_default as default };

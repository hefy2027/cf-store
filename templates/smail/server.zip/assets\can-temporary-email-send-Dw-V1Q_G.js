//#region app/md/ar/can-temporary-email-send.md?raw
var can_temporary_email_send_default = "## هل يمكن للبريد المؤقت إرسال رسائل؟\r\n\r\nفي أغلب الخدمات، **البريد المؤقت مخصص للاستقبال فقط** مثل رموز OTP وروابط التأكيد.\r\n\r\n### لماذا يكون للاستقبال غالبًا\r\n\r\n- تقليل مخاطر الرسائل المزعجة والاحتيال\r\n- تبسيط أنظمة الحماية والمراقبة\r\n- تحسين استقرار صندوق البريد المؤقت\r\n\r\n### متى تحتاج بريدًا دائمًا\r\n\r\nإذا كنت تحتاج إلى الإرسال والرد والأرشفة الطويلة، استخدم بريدًا دائمًا.\r\n\r\n### صفحات مرتبطة\r\n\r\n- [بريد مؤقت للتحقق ورموز OTP](/disposable-email-for-verification)\r\n- [بريد مؤقت بدون تسجيل](/temporary-email-no-registration)\r\n- [شروط الاستخدام](/terms)\r\n";
//#endregion
export { can_temporary_email_send_default as default };

//#region app/md/pt/about.md?raw
var about_default = "## Sobre o smail.pw (Email temporário)\r\n\r\nsmail.pw é um serviço de **email temporário** para cadastros de baixo risco, OTP e verificações pontuais.\r\n\r\n### Para que usar\r\n\r\n- Testar serviços sem expor o email principal\r\n- Receber links de confirmação de uso único\r\n- Reduzir spam na caixa pessoal\r\n\r\n### Limites importantes\r\n\r\nNão use para banco, trabalho, governo ou recuperação crítica de contas.\r\n\r\n### Contato\r\n\r\nEnvie feedback pelo canal de contato disponível no site.\r\n";
//#endregion
export { about_default as default };

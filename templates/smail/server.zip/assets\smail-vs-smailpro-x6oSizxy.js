//#region app/md/ru/smail-vs-smailpro.md?raw
var smail_vs_smailpro_default = "## smail.pw и smailpro\r\n\r\nОфициальное разъяснение: **smail.pw — независимый сервис**.\r\n\r\n### Важно\r\n\r\n- smail.pw не является тем же продуктом, что smail pro / smailpro\r\n- Нет аффилированности с похожими названиями\r\n- Функции и политика управляются отдельно\r\n\r\n### Связанные страницы\r\n\r\n- [О smail.pw](/about)\r\n- [FAQ](/faq)\r\n- [Политика конфиденциальности](/privacy)\r\n";
//#endregion
export { smail_vs_smailpro_default as default };

//#region app/md/ja/temporary-email-24-hours.md?raw
var temporary_email_24_hours_default = "## 24時間 一時メール\r\n\r\nsmail.pw の 24時間一時メールは、確認メールが遅れて届くケースに向いた構成です。\r\n\r\n### 24時間のメリット\r\n\r\n- 10分メールより余裕がある\r\n- 複数ステップの登録に対応しやすい\r\n- 数時間後でも確認しやすい\r\n\r\n### 使い方\r\n\r\n1. 一時アドレスを生成\r\n2. 対象サイトに入力\r\n3. smail.pw で受信確認\r\n4. 必要情報を期限前に保存\r\n\r\n### 関連ページ\r\n\r\n- [登録不要の一時メール](/temporary-email-no-registration)\r\n- [認証コード用使い捨てメール](/disposable-email-for-verification)\r\n- [FAQ](/faq)\r\n\r\n### 追加で役立つガイド\r\n\r\nこの流れは [登録向け一時メール](/temporary-email-for-registration) と [オンライン一時メール](/online-temporary-email) と組み合わせると効果的です。\r\n";
//#endregion
export { temporary_email_24_hours_default as default };

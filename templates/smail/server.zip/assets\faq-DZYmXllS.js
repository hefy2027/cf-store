//#region app/md/ko/faq.md?raw
var faq_default = "## smail.pw 자주 묻는 질문\r\n\r\n### smail.pw는 무엇인가요?\r\n단기 수신을 위한 임시 이메일 서비스입니다.\r\n\r\n### 가입이 필요한가요?\r\n아니요. 회원가입 없이 사용 가능합니다.\r\n\r\n### 메일 보관 기간은?\r\n최대 24시간 후 자동 삭제됩니다.\r\n\r\n### OTP 수신이 가능한가요?\r\n네, 대표적인 사용 사례입니다.\r\n\r\n### 메일이 안 오는 이유는?\r\n발신 지연, 임시 도메인 차단, 주소 오타가 주요 원인입니다.\r\n\r\n### 발신도 가능한가요?\r\n기본적으로 수신 중심 서비스입니다.\r\n\r\n### 중요한 계정에 써도 되나요?\r\n권장하지 않습니다. 중요한 계정은 영구 메일을 사용하세요.\r\n";
//#endregion
export { faq_default as default };

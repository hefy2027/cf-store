//#region app/md/ko/temporary-email-for-registration.md?raw
var temporary_email_for_registration_default = "## 가입용 임시 이메일\r\n\r\n**가입용 임시 이메일**은 회원가입 시 기본 메일 주소를 노출하고 싶지 않을 때 유용합니다.\r\n\r\n### 적합한 상황\r\n\r\n- 체험 계정 생성\r\n- 다운로드/쿠폰 인증\r\n- 저위험 서비스 가입\r\n\r\n### 사용 방법\r\n\r\n1. smail.pw에서 일회용 주소 생성\r\n2. 가입 폼에 주소 입력\r\n3. OTP 또는 확인 링크 수신\r\n4. 기본 메일 노출 없이 가입 완료\r\n\r\n### 관련 페이지\r\n\r\n- [가입 없는 임시 이메일](/temporary-email-no-registration)\r\n- [인증용 일회용 이메일](/disposable-email-for-verification)\r\n- [자주 묻는 질문](/faq)\r\n";
//#endregion
export { temporary_email_for_registration_default as default };

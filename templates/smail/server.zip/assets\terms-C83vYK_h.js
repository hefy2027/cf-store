//#region app/md/pt/terms.md?raw
var terms_default = "## Termos de uso\r\n\r\nAo usar o smail.pw, você concorda com estes termos.\r\n\r\n### Uso permitido\r\n\r\n- Cadastro e verificação de baixo risco\r\n- Recebimento temporário de emails\r\n\r\n### Uso proibido\r\n\r\n- Spam, fraude, phishing\r\n- Atividades ilegais ou maliciosas\r\n\r\n### Limitação\r\n\r\nNão há garantia de entrega permanente nem retenção acima de 24 horas.\r\n";
//#endregion
export { terms_default as default };

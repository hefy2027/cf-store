//#region app/md/ar/online-temporary-email.md?raw
var online_temporary_email_default = "## بريد مؤقت أونلاين\r\n\r\nيوفر **البريد المؤقت الأونلاين** استقبالًا فوريًا لرسائل التحقق مباشرة من المتصفح.\r\n\r\n### المزايا\r\n\r\n- استخدام فوري بدون تثبيت\r\n- تحديث سريع لصندوق الوارد\r\n- تقليل كشف البريد الأساسي\r\n\r\n### إذا تأخر OTP\r\n\r\n- تحقق من صحة العنوان\r\n- أعد الإرسال من المنصة الأصلية\r\n- انتظر بضع دقائق ثم حدّث الوارد\r\n\r\n### صفحات مرتبطة\r\n\r\n- [بريد مؤقت لمدة 24 ساعة](/temporary-email-24-hours)\r\n- [بريد مؤقت للتسجيل](/temporary-email-for-registration)\r\n- [بريد مؤقت للتحقق ورموز OTP](/disposable-email-for-verification)\r\n";
//#endregion
export { online_temporary_email_default as default };

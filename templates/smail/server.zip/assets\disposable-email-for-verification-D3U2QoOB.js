//#region app/md/ko/disposable-email-for-verification.md?raw
var disposable_email_for_verification_default = "## 인증 코드용 일회용 이메일\r\n\r\nOTP 또는 확인 링크를 받을 때 개인 주소 노출을 줄이고 싶다면 일회용 메일이 유용합니다.\r\n\r\n### 수신 가능한 내용\r\n\r\n- 이메일 OTP 코드\r\n- 가입 확인 링크\r\n- 활성화 메시지\r\n\r\n### 수신 팁\r\n\r\n- 주소를 정확히 복사\r\n- 원본 서비스에서 재전송\r\n- 몇 분 대기 후 새로고침\r\n\r\n### 보안 안내\r\n\r\n은행, 업무, 정부, 중요한 복구 계정에는 사용하지 마세요.\r\n\r\n### 관련 페이지\r\n\r\n- [24시간 임시 이메일](/temporary-email-24-hours)\r\n- [가입 없는 임시 이메일](/temporary-email-no-registration)\r\n- [이용약관](/terms)\r\n\r\n### 추가 가이드\r\n\r\n- [가입용 임시 이메일](/temporary-email-for-registration)\r\n- [임시 이메일로 발신할 수 있나요?](/can-temporary-email-send)\r\n";
//#endregion
export { disposable_email_for_verification_default as default };

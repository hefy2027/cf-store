//#region app/md/zh/online-temporary-email.md?raw
var online_temporary_email_default = "## 在线临时邮箱\r\n\r\n需要马上收验证码？**在线临时邮箱**可以直接在网页里即时生成和收信，适合 OTP、确认链接和短期验证场景。\r\n\r\n### 为什么很多人用在线临时邮箱\r\n\r\n- 打开即用，无需安装\r\n- 收件箱可即时刷新\r\n- 将一次性收信与真实邮箱隔离\r\n\r\n### 收信建议\r\n\r\n- 复制邮箱地址时不要多空格或少字符\r\n- 如果未收到邮件，先在来源站点点击重发\r\n- 等待 1-3 分钟后再刷新，避免发件方延迟\r\n\r\n### 保留周期\r\n\r\n邮件最多保留 24 小时，之后自动清理。\r\n\r\n### 相关阅读\r\n\r\n- [24 小时临时邮箱](/temporary-email-24-hours)\r\n- [临时邮箱注册指南](/temporary-email-for-registration)\r\n- [验证码一次性邮箱](/disposable-email-for-verification)\r\n";
//#endregion
export { online_temporary_email_default as default };

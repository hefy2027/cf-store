//#region app/md/ja/disposable-email-for-verification.md?raw
var disposable_email_for_verification_default = "## 認証コード用 使い捨てメール\r\n\r\nOTP や確認リンクを受け取りたいが、個人アドレスは出したくない場合に使えます。\r\n\r\n### 受信できる内容\r\n\r\n- OTP コード\r\n- 確認リンク\r\n- アクティベーション通知\r\n\r\n### 受信改善のコツ\r\n\r\n- 生成アドレスを正確にコピー\r\n- 元サイトから再送\r\n- 数分待って更新\r\n\r\n### セキュリティ注意\r\n\r\n銀行・業務・行政・重要復旧には使用しないでください。\r\n\r\n### 関連ページ\r\n\r\n- [24時間 一時メール](/temporary-email-24-hours)\r\n- [登録不要の一時メール](/temporary-email-no-registration)\r\n- [利用規約](/terms)\r\n\r\n### 関連ガイド\r\n\r\n- [登録向け一時メール](/temporary-email-for-registration)\r\n- [一時メールは送信できる？](/can-temporary-email-send)\r\n";
//#endregion
export { disposable_email_for_verification_default as default };

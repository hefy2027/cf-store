//#region app/md/fr/about.md?raw
var about_default = "## À propos de smail.pw (Email temporaire)\r\n\r\nsmail.pw est un service d'**email temporaire** pour les inscriptions à faible risque, les OTP et les vérifications ponctuelles.\r\n\r\n### Cas d'usage\r\n\r\n- Tester un service sans exposer votre adresse principale\r\n- Recevoir des liens de confirmation à usage unique\r\n- Réduire le spam dans votre boîte personnelle\r\n\r\n### Limites importantes\r\n\r\nLes boîtes sont temporaires. N'utilisez pas ce service pour la banque, le travail, l'administration ou la récupération de comptes critiques.\r\n\r\n### Contact\r\n\r\nPour toute suggestion, utilisez le canal de contact du site.\r\n";
//#endregion
export { about_default as default };

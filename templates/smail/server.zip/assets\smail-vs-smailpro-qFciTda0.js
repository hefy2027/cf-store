//#region app/md/ja/smail-vs-smailpro.md?raw
var smail_vs_smailpro_default = "## smail.pw と smailpro の違い\r\n\r\n公式説明: **smail.pw は独立したサービス**です。\r\n\r\n### 重要ポイント\r\n\r\n- smail.pw は smail pro / smailpro と同一製品ではありません\r\n- 類似名称サービスとの提携はありません\r\n- 機能とポリシーは独立して運用されています\r\n\r\n### 関連ページ\r\n\r\n- [smail.pw について](/about)\r\n- [よくある質問](/faq)\r\n- [プライバシーポリシー](/privacy)\r\n";
//#endregion
export { smail_vs_smailpro_default as default };

//#region app/md/es/smail-vs-smailpro.md?raw
var smail_vs_smailpro_default = "## smail.pw vs smailpro\r\n\r\nAclaración oficial: **smail.pw es un servicio independiente** de correo temporal.\r\n\r\n### Puntos importantes\r\n\r\n- smail.pw no es el mismo producto que smail pro o smailpro\r\n- No existe afiliación con marcas de nombre similar\r\n- Políticas y funciones se gestionan por separado\r\n\r\n### Páginas relacionadas\r\n\r\n- [Sobre smail.pw](/about)\r\n- [Preguntas frecuentes](/faq)\r\n- [Política de privacidad](/privacy)\r\n";
//#endregion
export { smail_vs_smailpro_default as default };

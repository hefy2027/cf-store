//#region app/md/de/smail-vs-smailpro.md?raw
var smail_vs_smailpro_default = "## smail.pw vs smailpro\r\n\r\nOffizielle Klarstellung: **smail.pw ist ein unabhängiger Dienst**.\r\n\r\n### Wichtig\r\n\r\n- smail.pw ist nicht identisch mit smail pro oder smailpro\r\n- Keine Zugehörigkeit zu ähnlich benannten Diensten\r\n- Funktionen und Richtlinien werden separat betrieben\r\n\r\n### Verwandte Seiten\r\n\r\n- [Über smail.pw](/about)\r\n- [FAQ](/faq)\r\n- [Datenschutzrichtlinie](/privacy)\r\n";
//#endregion
export { smail_vs_smailpro_default as default };

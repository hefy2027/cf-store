//#region app/md/zh/temporary-email-for-registration.md?raw
var temporary_email_for_registration_default = "## 临时邮箱注册指南\r\n\r\n当你需要注册账号但不想暴露真实邮箱时，可以使用**临时邮箱注册**方案。smail.pw 适合低风险注册、试用开通和验证码接收。\r\n\r\n### 适用场景\r\n\r\n- 试用账号注册\r\n- 一次性活动领取\r\n- 下载前邮箱验证\r\n- 低风险平台注册流程\r\n\r\n### 使用步骤\r\n\r\n1. 在 smail.pw 生成一次性邮箱地址。\r\n2. 将地址填写到目标网站注册表单。\r\n3. 返回收件箱接收验证码或确认链接。\r\n4. 完成注册后，主邮箱无需暴露给该平台。\r\n\r\n### 使用边界\r\n\r\n临时邮箱注册适用于短期、低风险流程。银行、工作、政务、重要找回链路请使用长期邮箱。\r\n\r\n### 相关阅读\r\n\r\n- [免注册临时邮箱](/temporary-email-no-registration)\r\n- [验证码一次性邮箱](/disposable-email-for-verification)\r\n- [常见问题](/faq)\r\n";
//#endregion
export { temporary_email_for_registration_default as default };

//#region app/md/de/about.md?raw
var about_default = "## Über smail.pw (Temporäre E-Mail)\r\n\r\nsmail.pw ist ein Dienst für **temporäre E-Mail** bei risikoarmen Registrierungen, OTP-Codes und einmaligen Verifizierungen.\r\n\r\n### Wofür es gedacht ist\r\n\r\n- Dienste testen ohne Hauptadresse preiszugeben\r\n- Einmalige Bestätigungslinks empfangen\r\n- Spam im privaten Postfach reduzieren\r\n\r\n### Wichtige Grenzen\r\n\r\nTemporäre Postfächer sind nicht für kritische Konten geeignet (Bank, Arbeit, Behörden, wichtige Recovery-Prozesse).\r\n\r\n### Kontakt\r\n\r\nFeedback kannst du über den Kontaktkanal der Website senden.\r\n";
//#endregion
export { about_default as default };

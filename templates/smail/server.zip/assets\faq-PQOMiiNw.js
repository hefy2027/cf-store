//#region app/md/pt/faq.md?raw
var faq_default = "## FAQ do smail.pw\r\n\r\n### O que é o smail.pw?\r\nÉ um serviço de email temporário para recebimento de curta duração.\r\n\r\n### Precisa de cadastro?\r\nNão, funciona sem registro.\r\n\r\n### Quanto tempo os emails ficam disponíveis?\r\nAté 24 horas, com remoção automática depois disso.\r\n\r\n### Serve para OTP e verificação?\r\nSim, é um dos principais usos.\r\n\r\n### Por que o email não chegou?\r\nPode haver atraso do remetente, bloqueio de domínio temporário ou erro de digitação no endereço.\r\n\r\n### Posso enviar emails?\r\nNormalmente não. O foco é recebimento.\r\n\r\n### Posso usar em contas importantes?\r\nNão. Para contas críticas, use email permanente.\r\n";
//#endregion
export { faq_default as default };

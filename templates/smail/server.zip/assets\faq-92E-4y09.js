//#region app/md/de/faq.md?raw
var faq_default = "## smail.pw FAQ\r\n\r\n### Was ist smail.pw?\r\nEin Dienst für temporäre Postfächer und kurzlebige E-Mails.\r\n\r\n### Brauche ich ein Konto?\r\nNein, keine Registrierung erforderlich.\r\n\r\n### Wie lange bleiben E-Mails erhalten?\r\nBis zu 24 Stunden, danach automatische Löschung.\r\n\r\n### Funktioniert OTP-Verifizierung?\r\nJa, das ist ein typischer Anwendungsfall.\r\n\r\n### Warum kam keine E-Mail an?\r\nMögliche Gründe: Absenderverzögerung, Blockierung temporärer Domains, Tippfehler.\r\n\r\n### Kann ich E-Mails senden?\r\nIn der Regel nein; der Dienst ist auf Empfang ausgelegt.\r\n\r\n### Für wichtige Konten geeignet?\r\nNein. Für kritische Konten bitte dauerhafte E-Mail nutzen.\r\n";
//#endregion
export { faq_default as default };

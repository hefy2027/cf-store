import { C as PostalMime, T as nanoid, r as createRequestHandler } from "./assets/chunk-BFXCU3MI-iWiEqKIY.js";
//#region workers/app.ts
var requestHandler = createRequestHandler(() => import("./assets/server-build-Cbk6gs_x.js"), "production");
//#endregion
//#region \0virtual:cloudflare/worker-entry
var worker_entry_default = {
	async fetch(request, env, ctx) {
		return requestHandler(request, { cloudflare: {
			env,
			ctx
		} });
	},
	async email(msg, env) {
		const parser = new PostalMime();
		const ab = await new Response(msg.raw).arrayBuffer();
		const parsed = await parser.parse(ab);
		const id = nanoid();
		await env.D1.prepare("INSERT INTO emails (id, to_address, from_name, from_address, subject, time) VALUES (?, ?, ?, ?, ?, ?)").bind(id, msg.to, parsed.from?.name, parsed.from?.address, parsed.subject, Date.now()).run();
		await env.R2.put(id, ab);
	},
	async scheduled() {}
};
//#endregion
export { worker_entry_default as default };

//#region app/md/pt/privacy.md?raw
var privacy_default = "## Política de privacidade\r\n\r\nsmail.pw é um serviço de email temporário. Processamos apenas dados mínimos para entrega e proteção contra abuso.\r\n\r\n### Dados que podem ser tratados\r\n\r\n- Endereço temporário e emails recebidos\r\n- Dados técnicos básicos (IP, navegador, horário)\r\n\r\n### Retenção\r\n\r\nO conteúdo de email é mantido por até 24 horas e removido automaticamente depois.\r\n\r\n### Importante\r\n\r\nNão utilize para informações sensíveis ou contas críticas.\r\n";
//#endregion
export { privacy_default as default };

//#region app/md/pt/smail-vs-smailpro.md?raw
var smail_vs_smailpro_default = "## smail.pw vs smailpro\r\n\r\nEsclarecimento oficial: **smail.pw é um serviço independente**.\r\n\r\n### Pontos importantes\r\n\r\n- smail.pw não é o mesmo produto que smail pro / smailpro\r\n- Não há afiliação com marcas de nome parecido\r\n- Funções e políticas são geridas separadamente\r\n\r\n### Páginas relacionadas\r\n\r\n- [Sobre o smail.pw](/about)\r\n- [Perguntas frequentes](/faq)\r\n- [Política de privacidade](/privacy)\r\n";
//#endregion
export { smail_vs_smailpro_default as default };

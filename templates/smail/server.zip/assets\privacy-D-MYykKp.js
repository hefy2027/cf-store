//#region app/md/ja/privacy.md?raw
var privacy_default = "## プライバシーポリシー\r\n\r\nsmail.pw は一時メールサービスです。配信と不正対策のために必要最小限のデータを扱います。\r\n\r\n### 取り扱う可能性のある情報\r\n\r\n- 一時アドレスと受信メール\r\n- 基本的な技術情報（IP、ブラウザ、時刻）\r\n\r\n### 保持期間\r\n\r\nメール内容は最大 24 時間保持され、その後自動削除されます。\r\n\r\n### 注意\r\n\r\n機密情報や重要アカウント用途には使用しないでください。\r\n";
//#endregion
export { privacy_default as default };

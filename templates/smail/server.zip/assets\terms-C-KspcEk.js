//#region app/md/es/terms.md?raw
var terms_default = "## Términos de uso\r\n\r\nAl usar smail.pw aceptas estos términos.\r\n\r\n### Uso permitido\r\n\r\n- Registro y verificación de bajo riesgo\r\n- Recepción temporal de correos\r\n\r\n### Uso prohibido\r\n\r\n- Spam, fraude o phishing\r\n- Actividad ilegal o maliciosa\r\n\r\n### Limitación\r\n\r\nNo garantizamos entrega permanente ni conservación más allá de 24 horas.\r\n";
//#endregion
export { terms_default as default };

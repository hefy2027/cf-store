//#region app/md/de/privacy.md?raw
var privacy_default = "## Datenschutz\r\n\r\nsmail.pw ist ein temporärer E-Mail-Dienst. Wir verarbeiten nur notwendige Daten für Zustellung und Missbrauchsschutz.\r\n\r\n### Mögliche Daten\r\n\r\n- Temporäre Adresse und eingehende E-Mails\r\n- Technische Basisdaten (IP, Browser, Zeit)\r\n\r\n### Aufbewahrung\r\n\r\nE-Mail-Inhalte werden bis zu 24 Stunden gespeichert und danach automatisch gelöscht.\r\n\r\n### Hinweis\r\n\r\nNicht für sensible Informationen oder kritische Konten verwenden.\r\n";
//#endregion
export { privacy_default as default };

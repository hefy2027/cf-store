//#region app/md/ja/about.md?raw
var about_default = "## smail.pw について（一時メール）\r\n\r\nsmail.pw は、低リスク登録や OTP 受信用の **一時メール** サービスです。メインのメールアドレスを公開せずに短期利用できます。\r\n\r\n### 主な用途\r\n\r\n- 新しいサービスの試用登録\r\n- ワンタイム確認リンクの受信\r\n- 個人受信箱のスパム削減\r\n\r\n### 注意点\r\n\r\n一時メールは恒久利用向けではありません。銀行・仕事・行政・重要な復旧用途には使用しないでください。\r\n\r\n### 連絡\r\n\r\nご意見はサイト内の問い合わせ手段をご利用ください。\r\n";
//#endregion
export { about_default as default };

//#region app/md/es/terms.md?raw
var terms_default = "## Términos de uso\n\nAl usar smail.pw aceptas estos términos.\n\n### Uso permitido\n\n- Registro y verificación de bajo riesgo\n- Recepción temporal de correos\n\n### Uso prohibido\n\n- Spam, fraude o phishing\n- Actividad ilegal o maliciosa\n\n### Limitación\n\nNo garantizamos entrega permanente ni conservación más allá de 24 horas.\n";
//#endregion
export { terms_default as default };

//#region app/md/ko/privacy.md?raw
var privacy_default = "## 개인정보 처리방침\n\nsmail.pw는 임시 이메일 서비스이며, 전달과 악용 방지를 위해 필요한 최소 데이터만 처리합니다.\n\n### 처리될 수 있는 정보\n\n- 임시 주소와 수신 메일\n- 기본 기술 정보(IP, 브라우저, 시간)\n\n### 보관 기간\n\n메일 내용은 최대 24시간 보관 후 자동 삭제됩니다.\n\n### 주의\n\n민감 정보나 중요한 계정에는 사용하지 마세요.\n";
//#endregion
export { privacy_default as default };

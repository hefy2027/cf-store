//#region app/md/ar/can-temporary-email-send.md?raw
var can_temporary_email_send_default = "## هل يمكن للبريد المؤقت إرسال رسائل؟\n\nفي أغلب الخدمات، **البريد المؤقت مخصص للاستقبال فقط** مثل رموز OTP وروابط التأكيد.\n\n### لماذا يكون للاستقبال غالبًا\n\n- تقليل مخاطر الرسائل المزعجة والاحتيال\n- تبسيط أنظمة الحماية والمراقبة\n- تحسين استقرار صندوق البريد المؤقت\n\n### متى تحتاج بريدًا دائمًا\n\nإذا كنت تحتاج إلى الإرسال والرد والأرشفة الطويلة، استخدم بريدًا دائمًا.\n\n### صفحات مرتبطة\n\n- [بريد مؤقت للتحقق ورموز OTP](/disposable-email-for-verification)\n- [بريد مؤقت بدون تسجيل](/temporary-email-no-registration)\n- [شروط الاستخدام](/terms)\n";
//#endregion
export { can_temporary_email_send_default as default };

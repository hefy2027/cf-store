//#region app/md/pt/faq.md?raw
var faq_default = "## FAQ do smail.pw\n\n### O que é o smail.pw?\nÉ um serviço de email temporário para recebimento de curta duração.\n\n### Precisa de cadastro?\nNão, funciona sem registro.\n\n### Quanto tempo os emails ficam disponíveis?\nAté 24 horas, com remoção automática depois disso.\n\n### Serve para OTP e verificação?\nSim, é um dos principais usos.\n\n### Por que o email não chegou?\nPode haver atraso do remetente, bloqueio de domínio temporário ou erro de digitação no endereço.\n\n### Posso enviar emails?\nNormalmente não. O foco é recebimento.\n\n### Posso usar em contas importantes?\nNão. Para contas críticas, use email permanente.\n";
//#endregion
export { faq_default as default };

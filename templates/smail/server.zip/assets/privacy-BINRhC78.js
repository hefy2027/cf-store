//#region app/md/de/privacy.md?raw
var privacy_default = "## Datenschutz\n\nsmail.pw ist ein temporärer E-Mail-Dienst. Wir verarbeiten nur notwendige Daten für Zustellung und Missbrauchsschutz.\n\n### Mögliche Daten\n\n- Temporäre Adresse und eingehende E-Mails\n- Technische Basisdaten (IP, Browser, Zeit)\n\n### Aufbewahrung\n\nE-Mail-Inhalte werden bis zu 24 Stunden gespeichert und danach automatisch gelöscht.\n\n### Hinweis\n\nNicht für sensible Informationen oder kritische Konten verwenden.\n";
//#endregion
export { privacy_default as default };

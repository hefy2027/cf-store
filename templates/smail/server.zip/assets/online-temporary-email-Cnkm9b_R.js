//#region app/md/ru/online-temporary-email.md?raw
var online_temporary_email_default = "## Онлайн временная почта\n\n**Онлайн временная почта** дает мгновенный доступ к письмам подтверждения прямо в браузере.\n\n### Преимущества\n\n- Моментальный старт без установки\n- Быстрое обновление входящих\n- Меньше раскрытия личного email\n\n### Если OTP не пришел\n\n- Проверьте адрес без ошибок\n- Запросите повторную отправку\n- Подождите несколько минут и обновите\n\n### Связанные страницы\n\n- [Временная почта на 24 часа](/temporary-email-24-hours)\n- [Временная почта для регистрации](/temporary-email-for-registration)\n- [Одноразовая почта для верификации](/disposable-email-for-verification)\n";
//#endregion
export { online_temporary_email_default as default };

//#region app/md/de/terms.md?raw
var terms_default = "## Nutzungsbedingungen\n\nMit der Nutzung von smail.pw akzeptierst du diese Bedingungen.\n\n### Erlaubte Nutzung\n\n- Risikoarme Registrierung und Verifizierung\n- Kurzfristiger E-Mail-Empfang\n\n### Verbotene Nutzung\n\n- Spam, Betrug, Phishing\n- Illegale oder schädliche Aktivitäten\n\n### Einschränkung\n\nKeine Garantie für dauerhafte Zustellung oder Speicherung über 24 Stunden hinaus.\n";
//#endregion
export { terms_default as default };

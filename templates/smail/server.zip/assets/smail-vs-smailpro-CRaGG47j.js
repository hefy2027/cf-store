//#region app/md/es/smail-vs-smailpro.md?raw
var smail_vs_smailpro_default = "## smail.pw vs smailpro\n\nAclaración oficial: **smail.pw es un servicio independiente** de correo temporal.\n\n### Puntos importantes\n\n- smail.pw no es el mismo producto que smail pro o smailpro\n- No existe afiliación con marcas de nombre similar\n- Políticas y funciones se gestionan por separado\n\n### Páginas relacionadas\n\n- [Sobre smail.pw](/about)\n- [Preguntas frecuentes](/faq)\n- [Política de privacidad](/privacy)\n";
//#endregion
export { smail_vs_smailpro_default as default };

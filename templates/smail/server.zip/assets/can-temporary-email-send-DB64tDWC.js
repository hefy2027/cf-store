//#region app/md/ko/can-temporary-email-send.md?raw
var can_temporary_email_send_default = "## 임시 이메일로 발신할 수 있나요?\n\n대부분의 서비스에서 **임시 이메일은 수신 전용**입니다. 주 용도는 OTP와 확인 링크 수신입니다.\n\n### 수신 전용인 이유\n\n- 스팸/악용 위험 감소\n- 보안 운영 단순화\n- 일회용 메일함 안정성 확보\n\n### 발신이 필요한 경우\n\n발송, 회신, 장기 보관이 필요하면 장기 메일 서비스를 사용하세요.\n\n### 관련 페이지\n\n- [인증용 일회용 이메일](/disposable-email-for-verification)\n- [가입 없는 임시 이메일](/temporary-email-no-registration)\n- [이용약관](/terms)\n";
//#endregion
export { can_temporary_email_send_default as default };

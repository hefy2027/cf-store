//#region app/md/ja/terms.md?raw
var terms_default = "## 利用規約\n\nsmail.pw を利用することで本規約に同意したものとみなします。\n\n### 許可される利用\n\n- 低リスクの登録・認証\n- 一時的なメール受信\n\n### 禁止される利用\n\n- スパム、詐欺、フィッシング\n- 違法・有害な行為\n\n### 免責\n\n24時間を超える保持や恒久的な配信は保証されません。\n";
//#endregion
export { terms_default as default };

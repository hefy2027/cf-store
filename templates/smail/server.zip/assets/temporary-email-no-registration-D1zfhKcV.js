//#region app/md/ja/temporary-email-no-registration.md?raw
var temporary_email_no_registration_default = "## 登録不要の一時メール\n\nsmail.pw では、アカウント作成なしで一時メールをすぐ利用できます。\n\n### 向いている場面\n\n- ツールの短時間試用\n- メール必須の一回限りダウンロード\n- 一時的なコミュニティ登録\n\n### 利点\n\n- 個人情報の露出を抑える\n- オンボーディング不要\n- メイン受信箱を汚さない\n\n### 注意\n\n長期運用や重要アカウントには使用しないでください。\n\n### 関連ページ\n\n- [24時間 一時メール](/temporary-email-24-hours)\n- [認証コード用使い捨てメール](/disposable-email-for-verification)\n- [プライバシーポリシー](/privacy)\n\n### おすすめの使い方\n\n登録を素早く進めたい場合は [登録向け一時メール](/temporary-email-for-registration) と [オンライン一時メール](/online-temporary-email) も確認してください。\n";
//#endregion
export { temporary_email_no_registration_default as default };

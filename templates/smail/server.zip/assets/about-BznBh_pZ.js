//#region app/md/pt/about.md?raw
var about_default = "## Sobre o smail.pw (Email temporário)\n\nsmail.pw é um serviço de **email temporário** para cadastros de baixo risco, OTP e verificações pontuais.\n\n### Para que usar\n\n- Testar serviços sem expor o email principal\n- Receber links de confirmação de uso único\n- Reduzir spam na caixa pessoal\n\n### Limites importantes\n\nNão use para banco, trabalho, governo ou recuperação crítica de contas.\n\n### Contato\n\nEnvie feedback pelo canal de contato disponível no site.\n";
//#endregion
export { about_default as default };

//#region app/md/ko/smail-vs-smailpro.md?raw
var smail_vs_smailpro_default = "## smail.pw vs smailpro\n\n공식 안내: **smail.pw는 독립 서비스**입니다.\n\n### 핵심 내용\n\n- smail.pw는 smail pro / smailpro와 동일 서비스가 아님\n- 유사 명칭 서비스와 제휴 관계 없음\n- 기능/정책/운영 인프라가 독립적임\n\n### 관련 페이지\n\n- [smail.pw 소개](/about)\n- [자주 묻는 질문](/faq)\n- [개인정보 처리방침](/privacy)\n";
//#endregion
export { smail_vs_smailpro_default as default };

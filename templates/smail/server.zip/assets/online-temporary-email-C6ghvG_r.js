//#region app/md/de/online-temporary-email.md?raw
var online_temporary_email_default = "## Online-Temporäre E-Mail\n\nMit **Online-Temporärmail** empfängst du Verifizierungsmails direkt im Browser.\n\n### Vorteile\n\n- Sofort nutzbar ohne Installation\n- Schnelles Aktualisieren des Posteingangs\n- Schutz deiner persönlichen Hauptadresse\n\n### Wenn OTP fehlt\n\n- Adresse exakt prüfen\n- Code erneut anfordern\n- Kurz warten und erneut aktualisieren\n\n### Verwandte Seiten\n\n- [24-Stunden-Temporäre E-Mail](/temporary-email-24-hours)\n- [Temporäre E-Mail für Registrierung](/temporary-email-for-registration)\n- [Wegwerf-E-Mail für Verifizierung](/disposable-email-for-verification)\n";
//#endregion
export { online_temporary_email_default as default };

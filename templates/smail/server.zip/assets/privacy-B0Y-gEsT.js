//#region app/md/pt/privacy.md?raw
var privacy_default = "## Política de privacidade\n\nsmail.pw é um serviço de email temporário. Processamos apenas dados mínimos para entrega e proteção contra abuso.\n\n### Dados que podem ser tratados\n\n- Endereço temporário e emails recebidos\n- Dados técnicos básicos (IP, navegador, horário)\n\n### Retenção\n\nO conteúdo de email é mantido por até 24 horas e removido automaticamente depois.\n\n### Importante\n\nNão utilize para informações sensíveis ou contas críticas.\n";
//#endregion
export { privacy_default as default };

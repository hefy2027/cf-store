//#region app/md/fr/terms.md?raw
var terms_default = "## Conditions d'utilisation\n\nEn utilisant smail.pw, vous acceptez ces conditions.\n\n### Usage autorisé\n\n- Inscriptions et vérifications à faible risque\n- Réception temporaire de messages\n\n### Usage interdit\n\n- Spam, fraude, phishing\n- Activité illégale ou malveillante\n\n### Limitation\n\nAucune garantie de livraison permanente ni de conservation au-delà de 24 heures.\n";
//#endregion
export { terms_default as default };

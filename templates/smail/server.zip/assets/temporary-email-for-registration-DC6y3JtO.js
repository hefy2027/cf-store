//#region app/md/ja/temporary-email-for-registration.md?raw
var temporary_email_for_registration_default = "## 登録向け一時メール\n\n**登録向け一時メール**は、アカウント作成時にメインアドレスを公開したくない場合に有効です。\n\n### 向いている場面\n\n- トライアル登録\n- ダウンロード前の確認メール\n- 低リスクなサービス登録\n\n### 手順\n\n1. smail.pw で使い捨てアドレスを生成。\n2. 登録フォームに入力。\n3. OTP または確認リンクを受信。\n4. メインメールを公開せず登録完了。\n\n### 関連ページ\n\n- [登録不要の一時メール](/temporary-email-no-registration)\n- [認証用使い捨てメール](/disposable-email-for-verification)\n- [よくある質問](/faq)\n";
//#endregion
export { temporary_email_for_registration_default as default };

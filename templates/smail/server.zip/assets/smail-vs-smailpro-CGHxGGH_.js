//#region app/md/pt/smail-vs-smailpro.md?raw
var smail_vs_smailpro_default = "## smail.pw vs smailpro\n\nEsclarecimento oficial: **smail.pw é um serviço independente**.\n\n### Pontos importantes\n\n- smail.pw não é o mesmo produto que smail pro / smailpro\n- Não há afiliação com marcas de nome parecido\n- Funções e políticas são geridas separadamente\n\n### Páginas relacionadas\n\n- [Sobre o smail.pw](/about)\n- [Perguntas frequentes](/faq)\n- [Política de privacidade](/privacy)\n";
//#endregion
export { smail_vs_smailpro_default as default };

import { C as PostalMime, D as __exportAll, E as __commonJSMin, O as __toESM$1, S as require_react, _ as useLocation, a as Links, b as withComponentProps, c as Navigate, d as ScrollRestoration, f as data, g as useLoaderData, h as useFetcher, i as Link, l as Outlet, m as redirect, n as createCookieSessionStorage, o as Meta, p as isRouteErrorResponse, s as NavLink, t as ServerRouter, u as Scripts, v as useNavigate, w as customAlphabet, x as withErrorBoundaryProps, y as useRevalidator } from "./chunk-BFXCU3MI-CvhDCxAg.js";
//#region node_modules/.pnpm/isbot@5.1.39/node_modules/isbot/index.mjs
var fullPattern = " daum[ /]| deusu/|(?:^|[^g])news(?!sapphire)|(?<! (?:channel/|google/))google(?!(app|/google| pixel))|(?<! cu)bots?(?:\\b|_)|(?<!(?:lib))http|(?<!cam)scan|24x7|@[a-z][\\w-]+\\.|\\(\\)|\\.com\\b|\\b\\w+\\.ai|\\bcursor/|\\bmanus-user/|\\bort/|\\bperl\\b|\\bplaywright\\b|\\bsecurityheaders\\b|\\bselenium\\b|\\btime/|\\||^[\\w \\.\\-\\(?:\\):%]+(?:/v?\\d+(?:\\.\\d+)?(?:\\.\\d{1,10})*?)?(?:,|$)|^[\\w\\-]+/[\\w]+$|^[^ ]{50,}$|^\\d+\\b|^\\W|^\\w*search\\b|^\\w+/[\\w\\(\\)]*$|^\\w+/\\d\\.\\d\\s\\([\\w@]+\\)$|^active|^ad muncher|^amaya|^apache/|^avsdevicesdk/|^azure|^biglotron|^bot|^bw/|^clamav[ /]|^claude-code/|^client/|^cobweb/|^custom|^ddg[_-]android|^discourse|^dispatch/\\d|^downcast/|^duckduckgo|^email|^facebook|^getright/|^gozilla/|^hobbit|^hotzonu|^hwcdn/|^igetter/|^jeode/|^jetty/|^jigsaw|^microsoft bits|^movabletype|^mozilla/\\d\\.\\d\\s[\\w\\.-]+$|^mozilla/\\d\\.\\d\\s\\((?:compatible;)?(?:\\s?[\\w\\d-.]+\\/\\d+\\.\\d+)?\\)$|^navermailapp|^netsurf|^offline|^openai/|^owler|^php|^postman|^python|^rank|^read|^reed|^rest|^rss|^snapchat|^space bison|^svn|^swcd |^taringa|^thumbor/|^track|^w3c|^webbandit/|^webcopier|^wget|^whatsapp|^wordpress|^xenu link sleuth|^yahoo|^yandex|^zdm/\\d|^zoom marketplace/|advisor|agent\\b|analyzer|archive|ask jeeves/teoma|audit|bit\\.ly/|bluecoat drtr|browsex|burpcollaborator|capture|catch|check\\b|checker|chrome-lighthouse|chromeframe|classifier|cloudflare|convertify|crawl|cypress/|dareboost|datanyze|dejaclick|detect|dmbrowser|download|exaleadcloudview|feed|fetcher|firephp|functionize|grab|headless|httrack|hubspot marketing grader|ibisbrowser|infrawatch|insight|inspect|iplabel|java(?!;)|library|linkcheck|mail\\.ru/|manager|measure|monitor\\b|neustar wpm|node\\b|nutch|offbyone|onetrust|optimize|pageburst|pagespeed|parser|phantomjs|pingdom|powermarks|preview|proxy|ptst[ /]\\d|retriever|rexx;|rigor|rss\\b|scrape|server|sogou|sparkler/|speedcurve|spider|splash|statuscake|supercleaner|synapse|synthetic|tools|torrent|transcoder|url|validator|virtuoso|wappalyzer|webglance|webkit2png|whatcms/|xtate/";
var naivePattern = /bot|crawl|http|lighthouse|scan|search|spider/i;
var pattern;
function getPattern() {
	if (pattern instanceof RegExp) return pattern;
	try {
		pattern = new RegExp(fullPattern, "i");
	} catch (error) {
		pattern = naivePattern;
	}
	return pattern;
}
var isNonEmptyString = (value) => typeof value === "string" && value !== "";
function isbot(userAgent) {
	return isNonEmptyString(userAgent) && getPattern().test(userAgent);
}
//#endregion
//#region node_modules/.pnpm/react-dom@19.2.5_react@19.2.5/node_modules/react-dom/cjs/react-dom.production.js
/**
* @license React
* react-dom.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_dom_production = /* @__PURE__ */ __commonJSMin(((exports) => {
	var React = require_react();
	function formatProdErrorMessage(code) {
		var url = "https://react.dev/errors/" + code;
		if (1 < arguments.length) {
			url += "?args[]=" + encodeURIComponent(arguments[1]);
			for (var i = 2; i < arguments.length; i++) url += "&args[]=" + encodeURIComponent(arguments[i]);
		}
		return "Minified React error #" + code + "; visit " + url + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
	}
	function noop() {}
	var Internals = {
		d: {
			f: noop,
			r: function() {
				throw Error(formatProdErrorMessage(522));
			},
			D: noop,
			C: noop,
			L: noop,
			m: noop,
			X: noop,
			S: noop,
			M: noop
		},
		p: 0,
		findDOMNode: null
	}, REACT_PORTAL_TYPE = Symbol.for("react.portal");
	function createPortal$1(children, containerInfo, implementation) {
		var key = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
		return {
			$$typeof: REACT_PORTAL_TYPE,
			key: null == key ? null : "" + key,
			children,
			containerInfo,
			implementation
		};
	}
	var ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
	function getCrossOriginStringAs(as, input) {
		if ("font" === as) return "";
		if ("string" === typeof input) return "use-credentials" === input ? input : "";
	}
	exports.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = Internals;
	exports.createPortal = function(children, container) {
		var key = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
		if (!container || 1 !== container.nodeType && 9 !== container.nodeType && 11 !== container.nodeType) throw Error(formatProdErrorMessage(299));
		return createPortal$1(children, container, null, key);
	};
	exports.flushSync = function(fn) {
		var previousTransition = ReactSharedInternals.T, previousUpdatePriority = Internals.p;
		try {
			if (ReactSharedInternals.T = null, Internals.p = 2, fn) return fn();
		} finally {
			ReactSharedInternals.T = previousTransition, Internals.p = previousUpdatePriority, Internals.d.f();
		}
	};
	exports.preconnect = function(href, options) {
		"string" === typeof href && (options ? (options = options.crossOrigin, options = "string" === typeof options ? "use-credentials" === options ? options : "" : void 0) : options = null, Internals.d.C(href, options));
	};
	exports.prefetchDNS = function(href) {
		"string" === typeof href && Internals.d.D(href);
	};
	exports.preinit = function(href, options) {
		if ("string" === typeof href && options && "string" === typeof options.as) {
			var as = options.as, crossOrigin = getCrossOriginStringAs(as, options.crossOrigin), integrity = "string" === typeof options.integrity ? options.integrity : void 0, fetchPriority = "string" === typeof options.fetchPriority ? options.fetchPriority : void 0;
			"style" === as ? Internals.d.S(href, "string" === typeof options.precedence ? options.precedence : void 0, {
				crossOrigin,
				integrity,
				fetchPriority
			}) : "script" === as && Internals.d.X(href, {
				crossOrigin,
				integrity,
				fetchPriority,
				nonce: "string" === typeof options.nonce ? options.nonce : void 0
			});
		}
	};
	exports.preinitModule = function(href, options) {
		if ("string" === typeof href) if ("object" === typeof options && null !== options) {
			if (null == options.as || "script" === options.as) {
				var crossOrigin = getCrossOriginStringAs(options.as, options.crossOrigin);
				Internals.d.M(href, {
					crossOrigin,
					integrity: "string" === typeof options.integrity ? options.integrity : void 0,
					nonce: "string" === typeof options.nonce ? options.nonce : void 0
				});
			}
		} else options ?? Internals.d.M(href);
	};
	exports.preload = function(href, options) {
		if ("string" === typeof href && "object" === typeof options && null !== options && "string" === typeof options.as) {
			var as = options.as, crossOrigin = getCrossOriginStringAs(as, options.crossOrigin);
			Internals.d.L(href, as, {
				crossOrigin,
				integrity: "string" === typeof options.integrity ? options.integrity : void 0,
				nonce: "string" === typeof options.nonce ? options.nonce : void 0,
				type: "string" === typeof options.type ? options.type : void 0,
				fetchPriority: "string" === typeof options.fetchPriority ? options.fetchPriority : void 0,
				referrerPolicy: "string" === typeof options.referrerPolicy ? options.referrerPolicy : void 0,
				imageSrcSet: "string" === typeof options.imageSrcSet ? options.imageSrcSet : void 0,
				imageSizes: "string" === typeof options.imageSizes ? options.imageSizes : void 0,
				media: "string" === typeof options.media ? options.media : void 0
			});
		}
	};
	exports.preloadModule = function(href, options) {
		if ("string" === typeof href) if (options) {
			var crossOrigin = getCrossOriginStringAs(options.as, options.crossOrigin);
			Internals.d.m(href, {
				as: "string" === typeof options.as && "script" !== options.as ? options.as : void 0,
				crossOrigin,
				integrity: "string" === typeof options.integrity ? options.integrity : void 0
			});
		} else Internals.d.m(href);
	};
	exports.requestFormReset = function(form) {
		Internals.d.r(form);
	};
	exports.unstable_batchedUpdates = function(fn, a) {
		return fn(a);
	};
	exports.useFormState = function(action, initialState, permalink) {
		return ReactSharedInternals.H.useFormState(action, initialState, permalink);
	};
	exports.useFormStatus = function() {
		return ReactSharedInternals.H.useHostTransitionStatus();
	};
	exports.version = "19.2.5";
}));
//#endregion
//#region node_modules/.pnpm/react-dom@19.2.5_react@19.2.5/node_modules/react-dom/index.js
var require_react_dom = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function checkDCE() {
		if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function") return;
		try {
			__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
		} catch (err) {
			console.error(err);
		}
	}
	checkDCE();
	module.exports = require_react_dom_production();
}));
//#endregion
//#region node_modules/.pnpm/react-dom@19.2.5_react@19.2.5/node_modules/react-dom/cjs/react-dom-server.edge.production.js
/**
* @license React
* react-dom-server.edge.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_dom_server_edge_production = /* @__PURE__ */ __commonJSMin(((exports) => {
	var React = require_react(), ReactDOM = require_react_dom(), REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_SCOPE_TYPE = Symbol.for("react.scope"), REACT_ACTIVITY_TYPE = Symbol.for("react.activity"), REACT_LEGACY_HIDDEN_TYPE = Symbol.for("react.legacy_hidden"), REACT_MEMO_CACHE_SENTINEL = Symbol.for("react.memo_cache_sentinel"), REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition"), MAYBE_ITERATOR_SYMBOL = Symbol.iterator;
	function getIteratorFn(maybeIterable) {
		if (null === maybeIterable || "object" !== typeof maybeIterable) return null;
		maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
		return "function" === typeof maybeIterable ? maybeIterable : null;
	}
	var isArrayImpl = Array.isArray;
	function murmurhash3_32_gc(key, seed) {
		var remainder = key.length & 3;
		var bytes = key.length - remainder;
		var h1 = seed;
		for (seed = 0; seed < bytes;) {
			var k1 = key.charCodeAt(seed) & 255 | (key.charCodeAt(++seed) & 255) << 8 | (key.charCodeAt(++seed) & 255) << 16 | (key.charCodeAt(++seed) & 255) << 24;
			++seed;
			k1 = 3432918353 * (k1 & 65535) + ((3432918353 * (k1 >>> 16) & 65535) << 16) & 4294967295;
			k1 = k1 << 15 | k1 >>> 17;
			k1 = 461845907 * (k1 & 65535) + ((461845907 * (k1 >>> 16) & 65535) << 16) & 4294967295;
			h1 ^= k1;
			h1 = h1 << 13 | h1 >>> 19;
			h1 = 5 * (h1 & 65535) + ((5 * (h1 >>> 16) & 65535) << 16) & 4294967295;
			h1 = (h1 & 65535) + 27492 + (((h1 >>> 16) + 58964 & 65535) << 16);
		}
		k1 = 0;
		switch (remainder) {
			case 3: k1 ^= (key.charCodeAt(seed + 2) & 255) << 16;
			case 2: k1 ^= (key.charCodeAt(seed + 1) & 255) << 8;
			case 1: k1 ^= key.charCodeAt(seed) & 255, k1 = 3432918353 * (k1 & 65535) + ((3432918353 * (k1 >>> 16) & 65535) << 16) & 4294967295, k1 = k1 << 15 | k1 >>> 17, h1 ^= 461845907 * (k1 & 65535) + ((461845907 * (k1 >>> 16) & 65535) << 16) & 4294967295;
		}
		h1 ^= key.length;
		h1 ^= h1 >>> 16;
		h1 = 2246822507 * (h1 & 65535) + ((2246822507 * (h1 >>> 16) & 65535) << 16) & 4294967295;
		h1 ^= h1 >>> 13;
		h1 = 3266489909 * (h1 & 65535) + ((3266489909 * (h1 >>> 16) & 65535) << 16) & 4294967295;
		return (h1 ^ h1 >>> 16) >>> 0;
	}
	function handleErrorInNextTick(error) {
		setTimeout(function() {
			throw error;
		});
	}
	var LocalPromise = Promise, scheduleMicrotask = "function" === typeof queueMicrotask ? queueMicrotask : function(callback) {
		LocalPromise.resolve(null).then(callback).catch(handleErrorInNextTick);
	}, currentView = null, writtenBytes = 0;
	function writeChunk(destination, chunk) {
		if (0 !== chunk.byteLength) if (2048 < chunk.byteLength) 0 < writtenBytes && (destination.enqueue(new Uint8Array(currentView.buffer, 0, writtenBytes)), currentView = new Uint8Array(2048), writtenBytes = 0), destination.enqueue(chunk);
		else {
			var allowableBytes = currentView.length - writtenBytes;
			allowableBytes < chunk.byteLength && (0 === allowableBytes ? destination.enqueue(currentView) : (currentView.set(chunk.subarray(0, allowableBytes), writtenBytes), destination.enqueue(currentView), chunk = chunk.subarray(allowableBytes)), currentView = new Uint8Array(2048), writtenBytes = 0);
			currentView.set(chunk, writtenBytes);
			writtenBytes += chunk.byteLength;
		}
	}
	function writeChunkAndReturn(destination, chunk) {
		writeChunk(destination, chunk);
		return !0;
	}
	function completeWriting(destination) {
		currentView && 0 < writtenBytes && (destination.enqueue(new Uint8Array(currentView.buffer, 0, writtenBytes)), currentView = null, writtenBytes = 0);
	}
	var textEncoder = new TextEncoder();
	function stringToChunk(content) {
		return textEncoder.encode(content);
	}
	function stringToPrecomputedChunk(content) {
		return textEncoder.encode(content);
	}
	function byteLengthOfChunk(chunk) {
		return chunk.byteLength;
	}
	function closeWithError(destination, error) {
		"function" === typeof destination.error ? destination.error(error) : destination.close();
	}
	var assign = Object.assign, hasOwnProperty = Object.prototype.hasOwnProperty, VALID_ATTRIBUTE_NAME_REGEX = RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"), illegalAttributeNameCache = {}, validatedAttributeNameCache = {};
	function isAttributeNameSafe(attributeName) {
		if (hasOwnProperty.call(validatedAttributeNameCache, attributeName)) return !0;
		if (hasOwnProperty.call(illegalAttributeNameCache, attributeName)) return !1;
		if (VALID_ATTRIBUTE_NAME_REGEX.test(attributeName)) return validatedAttributeNameCache[attributeName] = !0;
		illegalAttributeNameCache[attributeName] = !0;
		return !1;
	}
	var unitlessNumbers = new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" ")), aliases = new Map([
		["acceptCharset", "accept-charset"],
		["htmlFor", "for"],
		["httpEquiv", "http-equiv"],
		["crossOrigin", "crossorigin"],
		["accentHeight", "accent-height"],
		["alignmentBaseline", "alignment-baseline"],
		["arabicForm", "arabic-form"],
		["baselineShift", "baseline-shift"],
		["capHeight", "cap-height"],
		["clipPath", "clip-path"],
		["clipRule", "clip-rule"],
		["colorInterpolation", "color-interpolation"],
		["colorInterpolationFilters", "color-interpolation-filters"],
		["colorProfile", "color-profile"],
		["colorRendering", "color-rendering"],
		["dominantBaseline", "dominant-baseline"],
		["enableBackground", "enable-background"],
		["fillOpacity", "fill-opacity"],
		["fillRule", "fill-rule"],
		["floodColor", "flood-color"],
		["floodOpacity", "flood-opacity"],
		["fontFamily", "font-family"],
		["fontSize", "font-size"],
		["fontSizeAdjust", "font-size-adjust"],
		["fontStretch", "font-stretch"],
		["fontStyle", "font-style"],
		["fontVariant", "font-variant"],
		["fontWeight", "font-weight"],
		["glyphName", "glyph-name"],
		["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
		["glyphOrientationVertical", "glyph-orientation-vertical"],
		["horizAdvX", "horiz-adv-x"],
		["horizOriginX", "horiz-origin-x"],
		["imageRendering", "image-rendering"],
		["letterSpacing", "letter-spacing"],
		["lightingColor", "lighting-color"],
		["markerEnd", "marker-end"],
		["markerMid", "marker-mid"],
		["markerStart", "marker-start"],
		["overlinePosition", "overline-position"],
		["overlineThickness", "overline-thickness"],
		["paintOrder", "paint-order"],
		["panose-1", "panose-1"],
		["pointerEvents", "pointer-events"],
		["renderingIntent", "rendering-intent"],
		["shapeRendering", "shape-rendering"],
		["stopColor", "stop-color"],
		["stopOpacity", "stop-opacity"],
		["strikethroughPosition", "strikethrough-position"],
		["strikethroughThickness", "strikethrough-thickness"],
		["strokeDasharray", "stroke-dasharray"],
		["strokeDashoffset", "stroke-dashoffset"],
		["strokeLinecap", "stroke-linecap"],
		["strokeLinejoin", "stroke-linejoin"],
		["strokeMiterlimit", "stroke-miterlimit"],
		["strokeOpacity", "stroke-opacity"],
		["strokeWidth", "stroke-width"],
		["textAnchor", "text-anchor"],
		["textDecoration", "text-decoration"],
		["textRendering", "text-rendering"],
		["transformOrigin", "transform-origin"],
		["underlinePosition", "underline-position"],
		["underlineThickness", "underline-thickness"],
		["unicodeBidi", "unicode-bidi"],
		["unicodeRange", "unicode-range"],
		["unitsPerEm", "units-per-em"],
		["vAlphabetic", "v-alphabetic"],
		["vHanging", "v-hanging"],
		["vIdeographic", "v-ideographic"],
		["vMathematical", "v-mathematical"],
		["vectorEffect", "vector-effect"],
		["vertAdvY", "vert-adv-y"],
		["vertOriginX", "vert-origin-x"],
		["vertOriginY", "vert-origin-y"],
		["wordSpacing", "word-spacing"],
		["writingMode", "writing-mode"],
		["xmlnsXlink", "xmlns:xlink"],
		["xHeight", "x-height"]
	]), matchHtmlRegExp = /["'&<>]/;
	function escapeTextForBrowser(text) {
		if ("boolean" === typeof text || "number" === typeof text || "bigint" === typeof text) return "" + text;
		text = "" + text;
		var match = matchHtmlRegExp.exec(text);
		if (match) {
			var html = "", index, lastIndex = 0;
			for (index = match.index; index < text.length; index++) {
				switch (text.charCodeAt(index)) {
					case 34:
						match = "&quot;";
						break;
					case 38:
						match = "&amp;";
						break;
					case 39:
						match = "&#x27;";
						break;
					case 60:
						match = "&lt;";
						break;
					case 62:
						match = "&gt;";
						break;
					default: continue;
				}
				lastIndex !== index && (html += text.slice(lastIndex, index));
				lastIndex = index + 1;
				html += match;
			}
			text = lastIndex !== index ? html + text.slice(lastIndex, index) : html;
		}
		return text;
	}
	var uppercasePattern = /([A-Z])/g, msPattern = /^ms-/, isJavaScriptProtocol = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
	function sanitizeURL(url) {
		return isJavaScriptProtocol.test("" + url) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : url;
	}
	var ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, ReactDOMSharedInternals = ReactDOM.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, sharedNotPendingObject = {
		pending: !1,
		data: null,
		method: null,
		action: null
	}, previousDispatcher = ReactDOMSharedInternals.d;
	ReactDOMSharedInternals.d = {
		f: previousDispatcher.f,
		r: previousDispatcher.r,
		D: prefetchDNS,
		C: preconnect,
		L: preload,
		m: preloadModule,
		X: preinitScript,
		S: preinitStyle,
		M: preinitModuleScript
	};
	var PRELOAD_NO_CREDS = [], currentlyFlushingRenderState = null;
	stringToPrecomputedChunk("\"></template>");
	var startInlineScript = stringToPrecomputedChunk("<script"), endInlineScript = stringToPrecomputedChunk("<\/script>"), startScriptSrc = stringToPrecomputedChunk("<script src=\""), startModuleSrc = stringToPrecomputedChunk("<script type=\"module\" src=\""), scriptNonce = stringToPrecomputedChunk(" nonce=\""), scriptIntegirty = stringToPrecomputedChunk(" integrity=\""), scriptCrossOrigin = stringToPrecomputedChunk(" crossorigin=\""), endAsyncScript = stringToPrecomputedChunk(" async=\"\"><\/script>"), startInlineStyle = stringToPrecomputedChunk("<style"), scriptRegex = /(<\/|<)(s)(cript)/gi;
	function scriptReplacer(match, prefix, s, suffix) {
		return "" + prefix + ("s" === s ? "\\u0073" : "\\u0053") + suffix;
	}
	var importMapScriptStart = stringToPrecomputedChunk("<script type=\"importmap\">"), importMapScriptEnd = stringToPrecomputedChunk("<\/script>");
	function createRenderState(resumableState, nonce, externalRuntimeConfig, importMap, onHeaders, maxHeadersLength) {
		externalRuntimeConfig = "string" === typeof nonce ? nonce : nonce && nonce.script;
		var inlineScriptWithNonce = void 0 === externalRuntimeConfig ? startInlineScript : stringToPrecomputedChunk("<script nonce=\"" + escapeTextForBrowser(externalRuntimeConfig) + "\""), nonceStyle = "string" === typeof nonce ? void 0 : nonce && nonce.style, inlineStyleWithNonce = void 0 === nonceStyle ? startInlineStyle : stringToPrecomputedChunk("<style nonce=\"" + escapeTextForBrowser(nonceStyle) + "\""), idPrefix = resumableState.idPrefix, bootstrapChunks = [], bootstrapScriptContent = resumableState.bootstrapScriptContent, bootstrapScripts = resumableState.bootstrapScripts, bootstrapModules = resumableState.bootstrapModules;
		void 0 !== bootstrapScriptContent && (bootstrapChunks.push(inlineScriptWithNonce), pushCompletedShellIdAttribute(bootstrapChunks, resumableState), bootstrapChunks.push(endOfStartTag, stringToChunk(("" + bootstrapScriptContent).replace(scriptRegex, scriptReplacer)), endInlineScript));
		bootstrapScriptContent = [];
		void 0 !== importMap && (bootstrapScriptContent.push(importMapScriptStart), bootstrapScriptContent.push(stringToChunk(("" + JSON.stringify(importMap)).replace(scriptRegex, scriptReplacer))), bootstrapScriptContent.push(importMapScriptEnd));
		importMap = onHeaders ? {
			preconnects: "",
			fontPreloads: "",
			highImagePreloads: "",
			remainingCapacity: 2 + ("number" === typeof maxHeadersLength ? maxHeadersLength : 2e3)
		} : null;
		onHeaders = {
			placeholderPrefix: stringToPrecomputedChunk(idPrefix + "P:"),
			segmentPrefix: stringToPrecomputedChunk(idPrefix + "S:"),
			boundaryPrefix: stringToPrecomputedChunk(idPrefix + "B:"),
			startInlineScript: inlineScriptWithNonce,
			startInlineStyle: inlineStyleWithNonce,
			preamble: createPreambleState(),
			externalRuntimeScript: null,
			bootstrapChunks,
			importMapChunks: bootstrapScriptContent,
			onHeaders,
			headers: importMap,
			resets: {
				font: {},
				dns: {},
				connect: {
					default: {},
					anonymous: {},
					credentials: {}
				},
				image: {},
				style: {}
			},
			charsetChunks: [],
			viewportChunks: [],
			hoistableChunks: [],
			preconnects: /* @__PURE__ */ new Set(),
			fontPreloads: /* @__PURE__ */ new Set(),
			highImagePreloads: /* @__PURE__ */ new Set(),
			styles: /* @__PURE__ */ new Map(),
			bootstrapScripts: /* @__PURE__ */ new Set(),
			scripts: /* @__PURE__ */ new Set(),
			bulkPreloads: /* @__PURE__ */ new Set(),
			preloads: {
				images: /* @__PURE__ */ new Map(),
				stylesheets: /* @__PURE__ */ new Map(),
				scripts: /* @__PURE__ */ new Map(),
				moduleScripts: /* @__PURE__ */ new Map()
			},
			nonce: {
				script: externalRuntimeConfig,
				style: nonceStyle
			},
			hoistableState: null,
			stylesToHoist: !1
		};
		if (void 0 !== bootstrapScripts) for (importMap = 0; importMap < bootstrapScripts.length; importMap++) idPrefix = bootstrapScripts[importMap], nonceStyle = inlineScriptWithNonce = void 0, inlineStyleWithNonce = {
			rel: "preload",
			as: "script",
			fetchPriority: "low",
			nonce
		}, "string" === typeof idPrefix ? inlineStyleWithNonce.href = maxHeadersLength = idPrefix : (inlineStyleWithNonce.href = maxHeadersLength = idPrefix.src, inlineStyleWithNonce.integrity = nonceStyle = "string" === typeof idPrefix.integrity ? idPrefix.integrity : void 0, inlineStyleWithNonce.crossOrigin = inlineScriptWithNonce = "string" === typeof idPrefix || null == idPrefix.crossOrigin ? void 0 : "use-credentials" === idPrefix.crossOrigin ? "use-credentials" : ""), idPrefix = resumableState, bootstrapScriptContent = maxHeadersLength, idPrefix.scriptResources[bootstrapScriptContent] = null, idPrefix.moduleScriptResources[bootstrapScriptContent] = null, idPrefix = [], pushLinkImpl(idPrefix, inlineStyleWithNonce), onHeaders.bootstrapScripts.add(idPrefix), bootstrapChunks.push(startScriptSrc, stringToChunk(escapeTextForBrowser(maxHeadersLength)), attributeEnd), externalRuntimeConfig && bootstrapChunks.push(scriptNonce, stringToChunk(escapeTextForBrowser(externalRuntimeConfig)), attributeEnd), "string" === typeof nonceStyle && bootstrapChunks.push(scriptIntegirty, stringToChunk(escapeTextForBrowser(nonceStyle)), attributeEnd), "string" === typeof inlineScriptWithNonce && bootstrapChunks.push(scriptCrossOrigin, stringToChunk(escapeTextForBrowser(inlineScriptWithNonce)), attributeEnd), pushCompletedShellIdAttribute(bootstrapChunks, resumableState), bootstrapChunks.push(endAsyncScript);
		if (void 0 !== bootstrapModules) for (nonce = 0; nonce < bootstrapModules.length; nonce++) nonceStyle = bootstrapModules[nonce], maxHeadersLength = importMap = void 0, inlineScriptWithNonce = {
			rel: "modulepreload",
			fetchPriority: "low",
			nonce: externalRuntimeConfig
		}, "string" === typeof nonceStyle ? inlineScriptWithNonce.href = bootstrapScripts = nonceStyle : (inlineScriptWithNonce.href = bootstrapScripts = nonceStyle.src, inlineScriptWithNonce.integrity = maxHeadersLength = "string" === typeof nonceStyle.integrity ? nonceStyle.integrity : void 0, inlineScriptWithNonce.crossOrigin = importMap = "string" === typeof nonceStyle || null == nonceStyle.crossOrigin ? void 0 : "use-credentials" === nonceStyle.crossOrigin ? "use-credentials" : ""), nonceStyle = resumableState, inlineStyleWithNonce = bootstrapScripts, nonceStyle.scriptResources[inlineStyleWithNonce] = null, nonceStyle.moduleScriptResources[inlineStyleWithNonce] = null, nonceStyle = [], pushLinkImpl(nonceStyle, inlineScriptWithNonce), onHeaders.bootstrapScripts.add(nonceStyle), bootstrapChunks.push(startModuleSrc, stringToChunk(escapeTextForBrowser(bootstrapScripts)), attributeEnd), externalRuntimeConfig && bootstrapChunks.push(scriptNonce, stringToChunk(escapeTextForBrowser(externalRuntimeConfig)), attributeEnd), "string" === typeof maxHeadersLength && bootstrapChunks.push(scriptIntegirty, stringToChunk(escapeTextForBrowser(maxHeadersLength)), attributeEnd), "string" === typeof importMap && bootstrapChunks.push(scriptCrossOrigin, stringToChunk(escapeTextForBrowser(importMap)), attributeEnd), pushCompletedShellIdAttribute(bootstrapChunks, resumableState), bootstrapChunks.push(endAsyncScript);
		return onHeaders;
	}
	function createResumableState(identifierPrefix, externalRuntimeConfig, bootstrapScriptContent, bootstrapScripts, bootstrapModules) {
		return {
			idPrefix: void 0 === identifierPrefix ? "" : identifierPrefix,
			nextFormID: 0,
			streamingFormat: 0,
			bootstrapScriptContent,
			bootstrapScripts,
			bootstrapModules,
			instructions: 0,
			hasBody: !1,
			hasHtml: !1,
			unknownResources: {},
			dnsResources: {},
			connectResources: {
				default: {},
				anonymous: {},
				credentials: {}
			},
			imageResources: {},
			styleResources: {},
			scriptResources: {},
			moduleUnknownResources: {},
			moduleScriptResources: {}
		};
	}
	function createPreambleState() {
		return {
			htmlChunks: null,
			headChunks: null,
			bodyChunks: null
		};
	}
	function createFormatContext(insertionMode, selectedValue, tagScope, viewTransition) {
		return {
			insertionMode,
			selectedValue,
			tagScope,
			viewTransition
		};
	}
	function createRootFormatContext(namespaceURI) {
		return createFormatContext("http://www.w3.org/2000/svg" === namespaceURI ? 4 : "http://www.w3.org/1998/Math/MathML" === namespaceURI ? 5 : 0, null, 0, null);
	}
	function getChildFormatContext(parentContext, type, props) {
		var subtreeScope = parentContext.tagScope & -25;
		switch (type) {
			case "noscript": return createFormatContext(2, null, subtreeScope | 1, null);
			case "select": return createFormatContext(2, null != props.value ? props.value : props.defaultValue, subtreeScope, null);
			case "svg": return createFormatContext(4, null, subtreeScope, null);
			case "picture": return createFormatContext(2, null, subtreeScope | 2, null);
			case "math": return createFormatContext(5, null, subtreeScope, null);
			case "foreignObject": return createFormatContext(2, null, subtreeScope, null);
			case "table": return createFormatContext(6, null, subtreeScope, null);
			case "thead":
			case "tbody":
			case "tfoot": return createFormatContext(7, null, subtreeScope, null);
			case "colgroup": return createFormatContext(9, null, subtreeScope, null);
			case "tr": return createFormatContext(8, null, subtreeScope, null);
			case "head":
				if (2 > parentContext.insertionMode) return createFormatContext(3, null, subtreeScope, null);
				break;
			case "html": if (0 === parentContext.insertionMode) return createFormatContext(1, null, subtreeScope, null);
		}
		return 6 <= parentContext.insertionMode || 2 > parentContext.insertionMode ? createFormatContext(2, null, subtreeScope, null) : parentContext.tagScope !== subtreeScope ? createFormatContext(parentContext.insertionMode, parentContext.selectedValue, subtreeScope, null) : parentContext;
	}
	function getSuspenseViewTransition(parentViewTransition) {
		return null === parentViewTransition ? null : {
			update: parentViewTransition.update,
			enter: "none",
			exit: "none",
			share: parentViewTransition.update,
			name: parentViewTransition.autoName,
			autoName: parentViewTransition.autoName,
			nameIdx: 0
		};
	}
	function getSuspenseFallbackFormatContext(resumableState, parentContext) {
		parentContext.tagScope & 32 && (resumableState.instructions |= 128);
		return createFormatContext(parentContext.insertionMode, parentContext.selectedValue, parentContext.tagScope | 12, getSuspenseViewTransition(parentContext.viewTransition));
	}
	function getSuspenseContentFormatContext(resumableState, parentContext) {
		resumableState = getSuspenseViewTransition(parentContext.viewTransition);
		var subtreeScope = parentContext.tagScope | 16;
		null !== resumableState && "none" !== resumableState.share && (subtreeScope |= 64);
		return createFormatContext(parentContext.insertionMode, parentContext.selectedValue, subtreeScope, resumableState);
	}
	var textSeparator = stringToPrecomputedChunk("<!-- -->");
	function pushTextInstance(target, text, renderState, textEmbedded) {
		if ("" === text) return textEmbedded;
		textEmbedded && target.push(textSeparator);
		target.push(stringToChunk(escapeTextForBrowser(text)));
		return !0;
	}
	var styleNameCache = /* @__PURE__ */ new Map(), styleAttributeStart = stringToPrecomputedChunk(" style=\""), styleAssign = stringToPrecomputedChunk(":"), styleSeparator = stringToPrecomputedChunk(";");
	function pushStyleAttribute(target, style) {
		if ("object" !== typeof style) throw Error("The `style` prop expects a mapping from style properties to values, not a string. For example, style={{marginRight: spacing + 'em'}} when using JSX.");
		var isFirst = !0, styleName;
		for (styleName in style) if (hasOwnProperty.call(style, styleName)) {
			var styleValue = style[styleName];
			if (null != styleValue && "boolean" !== typeof styleValue && "" !== styleValue) {
				if (0 === styleName.indexOf("--")) {
					var nameChunk = stringToChunk(escapeTextForBrowser(styleName));
					styleValue = stringToChunk(escapeTextForBrowser(("" + styleValue).trim()));
				} else nameChunk = styleNameCache.get(styleName), void 0 === nameChunk && (nameChunk = stringToPrecomputedChunk(escapeTextForBrowser(styleName.replace(uppercasePattern, "-$1").toLowerCase().replace(msPattern, "-ms-"))), styleNameCache.set(styleName, nameChunk)), styleValue = "number" === typeof styleValue ? 0 === styleValue || unitlessNumbers.has(styleName) ? stringToChunk("" + styleValue) : stringToChunk(styleValue + "px") : stringToChunk(escapeTextForBrowser(("" + styleValue).trim()));
				isFirst ? (isFirst = !1, target.push(styleAttributeStart, nameChunk, styleAssign, styleValue)) : target.push(styleSeparator, nameChunk, styleAssign, styleValue);
			}
		}
		isFirst || target.push(attributeEnd);
	}
	var attributeSeparator = stringToPrecomputedChunk(" "), attributeAssign = stringToPrecomputedChunk("=\""), attributeEnd = stringToPrecomputedChunk("\""), attributeEmptyString = stringToPrecomputedChunk("=\"\"");
	function pushBooleanAttribute(target, name, value) {
		value && "function" !== typeof value && "symbol" !== typeof value && target.push(attributeSeparator, stringToChunk(name), attributeEmptyString);
	}
	function pushStringAttribute(target, name, value) {
		"function" !== typeof value && "symbol" !== typeof value && "boolean" !== typeof value && target.push(attributeSeparator, stringToChunk(name), attributeAssign, stringToChunk(escapeTextForBrowser(value)), attributeEnd);
	}
	var actionJavaScriptURL = stringToPrecomputedChunk(escapeTextForBrowser("javascript:throw new Error('React form unexpectedly submitted.')")), startHiddenInputChunk = stringToPrecomputedChunk("<input type=\"hidden\"");
	function pushAdditionalFormField(value, key) {
		this.push(startHiddenInputChunk);
		validateAdditionalFormField(value);
		pushStringAttribute(this, "name", key);
		pushStringAttribute(this, "value", value);
		this.push(endOfStartTagSelfClosing);
	}
	function validateAdditionalFormField(value) {
		if ("string" !== typeof value) throw Error("File/Blob fields are not yet supported in progressive forms. Will fallback to client hydration.");
	}
	function getCustomFormFields(resumableState, formAction) {
		if ("function" === typeof formAction.$$FORM_ACTION) {
			var id = resumableState.nextFormID++;
			resumableState = resumableState.idPrefix + id;
			try {
				var customFields = formAction.$$FORM_ACTION(resumableState);
				if (customFields) customFields.data?.forEach(validateAdditionalFormField);
				return customFields;
			} catch (x) {
				if ("object" === typeof x && null !== x && "function" === typeof x.then) throw x;
			}
		}
		return null;
	}
	function pushFormActionAttribute(target, resumableState, renderState, formAction, formEncType, formMethod, formTarget, name) {
		var formData = null;
		if ("function" === typeof formAction) {
			var customFields = getCustomFormFields(resumableState, formAction);
			null !== customFields ? (name = customFields.name, formAction = customFields.action || "", formEncType = customFields.encType, formMethod = customFields.method, formTarget = customFields.target, formData = customFields.data) : (target.push(attributeSeparator, stringToChunk("formAction"), attributeAssign, actionJavaScriptURL, attributeEnd), formTarget = formMethod = formEncType = formAction = name = null, injectFormReplayingRuntime(resumableState, renderState));
		}
		null != name && pushAttribute(target, "name", name);
		null != formAction && pushAttribute(target, "formAction", formAction);
		null != formEncType && pushAttribute(target, "formEncType", formEncType);
		null != formMethod && pushAttribute(target, "formMethod", formMethod);
		null != formTarget && pushAttribute(target, "formTarget", formTarget);
		return formData;
	}
	function pushAttribute(target, name, value) {
		switch (name) {
			case "className":
				pushStringAttribute(target, "class", value);
				break;
			case "tabIndex":
				pushStringAttribute(target, "tabindex", value);
				break;
			case "dir":
			case "role":
			case "viewBox":
			case "width":
			case "height":
				pushStringAttribute(target, name, value);
				break;
			case "style":
				pushStyleAttribute(target, value);
				break;
			case "src":
			case "href": if ("" === value) break;
			case "action":
			case "formAction":
				if (null == value || "function" === typeof value || "symbol" === typeof value || "boolean" === typeof value) break;
				value = sanitizeURL("" + value);
				target.push(attributeSeparator, stringToChunk(name), attributeAssign, stringToChunk(escapeTextForBrowser(value)), attributeEnd);
				break;
			case "defaultValue":
			case "defaultChecked":
			case "innerHTML":
			case "suppressContentEditableWarning":
			case "suppressHydrationWarning":
			case "ref": break;
			case "autoFocus":
			case "multiple":
			case "muted":
				pushBooleanAttribute(target, name.toLowerCase(), value);
				break;
			case "xlinkHref":
				if ("function" === typeof value || "symbol" === typeof value || "boolean" === typeof value) break;
				value = sanitizeURL("" + value);
				target.push(attributeSeparator, stringToChunk("xlink:href"), attributeAssign, stringToChunk(escapeTextForBrowser(value)), attributeEnd);
				break;
			case "contentEditable":
			case "spellCheck":
			case "draggable":
			case "value":
			case "autoReverse":
			case "externalResourcesRequired":
			case "focusable":
			case "preserveAlpha":
				"function" !== typeof value && "symbol" !== typeof value && target.push(attributeSeparator, stringToChunk(name), attributeAssign, stringToChunk(escapeTextForBrowser(value)), attributeEnd);
				break;
			case "inert":
			case "allowFullScreen":
			case "async":
			case "autoPlay":
			case "controls":
			case "default":
			case "defer":
			case "disabled":
			case "disablePictureInPicture":
			case "disableRemotePlayback":
			case "formNoValidate":
			case "hidden":
			case "loop":
			case "noModule":
			case "noValidate":
			case "open":
			case "playsInline":
			case "readOnly":
			case "required":
			case "reversed":
			case "scoped":
			case "seamless":
			case "itemScope":
				value && "function" !== typeof value && "symbol" !== typeof value && target.push(attributeSeparator, stringToChunk(name), attributeEmptyString);
				break;
			case "capture":
			case "download":
				!0 === value ? target.push(attributeSeparator, stringToChunk(name), attributeEmptyString) : !1 !== value && "function" !== typeof value && "symbol" !== typeof value && target.push(attributeSeparator, stringToChunk(name), attributeAssign, stringToChunk(escapeTextForBrowser(value)), attributeEnd);
				break;
			case "cols":
			case "rows":
			case "size":
			case "span":
				"function" !== typeof value && "symbol" !== typeof value && !isNaN(value) && 1 <= value && target.push(attributeSeparator, stringToChunk(name), attributeAssign, stringToChunk(escapeTextForBrowser(value)), attributeEnd);
				break;
			case "rowSpan":
			case "start":
				"function" === typeof value || "symbol" === typeof value || isNaN(value) || target.push(attributeSeparator, stringToChunk(name), attributeAssign, stringToChunk(escapeTextForBrowser(value)), attributeEnd);
				break;
			case "xlinkActuate":
				pushStringAttribute(target, "xlink:actuate", value);
				break;
			case "xlinkArcrole":
				pushStringAttribute(target, "xlink:arcrole", value);
				break;
			case "xlinkRole":
				pushStringAttribute(target, "xlink:role", value);
				break;
			case "xlinkShow":
				pushStringAttribute(target, "xlink:show", value);
				break;
			case "xlinkTitle":
				pushStringAttribute(target, "xlink:title", value);
				break;
			case "xlinkType":
				pushStringAttribute(target, "xlink:type", value);
				break;
			case "xmlBase":
				pushStringAttribute(target, "xml:base", value);
				break;
			case "xmlLang":
				pushStringAttribute(target, "xml:lang", value);
				break;
			case "xmlSpace":
				pushStringAttribute(target, "xml:space", value);
				break;
			default: if (!(2 < name.length) || "o" !== name[0] && "O" !== name[0] || "n" !== name[1] && "N" !== name[1]) {
				if (name = aliases.get(name) || name, isAttributeNameSafe(name)) {
					switch (typeof value) {
						case "function":
						case "symbol": return;
						case "boolean":
							var prefix$8 = name.toLowerCase().slice(0, 5);
							if ("data-" !== prefix$8 && "aria-" !== prefix$8) return;
					}
					target.push(attributeSeparator, stringToChunk(name), attributeAssign, stringToChunk(escapeTextForBrowser(value)), attributeEnd);
				}
			}
		}
	}
	var endOfStartTag = stringToPrecomputedChunk(">"), endOfStartTagSelfClosing = stringToPrecomputedChunk("/>");
	function pushInnerHTML(target, innerHTML, children) {
		if (null != innerHTML) {
			if (null != children) throw Error("Can only set one of `children` or `props.dangerouslySetInnerHTML`.");
			if ("object" !== typeof innerHTML || !("__html" in innerHTML)) throw Error("`props.dangerouslySetInnerHTML` must be in the form `{__html: ...}`. Please visit https://react.dev/link/dangerously-set-inner-html for more information.");
			innerHTML = innerHTML.__html;
			null !== innerHTML && void 0 !== innerHTML && target.push(stringToChunk("" + innerHTML));
		}
	}
	function flattenOptionChildren(children) {
		var content = "";
		React.Children.forEach(children, function(child) {
			null != child && (content += child);
		});
		return content;
	}
	var selectedMarkerAttribute = stringToPrecomputedChunk(" selected=\"\""), formReplayingRuntimeScript = stringToPrecomputedChunk("addEventListener(\"submit\",function(a){if(!a.defaultPrevented){var c=a.target,d=a.submitter,e=c.action,b=d;if(d){var f=d.getAttribute(\"formAction\");null!=f&&(e=f,b=null)}\"javascript:throw new Error('React form unexpectedly submitted.')\"===e&&(a.preventDefault(),b?(a=document.createElement(\"input\"),a.name=b.name,a.value=b.value,b.parentNode.insertBefore(a,b),b=new FormData(c),a.parentNode.removeChild(a)):b=new FormData(c),a=c.ownerDocument||c,(a.$$reactFormReplay=a.$$reactFormReplay||[]).push(c,d,b))}});");
	function injectFormReplayingRuntime(resumableState, renderState) {
		if (0 === (resumableState.instructions & 16)) {
			resumableState.instructions |= 16;
			var preamble = renderState.preamble, bootstrapChunks = renderState.bootstrapChunks;
			(preamble.htmlChunks || preamble.headChunks) && 0 === bootstrapChunks.length ? (bootstrapChunks.push(renderState.startInlineScript), pushCompletedShellIdAttribute(bootstrapChunks, resumableState), bootstrapChunks.push(endOfStartTag, formReplayingRuntimeScript, endInlineScript)) : bootstrapChunks.unshift(renderState.startInlineScript, endOfStartTag, formReplayingRuntimeScript, endInlineScript);
		}
	}
	var formStateMarkerIsMatching = stringToPrecomputedChunk("<!--F!-->"), formStateMarkerIsNotMatching = stringToPrecomputedChunk("<!--F-->");
	function pushLinkImpl(target, props) {
		target.push(startChunkForTag("link"));
		for (var propKey in props) if (hasOwnProperty.call(props, propKey)) {
			var propValue = props[propKey];
			if (null != propValue) switch (propKey) {
				case "children":
				case "dangerouslySetInnerHTML": throw Error("link is a self-closing tag and must neither have `children` nor use `dangerouslySetInnerHTML`.");
				default: pushAttribute(target, propKey, propValue);
			}
		}
		target.push(endOfStartTagSelfClosing);
		return null;
	}
	var styleRegex = /(<\/|<)(s)(tyle)/gi;
	function styleReplacer(match, prefix, s, suffix) {
		return "" + prefix + ("s" === s ? "\\73 " : "\\53 ") + suffix;
	}
	function pushSelfClosing(target, props, tag) {
		target.push(startChunkForTag(tag));
		for (var propKey in props) if (hasOwnProperty.call(props, propKey)) {
			var propValue = props[propKey];
			if (null != propValue) switch (propKey) {
				case "children":
				case "dangerouslySetInnerHTML": throw Error(tag + " is a self-closing tag and must neither have `children` nor use `dangerouslySetInnerHTML`.");
				default: pushAttribute(target, propKey, propValue);
			}
		}
		target.push(endOfStartTagSelfClosing);
		return null;
	}
	function pushTitleImpl(target, props) {
		target.push(startChunkForTag("title"));
		var children = null, innerHTML = null, propKey;
		for (propKey in props) if (hasOwnProperty.call(props, propKey)) {
			var propValue = props[propKey];
			if (null != propValue) switch (propKey) {
				case "children":
					children = propValue;
					break;
				case "dangerouslySetInnerHTML":
					innerHTML = propValue;
					break;
				default: pushAttribute(target, propKey, propValue);
			}
		}
		target.push(endOfStartTag);
		props = Array.isArray(children) ? 2 > children.length ? children[0] : null : children;
		"function" !== typeof props && "symbol" !== typeof props && null !== props && void 0 !== props && target.push(stringToChunk(escapeTextForBrowser("" + props)));
		pushInnerHTML(target, innerHTML, children);
		target.push(endChunkForTag("title"));
		return null;
	}
	var headPreambleContributionChunk = stringToPrecomputedChunk("<!--head-->"), bodyPreambleContributionChunk = stringToPrecomputedChunk("<!--body-->"), htmlPreambleContributionChunk = stringToPrecomputedChunk("<!--html-->");
	function pushScriptImpl(target, props) {
		target.push(startChunkForTag("script"));
		var children = null, innerHTML = null, propKey;
		for (propKey in props) if (hasOwnProperty.call(props, propKey)) {
			var propValue = props[propKey];
			if (null != propValue) switch (propKey) {
				case "children":
					children = propValue;
					break;
				case "dangerouslySetInnerHTML":
					innerHTML = propValue;
					break;
				default: pushAttribute(target, propKey, propValue);
			}
		}
		target.push(endOfStartTag);
		pushInnerHTML(target, innerHTML, children);
		"string" === typeof children && target.push(stringToChunk(("" + children).replace(scriptRegex, scriptReplacer)));
		target.push(endChunkForTag("script"));
		return null;
	}
	function pushStartSingletonElement(target, props, tag) {
		target.push(startChunkForTag(tag));
		var innerHTML = tag = null, propKey;
		for (propKey in props) if (hasOwnProperty.call(props, propKey)) {
			var propValue = props[propKey];
			if (null != propValue) switch (propKey) {
				case "children":
					tag = propValue;
					break;
				case "dangerouslySetInnerHTML":
					innerHTML = propValue;
					break;
				default: pushAttribute(target, propKey, propValue);
			}
		}
		target.push(endOfStartTag);
		pushInnerHTML(target, innerHTML, tag);
		return tag;
	}
	function pushStartGenericElement(target, props, tag) {
		target.push(startChunkForTag(tag));
		var innerHTML = tag = null, propKey;
		for (propKey in props) if (hasOwnProperty.call(props, propKey)) {
			var propValue = props[propKey];
			if (null != propValue) switch (propKey) {
				case "children":
					tag = propValue;
					break;
				case "dangerouslySetInnerHTML":
					innerHTML = propValue;
					break;
				default: pushAttribute(target, propKey, propValue);
			}
		}
		target.push(endOfStartTag);
		pushInnerHTML(target, innerHTML, tag);
		return "string" === typeof tag ? (target.push(stringToChunk(escapeTextForBrowser(tag))), null) : tag;
	}
	var leadingNewline = stringToPrecomputedChunk("\n"), VALID_TAG_REGEX = /^[a-zA-Z][a-zA-Z:_\.\-\d]*$/, validatedTagCache = /* @__PURE__ */ new Map();
	function startChunkForTag(tag) {
		var tagStartChunk = validatedTagCache.get(tag);
		if (void 0 === tagStartChunk) {
			if (!VALID_TAG_REGEX.test(tag)) throw Error("Invalid tag: " + tag);
			tagStartChunk = stringToPrecomputedChunk("<" + tag);
			validatedTagCache.set(tag, tagStartChunk);
		}
		return tagStartChunk;
	}
	var doctypeChunk = stringToPrecomputedChunk("<!DOCTYPE html>");
	function pushStartInstance(target$jscomp$0, type, props, resumableState, renderState, preambleState, hoistableState, formatContext, textEmbedded) {
		switch (type) {
			case "div":
			case "span":
			case "svg":
			case "path": break;
			case "a":
				target$jscomp$0.push(startChunkForTag("a"));
				var children = null, innerHTML = null, propKey;
				for (propKey in props) if (hasOwnProperty.call(props, propKey)) {
					var propValue = props[propKey];
					if (null != propValue) switch (propKey) {
						case "children":
							children = propValue;
							break;
						case "dangerouslySetInnerHTML":
							innerHTML = propValue;
							break;
						case "href":
							"" === propValue ? pushStringAttribute(target$jscomp$0, "href", "") : pushAttribute(target$jscomp$0, propKey, propValue);
							break;
						default: pushAttribute(target$jscomp$0, propKey, propValue);
					}
				}
				target$jscomp$0.push(endOfStartTag);
				pushInnerHTML(target$jscomp$0, innerHTML, children);
				if ("string" === typeof children) {
					target$jscomp$0.push(stringToChunk(escapeTextForBrowser(children)));
					var JSCompiler_inline_result = null;
				} else JSCompiler_inline_result = children;
				return JSCompiler_inline_result;
			case "g":
			case "p":
			case "li": break;
			case "select":
				target$jscomp$0.push(startChunkForTag("select"));
				var children$jscomp$0 = null, innerHTML$jscomp$0 = null, propKey$jscomp$0;
				for (propKey$jscomp$0 in props) if (hasOwnProperty.call(props, propKey$jscomp$0)) {
					var propValue$jscomp$0 = props[propKey$jscomp$0];
					if (null != propValue$jscomp$0) switch (propKey$jscomp$0) {
						case "children":
							children$jscomp$0 = propValue$jscomp$0;
							break;
						case "dangerouslySetInnerHTML":
							innerHTML$jscomp$0 = propValue$jscomp$0;
							break;
						case "defaultValue":
						case "value": break;
						default: pushAttribute(target$jscomp$0, propKey$jscomp$0, propValue$jscomp$0);
					}
				}
				target$jscomp$0.push(endOfStartTag);
				pushInnerHTML(target$jscomp$0, innerHTML$jscomp$0, children$jscomp$0);
				return children$jscomp$0;
			case "option":
				var selectedValue = formatContext.selectedValue;
				target$jscomp$0.push(startChunkForTag("option"));
				var children$jscomp$1 = null, value = null, selected = null, innerHTML$jscomp$1 = null, propKey$jscomp$1;
				for (propKey$jscomp$1 in props) if (hasOwnProperty.call(props, propKey$jscomp$1)) {
					var propValue$jscomp$1 = props[propKey$jscomp$1];
					if (null != propValue$jscomp$1) switch (propKey$jscomp$1) {
						case "children":
							children$jscomp$1 = propValue$jscomp$1;
							break;
						case "selected":
							selected = propValue$jscomp$1;
							break;
						case "dangerouslySetInnerHTML":
							innerHTML$jscomp$1 = propValue$jscomp$1;
							break;
						case "value": value = propValue$jscomp$1;
						default: pushAttribute(target$jscomp$0, propKey$jscomp$1, propValue$jscomp$1);
					}
				}
				if (null != selectedValue) {
					var stringValue = null !== value ? "" + value : flattenOptionChildren(children$jscomp$1);
					if (isArrayImpl(selectedValue)) {
						for (var i = 0; i < selectedValue.length; i++) if ("" + selectedValue[i] === stringValue) {
							target$jscomp$0.push(selectedMarkerAttribute);
							break;
						}
					} else "" + selectedValue === stringValue && target$jscomp$0.push(selectedMarkerAttribute);
				} else selected && target$jscomp$0.push(selectedMarkerAttribute);
				target$jscomp$0.push(endOfStartTag);
				pushInnerHTML(target$jscomp$0, innerHTML$jscomp$1, children$jscomp$1);
				return children$jscomp$1;
			case "textarea":
				target$jscomp$0.push(startChunkForTag("textarea"));
				var value$jscomp$0 = null, defaultValue = null, children$jscomp$2 = null, propKey$jscomp$2;
				for (propKey$jscomp$2 in props) if (hasOwnProperty.call(props, propKey$jscomp$2)) {
					var propValue$jscomp$2 = props[propKey$jscomp$2];
					if (null != propValue$jscomp$2) switch (propKey$jscomp$2) {
						case "children":
							children$jscomp$2 = propValue$jscomp$2;
							break;
						case "value":
							value$jscomp$0 = propValue$jscomp$2;
							break;
						case "defaultValue":
							defaultValue = propValue$jscomp$2;
							break;
						case "dangerouslySetInnerHTML": throw Error("`dangerouslySetInnerHTML` does not make sense on <textarea>.");
						default: pushAttribute(target$jscomp$0, propKey$jscomp$2, propValue$jscomp$2);
					}
				}
				null === value$jscomp$0 && null !== defaultValue && (value$jscomp$0 = defaultValue);
				target$jscomp$0.push(endOfStartTag);
				if (null != children$jscomp$2) {
					if (null != value$jscomp$0) throw Error("If you supply `defaultValue` on a <textarea>, do not pass children.");
					if (isArrayImpl(children$jscomp$2)) {
						if (1 < children$jscomp$2.length) throw Error("<textarea> can only have at most one child.");
						value$jscomp$0 = "" + children$jscomp$2[0];
					}
					value$jscomp$0 = "" + children$jscomp$2;
				}
				"string" === typeof value$jscomp$0 && "\n" === value$jscomp$0[0] && target$jscomp$0.push(leadingNewline);
				null !== value$jscomp$0 && target$jscomp$0.push(stringToChunk(escapeTextForBrowser("" + value$jscomp$0)));
				return null;
			case "input":
				target$jscomp$0.push(startChunkForTag("input"));
				var name = null, formAction = null, formEncType = null, formMethod = null, formTarget = null, value$jscomp$1 = null, defaultValue$jscomp$0 = null, checked = null, defaultChecked = null, propKey$jscomp$3;
				for (propKey$jscomp$3 in props) if (hasOwnProperty.call(props, propKey$jscomp$3)) {
					var propValue$jscomp$3 = props[propKey$jscomp$3];
					if (null != propValue$jscomp$3) switch (propKey$jscomp$3) {
						case "children":
						case "dangerouslySetInnerHTML": throw Error("input is a self-closing tag and must neither have `children` nor use `dangerouslySetInnerHTML`.");
						case "name":
							name = propValue$jscomp$3;
							break;
						case "formAction":
							formAction = propValue$jscomp$3;
							break;
						case "formEncType":
							formEncType = propValue$jscomp$3;
							break;
						case "formMethod":
							formMethod = propValue$jscomp$3;
							break;
						case "formTarget":
							formTarget = propValue$jscomp$3;
							break;
						case "defaultChecked":
							defaultChecked = propValue$jscomp$3;
							break;
						case "defaultValue":
							defaultValue$jscomp$0 = propValue$jscomp$3;
							break;
						case "checked":
							checked = propValue$jscomp$3;
							break;
						case "value":
							value$jscomp$1 = propValue$jscomp$3;
							break;
						default: pushAttribute(target$jscomp$0, propKey$jscomp$3, propValue$jscomp$3);
					}
				}
				var formData = pushFormActionAttribute(target$jscomp$0, resumableState, renderState, formAction, formEncType, formMethod, formTarget, name);
				null !== checked ? pushBooleanAttribute(target$jscomp$0, "checked", checked) : null !== defaultChecked && pushBooleanAttribute(target$jscomp$0, "checked", defaultChecked);
				null !== value$jscomp$1 ? pushAttribute(target$jscomp$0, "value", value$jscomp$1) : null !== defaultValue$jscomp$0 && pushAttribute(target$jscomp$0, "value", defaultValue$jscomp$0);
				target$jscomp$0.push(endOfStartTagSelfClosing);
				formData?.forEach(pushAdditionalFormField, target$jscomp$0);
				return null;
			case "button":
				target$jscomp$0.push(startChunkForTag("button"));
				var children$jscomp$3 = null, innerHTML$jscomp$2 = null, name$jscomp$0 = null, formAction$jscomp$0 = null, formEncType$jscomp$0 = null, formMethod$jscomp$0 = null, formTarget$jscomp$0 = null, propKey$jscomp$4;
				for (propKey$jscomp$4 in props) if (hasOwnProperty.call(props, propKey$jscomp$4)) {
					var propValue$jscomp$4 = props[propKey$jscomp$4];
					if (null != propValue$jscomp$4) switch (propKey$jscomp$4) {
						case "children":
							children$jscomp$3 = propValue$jscomp$4;
							break;
						case "dangerouslySetInnerHTML":
							innerHTML$jscomp$2 = propValue$jscomp$4;
							break;
						case "name":
							name$jscomp$0 = propValue$jscomp$4;
							break;
						case "formAction":
							formAction$jscomp$0 = propValue$jscomp$4;
							break;
						case "formEncType":
							formEncType$jscomp$0 = propValue$jscomp$4;
							break;
						case "formMethod":
							formMethod$jscomp$0 = propValue$jscomp$4;
							break;
						case "formTarget":
							formTarget$jscomp$0 = propValue$jscomp$4;
							break;
						default: pushAttribute(target$jscomp$0, propKey$jscomp$4, propValue$jscomp$4);
					}
				}
				var formData$jscomp$0 = pushFormActionAttribute(target$jscomp$0, resumableState, renderState, formAction$jscomp$0, formEncType$jscomp$0, formMethod$jscomp$0, formTarget$jscomp$0, name$jscomp$0);
				target$jscomp$0.push(endOfStartTag);
				formData$jscomp$0?.forEach(pushAdditionalFormField, target$jscomp$0);
				pushInnerHTML(target$jscomp$0, innerHTML$jscomp$2, children$jscomp$3);
				if ("string" === typeof children$jscomp$3) {
					target$jscomp$0.push(stringToChunk(escapeTextForBrowser(children$jscomp$3)));
					var JSCompiler_inline_result$jscomp$0 = null;
				} else JSCompiler_inline_result$jscomp$0 = children$jscomp$3;
				return JSCompiler_inline_result$jscomp$0;
			case "form":
				target$jscomp$0.push(startChunkForTag("form"));
				var children$jscomp$4 = null, innerHTML$jscomp$3 = null, formAction$jscomp$1 = null, formEncType$jscomp$1 = null, formMethod$jscomp$1 = null, formTarget$jscomp$1 = null, propKey$jscomp$5;
				for (propKey$jscomp$5 in props) if (hasOwnProperty.call(props, propKey$jscomp$5)) {
					var propValue$jscomp$5 = props[propKey$jscomp$5];
					if (null != propValue$jscomp$5) switch (propKey$jscomp$5) {
						case "children":
							children$jscomp$4 = propValue$jscomp$5;
							break;
						case "dangerouslySetInnerHTML":
							innerHTML$jscomp$3 = propValue$jscomp$5;
							break;
						case "action":
							formAction$jscomp$1 = propValue$jscomp$5;
							break;
						case "encType":
							formEncType$jscomp$1 = propValue$jscomp$5;
							break;
						case "method":
							formMethod$jscomp$1 = propValue$jscomp$5;
							break;
						case "target":
							formTarget$jscomp$1 = propValue$jscomp$5;
							break;
						default: pushAttribute(target$jscomp$0, propKey$jscomp$5, propValue$jscomp$5);
					}
				}
				var formData$jscomp$1 = null, formActionName = null;
				if ("function" === typeof formAction$jscomp$1) {
					var customFields = getCustomFormFields(resumableState, formAction$jscomp$1);
					null !== customFields ? (formAction$jscomp$1 = customFields.action || "", formEncType$jscomp$1 = customFields.encType, formMethod$jscomp$1 = customFields.method, formTarget$jscomp$1 = customFields.target, formData$jscomp$1 = customFields.data, formActionName = customFields.name) : (target$jscomp$0.push(attributeSeparator, stringToChunk("action"), attributeAssign, actionJavaScriptURL, attributeEnd), formTarget$jscomp$1 = formMethod$jscomp$1 = formEncType$jscomp$1 = formAction$jscomp$1 = null, injectFormReplayingRuntime(resumableState, renderState));
				}
				null != formAction$jscomp$1 && pushAttribute(target$jscomp$0, "action", formAction$jscomp$1);
				null != formEncType$jscomp$1 && pushAttribute(target$jscomp$0, "encType", formEncType$jscomp$1);
				null != formMethod$jscomp$1 && pushAttribute(target$jscomp$0, "method", formMethod$jscomp$1);
				null != formTarget$jscomp$1 && pushAttribute(target$jscomp$0, "target", formTarget$jscomp$1);
				target$jscomp$0.push(endOfStartTag);
				null !== formActionName && (target$jscomp$0.push(startHiddenInputChunk), pushStringAttribute(target$jscomp$0, "name", formActionName), target$jscomp$0.push(endOfStartTagSelfClosing), formData$jscomp$1?.forEach(pushAdditionalFormField, target$jscomp$0));
				pushInnerHTML(target$jscomp$0, innerHTML$jscomp$3, children$jscomp$4);
				if ("string" === typeof children$jscomp$4) {
					target$jscomp$0.push(stringToChunk(escapeTextForBrowser(children$jscomp$4)));
					var JSCompiler_inline_result$jscomp$1 = null;
				} else JSCompiler_inline_result$jscomp$1 = children$jscomp$4;
				return JSCompiler_inline_result$jscomp$1;
			case "menuitem":
				target$jscomp$0.push(startChunkForTag("menuitem"));
				for (var propKey$jscomp$6 in props) if (hasOwnProperty.call(props, propKey$jscomp$6)) {
					var propValue$jscomp$6 = props[propKey$jscomp$6];
					if (null != propValue$jscomp$6) switch (propKey$jscomp$6) {
						case "children":
						case "dangerouslySetInnerHTML": throw Error("menuitems cannot have `children` nor `dangerouslySetInnerHTML`.");
						default: pushAttribute(target$jscomp$0, propKey$jscomp$6, propValue$jscomp$6);
					}
				}
				target$jscomp$0.push(endOfStartTag);
				return null;
			case "object":
				target$jscomp$0.push(startChunkForTag("object"));
				var children$jscomp$5 = null, innerHTML$jscomp$4 = null, propKey$jscomp$7;
				for (propKey$jscomp$7 in props) if (hasOwnProperty.call(props, propKey$jscomp$7)) {
					var propValue$jscomp$7 = props[propKey$jscomp$7];
					if (null != propValue$jscomp$7) switch (propKey$jscomp$7) {
						case "children":
							children$jscomp$5 = propValue$jscomp$7;
							break;
						case "dangerouslySetInnerHTML":
							innerHTML$jscomp$4 = propValue$jscomp$7;
							break;
						case "data":
							var sanitizedValue = sanitizeURL("" + propValue$jscomp$7);
							if ("" === sanitizedValue) break;
							target$jscomp$0.push(attributeSeparator, stringToChunk("data"), attributeAssign, stringToChunk(escapeTextForBrowser(sanitizedValue)), attributeEnd);
							break;
						default: pushAttribute(target$jscomp$0, propKey$jscomp$7, propValue$jscomp$7);
					}
				}
				target$jscomp$0.push(endOfStartTag);
				pushInnerHTML(target$jscomp$0, innerHTML$jscomp$4, children$jscomp$5);
				if ("string" === typeof children$jscomp$5) {
					target$jscomp$0.push(stringToChunk(escapeTextForBrowser(children$jscomp$5)));
					var JSCompiler_inline_result$jscomp$2 = null;
				} else JSCompiler_inline_result$jscomp$2 = children$jscomp$5;
				return JSCompiler_inline_result$jscomp$2;
			case "title":
				var noscriptTagInScope = formatContext.tagScope & 1, isFallback = formatContext.tagScope & 4;
				if (4 === formatContext.insertionMode || noscriptTagInScope || null != props.itemProp) var JSCompiler_inline_result$jscomp$3 = pushTitleImpl(target$jscomp$0, props);
				else isFallback ? JSCompiler_inline_result$jscomp$3 = null : (pushTitleImpl(renderState.hoistableChunks, props), JSCompiler_inline_result$jscomp$3 = void 0);
				return JSCompiler_inline_result$jscomp$3;
			case "link":
				var noscriptTagInScope$jscomp$0 = formatContext.tagScope & 1, isFallback$jscomp$0 = formatContext.tagScope & 4, rel = props.rel, href = props.href, precedence = props.precedence;
				if (4 === formatContext.insertionMode || noscriptTagInScope$jscomp$0 || null != props.itemProp || "string" !== typeof rel || "string" !== typeof href || "" === href) {
					pushLinkImpl(target$jscomp$0, props);
					var JSCompiler_inline_result$jscomp$4 = null;
				} else if ("stylesheet" === props.rel) if ("string" !== typeof precedence || null != props.disabled || props.onLoad || props.onError) JSCompiler_inline_result$jscomp$4 = pushLinkImpl(target$jscomp$0, props);
				else {
					var styleQueue = renderState.styles.get(precedence), resourceState = resumableState.styleResources.hasOwnProperty(href) ? resumableState.styleResources[href] : void 0;
					if (null !== resourceState) {
						resumableState.styleResources[href] = null;
						styleQueue || (styleQueue = {
							precedence: stringToChunk(escapeTextForBrowser(precedence)),
							rules: [],
							hrefs: [],
							sheets: /* @__PURE__ */ new Map()
						}, renderState.styles.set(precedence, styleQueue));
						var resource = {
							state: 0,
							props: assign({}, props, {
								"data-precedence": props.precedence,
								precedence: null
							})
						};
						if (resourceState) {
							2 === resourceState.length && adoptPreloadCredentials(resource.props, resourceState);
							var preloadResource = renderState.preloads.stylesheets.get(href);
							preloadResource && 0 < preloadResource.length ? preloadResource.length = 0 : resource.state = 1;
						}
						styleQueue.sheets.set(href, resource);
						hoistableState && hoistableState.stylesheets.add(resource);
					} else if (styleQueue) {
						var resource$9 = styleQueue.sheets.get(href);
						resource$9 && hoistableState && hoistableState.stylesheets.add(resource$9);
					}
					textEmbedded && target$jscomp$0.push(textSeparator);
					JSCompiler_inline_result$jscomp$4 = null;
				}
				else props.onLoad || props.onError ? JSCompiler_inline_result$jscomp$4 = pushLinkImpl(target$jscomp$0, props) : (textEmbedded && target$jscomp$0.push(textSeparator), JSCompiler_inline_result$jscomp$4 = isFallback$jscomp$0 ? null : pushLinkImpl(renderState.hoistableChunks, props));
				return JSCompiler_inline_result$jscomp$4;
			case "script":
				var noscriptTagInScope$jscomp$1 = formatContext.tagScope & 1, asyncProp = props.async;
				if ("string" !== typeof props.src || !props.src || !asyncProp || "function" === typeof asyncProp || "symbol" === typeof asyncProp || props.onLoad || props.onError || 4 === formatContext.insertionMode || noscriptTagInScope$jscomp$1 || null != props.itemProp) var JSCompiler_inline_result$jscomp$5 = pushScriptImpl(target$jscomp$0, props);
				else {
					var key = props.src;
					if ("module" === props.type) {
						var resources = resumableState.moduleScriptResources;
						var preloads = renderState.preloads.moduleScripts;
					} else resources = resumableState.scriptResources, preloads = renderState.preloads.scripts;
					var resourceState$jscomp$0 = resources.hasOwnProperty(key) ? resources[key] : void 0;
					if (null !== resourceState$jscomp$0) {
						resources[key] = null;
						var scriptProps = props;
						if (resourceState$jscomp$0) {
							2 === resourceState$jscomp$0.length && (scriptProps = assign({}, props), adoptPreloadCredentials(scriptProps, resourceState$jscomp$0));
							var preloadResource$jscomp$0 = preloads.get(key);
							preloadResource$jscomp$0 && (preloadResource$jscomp$0.length = 0);
						}
						var resource$jscomp$0 = [];
						renderState.scripts.add(resource$jscomp$0);
						pushScriptImpl(resource$jscomp$0, scriptProps);
					}
					textEmbedded && target$jscomp$0.push(textSeparator);
					JSCompiler_inline_result$jscomp$5 = null;
				}
				return JSCompiler_inline_result$jscomp$5;
			case "style":
				var noscriptTagInScope$jscomp$2 = formatContext.tagScope & 1, precedence$jscomp$0 = props.precedence, href$jscomp$0 = props.href, nonce = props.nonce;
				if (4 === formatContext.insertionMode || noscriptTagInScope$jscomp$2 || null != props.itemProp || "string" !== typeof precedence$jscomp$0 || "string" !== typeof href$jscomp$0 || "" === href$jscomp$0) {
					target$jscomp$0.push(startChunkForTag("style"));
					var children$jscomp$6 = null, innerHTML$jscomp$5 = null, propKey$jscomp$8;
					for (propKey$jscomp$8 in props) if (hasOwnProperty.call(props, propKey$jscomp$8)) {
						var propValue$jscomp$8 = props[propKey$jscomp$8];
						if (null != propValue$jscomp$8) switch (propKey$jscomp$8) {
							case "children":
								children$jscomp$6 = propValue$jscomp$8;
								break;
							case "dangerouslySetInnerHTML":
								innerHTML$jscomp$5 = propValue$jscomp$8;
								break;
							default: pushAttribute(target$jscomp$0, propKey$jscomp$8, propValue$jscomp$8);
						}
					}
					target$jscomp$0.push(endOfStartTag);
					var child = Array.isArray(children$jscomp$6) ? 2 > children$jscomp$6.length ? children$jscomp$6[0] : null : children$jscomp$6;
					"function" !== typeof child && "symbol" !== typeof child && null !== child && void 0 !== child && target$jscomp$0.push(stringToChunk(("" + child).replace(styleRegex, styleReplacer)));
					pushInnerHTML(target$jscomp$0, innerHTML$jscomp$5, children$jscomp$6);
					target$jscomp$0.push(endChunkForTag("style"));
					var JSCompiler_inline_result$jscomp$6 = null;
				} else {
					var styleQueue$jscomp$0 = renderState.styles.get(precedence$jscomp$0);
					if (null !== (resumableState.styleResources.hasOwnProperty(href$jscomp$0) ? resumableState.styleResources[href$jscomp$0] : void 0)) {
						resumableState.styleResources[href$jscomp$0] = null;
						styleQueue$jscomp$0 || (styleQueue$jscomp$0 = {
							precedence: stringToChunk(escapeTextForBrowser(precedence$jscomp$0)),
							rules: [],
							hrefs: [],
							sheets: /* @__PURE__ */ new Map()
						}, renderState.styles.set(precedence$jscomp$0, styleQueue$jscomp$0));
						var nonceStyle = renderState.nonce.style;
						if (!nonceStyle || nonceStyle === nonce) {
							styleQueue$jscomp$0.hrefs.push(stringToChunk(escapeTextForBrowser(href$jscomp$0)));
							var target = styleQueue$jscomp$0.rules, children$jscomp$7 = null, innerHTML$jscomp$6 = null, propKey$jscomp$9;
							for (propKey$jscomp$9 in props) if (hasOwnProperty.call(props, propKey$jscomp$9)) {
								var propValue$jscomp$9 = props[propKey$jscomp$9];
								if (null != propValue$jscomp$9) switch (propKey$jscomp$9) {
									case "children":
										children$jscomp$7 = propValue$jscomp$9;
										break;
									case "dangerouslySetInnerHTML": innerHTML$jscomp$6 = propValue$jscomp$9;
								}
							}
							var child$jscomp$0 = Array.isArray(children$jscomp$7) ? 2 > children$jscomp$7.length ? children$jscomp$7[0] : null : children$jscomp$7;
							"function" !== typeof child$jscomp$0 && "symbol" !== typeof child$jscomp$0 && null !== child$jscomp$0 && void 0 !== child$jscomp$0 && target.push(stringToChunk(("" + child$jscomp$0).replace(styleRegex, styleReplacer)));
							pushInnerHTML(target, innerHTML$jscomp$6, children$jscomp$7);
						}
					}
					styleQueue$jscomp$0 && hoistableState && hoistableState.styles.add(styleQueue$jscomp$0);
					textEmbedded && target$jscomp$0.push(textSeparator);
					JSCompiler_inline_result$jscomp$6 = void 0;
				}
				return JSCompiler_inline_result$jscomp$6;
			case "meta":
				var noscriptTagInScope$jscomp$3 = formatContext.tagScope & 1, isFallback$jscomp$1 = formatContext.tagScope & 4;
				if (4 === formatContext.insertionMode || noscriptTagInScope$jscomp$3 || null != props.itemProp) var JSCompiler_inline_result$jscomp$7 = pushSelfClosing(target$jscomp$0, props, "meta");
				else textEmbedded && target$jscomp$0.push(textSeparator), JSCompiler_inline_result$jscomp$7 = isFallback$jscomp$1 ? null : "string" === typeof props.charSet ? pushSelfClosing(renderState.charsetChunks, props, "meta") : "viewport" === props.name ? pushSelfClosing(renderState.viewportChunks, props, "meta") : pushSelfClosing(renderState.hoistableChunks, props, "meta");
				return JSCompiler_inline_result$jscomp$7;
			case "listing":
			case "pre":
				target$jscomp$0.push(startChunkForTag(type));
				var children$jscomp$8 = null, innerHTML$jscomp$7 = null, propKey$jscomp$10;
				for (propKey$jscomp$10 in props) if (hasOwnProperty.call(props, propKey$jscomp$10)) {
					var propValue$jscomp$10 = props[propKey$jscomp$10];
					if (null != propValue$jscomp$10) switch (propKey$jscomp$10) {
						case "children":
							children$jscomp$8 = propValue$jscomp$10;
							break;
						case "dangerouslySetInnerHTML":
							innerHTML$jscomp$7 = propValue$jscomp$10;
							break;
						default: pushAttribute(target$jscomp$0, propKey$jscomp$10, propValue$jscomp$10);
					}
				}
				target$jscomp$0.push(endOfStartTag);
				if (null != innerHTML$jscomp$7) {
					if (null != children$jscomp$8) throw Error("Can only set one of `children` or `props.dangerouslySetInnerHTML`.");
					if ("object" !== typeof innerHTML$jscomp$7 || !("__html" in innerHTML$jscomp$7)) throw Error("`props.dangerouslySetInnerHTML` must be in the form `{__html: ...}`. Please visit https://react.dev/link/dangerously-set-inner-html for more information.");
					var html = innerHTML$jscomp$7.__html;
					null !== html && void 0 !== html && ("string" === typeof html && 0 < html.length && "\n" === html[0] ? target$jscomp$0.push(leadingNewline, stringToChunk(html)) : target$jscomp$0.push(stringToChunk("" + html)));
				}
				"string" === typeof children$jscomp$8 && "\n" === children$jscomp$8[0] && target$jscomp$0.push(leadingNewline);
				return children$jscomp$8;
			case "img":
				var pictureOrNoScriptTagInScope = formatContext.tagScope & 3, src = props.src, srcSet = props.srcSet;
				if (!("lazy" === props.loading || !src && !srcSet || "string" !== typeof src && null != src || "string" !== typeof srcSet && null != srcSet || "low" === props.fetchPriority || pictureOrNoScriptTagInScope) && ("string" !== typeof src || ":" !== src[4] || "d" !== src[0] && "D" !== src[0] || "a" !== src[1] && "A" !== src[1] || "t" !== src[2] && "T" !== src[2] || "a" !== src[3] && "A" !== src[3]) && ("string" !== typeof srcSet || ":" !== srcSet[4] || "d" !== srcSet[0] && "D" !== srcSet[0] || "a" !== srcSet[1] && "A" !== srcSet[1] || "t" !== srcSet[2] && "T" !== srcSet[2] || "a" !== srcSet[3] && "A" !== srcSet[3])) {
					null !== hoistableState && formatContext.tagScope & 64 && (hoistableState.suspenseyImages = !0);
					var sizes = "string" === typeof props.sizes ? props.sizes : void 0, key$jscomp$0 = srcSet ? srcSet + "\n" + (sizes || "") : src, promotablePreloads = renderState.preloads.images, resource$jscomp$1 = promotablePreloads.get(key$jscomp$0);
					if (resource$jscomp$1) {
						if ("high" === props.fetchPriority || 10 > renderState.highImagePreloads.size) promotablePreloads.delete(key$jscomp$0), renderState.highImagePreloads.add(resource$jscomp$1);
					} else if (!resumableState.imageResources.hasOwnProperty(key$jscomp$0)) {
						resumableState.imageResources[key$jscomp$0] = PRELOAD_NO_CREDS;
						var input = props.crossOrigin;
						var JSCompiler_inline_result$jscomp$8 = "string" === typeof input ? "use-credentials" === input ? input : "" : void 0;
						var headers = renderState.headers, header;
						headers && 0 < headers.remainingCapacity && "string" !== typeof props.srcSet && ("high" === props.fetchPriority || 500 > headers.highImagePreloads.length) && (header = getPreloadAsHeader(src, "image", {
							imageSrcSet: props.srcSet,
							imageSizes: props.sizes,
							crossOrigin: JSCompiler_inline_result$jscomp$8,
							integrity: props.integrity,
							nonce: props.nonce,
							type: props.type,
							fetchPriority: props.fetchPriority,
							referrerPolicy: props.refererPolicy
						}), 0 <= (headers.remainingCapacity -= header.length + 2)) ? (renderState.resets.image[key$jscomp$0] = PRELOAD_NO_CREDS, headers.highImagePreloads && (headers.highImagePreloads += ", "), headers.highImagePreloads += header) : (resource$jscomp$1 = [], pushLinkImpl(resource$jscomp$1, {
							rel: "preload",
							as: "image",
							href: srcSet ? void 0 : src,
							imageSrcSet: srcSet,
							imageSizes: sizes,
							crossOrigin: JSCompiler_inline_result$jscomp$8,
							integrity: props.integrity,
							type: props.type,
							fetchPriority: props.fetchPriority,
							referrerPolicy: props.referrerPolicy
						}), "high" === props.fetchPriority || 10 > renderState.highImagePreloads.size ? renderState.highImagePreloads.add(resource$jscomp$1) : (renderState.bulkPreloads.add(resource$jscomp$1), promotablePreloads.set(key$jscomp$0, resource$jscomp$1)));
					}
				}
				return pushSelfClosing(target$jscomp$0, props, "img");
			case "base":
			case "area":
			case "br":
			case "col":
			case "embed":
			case "hr":
			case "keygen":
			case "param":
			case "source":
			case "track":
			case "wbr": return pushSelfClosing(target$jscomp$0, props, type);
			case "annotation-xml":
			case "color-profile":
			case "font-face":
			case "font-face-src":
			case "font-face-uri":
			case "font-face-format":
			case "font-face-name":
			case "missing-glyph": break;
			case "head":
				if (2 > formatContext.insertionMode) {
					var preamble = preambleState || renderState.preamble;
					if (preamble.headChunks) throw Error("The `<head>` tag may only be rendered once.");
					null !== preambleState && target$jscomp$0.push(headPreambleContributionChunk);
					preamble.headChunks = [];
					var JSCompiler_inline_result$jscomp$9 = pushStartSingletonElement(preamble.headChunks, props, "head");
				} else JSCompiler_inline_result$jscomp$9 = pushStartGenericElement(target$jscomp$0, props, "head");
				return JSCompiler_inline_result$jscomp$9;
			case "body":
				if (2 > formatContext.insertionMode) {
					var preamble$jscomp$0 = preambleState || renderState.preamble;
					if (preamble$jscomp$0.bodyChunks) throw Error("The `<body>` tag may only be rendered once.");
					null !== preambleState && target$jscomp$0.push(bodyPreambleContributionChunk);
					preamble$jscomp$0.bodyChunks = [];
					var JSCompiler_inline_result$jscomp$10 = pushStartSingletonElement(preamble$jscomp$0.bodyChunks, props, "body");
				} else JSCompiler_inline_result$jscomp$10 = pushStartGenericElement(target$jscomp$0, props, "body");
				return JSCompiler_inline_result$jscomp$10;
			case "html":
				if (0 === formatContext.insertionMode) {
					var preamble$jscomp$1 = preambleState || renderState.preamble;
					if (preamble$jscomp$1.htmlChunks) throw Error("The `<html>` tag may only be rendered once.");
					null !== preambleState && target$jscomp$0.push(htmlPreambleContributionChunk);
					preamble$jscomp$1.htmlChunks = [doctypeChunk];
					var JSCompiler_inline_result$jscomp$11 = pushStartSingletonElement(preamble$jscomp$1.htmlChunks, props, "html");
				} else JSCompiler_inline_result$jscomp$11 = pushStartGenericElement(target$jscomp$0, props, "html");
				return JSCompiler_inline_result$jscomp$11;
			default: if (-1 !== type.indexOf("-")) {
				target$jscomp$0.push(startChunkForTag(type));
				var children$jscomp$9 = null, innerHTML$jscomp$8 = null, propKey$jscomp$11;
				for (propKey$jscomp$11 in props) if (hasOwnProperty.call(props, propKey$jscomp$11)) {
					var propValue$jscomp$11 = props[propKey$jscomp$11];
					if (null != propValue$jscomp$11) {
						var attributeName = propKey$jscomp$11;
						switch (propKey$jscomp$11) {
							case "children":
								children$jscomp$9 = propValue$jscomp$11;
								break;
							case "dangerouslySetInnerHTML":
								innerHTML$jscomp$8 = propValue$jscomp$11;
								break;
							case "style":
								pushStyleAttribute(target$jscomp$0, propValue$jscomp$11);
								break;
							case "suppressContentEditableWarning":
							case "suppressHydrationWarning":
							case "ref": break;
							case "className": attributeName = "class";
							default: if (isAttributeNameSafe(propKey$jscomp$11) && "function" !== typeof propValue$jscomp$11 && "symbol" !== typeof propValue$jscomp$11 && !1 !== propValue$jscomp$11) {
								if (!0 === propValue$jscomp$11) propValue$jscomp$11 = "";
								else if ("object" === typeof propValue$jscomp$11) continue;
								target$jscomp$0.push(attributeSeparator, stringToChunk(attributeName), attributeAssign, stringToChunk(escapeTextForBrowser(propValue$jscomp$11)), attributeEnd);
							}
						}
					}
				}
				target$jscomp$0.push(endOfStartTag);
				pushInnerHTML(target$jscomp$0, innerHTML$jscomp$8, children$jscomp$9);
				return children$jscomp$9;
			}
		}
		return pushStartGenericElement(target$jscomp$0, props, type);
	}
	var endTagCache = /* @__PURE__ */ new Map();
	function endChunkForTag(tag) {
		var chunk = endTagCache.get(tag);
		void 0 === chunk && (chunk = stringToPrecomputedChunk("</" + tag + ">"), endTagCache.set(tag, chunk));
		return chunk;
	}
	function hoistPreambleState(renderState, preambleState) {
		renderState = renderState.preamble;
		null === renderState.htmlChunks && preambleState.htmlChunks && (renderState.htmlChunks = preambleState.htmlChunks);
		null === renderState.headChunks && preambleState.headChunks && (renderState.headChunks = preambleState.headChunks);
		null === renderState.bodyChunks && preambleState.bodyChunks && (renderState.bodyChunks = preambleState.bodyChunks);
	}
	function writeBootstrap(destination, renderState) {
		renderState = renderState.bootstrapChunks;
		for (var i = 0; i < renderState.length - 1; i++) writeChunk(destination, renderState[i]);
		return i < renderState.length ? (i = renderState[i], renderState.length = 0, writeChunkAndReturn(destination, i)) : !0;
	}
	var shellTimeRuntimeScript = stringToPrecomputedChunk("requestAnimationFrame(function(){$RT=performance.now()});"), placeholder1 = stringToPrecomputedChunk("<template id=\""), placeholder2 = stringToPrecomputedChunk("\"></template>"), startActivityBoundary = stringToPrecomputedChunk("<!--&-->"), endActivityBoundary = stringToPrecomputedChunk("<!--/&-->"), startCompletedSuspenseBoundary = stringToPrecomputedChunk("<!--$-->"), startPendingSuspenseBoundary1 = stringToPrecomputedChunk("<!--$?--><template id=\""), startPendingSuspenseBoundary2 = stringToPrecomputedChunk("\"></template>"), startClientRenderedSuspenseBoundary = stringToPrecomputedChunk("<!--$!-->"), endSuspenseBoundary = stringToPrecomputedChunk("<!--/$-->"), clientRenderedSuspenseBoundaryError1 = stringToPrecomputedChunk("<template"), clientRenderedSuspenseBoundaryErrorAttrInterstitial = stringToPrecomputedChunk("\""), clientRenderedSuspenseBoundaryError1A = stringToPrecomputedChunk(" data-dgst=\"");
	stringToPrecomputedChunk(" data-msg=\"");
	stringToPrecomputedChunk(" data-stck=\"");
	stringToPrecomputedChunk(" data-cstck=\"");
	var clientRenderedSuspenseBoundaryError2 = stringToPrecomputedChunk("></template>");
	function writeStartPendingSuspenseBoundary(destination, renderState, id) {
		writeChunk(destination, startPendingSuspenseBoundary1);
		if (null === id) throw Error("An ID must have been assigned before we can complete the boundary.");
		writeChunk(destination, renderState.boundaryPrefix);
		writeChunk(destination, stringToChunk(id.toString(16)));
		return writeChunkAndReturn(destination, startPendingSuspenseBoundary2);
	}
	var startSegmentHTML = stringToPrecomputedChunk("<div hidden id=\""), startSegmentHTML2 = stringToPrecomputedChunk("\">"), endSegmentHTML = stringToPrecomputedChunk("</div>"), startSegmentSVG = stringToPrecomputedChunk("<svg aria-hidden=\"true\" style=\"display:none\" id=\""), startSegmentSVG2 = stringToPrecomputedChunk("\">"), endSegmentSVG = stringToPrecomputedChunk("</svg>"), startSegmentMathML = stringToPrecomputedChunk("<math aria-hidden=\"true\" style=\"display:none\" id=\""), startSegmentMathML2 = stringToPrecomputedChunk("\">"), endSegmentMathML = stringToPrecomputedChunk("</math>"), startSegmentTable = stringToPrecomputedChunk("<table hidden id=\""), startSegmentTable2 = stringToPrecomputedChunk("\">"), endSegmentTable = stringToPrecomputedChunk("</table>"), startSegmentTableBody = stringToPrecomputedChunk("<table hidden><tbody id=\""), startSegmentTableBody2 = stringToPrecomputedChunk("\">"), endSegmentTableBody = stringToPrecomputedChunk("</tbody></table>"), startSegmentTableRow = stringToPrecomputedChunk("<table hidden><tr id=\""), startSegmentTableRow2 = stringToPrecomputedChunk("\">"), endSegmentTableRow = stringToPrecomputedChunk("</tr></table>"), startSegmentColGroup = stringToPrecomputedChunk("<table hidden><colgroup id=\""), startSegmentColGroup2 = stringToPrecomputedChunk("\">"), endSegmentColGroup = stringToPrecomputedChunk("</colgroup></table>");
	function writeStartSegment(destination, renderState, formatContext, id) {
		switch (formatContext.insertionMode) {
			case 0:
			case 1:
			case 3:
			case 2: return writeChunk(destination, startSegmentHTML), writeChunk(destination, renderState.segmentPrefix), writeChunk(destination, stringToChunk(id.toString(16))), writeChunkAndReturn(destination, startSegmentHTML2);
			case 4: return writeChunk(destination, startSegmentSVG), writeChunk(destination, renderState.segmentPrefix), writeChunk(destination, stringToChunk(id.toString(16))), writeChunkAndReturn(destination, startSegmentSVG2);
			case 5: return writeChunk(destination, startSegmentMathML), writeChunk(destination, renderState.segmentPrefix), writeChunk(destination, stringToChunk(id.toString(16))), writeChunkAndReturn(destination, startSegmentMathML2);
			case 6: return writeChunk(destination, startSegmentTable), writeChunk(destination, renderState.segmentPrefix), writeChunk(destination, stringToChunk(id.toString(16))), writeChunkAndReturn(destination, startSegmentTable2);
			case 7: return writeChunk(destination, startSegmentTableBody), writeChunk(destination, renderState.segmentPrefix), writeChunk(destination, stringToChunk(id.toString(16))), writeChunkAndReturn(destination, startSegmentTableBody2);
			case 8: return writeChunk(destination, startSegmentTableRow), writeChunk(destination, renderState.segmentPrefix), writeChunk(destination, stringToChunk(id.toString(16))), writeChunkAndReturn(destination, startSegmentTableRow2);
			case 9: return writeChunk(destination, startSegmentColGroup), writeChunk(destination, renderState.segmentPrefix), writeChunk(destination, stringToChunk(id.toString(16))), writeChunkAndReturn(destination, startSegmentColGroup2);
			default: throw Error("Unknown insertion mode. This is a bug in React.");
		}
	}
	function writeEndSegment(destination, formatContext) {
		switch (formatContext.insertionMode) {
			case 0:
			case 1:
			case 3:
			case 2: return writeChunkAndReturn(destination, endSegmentHTML);
			case 4: return writeChunkAndReturn(destination, endSegmentSVG);
			case 5: return writeChunkAndReturn(destination, endSegmentMathML);
			case 6: return writeChunkAndReturn(destination, endSegmentTable);
			case 7: return writeChunkAndReturn(destination, endSegmentTableBody);
			case 8: return writeChunkAndReturn(destination, endSegmentTableRow);
			case 9: return writeChunkAndReturn(destination, endSegmentColGroup);
			default: throw Error("Unknown insertion mode. This is a bug in React.");
		}
	}
	var completeSegmentScript1Full = stringToPrecomputedChunk("$RS=function(a,b){a=document.getElementById(a);b=document.getElementById(b);for(a.parentNode.removeChild(a);a.firstChild;)b.parentNode.insertBefore(a.firstChild,b);b.parentNode.removeChild(b)};$RS(\""), completeSegmentScript1Partial = stringToPrecomputedChunk("$RS(\""), completeSegmentScript2 = stringToPrecomputedChunk("\",\""), completeSegmentScriptEnd = stringToPrecomputedChunk("\")<\/script>");
	stringToPrecomputedChunk("<template data-rsi=\"\" data-sid=\"");
	stringToPrecomputedChunk("\" data-pid=\"");
	var completeBoundaryScriptFunctionOnly = stringToPrecomputedChunk("$RB=[];$RV=function(a){$RT=performance.now();for(var b=0;b<a.length;b+=2){var c=a[b],e=a[b+1];null!==e.parentNode&&e.parentNode.removeChild(e);var f=c.parentNode;if(f){var g=c.previousSibling,h=0;do{if(c&&8===c.nodeType){var d=c.data;if(\"/$\"===d||\"/&\"===d)if(0===h)break;else h--;else\"$\"!==d&&\"$?\"!==d&&\"$~\"!==d&&\"$!\"!==d&&\"&\"!==d||h++}d=c.nextSibling;f.removeChild(c);c=d}while(c);for(;e.firstChild;)f.insertBefore(e.firstChild,c);g.data=\"$\";g._reactRetry&&requestAnimationFrame(g._reactRetry)}}a.length=0};\n$RC=function(a,b){if(b=document.getElementById(b))(a=document.getElementById(a))?(a.previousSibling.data=\"$~\",$RB.push(a,b),2===$RB.length&&(\"number\"!==typeof $RT?requestAnimationFrame($RV.bind(null,$RB)):(a=performance.now(),setTimeout($RV.bind(null,$RB),2300>a&&2E3<a?2300-a:$RT+300-a)))):b.parentNode.removeChild(b)};");
	stringToChunk("$RV=function(A,g){function k(a,b){var e=a.getAttribute(b);e&&(b=a.style,l.push(a,b.viewTransitionName,b.viewTransitionClass),\"auto\"!==e&&(b.viewTransitionClass=e),(a=a.getAttribute(\"vt-name\"))||(a=\"_T_\"+K++ +\"_\"),b.viewTransitionName=a,B=!0)}var B=!1,K=0,l=[];try{var f=document.__reactViewTransition;if(f){f.finished.finally($RV.bind(null,g));return}var m=new Map;for(f=1;f<g.length;f+=2)for(var h=g[f].querySelectorAll(\"[vt-share]\"),d=0;d<h.length;d++){var c=h[d];m.set(c.getAttribute(\"vt-name\"),c)}var u=[];for(h=0;h<g.length;h+=2){var C=g[h],x=C.parentNode;if(x){var v=x.getBoundingClientRect();if(v.left||v.top||v.width||v.height){c=C;for(f=0;c;){if(8===c.nodeType){var r=c.data;if(\"/$\"===r)if(0===f)break;else f--;else\"$\"!==r&&\"$?\"!==r&&\"$~\"!==r&&\"$!\"!==r||f++}else if(1===c.nodeType){d=c;var D=d.getAttribute(\"vt-name\"),y=m.get(D);k(d,y?\"vt-share\":\"vt-exit\");y&&(k(y,\"vt-share\"),m.set(D,null));var E=d.querySelectorAll(\"[vt-share]\");for(d=0;d<E.length;d++){var F=E[d],G=F.getAttribute(\"vt-name\"),\nH=m.get(G);H&&(k(F,\"vt-share\"),k(H,\"vt-share\"),m.set(G,null))}}c=c.nextSibling}for(var I=g[h+1],t=I.firstElementChild;t;)null!==m.get(t.getAttribute(\"vt-name\"))&&k(t,\"vt-enter\"),t=t.nextElementSibling;c=x;do for(var n=c.firstElementChild;n;){var J=n.getAttribute(\"vt-update\");J&&\"none\"!==J&&!l.includes(n)&&k(n,\"vt-update\");n=n.nextElementSibling}while((c=c.parentNode)&&1===c.nodeType&&\"none\"!==c.getAttribute(\"vt-update\"));u.push.apply(u,I.querySelectorAll('img[src]:not([loading=\"lazy\"])'))}}}if(B){var z=\ndocument.__reactViewTransition=document.startViewTransition({update:function(){A(g);for(var a=[document.documentElement.clientHeight,document.fonts.ready],b={},e=0;e<u.length;b={g:b.g},e++)if(b.g=u[e],!b.g.complete){var p=b.g.getBoundingClientRect();0<p.bottom&&0<p.right&&p.top<window.innerHeight&&p.left<window.innerWidth&&(p=new Promise(function(w){return function(q){w.g.addEventListener(\"load\",q);w.g.addEventListener(\"error\",q)}}(b)),a.push(p))}return Promise.race([Promise.all(a),new Promise(function(w){var q=\nperformance.now();setTimeout(w,2300>q&&2E3<q?2300-q:500)})])},types:[]});z.ready.finally(function(){for(var a=l.length-3;0<=a;a-=3){var b=l[a],e=b.style;e.viewTransitionName=l[a+1];e.viewTransitionClass=l[a+1];\"\"===b.getAttribute(\"style\")&&b.removeAttribute(\"style\")}});z.finished.finally(function(){document.__reactViewTransition===z&&(document.__reactViewTransition=null)});$RB=[];return}}catch(a){}A(g)}.bind(null,$RV);");
	var completeBoundaryScript1Partial = stringToPrecomputedChunk("$RC(\""), completeBoundaryWithStylesScript1FullPartial = stringToPrecomputedChunk("$RM=new Map;$RR=function(n,w,p){function u(q){this._p=null;q()}for(var r=new Map,t=document,h,b,e=t.querySelectorAll(\"link[data-precedence],style[data-precedence]\"),v=[],k=0;b=e[k++];)\"not all\"===b.getAttribute(\"media\")?v.push(b):(\"LINK\"===b.tagName&&$RM.set(b.getAttribute(\"href\"),b),r.set(b.dataset.precedence,h=b));e=0;b=[];var l,a;for(k=!0;;){if(k){var f=p[e++];if(!f){k=!1;e=0;continue}var c=!1,m=0;var d=f[m++];if(a=$RM.get(d)){var g=a._p;c=!0}else{a=t.createElement(\"link\");a.href=d;a.rel=\n\"stylesheet\";for(a.dataset.precedence=l=f[m++];g=f[m++];)a.setAttribute(g,f[m++]);g=a._p=new Promise(function(q,x){a.onload=u.bind(a,q);a.onerror=u.bind(a,x)});$RM.set(d,a)}d=a.getAttribute(\"media\");!g||d&&!matchMedia(d).matches||b.push(g);if(c)continue}else{a=v[e++];if(!a)break;l=a.getAttribute(\"data-precedence\");a.removeAttribute(\"media\")}c=r.get(l)||h;c===h&&(h=a);r.set(l,a);c?c.parentNode.insertBefore(a,c.nextSibling):(c=t.head,c.insertBefore(a,c.firstChild))}if(p=document.getElementById(n))p.previousSibling.data=\n\"$~\";Promise.all(b).then($RC.bind(null,n,w),$RX.bind(null,n,\"CSS failed to load\"))};$RR(\""), completeBoundaryWithStylesScript1Partial = stringToPrecomputedChunk("$RR(\""), completeBoundaryScript2 = stringToPrecomputedChunk("\",\""), completeBoundaryScript3a = stringToPrecomputedChunk("\","), completeBoundaryScript3b = stringToPrecomputedChunk("\""), completeBoundaryScriptEnd = stringToPrecomputedChunk(")<\/script>");
	stringToPrecomputedChunk("<template data-rci=\"\" data-bid=\"");
	stringToPrecomputedChunk("<template data-rri=\"\" data-bid=\"");
	stringToPrecomputedChunk("\" data-sid=\"");
	stringToPrecomputedChunk("\" data-sty=\"");
	var clientRenderScriptFunctionOnly = stringToPrecomputedChunk("$RX=function(b,c,d,e,f){var a=document.getElementById(b);a&&(b=a.previousSibling,b.data=\"$!\",a=a.dataset,c&&(a.dgst=c),d&&(a.msg=d),e&&(a.stck=e),f&&(a.cstck=f),b._reactRetry&&b._reactRetry())};"), clientRenderScript1Full = stringToPrecomputedChunk("$RX=function(b,c,d,e,f){var a=document.getElementById(b);a&&(b=a.previousSibling,b.data=\"$!\",a=a.dataset,c&&(a.dgst=c),d&&(a.msg=d),e&&(a.stck=e),f&&(a.cstck=f),b._reactRetry&&b._reactRetry())};;$RX(\""), clientRenderScript1Partial = stringToPrecomputedChunk("$RX(\""), clientRenderScript1A = stringToPrecomputedChunk("\""), clientRenderErrorScriptArgInterstitial = stringToPrecomputedChunk(","), clientRenderScriptEnd = stringToPrecomputedChunk(")<\/script>");
	stringToPrecomputedChunk("<template data-rxi=\"\" data-bid=\"");
	stringToPrecomputedChunk("\" data-dgst=\"");
	stringToPrecomputedChunk("\" data-msg=\"");
	stringToPrecomputedChunk("\" data-stck=\"");
	stringToPrecomputedChunk("\" data-cstck=\"");
	var regexForJSStringsInInstructionScripts = /[<\u2028\u2029]/g;
	function escapeJSStringsForInstructionScripts(input) {
		return JSON.stringify(input).replace(regexForJSStringsInInstructionScripts, function(match) {
			switch (match) {
				case "<": return "\\u003c";
				case "\u2028": return "\\u2028";
				case "\u2029": return "\\u2029";
				default: throw Error("escapeJSStringsForInstructionScripts encountered a match it does not know how to replace. this means the match regex and the replacement characters are no longer in sync. This is a bug in React");
			}
		});
	}
	var regexForJSStringsInScripts = /[&><\u2028\u2029]/g;
	function escapeJSObjectForInstructionScripts(input) {
		return JSON.stringify(input).replace(regexForJSStringsInScripts, function(match) {
			switch (match) {
				case "&": return "\\u0026";
				case ">": return "\\u003e";
				case "<": return "\\u003c";
				case "\u2028": return "\\u2028";
				case "\u2029": return "\\u2029";
				default: throw Error("escapeJSObjectForInstructionScripts encountered a match it does not know how to replace. this means the match regex and the replacement characters are no longer in sync. This is a bug in React");
			}
		});
	}
	var lateStyleTagResourceOpen1 = stringToPrecomputedChunk(" media=\"not all\" data-precedence=\""), lateStyleTagResourceOpen2 = stringToPrecomputedChunk("\" data-href=\""), lateStyleTagResourceOpen3 = stringToPrecomputedChunk("\">"), lateStyleTagTemplateClose = stringToPrecomputedChunk("</style>"), currentlyRenderingBoundaryHasStylesToHoist = !1, destinationHasCapacity = !0;
	function flushStyleTagsLateForBoundary(styleQueue) {
		var rules = styleQueue.rules, hrefs = styleQueue.hrefs, i = 0;
		if (hrefs.length) {
			writeChunk(this, currentlyFlushingRenderState.startInlineStyle);
			writeChunk(this, lateStyleTagResourceOpen1);
			writeChunk(this, styleQueue.precedence);
			for (writeChunk(this, lateStyleTagResourceOpen2); i < hrefs.length - 1; i++) writeChunk(this, hrefs[i]), writeChunk(this, spaceSeparator);
			writeChunk(this, hrefs[i]);
			writeChunk(this, lateStyleTagResourceOpen3);
			for (i = 0; i < rules.length; i++) writeChunk(this, rules[i]);
			destinationHasCapacity = writeChunkAndReturn(this, lateStyleTagTemplateClose);
			currentlyRenderingBoundaryHasStylesToHoist = !0;
			rules.length = 0;
			hrefs.length = 0;
		}
	}
	function hasStylesToHoist(stylesheet) {
		return 2 !== stylesheet.state ? currentlyRenderingBoundaryHasStylesToHoist = !0 : !1;
	}
	function writeHoistablesForBoundary(destination, hoistableState, renderState) {
		currentlyRenderingBoundaryHasStylesToHoist = !1;
		destinationHasCapacity = !0;
		currentlyFlushingRenderState = renderState;
		hoistableState.styles.forEach(flushStyleTagsLateForBoundary, destination);
		currentlyFlushingRenderState = null;
		hoistableState.stylesheets.forEach(hasStylesToHoist);
		currentlyRenderingBoundaryHasStylesToHoist && (renderState.stylesToHoist = !0);
		return destinationHasCapacity;
	}
	function flushResource(resource) {
		for (var i = 0; i < resource.length; i++) writeChunk(this, resource[i]);
		resource.length = 0;
	}
	var stylesheetFlushingQueue = [];
	function flushStyleInPreamble(stylesheet) {
		pushLinkImpl(stylesheetFlushingQueue, stylesheet.props);
		for (var i = 0; i < stylesheetFlushingQueue.length; i++) writeChunk(this, stylesheetFlushingQueue[i]);
		stylesheetFlushingQueue.length = 0;
		stylesheet.state = 2;
	}
	var styleTagResourceOpen1 = stringToPrecomputedChunk(" data-precedence=\""), styleTagResourceOpen2 = stringToPrecomputedChunk("\" data-href=\""), spaceSeparator = stringToPrecomputedChunk(" "), styleTagResourceOpen3 = stringToPrecomputedChunk("\">"), styleTagResourceClose = stringToPrecomputedChunk("</style>");
	function flushStylesInPreamble(styleQueue) {
		var hasStylesheets = 0 < styleQueue.sheets.size;
		styleQueue.sheets.forEach(flushStyleInPreamble, this);
		styleQueue.sheets.clear();
		var rules = styleQueue.rules, hrefs = styleQueue.hrefs;
		if (!hasStylesheets || hrefs.length) {
			writeChunk(this, currentlyFlushingRenderState.startInlineStyle);
			writeChunk(this, styleTagResourceOpen1);
			writeChunk(this, styleQueue.precedence);
			styleQueue = 0;
			if (hrefs.length) {
				for (writeChunk(this, styleTagResourceOpen2); styleQueue < hrefs.length - 1; styleQueue++) writeChunk(this, hrefs[styleQueue]), writeChunk(this, spaceSeparator);
				writeChunk(this, hrefs[styleQueue]);
			}
			writeChunk(this, styleTagResourceOpen3);
			for (styleQueue = 0; styleQueue < rules.length; styleQueue++) writeChunk(this, rules[styleQueue]);
			writeChunk(this, styleTagResourceClose);
			rules.length = 0;
			hrefs.length = 0;
		}
	}
	function preloadLateStyle(stylesheet) {
		if (0 === stylesheet.state) {
			stylesheet.state = 1;
			var props = stylesheet.props;
			pushLinkImpl(stylesheetFlushingQueue, {
				rel: "preload",
				as: "style",
				href: stylesheet.props.href,
				crossOrigin: props.crossOrigin,
				fetchPriority: props.fetchPriority,
				integrity: props.integrity,
				media: props.media,
				hrefLang: props.hrefLang,
				referrerPolicy: props.referrerPolicy
			});
			for (stylesheet = 0; stylesheet < stylesheetFlushingQueue.length; stylesheet++) writeChunk(this, stylesheetFlushingQueue[stylesheet]);
			stylesheetFlushingQueue.length = 0;
		}
	}
	function preloadLateStyles(styleQueue) {
		styleQueue.sheets.forEach(preloadLateStyle, this);
		styleQueue.sheets.clear();
	}
	stringToPrecomputedChunk("<link rel=\"expect\" href=\"#");
	stringToPrecomputedChunk("\" blocking=\"render\"/>");
	var completedShellIdAttributeStart = stringToPrecomputedChunk(" id=\"");
	function pushCompletedShellIdAttribute(target, resumableState) {
		0 === (resumableState.instructions & 32) && (resumableState.instructions |= 32, target.push(completedShellIdAttributeStart, stringToChunk(escapeTextForBrowser("_" + resumableState.idPrefix + "R_")), attributeEnd));
	}
	var arrayFirstOpenBracket = stringToPrecomputedChunk("["), arraySubsequentOpenBracket = stringToPrecomputedChunk(",["), arrayInterstitial = stringToPrecomputedChunk(","), arrayCloseBracket = stringToPrecomputedChunk("]");
	function writeStyleResourceDependenciesInJS(destination, hoistableState) {
		writeChunk(destination, arrayFirstOpenBracket);
		var nextArrayOpenBrackChunk = arrayFirstOpenBracket;
		hoistableState.stylesheets.forEach(function(resource) {
			if (2 !== resource.state) if (3 === resource.state) writeChunk(destination, nextArrayOpenBrackChunk), writeChunk(destination, stringToChunk(escapeJSObjectForInstructionScripts("" + resource.props.href))), writeChunk(destination, arrayCloseBracket), nextArrayOpenBrackChunk = arraySubsequentOpenBracket;
			else {
				writeChunk(destination, nextArrayOpenBrackChunk);
				var precedence = resource.props["data-precedence"], props = resource.props;
				writeChunk(destination, stringToChunk(escapeJSObjectForInstructionScripts(sanitizeURL("" + resource.props.href))));
				precedence = "" + precedence;
				writeChunk(destination, arrayInterstitial);
				writeChunk(destination, stringToChunk(escapeJSObjectForInstructionScripts(precedence)));
				for (var propKey in props) if (hasOwnProperty.call(props, propKey) && (precedence = props[propKey], null != precedence)) switch (propKey) {
					case "href":
					case "rel":
					case "precedence":
					case "data-precedence": break;
					case "children":
					case "dangerouslySetInnerHTML": throw Error("link is a self-closing tag and must neither have `children` nor use `dangerouslySetInnerHTML`.");
					default: writeStyleResourceAttributeInJS(destination, propKey, precedence);
				}
				writeChunk(destination, arrayCloseBracket);
				nextArrayOpenBrackChunk = arraySubsequentOpenBracket;
				resource.state = 3;
			}
		});
		writeChunk(destination, arrayCloseBracket);
	}
	function writeStyleResourceAttributeInJS(destination, name, value) {
		var attributeName = name.toLowerCase();
		switch (typeof value) {
			case "function":
			case "symbol": return;
		}
		switch (name) {
			case "innerHTML":
			case "dangerouslySetInnerHTML":
			case "suppressContentEditableWarning":
			case "suppressHydrationWarning":
			case "style":
			case "ref": return;
			case "className":
				attributeName = "class";
				name = "" + value;
				break;
			case "hidden":
				if (!1 === value) return;
				name = "";
				break;
			case "src":
			case "href":
				value = sanitizeURL(value);
				name = "" + value;
				break;
			default:
				if (2 < name.length && ("o" === name[0] || "O" === name[0]) && ("n" === name[1] || "N" === name[1]) || !isAttributeNameSafe(name)) return;
				name = "" + value;
		}
		writeChunk(destination, arrayInterstitial);
		writeChunk(destination, stringToChunk(escapeJSObjectForInstructionScripts(attributeName)));
		writeChunk(destination, arrayInterstitial);
		writeChunk(destination, stringToChunk(escapeJSObjectForInstructionScripts(name)));
	}
	function createHoistableState() {
		return {
			styles: /* @__PURE__ */ new Set(),
			stylesheets: /* @__PURE__ */ new Set(),
			suspenseyImages: !1
		};
	}
	function prefetchDNS(href) {
		var request = resolveRequest();
		if (request) {
			var resumableState = request.resumableState, renderState = request.renderState;
			if ("string" === typeof href && href) {
				if (!resumableState.dnsResources.hasOwnProperty(href)) {
					resumableState.dnsResources[href] = null;
					resumableState = renderState.headers;
					var header, JSCompiler_temp;
					if (JSCompiler_temp = resumableState && 0 < resumableState.remainingCapacity) JSCompiler_temp = (header = "<" + ("" + href).replace(regexForHrefInLinkHeaderURLContext, escapeHrefForLinkHeaderURLContextReplacer) + ">; rel=dns-prefetch", 0 <= (resumableState.remainingCapacity -= header.length + 2));
					JSCompiler_temp ? (renderState.resets.dns[href] = null, resumableState.preconnects && (resumableState.preconnects += ", "), resumableState.preconnects += header) : (header = [], pushLinkImpl(header, {
						href,
						rel: "dns-prefetch"
					}), renderState.preconnects.add(header));
				}
				enqueueFlush(request);
			}
		} else previousDispatcher.D(href);
	}
	function preconnect(href, crossOrigin) {
		var request = resolveRequest();
		if (request) {
			var resumableState = request.resumableState, renderState = request.renderState;
			if ("string" === typeof href && href) {
				var bucket = "use-credentials" === crossOrigin ? "credentials" : "string" === typeof crossOrigin ? "anonymous" : "default";
				if (!resumableState.connectResources[bucket].hasOwnProperty(href)) {
					resumableState.connectResources[bucket][href] = null;
					resumableState = renderState.headers;
					var header, JSCompiler_temp;
					if (JSCompiler_temp = resumableState && 0 < resumableState.remainingCapacity) {
						JSCompiler_temp = "<" + ("" + href).replace(regexForHrefInLinkHeaderURLContext, escapeHrefForLinkHeaderURLContextReplacer) + ">; rel=preconnect";
						if ("string" === typeof crossOrigin) {
							var escapedCrossOrigin = ("" + crossOrigin).replace(regexForLinkHeaderQuotedParamValueContext, escapeStringForLinkHeaderQuotedParamValueContextReplacer);
							JSCompiler_temp += "; crossorigin=\"" + escapedCrossOrigin + "\"";
						}
						JSCompiler_temp = (header = JSCompiler_temp, 0 <= (resumableState.remainingCapacity -= header.length + 2));
					}
					JSCompiler_temp ? (renderState.resets.connect[bucket][href] = null, resumableState.preconnects && (resumableState.preconnects += ", "), resumableState.preconnects += header) : (bucket = [], pushLinkImpl(bucket, {
						rel: "preconnect",
						href,
						crossOrigin
					}), renderState.preconnects.add(bucket));
				}
				enqueueFlush(request);
			}
		} else previousDispatcher.C(href, crossOrigin);
	}
	function preload(href, as, options) {
		var request = resolveRequest();
		if (request) {
			var resumableState = request.resumableState, renderState = request.renderState;
			if (as && href) {
				switch (as) {
					case "image":
						if (options) {
							var imageSrcSet = options.imageSrcSet;
							var imageSizes = options.imageSizes;
							var fetchPriority = options.fetchPriority;
						}
						var key = imageSrcSet ? imageSrcSet + "\n" + (imageSizes || "") : href;
						if (resumableState.imageResources.hasOwnProperty(key)) return;
						resumableState.imageResources[key] = PRELOAD_NO_CREDS;
						resumableState = renderState.headers;
						var header;
						resumableState && 0 < resumableState.remainingCapacity && "string" !== typeof imageSrcSet && "high" === fetchPriority && (header = getPreloadAsHeader(href, as, options), 0 <= (resumableState.remainingCapacity -= header.length + 2)) ? (renderState.resets.image[key] = PRELOAD_NO_CREDS, resumableState.highImagePreloads && (resumableState.highImagePreloads += ", "), resumableState.highImagePreloads += header) : (resumableState = [], pushLinkImpl(resumableState, assign({
							rel: "preload",
							href: imageSrcSet ? void 0 : href,
							as
						}, options)), "high" === fetchPriority ? renderState.highImagePreloads.add(resumableState) : (renderState.bulkPreloads.add(resumableState), renderState.preloads.images.set(key, resumableState)));
						break;
					case "style":
						if (resumableState.styleResources.hasOwnProperty(href)) return;
						imageSrcSet = [];
						pushLinkImpl(imageSrcSet, assign({
							rel: "preload",
							href,
							as
						}, options));
						resumableState.styleResources[href] = !options || "string" !== typeof options.crossOrigin && "string" !== typeof options.integrity ? PRELOAD_NO_CREDS : [options.crossOrigin, options.integrity];
						renderState.preloads.stylesheets.set(href, imageSrcSet);
						renderState.bulkPreloads.add(imageSrcSet);
						break;
					case "script":
						if (resumableState.scriptResources.hasOwnProperty(href)) return;
						imageSrcSet = [];
						renderState.preloads.scripts.set(href, imageSrcSet);
						renderState.bulkPreloads.add(imageSrcSet);
						pushLinkImpl(imageSrcSet, assign({
							rel: "preload",
							href,
							as
						}, options));
						resumableState.scriptResources[href] = !options || "string" !== typeof options.crossOrigin && "string" !== typeof options.integrity ? PRELOAD_NO_CREDS : [options.crossOrigin, options.integrity];
						break;
					default:
						if (resumableState.unknownResources.hasOwnProperty(as)) {
							if (imageSrcSet = resumableState.unknownResources[as], imageSrcSet.hasOwnProperty(href)) return;
						} else imageSrcSet = {}, resumableState.unknownResources[as] = imageSrcSet;
						imageSrcSet[href] = PRELOAD_NO_CREDS;
						if ((resumableState = renderState.headers) && 0 < resumableState.remainingCapacity && "font" === as && (key = getPreloadAsHeader(href, as, options), 0 <= (resumableState.remainingCapacity -= key.length + 2))) renderState.resets.font[href] = PRELOAD_NO_CREDS, resumableState.fontPreloads && (resumableState.fontPreloads += ", "), resumableState.fontPreloads += key;
						else switch (resumableState = [], href = assign({
							rel: "preload",
							href,
							as
						}, options), pushLinkImpl(resumableState, href), as) {
							case "font":
								renderState.fontPreloads.add(resumableState);
								break;
							default: renderState.bulkPreloads.add(resumableState);
						}
				}
				enqueueFlush(request);
			}
		} else previousDispatcher.L(href, as, options);
	}
	function preloadModule(href, options) {
		var request = resolveRequest();
		if (request) {
			var resumableState = request.resumableState, renderState = request.renderState;
			if (href) {
				var as = options && "string" === typeof options.as ? options.as : "script";
				switch (as) {
					case "script":
						if (resumableState.moduleScriptResources.hasOwnProperty(href)) return;
						as = [];
						resumableState.moduleScriptResources[href] = !options || "string" !== typeof options.crossOrigin && "string" !== typeof options.integrity ? PRELOAD_NO_CREDS : [options.crossOrigin, options.integrity];
						renderState.preloads.moduleScripts.set(href, as);
						break;
					default:
						if (resumableState.moduleUnknownResources.hasOwnProperty(as)) {
							var resources = resumableState.unknownResources[as];
							if (resources.hasOwnProperty(href)) return;
						} else resources = {}, resumableState.moduleUnknownResources[as] = resources;
						as = [];
						resources[href] = PRELOAD_NO_CREDS;
				}
				pushLinkImpl(as, assign({
					rel: "modulepreload",
					href
				}, options));
				renderState.bulkPreloads.add(as);
				enqueueFlush(request);
			}
		} else previousDispatcher.m(href, options);
	}
	function preinitStyle(href, precedence, options) {
		var request = resolveRequest();
		if (request) {
			var resumableState = request.resumableState, renderState = request.renderState;
			if (href) {
				precedence = precedence || "default";
				var styleQueue = renderState.styles.get(precedence), resourceState = resumableState.styleResources.hasOwnProperty(href) ? resumableState.styleResources[href] : void 0;
				null !== resourceState && (resumableState.styleResources[href] = null, styleQueue || (styleQueue = {
					precedence: stringToChunk(escapeTextForBrowser(precedence)),
					rules: [],
					hrefs: [],
					sheets: /* @__PURE__ */ new Map()
				}, renderState.styles.set(precedence, styleQueue)), precedence = {
					state: 0,
					props: assign({
						rel: "stylesheet",
						href,
						"data-precedence": precedence
					}, options)
				}, resourceState && (2 === resourceState.length && adoptPreloadCredentials(precedence.props, resourceState), (renderState = renderState.preloads.stylesheets.get(href)) && 0 < renderState.length ? renderState.length = 0 : precedence.state = 1), styleQueue.sheets.set(href, precedence), enqueueFlush(request));
			}
		} else previousDispatcher.S(href, precedence, options);
	}
	function preinitScript(src, options) {
		var request = resolveRequest();
		if (request) {
			var resumableState = request.resumableState, renderState = request.renderState;
			if (src) {
				var resourceState = resumableState.scriptResources.hasOwnProperty(src) ? resumableState.scriptResources[src] : void 0;
				null !== resourceState && (resumableState.scriptResources[src] = null, options = assign({
					src,
					async: !0
				}, options), resourceState && (2 === resourceState.length && adoptPreloadCredentials(options, resourceState), src = renderState.preloads.scripts.get(src)) && (src.length = 0), src = [], renderState.scripts.add(src), pushScriptImpl(src, options), enqueueFlush(request));
			}
		} else previousDispatcher.X(src, options);
	}
	function preinitModuleScript(src, options) {
		var request = resolveRequest();
		if (request) {
			var resumableState = request.resumableState, renderState = request.renderState;
			if (src) {
				var resourceState = resumableState.moduleScriptResources.hasOwnProperty(src) ? resumableState.moduleScriptResources[src] : void 0;
				null !== resourceState && (resumableState.moduleScriptResources[src] = null, options = assign({
					src,
					type: "module",
					async: !0
				}, options), resourceState && (2 === resourceState.length && adoptPreloadCredentials(options, resourceState), src = renderState.preloads.moduleScripts.get(src)) && (src.length = 0), src = [], renderState.scripts.add(src), pushScriptImpl(src, options), enqueueFlush(request));
			}
		} else previousDispatcher.M(src, options);
	}
	function adoptPreloadCredentials(target, preloadState) {
		target.crossOrigin ??= preloadState[0];
		target.integrity ??= preloadState[1];
	}
	function getPreloadAsHeader(href, as, params) {
		href = ("" + href).replace(regexForHrefInLinkHeaderURLContext, escapeHrefForLinkHeaderURLContextReplacer);
		as = ("" + as).replace(regexForLinkHeaderQuotedParamValueContext, escapeStringForLinkHeaderQuotedParamValueContextReplacer);
		as = "<" + href + ">; rel=preload; as=\"" + as + "\"";
		for (var paramName in params) hasOwnProperty.call(params, paramName) && (href = params[paramName], "string" === typeof href && (as += "; " + paramName.toLowerCase() + "=\"" + ("" + href).replace(regexForLinkHeaderQuotedParamValueContext, escapeStringForLinkHeaderQuotedParamValueContextReplacer) + "\""));
		return as;
	}
	var regexForHrefInLinkHeaderURLContext = /[<>\r\n]/g;
	function escapeHrefForLinkHeaderURLContextReplacer(match) {
		switch (match) {
			case "<": return "%3C";
			case ">": return "%3E";
			case "\n": return "%0A";
			case "\r": return "%0D";
			default: throw Error("escapeLinkHrefForHeaderContextReplacer encountered a match it does not know how to replace. this means the match regex and the replacement characters are no longer in sync. This is a bug in React");
		}
	}
	var regexForLinkHeaderQuotedParamValueContext = /["';,\r\n]/g;
	function escapeStringForLinkHeaderQuotedParamValueContextReplacer(match) {
		switch (match) {
			case "\"": return "%22";
			case "'": return "%27";
			case ";": return "%3B";
			case ",": return "%2C";
			case "\n": return "%0A";
			case "\r": return "%0D";
			default: throw Error("escapeStringForLinkHeaderQuotedParamValueContextReplacer encountered a match it does not know how to replace. this means the match regex and the replacement characters are no longer in sync. This is a bug in React");
		}
	}
	function hoistStyleQueueDependency(styleQueue) {
		this.styles.add(styleQueue);
	}
	function hoistStylesheetDependency(stylesheet) {
		this.stylesheets.add(stylesheet);
	}
	function hoistHoistables(parentState, childState) {
		childState.styles.forEach(hoistStyleQueueDependency, parentState);
		childState.stylesheets.forEach(hoistStylesheetDependency, parentState);
		childState.suspenseyImages && (parentState.suspenseyImages = !0);
	}
	function hasSuspenseyContent(hoistableState) {
		return 0 < hoistableState.stylesheets.size || hoistableState.suspenseyImages;
	}
	var bind = Function.prototype.bind, supportsRequestStorage = "function" === typeof AsyncLocalStorage, requestStorage = supportsRequestStorage ? new AsyncLocalStorage() : null, REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference");
	function getComponentNameFromType(type) {
		if (null == type) return null;
		if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
		if ("string" === typeof type) return type;
		switch (type) {
			case REACT_FRAGMENT_TYPE: return "Fragment";
			case REACT_PROFILER_TYPE: return "Profiler";
			case REACT_STRICT_MODE_TYPE: return "StrictMode";
			case REACT_SUSPENSE_TYPE: return "Suspense";
			case REACT_SUSPENSE_LIST_TYPE: return "SuspenseList";
			case REACT_ACTIVITY_TYPE: return "Activity";
		}
		if ("object" === typeof type) switch (type.$$typeof) {
			case REACT_PORTAL_TYPE: return "Portal";
			case REACT_CONTEXT_TYPE: return type.displayName || "Context";
			case REACT_CONSUMER_TYPE: return (type._context.displayName || "Context") + ".Consumer";
			case REACT_FORWARD_REF_TYPE:
				var innerType = type.render;
				type = type.displayName;
				type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
				return type;
			case REACT_MEMO_TYPE: return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
			case REACT_LAZY_TYPE:
				innerType = type._payload;
				type = type._init;
				try {
					return getComponentNameFromType(type(innerType));
				} catch (x) {}
		}
		return null;
	}
	var emptyContextObject = {}, currentActiveSnapshot = null;
	function popToNearestCommonAncestor(prev, next) {
		if (prev !== next) {
			prev.context._currentValue = prev.parentValue;
			prev = prev.parent;
			var parentNext = next.parent;
			if (null === prev) {
				if (null !== parentNext) throw Error("The stacks must reach the root at the same time. This is a bug in React.");
			} else {
				if (null === parentNext) throw Error("The stacks must reach the root at the same time. This is a bug in React.");
				popToNearestCommonAncestor(prev, parentNext);
			}
			next.context._currentValue = next.value;
		}
	}
	function popAllPrevious(prev) {
		prev.context._currentValue = prev.parentValue;
		prev = prev.parent;
		null !== prev && popAllPrevious(prev);
	}
	function pushAllNext(next) {
		var parentNext = next.parent;
		null !== parentNext && pushAllNext(parentNext);
		next.context._currentValue = next.value;
	}
	function popPreviousToCommonLevel(prev, next) {
		prev.context._currentValue = prev.parentValue;
		prev = prev.parent;
		if (null === prev) throw Error("The depth must equal at least at zero before reaching the root. This is a bug in React.");
		prev.depth === next.depth ? popToNearestCommonAncestor(prev, next) : popPreviousToCommonLevel(prev, next);
	}
	function popNextToCommonLevel(prev, next) {
		var parentNext = next.parent;
		if (null === parentNext) throw Error("The depth must equal at least at zero before reaching the root. This is a bug in React.");
		prev.depth === parentNext.depth ? popToNearestCommonAncestor(prev, parentNext) : popNextToCommonLevel(prev, parentNext);
		next.context._currentValue = next.value;
	}
	function switchContext(newSnapshot) {
		var prev = currentActiveSnapshot;
		prev !== newSnapshot && (null === prev ? pushAllNext(newSnapshot) : null === newSnapshot ? popAllPrevious(prev) : prev.depth === newSnapshot.depth ? popToNearestCommonAncestor(prev, newSnapshot) : prev.depth > newSnapshot.depth ? popPreviousToCommonLevel(prev, newSnapshot) : popNextToCommonLevel(prev, newSnapshot), currentActiveSnapshot = newSnapshot);
	}
	var classComponentUpdater = {
		enqueueSetState: function(inst, payload) {
			inst = inst._reactInternals;
			null !== inst.queue && inst.queue.push(payload);
		},
		enqueueReplaceState: function(inst, payload) {
			inst = inst._reactInternals;
			inst.replace = !0;
			inst.queue = [payload];
		},
		enqueueForceUpdate: function() {}
	}, emptyTreeContext = {
		id: 1,
		overflow: ""
	};
	function pushTreeContext(baseContext, totalChildren, index) {
		var baseIdWithLeadingBit = baseContext.id;
		baseContext = baseContext.overflow;
		var baseLength = 32 - clz32(baseIdWithLeadingBit) - 1;
		baseIdWithLeadingBit &= ~(1 << baseLength);
		index += 1;
		var length = 32 - clz32(totalChildren) + baseLength;
		if (30 < length) {
			var numberOfOverflowBits = baseLength - baseLength % 5;
			length = (baseIdWithLeadingBit & (1 << numberOfOverflowBits) - 1).toString(32);
			baseIdWithLeadingBit >>= numberOfOverflowBits;
			baseLength -= numberOfOverflowBits;
			return {
				id: 1 << 32 - clz32(totalChildren) + baseLength | index << baseLength | baseIdWithLeadingBit,
				overflow: length + baseContext
			};
		}
		return {
			id: 1 << length | index << baseLength | baseIdWithLeadingBit,
			overflow: baseContext
		};
	}
	var clz32 = Math.clz32 ? Math.clz32 : clz32Fallback, log = Math.log, LN2 = Math.LN2;
	function clz32Fallback(x) {
		x >>>= 0;
		return 0 === x ? 32 : 31 - (log(x) / LN2 | 0) | 0;
	}
	function noop() {}
	var SuspenseException = Error("Suspense Exception: This is not a real error! It's an implementation detail of `use` to interrupt the current render. You must either rethrow it immediately, or move the `use` call outside of the `try/catch` block. Capturing without rethrowing will lead to unexpected behavior.\n\nTo handle async errors, wrap your component in an error boundary, or call the promise's `.catch` method and pass the result to `use`.");
	function trackUsedThenable(thenableState, thenable, index) {
		index = thenableState[index];
		void 0 === index ? thenableState.push(thenable) : index !== thenable && (thenable.then(noop, noop), thenable = index);
		switch (thenable.status) {
			case "fulfilled": return thenable.value;
			case "rejected": throw thenable.reason;
			default:
				"string" === typeof thenable.status ? thenable.then(noop, noop) : (thenableState = thenable, thenableState.status = "pending", thenableState.then(function(fulfilledValue) {
					if ("pending" === thenable.status) {
						var fulfilledThenable = thenable;
						fulfilledThenable.status = "fulfilled";
						fulfilledThenable.value = fulfilledValue;
					}
				}, function(error) {
					if ("pending" === thenable.status) {
						var rejectedThenable = thenable;
						rejectedThenable.status = "rejected";
						rejectedThenable.reason = error;
					}
				}));
				switch (thenable.status) {
					case "fulfilled": return thenable.value;
					case "rejected": throw thenable.reason;
				}
				suspendedThenable = thenable;
				throw SuspenseException;
		}
	}
	var suspendedThenable = null;
	function getSuspendedThenable() {
		if (null === suspendedThenable) throw Error("Expected a suspended thenable. This is a bug in React. Please file an issue.");
		var thenable = suspendedThenable;
		suspendedThenable = null;
		return thenable;
	}
	function is(x, y) {
		return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
	}
	var objectIs = "function" === typeof Object.is ? Object.is : is, currentlyRenderingComponent = null, currentlyRenderingTask = null, currentlyRenderingRequest = null, currentlyRenderingKeyPath = null, firstWorkInProgressHook = null, workInProgressHook = null, isReRender = !1, didScheduleRenderPhaseUpdate = !1, localIdCounter = 0, actionStateCounter = 0, actionStateMatchingIndex = -1, thenableIndexCounter = 0, thenableState = null, renderPhaseUpdates = null, numberOfReRenders = 0;
	function resolveCurrentlyRenderingComponent() {
		if (null === currentlyRenderingComponent) throw Error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.");
		return currentlyRenderingComponent;
	}
	function createHook() {
		if (0 < numberOfReRenders) throw Error("Rendered more hooks than during the previous render");
		return {
			memoizedState: null,
			queue: null,
			next: null
		};
	}
	function createWorkInProgressHook() {
		null === workInProgressHook ? null === firstWorkInProgressHook ? (isReRender = !1, firstWorkInProgressHook = workInProgressHook = createHook()) : (isReRender = !0, workInProgressHook = firstWorkInProgressHook) : null === workInProgressHook.next ? (isReRender = !1, workInProgressHook = workInProgressHook.next = createHook()) : (isReRender = !0, workInProgressHook = workInProgressHook.next);
		return workInProgressHook;
	}
	function getThenableStateAfterSuspending() {
		var state = thenableState;
		thenableState = null;
		return state;
	}
	function resetHooksState() {
		currentlyRenderingKeyPath = currentlyRenderingRequest = currentlyRenderingTask = currentlyRenderingComponent = null;
		didScheduleRenderPhaseUpdate = !1;
		firstWorkInProgressHook = null;
		numberOfReRenders = 0;
		workInProgressHook = renderPhaseUpdates = null;
	}
	function basicStateReducer(state, action) {
		return "function" === typeof action ? action(state) : action;
	}
	function useReducer(reducer, initialArg, init) {
		currentlyRenderingComponent = resolveCurrentlyRenderingComponent();
		workInProgressHook = createWorkInProgressHook();
		if (isReRender) {
			var queue = workInProgressHook.queue;
			initialArg = queue.dispatch;
			if (null !== renderPhaseUpdates && (init = renderPhaseUpdates.get(queue), void 0 !== init)) {
				renderPhaseUpdates.delete(queue);
				queue = workInProgressHook.memoizedState;
				do
					queue = reducer(queue, init.action), init = init.next;
				while (null !== init);
				workInProgressHook.memoizedState = queue;
				return [queue, initialArg];
			}
			return [workInProgressHook.memoizedState, initialArg];
		}
		reducer = reducer === basicStateReducer ? "function" === typeof initialArg ? initialArg() : initialArg : void 0 !== init ? init(initialArg) : initialArg;
		workInProgressHook.memoizedState = reducer;
		reducer = workInProgressHook.queue = {
			last: null,
			dispatch: null
		};
		reducer = reducer.dispatch = dispatchAction.bind(null, currentlyRenderingComponent, reducer);
		return [workInProgressHook.memoizedState, reducer];
	}
	function useMemo(nextCreate, deps) {
		currentlyRenderingComponent = resolveCurrentlyRenderingComponent();
		workInProgressHook = createWorkInProgressHook();
		deps = void 0 === deps ? null : deps;
		if (null !== workInProgressHook) {
			var prevState = workInProgressHook.memoizedState;
			if (null !== prevState && null !== deps) {
				var prevDeps = prevState[1];
				a: if (null === prevDeps) prevDeps = !1;
				else {
					for (var i = 0; i < prevDeps.length && i < deps.length; i++) if (!objectIs(deps[i], prevDeps[i])) {
						prevDeps = !1;
						break a;
					}
					prevDeps = !0;
				}
				if (prevDeps) return prevState[0];
			}
		}
		nextCreate = nextCreate();
		workInProgressHook.memoizedState = [nextCreate, deps];
		return nextCreate;
	}
	function dispatchAction(componentIdentity, queue, action) {
		if (25 <= numberOfReRenders) throw Error("Too many re-renders. React limits the number of renders to prevent an infinite loop.");
		if (componentIdentity === currentlyRenderingComponent) if (didScheduleRenderPhaseUpdate = !0, componentIdentity = {
			action,
			next: null
		}, null === renderPhaseUpdates && (renderPhaseUpdates = /* @__PURE__ */ new Map()), action = renderPhaseUpdates.get(queue), void 0 === action) renderPhaseUpdates.set(queue, componentIdentity);
		else {
			for (queue = action; null !== queue.next;) queue = queue.next;
			queue.next = componentIdentity;
		}
	}
	function throwOnUseEffectEventCall() {
		throw Error("A function wrapped in useEffectEvent can't be called during rendering.");
	}
	function unsupportedStartTransition() {
		throw Error("startTransition cannot be called during server rendering.");
	}
	function unsupportedSetOptimisticState() {
		throw Error("Cannot update optimistic state while rendering.");
	}
	function useActionState(action, initialState, permalink) {
		resolveCurrentlyRenderingComponent();
		var actionStateHookIndex = actionStateCounter++, request = currentlyRenderingRequest;
		if ("function" === typeof action.$$FORM_ACTION) {
			var nextPostbackStateKey = null, componentKeyPath = currentlyRenderingKeyPath;
			request = request.formState;
			var isSignatureEqual = action.$$IS_SIGNATURE_EQUAL;
			if (null !== request && "function" === typeof isSignatureEqual) {
				var postbackKey = request[1];
				isSignatureEqual.call(action, request[2], request[3]) && (nextPostbackStateKey = void 0 !== permalink ? "p" + permalink : "k" + murmurhash3_32_gc(JSON.stringify([
					componentKeyPath,
					null,
					actionStateHookIndex
				]), 0), postbackKey === nextPostbackStateKey && (actionStateMatchingIndex = actionStateHookIndex, initialState = request[0]));
			}
			var boundAction = action.bind(null, initialState);
			action = function(payload) {
				boundAction(payload);
			};
			"function" === typeof boundAction.$$FORM_ACTION && (action.$$FORM_ACTION = function(prefix) {
				prefix = boundAction.$$FORM_ACTION(prefix);
				void 0 !== permalink && (permalink += "", prefix.action = permalink);
				var formData = prefix.data;
				formData && (null === nextPostbackStateKey && (nextPostbackStateKey = void 0 !== permalink ? "p" + permalink : "k" + murmurhash3_32_gc(JSON.stringify([
					componentKeyPath,
					null,
					actionStateHookIndex
				]), 0)), formData.append("$ACTION_KEY", nextPostbackStateKey));
				return prefix;
			});
			return [
				initialState,
				action,
				!1
			];
		}
		var boundAction$22 = action.bind(null, initialState);
		return [
			initialState,
			function(payload) {
				boundAction$22(payload);
			},
			!1
		];
	}
	function unwrapThenable(thenable) {
		var index = thenableIndexCounter;
		thenableIndexCounter += 1;
		null === thenableState && (thenableState = []);
		return trackUsedThenable(thenableState, thenable, index);
	}
	function unsupportedRefresh() {
		throw Error("Cache cannot be refreshed during server rendering.");
	}
	var HooksDispatcher = {
		readContext: function(context) {
			return context._currentValue;
		},
		use: function(usable) {
			if (null !== usable && "object" === typeof usable) {
				if ("function" === typeof usable.then) return unwrapThenable(usable);
				if (usable.$$typeof === REACT_CONTEXT_TYPE) return usable._currentValue;
			}
			throw Error("An unsupported type was passed to use(): " + String(usable));
		},
		useContext: function(context) {
			resolveCurrentlyRenderingComponent();
			return context._currentValue;
		},
		useMemo,
		useReducer,
		useRef: function(initialValue) {
			currentlyRenderingComponent = resolveCurrentlyRenderingComponent();
			workInProgressHook = createWorkInProgressHook();
			var previousRef = workInProgressHook.memoizedState;
			return null === previousRef ? (initialValue = { current: initialValue }, workInProgressHook.memoizedState = initialValue) : previousRef;
		},
		useState: function(initialState) {
			return useReducer(basicStateReducer, initialState);
		},
		useInsertionEffect: noop,
		useLayoutEffect: noop,
		useCallback: function(callback, deps) {
			return useMemo(function() {
				return callback;
			}, deps);
		},
		useImperativeHandle: noop,
		useEffect: noop,
		useDebugValue: noop,
		useDeferredValue: function(value, initialValue) {
			resolveCurrentlyRenderingComponent();
			return void 0 !== initialValue ? initialValue : value;
		},
		useTransition: function() {
			resolveCurrentlyRenderingComponent();
			return [!1, unsupportedStartTransition];
		},
		useId: function() {
			var JSCompiler_inline_result = currentlyRenderingTask.treeContext;
			var overflow = JSCompiler_inline_result.overflow;
			JSCompiler_inline_result = JSCompiler_inline_result.id;
			JSCompiler_inline_result = (JSCompiler_inline_result & ~(1 << 32 - clz32(JSCompiler_inline_result) - 1)).toString(32) + overflow;
			var resumableState = currentResumableState;
			if (null === resumableState) throw Error("Invalid hook call. Hooks can only be called inside of the body of a function component.");
			overflow = localIdCounter++;
			JSCompiler_inline_result = "_" + resumableState.idPrefix + "R_" + JSCompiler_inline_result;
			0 < overflow && (JSCompiler_inline_result += "H" + overflow.toString(32));
			return JSCompiler_inline_result + "_";
		},
		useSyncExternalStore: function(subscribe, getSnapshot, getServerSnapshot) {
			if (void 0 === getServerSnapshot) throw Error("Missing getServerSnapshot, which is required for server-rendered content. Will revert to client rendering.");
			return getServerSnapshot();
		},
		useOptimistic: function(passthrough) {
			resolveCurrentlyRenderingComponent();
			return [passthrough, unsupportedSetOptimisticState];
		},
		useActionState,
		useFormState: useActionState,
		useHostTransitionStatus: function() {
			resolveCurrentlyRenderingComponent();
			return sharedNotPendingObject;
		},
		useMemoCache: function(size) {
			for (var data = Array(size), i = 0; i < size; i++) data[i] = REACT_MEMO_CACHE_SENTINEL;
			return data;
		},
		useCacheRefresh: function() {
			return unsupportedRefresh;
		},
		useEffectEvent: function() {
			return throwOnUseEffectEventCall;
		}
	}, currentResumableState = null, DefaultAsyncDispatcher = {
		getCacheForType: function() {
			throw Error("Not implemented.");
		},
		cacheSignal: function() {
			throw Error("Not implemented.");
		}
	};
	function prepareStackTrace(error, structuredStackTrace) {
		error = (error.name || "Error") + ": " + (error.message || "");
		for (var i = 0; i < structuredStackTrace.length; i++) error += "\n    at " + structuredStackTrace[i].toString();
		return error;
	}
	var prefix, suffix;
	function describeBuiltInComponentFrame(name) {
		if (void 0 === prefix) try {
			throw Error();
		} catch (x) {
			var match = x.stack.trim().match(/\n( *(at )?)/);
			prefix = match && match[1] || "";
			suffix = -1 < x.stack.indexOf("\n    at") ? " (<anonymous>)" : -1 < x.stack.indexOf("@") ? "@unknown:0:0" : "";
		}
		return "\n" + prefix + name + suffix;
	}
	var reentry = !1;
	function describeNativeComponentFrame(fn, construct) {
		if (!fn || reentry) return "";
		reentry = !0;
		var previousPrepareStackTrace = Error.prepareStackTrace;
		Error.prepareStackTrace = prepareStackTrace;
		try {
			var RunInRootFrame = { DetermineComponentFrameRoot: function() {
				try {
					if (construct) {
						var Fake = function() {
							throw Error();
						};
						Object.defineProperty(Fake.prototype, "props", { set: function() {
							throw Error();
						} });
						if ("object" === typeof Reflect && Reflect.construct) {
							try {
								Reflect.construct(Fake, []);
							} catch (x) {
								var control = x;
							}
							Reflect.construct(fn, [], Fake);
						} else {
							try {
								Fake.call();
							} catch (x$24) {
								control = x$24;
							}
							fn.call(Fake.prototype);
						}
					} else {
						try {
							throw Error();
						} catch (x$25) {
							control = x$25;
						}
						(Fake = fn()) && "function" === typeof Fake.catch && Fake.catch(function() {});
					}
				} catch (sample) {
					if (sample && control && "string" === typeof sample.stack) return [sample.stack, control.stack];
				}
				return [null, null];
			} };
			RunInRootFrame.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
			var namePropDescriptor = Object.getOwnPropertyDescriptor(RunInRootFrame.DetermineComponentFrameRoot, "name");
			namePropDescriptor && namePropDescriptor.configurable && Object.defineProperty(RunInRootFrame.DetermineComponentFrameRoot, "name", { value: "DetermineComponentFrameRoot" });
			var _RunInRootFrame$Deter = RunInRootFrame.DetermineComponentFrameRoot(), sampleStack = _RunInRootFrame$Deter[0], controlStack = _RunInRootFrame$Deter[1];
			if (sampleStack && controlStack) {
				var sampleLines = sampleStack.split("\n"), controlLines = controlStack.split("\n");
				for (namePropDescriptor = RunInRootFrame = 0; RunInRootFrame < sampleLines.length && !sampleLines[RunInRootFrame].includes("DetermineComponentFrameRoot");) RunInRootFrame++;
				for (; namePropDescriptor < controlLines.length && !controlLines[namePropDescriptor].includes("DetermineComponentFrameRoot");) namePropDescriptor++;
				if (RunInRootFrame === sampleLines.length || namePropDescriptor === controlLines.length) for (RunInRootFrame = sampleLines.length - 1, namePropDescriptor = controlLines.length - 1; 1 <= RunInRootFrame && 0 <= namePropDescriptor && sampleLines[RunInRootFrame] !== controlLines[namePropDescriptor];) namePropDescriptor--;
				for (; 1 <= RunInRootFrame && 0 <= namePropDescriptor; RunInRootFrame--, namePropDescriptor--) if (sampleLines[RunInRootFrame] !== controlLines[namePropDescriptor]) {
					if (1 !== RunInRootFrame || 1 !== namePropDescriptor) do
						if (RunInRootFrame--, namePropDescriptor--, 0 > namePropDescriptor || sampleLines[RunInRootFrame] !== controlLines[namePropDescriptor]) {
							var frame = "\n" + sampleLines[RunInRootFrame].replace(" at new ", " at ");
							fn.displayName && frame.includes("<anonymous>") && (frame = frame.replace("<anonymous>", fn.displayName));
							return frame;
						}
					while (1 <= RunInRootFrame && 0 <= namePropDescriptor);
					break;
				}
			}
		} finally {
			reentry = !1, Error.prepareStackTrace = previousPrepareStackTrace;
		}
		return (previousPrepareStackTrace = fn ? fn.displayName || fn.name : "") ? describeBuiltInComponentFrame(previousPrepareStackTrace) : "";
	}
	function describeComponentStackByType(type) {
		if ("string" === typeof type) return describeBuiltInComponentFrame(type);
		if ("function" === typeof type) return type.prototype && type.prototype.isReactComponent ? describeNativeComponentFrame(type, !0) : describeNativeComponentFrame(type, !1);
		if ("object" === typeof type && null !== type) {
			switch (type.$$typeof) {
				case REACT_FORWARD_REF_TYPE: return describeNativeComponentFrame(type.render, !1);
				case REACT_MEMO_TYPE: return describeNativeComponentFrame(type.type, !1);
				case REACT_LAZY_TYPE:
					var lazyComponent = type, payload = lazyComponent._payload;
					lazyComponent = lazyComponent._init;
					try {
						type = lazyComponent(payload);
					} catch (x) {
						return describeBuiltInComponentFrame("Lazy");
					}
					return describeComponentStackByType(type);
			}
			if ("string" === typeof type.name) {
				a: {
					payload = type.name;
					lazyComponent = type.env;
					var location = type.debugLocation;
					if (null != location && (type = Error.prepareStackTrace, Error.prepareStackTrace = prepareStackTrace, location = location.stack, Error.prepareStackTrace = type, location.startsWith("Error: react-stack-top-frame\n") && (location = location.slice(29)), type = location.indexOf("\n"), -1 !== type && (location = location.slice(type + 1)), type = location.indexOf("react_stack_bottom_frame"), -1 !== type && (type = location.lastIndexOf("\n", type)), type = -1 !== type ? location = location.slice(0, type) : "", location = type.lastIndexOf("\n"), type = -1 === location ? type : type.slice(location + 1), -1 !== type.indexOf(payload))) {
						payload = "\n" + type;
						break a;
					}
					payload = describeBuiltInComponentFrame(payload + (lazyComponent ? " [" + lazyComponent + "]" : ""));
				}
				return payload;
			}
		}
		switch (type) {
			case REACT_SUSPENSE_LIST_TYPE: return describeBuiltInComponentFrame("SuspenseList");
			case REACT_SUSPENSE_TYPE: return describeBuiltInComponentFrame("Suspense");
		}
		return "";
	}
	function isEligibleForOutlining(request, boundary) {
		return (500 < boundary.byteSize || hasSuspenseyContent(boundary.contentState)) && null === boundary.contentPreamble;
	}
	function defaultErrorHandler(error) {
		if ("object" === typeof error && null !== error && "string" === typeof error.environmentName) {
			var JSCompiler_inline_result = error.environmentName;
			error = [error].slice(0);
			"string" === typeof error[0] ? error.splice(0, 1, "\x1B[0m\x1B[7m%c%s\x1B[0m%c " + error[0], "background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px", " " + JSCompiler_inline_result + " ", "") : error.splice(0, 0, "\x1B[0m\x1B[7m%c%s\x1B[0m%c", "background: #e6e6e6;background: light-dark(rgba(0,0,0,0.1), rgba(255,255,255,0.25));color: #000000;color: light-dark(#000000, #ffffff);border-radius: 2px", " " + JSCompiler_inline_result + " ", "");
			error.unshift(console);
			JSCompiler_inline_result = bind.apply(console.error, error);
			JSCompiler_inline_result();
		} else console.error(error);
		return null;
	}
	function RequestInstance(resumableState, renderState, rootFormatContext, progressiveChunkSize, onError, onAllReady, onShellReady, onShellError, onFatalError, onPostpone, formState) {
		var abortSet = /* @__PURE__ */ new Set();
		this.destination = null;
		this.flushScheduled = !1;
		this.resumableState = resumableState;
		this.renderState = renderState;
		this.rootFormatContext = rootFormatContext;
		this.progressiveChunkSize = void 0 === progressiveChunkSize ? 12800 : progressiveChunkSize;
		this.status = 10;
		this.fatalError = null;
		this.pendingRootTasks = this.allPendingTasks = this.nextSegmentId = 0;
		this.completedPreambleSegments = this.completedRootSegment = null;
		this.byteSize = 0;
		this.abortableTasks = abortSet;
		this.pingedTasks = [];
		this.clientRenderedBoundaries = [];
		this.completedBoundaries = [];
		this.partialBoundaries = [];
		this.trackedPostpones = null;
		this.onError = void 0 === onError ? defaultErrorHandler : onError;
		this.onPostpone = void 0 === onPostpone ? noop : onPostpone;
		this.onAllReady = void 0 === onAllReady ? noop : onAllReady;
		this.onShellReady = void 0 === onShellReady ? noop : onShellReady;
		this.onShellError = void 0 === onShellError ? noop : onShellError;
		this.onFatalError = void 0 === onFatalError ? noop : onFatalError;
		this.formState = void 0 === formState ? null : formState;
	}
	function createRequest(children, resumableState, renderState, rootFormatContext, progressiveChunkSize, onError, onAllReady, onShellReady, onShellError, onFatalError, onPostpone, formState) {
		resumableState = new RequestInstance(resumableState, renderState, rootFormatContext, progressiveChunkSize, onError, onAllReady, onShellReady, onShellError, onFatalError, onPostpone, formState);
		renderState = createPendingSegment(resumableState, 0, null, rootFormatContext, !1, !1);
		renderState.parentFlushed = !0;
		children = createRenderTask(resumableState, null, children, -1, null, renderState, null, null, resumableState.abortableTasks, null, rootFormatContext, null, emptyTreeContext, null, null);
		pushComponentStack(children);
		resumableState.pingedTasks.push(children);
		return resumableState;
	}
	function createPrerenderRequest(children, resumableState, renderState, rootFormatContext, progressiveChunkSize, onError, onAllReady, onShellReady, onShellError, onFatalError, onPostpone) {
		children = createRequest(children, resumableState, renderState, rootFormatContext, progressiveChunkSize, onError, onAllReady, onShellReady, onShellError, onFatalError, onPostpone, void 0);
		children.trackedPostpones = {
			workingMap: /* @__PURE__ */ new Map(),
			rootNodes: [],
			rootSlots: null
		};
		return children;
	}
	function resumeRequest(children, postponedState, renderState, onError, onAllReady, onShellReady, onShellError, onFatalError, onPostpone) {
		renderState = new RequestInstance(postponedState.resumableState, renderState, postponedState.rootFormatContext, postponedState.progressiveChunkSize, onError, onAllReady, onShellReady, onShellError, onFatalError, onPostpone, null);
		renderState.nextSegmentId = postponedState.nextSegmentId;
		if ("number" === typeof postponedState.replaySlots) return onError = createPendingSegment(renderState, 0, null, postponedState.rootFormatContext, !1, !1), onError.parentFlushed = !0, children = createRenderTask(renderState, null, children, -1, null, onError, null, null, renderState.abortableTasks, null, postponedState.rootFormatContext, null, emptyTreeContext, null, null), pushComponentStack(children), renderState.pingedTasks.push(children), renderState;
		children = createReplayTask(renderState, null, {
			nodes: postponedState.replayNodes,
			slots: postponedState.replaySlots,
			pendingTasks: 0
		}, children, -1, null, null, renderState.abortableTasks, null, postponedState.rootFormatContext, null, emptyTreeContext, null, null);
		pushComponentStack(children);
		renderState.pingedTasks.push(children);
		return renderState;
	}
	function resumeAndPrerenderRequest(children, postponedState, renderState, onError, onAllReady, onShellReady, onShellError, onFatalError, onPostpone) {
		children = resumeRequest(children, postponedState, renderState, onError, onAllReady, onShellReady, onShellError, onFatalError, onPostpone);
		children.trackedPostpones = {
			workingMap: /* @__PURE__ */ new Map(),
			rootNodes: [],
			rootSlots: null
		};
		return children;
	}
	var currentRequest = null;
	function resolveRequest() {
		if (currentRequest) return currentRequest;
		if (supportsRequestStorage) {
			var store = requestStorage.getStore();
			if (store) return store;
		}
		return null;
	}
	function pingTask(request, task) {
		request.pingedTasks.push(task);
		1 === request.pingedTasks.length && (request.flushScheduled = null !== request.destination, null !== request.trackedPostpones || 10 === request.status ? scheduleMicrotask(function() {
			return performWork(request);
		}) : setTimeout(function() {
			return performWork(request);
		}, 0));
	}
	function createSuspenseBoundary(request, row, fallbackAbortableTasks, contentPreamble, fallbackPreamble) {
		fallbackAbortableTasks = {
			status: 0,
			rootSegmentID: -1,
			parentFlushed: !1,
			pendingTasks: 0,
			row,
			completedSegments: [],
			byteSize: 0,
			fallbackAbortableTasks,
			errorDigest: null,
			contentState: createHoistableState(),
			fallbackState: createHoistableState(),
			contentPreamble,
			fallbackPreamble,
			trackedContentKeyPath: null,
			trackedFallbackNode: null
		};
		null !== row && (row.pendingTasks++, contentPreamble = row.boundaries, null !== contentPreamble && (request.allPendingTasks++, fallbackAbortableTasks.pendingTasks++, contentPreamble.push(fallbackAbortableTasks)), request = row.inheritedHoistables, null !== request && hoistHoistables(fallbackAbortableTasks.contentState, request));
		return fallbackAbortableTasks;
	}
	function createRenderTask(request, thenableState, node, childIndex, blockedBoundary, blockedSegment, blockedPreamble, hoistableState, abortSet, keyPath, formatContext, context, treeContext, row, componentStack) {
		request.allPendingTasks++;
		null === blockedBoundary ? request.pendingRootTasks++ : blockedBoundary.pendingTasks++;
		null !== row && row.pendingTasks++;
		var task = {
			replay: null,
			node,
			childIndex,
			ping: function() {
				return pingTask(request, task);
			},
			blockedBoundary,
			blockedSegment,
			blockedPreamble,
			hoistableState,
			abortSet,
			keyPath,
			formatContext,
			context,
			treeContext,
			row,
			componentStack,
			thenableState
		};
		abortSet.add(task);
		return task;
	}
	function createReplayTask(request, thenableState, replay, node, childIndex, blockedBoundary, hoistableState, abortSet, keyPath, formatContext, context, treeContext, row, componentStack) {
		request.allPendingTasks++;
		null === blockedBoundary ? request.pendingRootTasks++ : blockedBoundary.pendingTasks++;
		null !== row && row.pendingTasks++;
		replay.pendingTasks++;
		var task = {
			replay,
			node,
			childIndex,
			ping: function() {
				return pingTask(request, task);
			},
			blockedBoundary,
			blockedSegment: null,
			blockedPreamble: null,
			hoistableState,
			abortSet,
			keyPath,
			formatContext,
			context,
			treeContext,
			row,
			componentStack,
			thenableState
		};
		abortSet.add(task);
		return task;
	}
	function createPendingSegment(request, index, boundary, parentFormatContext, lastPushedText, textEmbedded) {
		return {
			status: 0,
			parentFlushed: !1,
			id: -1,
			index,
			chunks: [],
			children: [],
			preambleChildren: [],
			parentFormatContext,
			boundary,
			lastPushedText,
			textEmbedded
		};
	}
	function pushComponentStack(task) {
		var node = task.node;
		if ("object" === typeof node && null !== node) switch (node.$$typeof) {
			case REACT_ELEMENT_TYPE: task.componentStack = {
				parent: task.componentStack,
				type: node.type
			};
		}
	}
	function replaceSuspenseComponentStackWithSuspenseFallbackStack(componentStack) {
		return null === componentStack ? null : {
			parent: componentStack.parent,
			type: "Suspense Fallback"
		};
	}
	function getThrownInfo(node$jscomp$0) {
		var errorInfo = {};
		node$jscomp$0 && Object.defineProperty(errorInfo, "componentStack", {
			configurable: !0,
			enumerable: !0,
			get: function() {
				try {
					var info = "", node = node$jscomp$0;
					do
						info += describeComponentStackByType(node.type), node = node.parent;
					while (node);
					var JSCompiler_inline_result = info;
				} catch (x) {
					JSCompiler_inline_result = "\nError generating stack: " + x.message + "\n" + x.stack;
				}
				Object.defineProperty(errorInfo, "componentStack", { value: JSCompiler_inline_result });
				return JSCompiler_inline_result;
			}
		});
		return errorInfo;
	}
	function logRecoverableError(request, error, errorInfo) {
		request = request.onError;
		error = request(error, errorInfo);
		if (null == error || "string" === typeof error) return error;
	}
	function fatalError(request, error) {
		var onShellError = request.onShellError, onFatalError = request.onFatalError;
		onShellError(error);
		onFatalError(error);
		null !== request.destination ? (request.status = 14, closeWithError(request.destination, error)) : (request.status = 13, request.fatalError = error);
	}
	function finishSuspenseListRow(request, row) {
		unblockSuspenseListRow(request, row.next, row.hoistables);
	}
	function unblockSuspenseListRow(request, unblockedRow, inheritedHoistables) {
		for (; null !== unblockedRow;) {
			null !== inheritedHoistables && (hoistHoistables(unblockedRow.hoistables, inheritedHoistables), unblockedRow.inheritedHoistables = inheritedHoistables);
			var unblockedBoundaries = unblockedRow.boundaries;
			if (null !== unblockedBoundaries) {
				unblockedRow.boundaries = null;
				for (var i = 0; i < unblockedBoundaries.length; i++) {
					var unblockedBoundary = unblockedBoundaries[i];
					null !== inheritedHoistables && hoistHoistables(unblockedBoundary.contentState, inheritedHoistables);
					finishedTask(request, unblockedBoundary, null, null);
				}
			}
			unblockedRow.pendingTasks--;
			if (0 < unblockedRow.pendingTasks) break;
			inheritedHoistables = unblockedRow.hoistables;
			unblockedRow = unblockedRow.next;
		}
	}
	function tryToResolveTogetherRow(request, togetherRow) {
		var boundaries = togetherRow.boundaries;
		if (null !== boundaries && togetherRow.pendingTasks === boundaries.length) {
			for (var allCompleteAndInlinable = !0, i = 0; i < boundaries.length; i++) {
				var rowBoundary = boundaries[i];
				if (1 !== rowBoundary.pendingTasks || rowBoundary.parentFlushed || isEligibleForOutlining(request, rowBoundary)) {
					allCompleteAndInlinable = !1;
					break;
				}
			}
			allCompleteAndInlinable && unblockSuspenseListRow(request, togetherRow, togetherRow.hoistables);
		}
	}
	function createSuspenseListRow(previousRow) {
		var newRow = {
			pendingTasks: 1,
			boundaries: null,
			hoistables: createHoistableState(),
			inheritedHoistables: null,
			together: !1,
			next: null
		};
		null !== previousRow && 0 < previousRow.pendingTasks && (newRow.pendingTasks++, newRow.boundaries = [], previousRow.next = newRow);
		return newRow;
	}
	function renderSuspenseListRows(request, task, keyPath, rows, revealOrder) {
		var prevKeyPath = task.keyPath, prevTreeContext = task.treeContext, prevRow = task.row;
		task.keyPath = keyPath;
		keyPath = rows.length;
		var previousSuspenseListRow = null;
		if (null !== task.replay) {
			var resumeSlots = task.replay.slots;
			if (null !== resumeSlots && "object" === typeof resumeSlots) for (var n = 0; n < keyPath; n++) {
				var i = "backwards" !== revealOrder && "unstable_legacy-backwards" !== revealOrder ? n : keyPath - 1 - n, node = rows[i];
				task.row = previousSuspenseListRow = createSuspenseListRow(previousSuspenseListRow);
				task.treeContext = pushTreeContext(prevTreeContext, keyPath, i);
				var resumeSegmentID = resumeSlots[i];
				"number" === typeof resumeSegmentID ? (resumeNode(request, task, resumeSegmentID, node, i), delete resumeSlots[i]) : renderNode(request, task, node, i);
				0 === --previousSuspenseListRow.pendingTasks && finishSuspenseListRow(request, previousSuspenseListRow);
			}
			else for (resumeSlots = 0; resumeSlots < keyPath; resumeSlots++) n = "backwards" !== revealOrder && "unstable_legacy-backwards" !== revealOrder ? resumeSlots : keyPath - 1 - resumeSlots, i = rows[n], task.row = previousSuspenseListRow = createSuspenseListRow(previousSuspenseListRow), task.treeContext = pushTreeContext(prevTreeContext, keyPath, n), renderNode(request, task, i, n), 0 === --previousSuspenseListRow.pendingTasks && finishSuspenseListRow(request, previousSuspenseListRow);
		} else if ("backwards" !== revealOrder && "unstable_legacy-backwards" !== revealOrder) for (revealOrder = 0; revealOrder < keyPath; revealOrder++) resumeSlots = rows[revealOrder], task.row = previousSuspenseListRow = createSuspenseListRow(previousSuspenseListRow), task.treeContext = pushTreeContext(prevTreeContext, keyPath, revealOrder), renderNode(request, task, resumeSlots, revealOrder), 0 === --previousSuspenseListRow.pendingTasks && finishSuspenseListRow(request, previousSuspenseListRow);
		else {
			revealOrder = task.blockedSegment;
			resumeSlots = revealOrder.children.length;
			n = revealOrder.chunks.length;
			for (i = keyPath - 1; 0 <= i; i--) {
				node = rows[i];
				task.row = previousSuspenseListRow = createSuspenseListRow(previousSuspenseListRow);
				task.treeContext = pushTreeContext(prevTreeContext, keyPath, i);
				resumeSegmentID = createPendingSegment(request, n, null, task.formatContext, 0 === i ? revealOrder.lastPushedText : !0, !0);
				revealOrder.children.splice(resumeSlots, 0, resumeSegmentID);
				task.blockedSegment = resumeSegmentID;
				try {
					renderNode(request, task, node, i), resumeSegmentID.lastPushedText && resumeSegmentID.textEmbedded && resumeSegmentID.chunks.push(textSeparator), resumeSegmentID.status = 1, finishedSegment(request, task.blockedBoundary, resumeSegmentID), 0 === --previousSuspenseListRow.pendingTasks && finishSuspenseListRow(request, previousSuspenseListRow);
				} catch (thrownValue) {
					throw resumeSegmentID.status = 12 === request.status ? 3 : 4, thrownValue;
				}
			}
			task.blockedSegment = revealOrder;
			revealOrder.lastPushedText = !1;
		}
		null !== prevRow && null !== previousSuspenseListRow && 0 < previousSuspenseListRow.pendingTasks && (prevRow.pendingTasks++, previousSuspenseListRow.next = prevRow);
		task.treeContext = prevTreeContext;
		task.row = prevRow;
		task.keyPath = prevKeyPath;
	}
	function renderWithHooks(request, task, keyPath, Component, props, secondArg) {
		var prevThenableState = task.thenableState;
		task.thenableState = null;
		currentlyRenderingComponent = {};
		currentlyRenderingTask = task;
		currentlyRenderingRequest = request;
		currentlyRenderingKeyPath = keyPath;
		actionStateCounter = localIdCounter = 0;
		actionStateMatchingIndex = -1;
		thenableIndexCounter = 0;
		thenableState = prevThenableState;
		for (request = Component(props, secondArg); didScheduleRenderPhaseUpdate;) didScheduleRenderPhaseUpdate = !1, actionStateCounter = localIdCounter = 0, actionStateMatchingIndex = -1, thenableIndexCounter = 0, numberOfReRenders += 1, workInProgressHook = null, request = Component(props, secondArg);
		resetHooksState();
		return request;
	}
	function finishFunctionComponent(request, task, keyPath, children, hasId, actionStateCount, actionStateMatchingIndex) {
		var didEmitActionStateMarkers = !1;
		if (0 !== actionStateCount && null !== request.formState) {
			var segment = task.blockedSegment;
			if (null !== segment) {
				didEmitActionStateMarkers = !0;
				segment = segment.chunks;
				for (var i = 0; i < actionStateCount; i++) i === actionStateMatchingIndex ? segment.push(formStateMarkerIsMatching) : segment.push(formStateMarkerIsNotMatching);
			}
		}
		actionStateCount = task.keyPath;
		task.keyPath = keyPath;
		hasId ? (keyPath = task.treeContext, task.treeContext = pushTreeContext(keyPath, 1, 0), renderNode(request, task, children, -1), task.treeContext = keyPath) : didEmitActionStateMarkers ? renderNode(request, task, children, -1) : renderNodeDestructive(request, task, children, -1);
		task.keyPath = actionStateCount;
	}
	function renderElement(request, task, keyPath, type, props, ref) {
		if ("function" === typeof type) if (type.prototype && type.prototype.isReactComponent) {
			var newProps = props;
			if ("ref" in props) {
				newProps = {};
				for (var propName in props) "ref" !== propName && (newProps[propName] = props[propName]);
			}
			var defaultProps = type.defaultProps;
			if (defaultProps) {
				newProps === props && (newProps = assign({}, newProps, props));
				for (var propName$44 in defaultProps) void 0 === newProps[propName$44] && (newProps[propName$44] = defaultProps[propName$44]);
			}
			props = newProps;
			newProps = emptyContextObject;
			defaultProps = type.contextType;
			"object" === typeof defaultProps && null !== defaultProps && (newProps = defaultProps._currentValue);
			newProps = new type(props, newProps);
			var initialState = void 0 !== newProps.state ? newProps.state : null;
			newProps.updater = classComponentUpdater;
			newProps.props = props;
			newProps.state = initialState;
			defaultProps = {
				queue: [],
				replace: !1
			};
			newProps._reactInternals = defaultProps;
			ref = type.contextType;
			newProps.context = "object" === typeof ref && null !== ref ? ref._currentValue : emptyContextObject;
			ref = type.getDerivedStateFromProps;
			"function" === typeof ref && (ref = ref(props, initialState), initialState = null === ref || void 0 === ref ? initialState : assign({}, initialState, ref), newProps.state = initialState);
			if ("function" !== typeof type.getDerivedStateFromProps && "function" !== typeof newProps.getSnapshotBeforeUpdate && ("function" === typeof newProps.UNSAFE_componentWillMount || "function" === typeof newProps.componentWillMount)) if (type = newProps.state, "function" === typeof newProps.componentWillMount && newProps.componentWillMount(), "function" === typeof newProps.UNSAFE_componentWillMount && newProps.UNSAFE_componentWillMount(), type !== newProps.state && classComponentUpdater.enqueueReplaceState(newProps, newProps.state, null), null !== defaultProps.queue && 0 < defaultProps.queue.length) if (type = defaultProps.queue, ref = defaultProps.replace, defaultProps.queue = null, defaultProps.replace = !1, ref && 1 === type.length) newProps.state = type[0];
			else {
				defaultProps = ref ? type[0] : newProps.state;
				initialState = !0;
				for (ref = ref ? 1 : 0; ref < type.length; ref++) propName$44 = type[ref], propName$44 = "function" === typeof propName$44 ? propName$44.call(newProps, defaultProps, props, void 0) : propName$44, null != propName$44 && (initialState ? (initialState = !1, defaultProps = assign({}, defaultProps, propName$44)) : assign(defaultProps, propName$44));
				newProps.state = defaultProps;
			}
			else defaultProps.queue = null;
			type = newProps.render();
			if (12 === request.status) throw null;
			props = task.keyPath;
			task.keyPath = keyPath;
			renderNodeDestructive(request, task, type, -1);
			task.keyPath = props;
		} else {
			type = renderWithHooks(request, task, keyPath, type, props, void 0);
			if (12 === request.status) throw null;
			finishFunctionComponent(request, task, keyPath, type, 0 !== localIdCounter, actionStateCounter, actionStateMatchingIndex);
		}
		else if ("string" === typeof type) if (newProps = task.blockedSegment, null === newProps) newProps = props.children, defaultProps = task.formatContext, initialState = task.keyPath, task.formatContext = getChildFormatContext(defaultProps, type, props), task.keyPath = keyPath, renderNode(request, task, newProps, -1), task.formatContext = defaultProps, task.keyPath = initialState;
		else {
			initialState = pushStartInstance(newProps.chunks, type, props, request.resumableState, request.renderState, task.blockedPreamble, task.hoistableState, task.formatContext, newProps.lastPushedText);
			newProps.lastPushedText = !1;
			defaultProps = task.formatContext;
			ref = task.keyPath;
			task.keyPath = keyPath;
			if (3 === (task.formatContext = getChildFormatContext(defaultProps, type, props)).insertionMode) {
				keyPath = createPendingSegment(request, 0, null, task.formatContext, !1, !1);
				newProps.preambleChildren.push(keyPath);
				task.blockedSegment = keyPath;
				try {
					keyPath.status = 6, renderNode(request, task, initialState, -1), keyPath.lastPushedText && keyPath.textEmbedded && keyPath.chunks.push(textSeparator), keyPath.status = 1, finishedSegment(request, task.blockedBoundary, keyPath);
				} finally {
					task.blockedSegment = newProps;
				}
			} else renderNode(request, task, initialState, -1);
			task.formatContext = defaultProps;
			task.keyPath = ref;
			a: {
				task = newProps.chunks;
				request = request.resumableState;
				switch (type) {
					case "title":
					case "style":
					case "script":
					case "area":
					case "base":
					case "br":
					case "col":
					case "embed":
					case "hr":
					case "img":
					case "input":
					case "keygen":
					case "link":
					case "meta":
					case "param":
					case "source":
					case "track":
					case "wbr": break a;
					case "body":
						if (1 >= defaultProps.insertionMode) {
							request.hasBody = !0;
							break a;
						}
						break;
					case "html":
						if (0 === defaultProps.insertionMode) {
							request.hasHtml = !0;
							break a;
						}
						break;
					case "head": if (1 >= defaultProps.insertionMode) break a;
				}
				task.push(endChunkForTag(type));
			}
			newProps.lastPushedText = !1;
		}
		else {
			switch (type) {
				case REACT_LEGACY_HIDDEN_TYPE:
				case REACT_STRICT_MODE_TYPE:
				case REACT_PROFILER_TYPE:
				case REACT_FRAGMENT_TYPE:
					type = task.keyPath;
					task.keyPath = keyPath;
					renderNodeDestructive(request, task, props.children, -1);
					task.keyPath = type;
					return;
				case REACT_ACTIVITY_TYPE:
					type = task.blockedSegment;
					null === type ? "hidden" !== props.mode && (type = task.keyPath, task.keyPath = keyPath, renderNode(request, task, props.children, -1), task.keyPath = type) : "hidden" !== props.mode && (type.chunks.push(startActivityBoundary), type.lastPushedText = !1, newProps = task.keyPath, task.keyPath = keyPath, renderNode(request, task, props.children, -1), task.keyPath = newProps, type.chunks.push(endActivityBoundary), type.lastPushedText = !1);
					return;
				case REACT_SUSPENSE_LIST_TYPE:
					a: {
						type = props.children;
						props = props.revealOrder;
						if ("forwards" === props || "backwards" === props || "unstable_legacy-backwards" === props) {
							if (isArrayImpl(type)) {
								renderSuspenseListRows(request, task, keyPath, type, props);
								break a;
							}
							if (newProps = getIteratorFn(type)) {
								if (newProps = newProps.call(type)) {
									defaultProps = newProps.next();
									if (!defaultProps.done) {
										do
											defaultProps = newProps.next();
										while (!defaultProps.done);
										renderSuspenseListRows(request, task, keyPath, type, props);
									}
									break a;
								}
							}
						}
						"together" === props ? (props = task.keyPath, newProps = task.row, defaultProps = task.row = createSuspenseListRow(null), defaultProps.boundaries = [], defaultProps.together = !0, task.keyPath = keyPath, renderNodeDestructive(request, task, type, -1), 0 === --defaultProps.pendingTasks && finishSuspenseListRow(request, defaultProps), task.keyPath = props, task.row = newProps, null !== newProps && 0 < defaultProps.pendingTasks && (newProps.pendingTasks++, defaultProps.next = newProps)) : (props = task.keyPath, task.keyPath = keyPath, renderNodeDestructive(request, task, type, -1), task.keyPath = props);
					}
					return;
				case REACT_VIEW_TRANSITION_TYPE:
				case REACT_SCOPE_TYPE: throw Error("ReactDOMServer does not yet support scope components.");
				case REACT_SUSPENSE_TYPE:
					a: if (null !== task.replay) {
						type = task.keyPath;
						newProps = task.formatContext;
						defaultProps = task.row;
						task.keyPath = keyPath;
						task.formatContext = getSuspenseContentFormatContext(request.resumableState, newProps);
						task.row = null;
						keyPath = props.children;
						try {
							renderNode(request, task, keyPath, -1);
						} finally {
							task.keyPath = type, task.formatContext = newProps, task.row = defaultProps;
						}
					} else {
						type = task.keyPath;
						ref = task.formatContext;
						var prevRow = task.row;
						propName$44 = task.blockedBoundary;
						propName = task.blockedPreamble;
						var parentHoistableState = task.hoistableState, parentSegment = task.blockedSegment, fallback = props.fallback;
						props = props.children;
						var fallbackAbortSet = /* @__PURE__ */ new Set();
						var newBoundary = 2 > task.formatContext.insertionMode ? createSuspenseBoundary(request, task.row, fallbackAbortSet, createPreambleState(), createPreambleState()) : createSuspenseBoundary(request, task.row, fallbackAbortSet, null, null);
						null !== request.trackedPostpones && (newBoundary.trackedContentKeyPath = keyPath);
						var boundarySegment = createPendingSegment(request, parentSegment.chunks.length, newBoundary, task.formatContext, !1, !1);
						parentSegment.children.push(boundarySegment);
						parentSegment.lastPushedText = !1;
						var contentRootSegment = createPendingSegment(request, 0, null, task.formatContext, !1, !1);
						contentRootSegment.parentFlushed = !0;
						if (null !== request.trackedPostpones) {
							newProps = task.componentStack;
							defaultProps = [
								keyPath[0],
								"Suspense Fallback",
								keyPath[2]
							];
							initialState = [
								defaultProps[1],
								defaultProps[2],
								[],
								null
							];
							request.trackedPostpones.workingMap.set(defaultProps, initialState);
							newBoundary.trackedFallbackNode = initialState;
							task.blockedSegment = boundarySegment;
							task.blockedPreamble = newBoundary.fallbackPreamble;
							task.keyPath = defaultProps;
							task.formatContext = getSuspenseFallbackFormatContext(request.resumableState, ref);
							task.componentStack = replaceSuspenseComponentStackWithSuspenseFallbackStack(newProps);
							boundarySegment.status = 6;
							try {
								renderNode(request, task, fallback, -1), boundarySegment.lastPushedText && boundarySegment.textEmbedded && boundarySegment.chunks.push(textSeparator), boundarySegment.status = 1, finishedSegment(request, propName$44, boundarySegment);
							} catch (thrownValue) {
								throw boundarySegment.status = 12 === request.status ? 3 : 4, thrownValue;
							} finally {
								task.blockedSegment = parentSegment, task.blockedPreamble = propName, task.keyPath = type, task.formatContext = ref;
							}
							task = createRenderTask(request, null, props, -1, newBoundary, contentRootSegment, newBoundary.contentPreamble, newBoundary.contentState, task.abortSet, keyPath, getSuspenseContentFormatContext(request.resumableState, task.formatContext), task.context, task.treeContext, null, newProps);
							pushComponentStack(task);
							request.pingedTasks.push(task);
						} else {
							task.blockedBoundary = newBoundary;
							task.blockedPreamble = newBoundary.contentPreamble;
							task.hoistableState = newBoundary.contentState;
							task.blockedSegment = contentRootSegment;
							task.keyPath = keyPath;
							task.formatContext = getSuspenseContentFormatContext(request.resumableState, ref);
							task.row = null;
							contentRootSegment.status = 6;
							try {
								if (renderNode(request, task, props, -1), contentRootSegment.lastPushedText && contentRootSegment.textEmbedded && contentRootSegment.chunks.push(textSeparator), contentRootSegment.status = 1, finishedSegment(request, newBoundary, contentRootSegment), queueCompletedSegment(newBoundary, contentRootSegment), 0 === newBoundary.pendingTasks && 0 === newBoundary.status) {
									if (newBoundary.status = 1, !isEligibleForOutlining(request, newBoundary)) {
										null !== prevRow && 0 === --prevRow.pendingTasks && finishSuspenseListRow(request, prevRow);
										0 === request.pendingRootTasks && task.blockedPreamble && preparePreamble(request);
										break a;
									}
								} else null !== prevRow && prevRow.together && tryToResolveTogetherRow(request, prevRow);
							} catch (thrownValue$31) {
								newBoundary.status = 4, 12 === request.status ? (contentRootSegment.status = 3, newProps = request.fatalError) : (contentRootSegment.status = 4, newProps = thrownValue$31), defaultProps = getThrownInfo(task.componentStack), initialState = logRecoverableError(request, newProps, defaultProps), newBoundary.errorDigest = initialState, untrackBoundary(request, newBoundary);
							} finally {
								task.blockedBoundary = propName$44, task.blockedPreamble = propName, task.hoistableState = parentHoistableState, task.blockedSegment = parentSegment, task.keyPath = type, task.formatContext = ref, task.row = prevRow;
							}
							task = createRenderTask(request, null, fallback, -1, propName$44, boundarySegment, newBoundary.fallbackPreamble, newBoundary.fallbackState, fallbackAbortSet, [
								keyPath[0],
								"Suspense Fallback",
								keyPath[2]
							], getSuspenseFallbackFormatContext(request.resumableState, task.formatContext), task.context, task.treeContext, task.row, replaceSuspenseComponentStackWithSuspenseFallbackStack(task.componentStack));
							pushComponentStack(task);
							request.pingedTasks.push(task);
						}
					}
					return;
			}
			if ("object" === typeof type && null !== type) switch (type.$$typeof) {
				case REACT_FORWARD_REF_TYPE:
					if ("ref" in props) for (parentSegment in newProps = {}, props) "ref" !== parentSegment && (newProps[parentSegment] = props[parentSegment]);
					else newProps = props;
					type = renderWithHooks(request, task, keyPath, type.render, newProps, ref);
					finishFunctionComponent(request, task, keyPath, type, 0 !== localIdCounter, actionStateCounter, actionStateMatchingIndex);
					return;
				case REACT_MEMO_TYPE:
					renderElement(request, task, keyPath, type.type, props, ref);
					return;
				case REACT_CONTEXT_TYPE:
					defaultProps = props.children;
					newProps = task.keyPath;
					props = props.value;
					initialState = type._currentValue;
					type._currentValue = props;
					ref = currentActiveSnapshot;
					currentActiveSnapshot = type = {
						parent: ref,
						depth: null === ref ? 0 : ref.depth + 1,
						context: type,
						parentValue: initialState,
						value: props
					};
					task.context = type;
					task.keyPath = keyPath;
					renderNodeDestructive(request, task, defaultProps, -1);
					request = currentActiveSnapshot;
					if (null === request) throw Error("Tried to pop a Context at the root of the app. This is a bug in React.");
					request.context._currentValue = request.parentValue;
					request = currentActiveSnapshot = request.parent;
					task.context = request;
					task.keyPath = newProps;
					return;
				case REACT_CONSUMER_TYPE:
					props = props.children;
					type = props(type._context._currentValue);
					props = task.keyPath;
					task.keyPath = keyPath;
					renderNodeDestructive(request, task, type, -1);
					task.keyPath = props;
					return;
				case REACT_LAZY_TYPE:
					newProps = type._init;
					type = newProps(type._payload);
					if (12 === request.status) throw null;
					renderElement(request, task, keyPath, type, props, ref);
					return;
			}
			throw Error("Element type is invalid: expected a string (for built-in components) or a class/function (for composite components) but got: " + ((null == type ? type : typeof type) + "."));
		}
	}
	function resumeNode(request, task, segmentId, node, childIndex) {
		var prevReplay = task.replay, blockedBoundary = task.blockedBoundary, resumedSegment = createPendingSegment(request, 0, null, task.formatContext, !1, !1);
		resumedSegment.id = segmentId;
		resumedSegment.parentFlushed = !0;
		try {
			task.replay = null, task.blockedSegment = resumedSegment, renderNode(request, task, node, childIndex), resumedSegment.status = 1, finishedSegment(request, blockedBoundary, resumedSegment), null === blockedBoundary ? request.completedRootSegment = resumedSegment : (queueCompletedSegment(blockedBoundary, resumedSegment), blockedBoundary.parentFlushed && request.partialBoundaries.push(blockedBoundary));
		} finally {
			task.replay = prevReplay, task.blockedSegment = null;
		}
	}
	function renderNodeDestructive(request, task, node, childIndex) {
		null !== task.replay && "number" === typeof task.replay.slots ? resumeNode(request, task, task.replay.slots, node, childIndex) : (task.node = node, task.childIndex = childIndex, node = task.componentStack, pushComponentStack(task), retryNode(request, task), task.componentStack = node);
	}
	function retryNode(request, task) {
		var node = task.node, childIndex = task.childIndex;
		if (null !== node) {
			if ("object" === typeof node) {
				switch (node.$$typeof) {
					case REACT_ELEMENT_TYPE:
						var type = node.type, key = node.key, props = node.props;
						node = props.ref;
						var ref = void 0 !== node ? node : null, name = getComponentNameFromType(type), keyOrIndex = null == key ? -1 === childIndex ? 0 : childIndex : key;
						key = [
							task.keyPath,
							name,
							keyOrIndex
						];
						if (null !== task.replay) a: {
							var replay = task.replay;
							childIndex = replay.nodes;
							for (node = 0; node < childIndex.length; node++) {
								var node$jscomp$0 = childIndex[node];
								if (keyOrIndex === node$jscomp$0[1]) {
									if (4 === node$jscomp$0.length) {
										if (null !== name && name !== node$jscomp$0[0]) throw Error("Expected the resume to render <" + node$jscomp$0[0] + "> in this slot but instead it rendered <" + name + ">. The tree doesn't match so React will fallback to client rendering.");
										var childNodes = node$jscomp$0[2];
										name = node$jscomp$0[3];
										keyOrIndex = task.node;
										task.replay = {
											nodes: childNodes,
											slots: name,
											pendingTasks: 1
										};
										try {
											renderElement(request, task, key, type, props, ref);
											if (1 === task.replay.pendingTasks && 0 < task.replay.nodes.length) throw Error("Couldn't find all resumable slots by key/index during replaying. The tree doesn't match so React will fallback to client rendering.");
											task.replay.pendingTasks--;
										} catch (x) {
											if ("object" === typeof x && null !== x && (x === SuspenseException || "function" === typeof x.then)) throw task.node === keyOrIndex ? task.replay = replay : childIndex.splice(node, 1), x;
											task.replay.pendingTasks--;
											props = getThrownInfo(task.componentStack);
											key = request;
											request = task.blockedBoundary;
											type = x;
											props = logRecoverableError(key, type, props);
											abortRemainingReplayNodes(key, request, childNodes, name, type, props);
										}
										task.replay = replay;
									} else {
										if (type !== REACT_SUSPENSE_TYPE) throw Error("Expected the resume to render <Suspense> in this slot but instead it rendered <" + (getComponentNameFromType(type) || "Unknown") + ">. The tree doesn't match so React will fallback to client rendering.");
										b: {
											replay = void 0;
											type = node$jscomp$0[5];
											ref = node$jscomp$0[2];
											name = node$jscomp$0[3];
											keyOrIndex = null === node$jscomp$0[4] ? [] : node$jscomp$0[4][2];
											node$jscomp$0 = null === node$jscomp$0[4] ? null : node$jscomp$0[4][3];
											var prevKeyPath = task.keyPath, prevContext = task.formatContext, prevRow = task.row, previousReplaySet = task.replay, parentBoundary = task.blockedBoundary, parentHoistableState = task.hoistableState, content = props.children, fallback = props.fallback, fallbackAbortSet = /* @__PURE__ */ new Set();
											props = 2 > task.formatContext.insertionMode ? createSuspenseBoundary(request, task.row, fallbackAbortSet, createPreambleState(), createPreambleState()) : createSuspenseBoundary(request, task.row, fallbackAbortSet, null, null);
											props.parentFlushed = !0;
											props.rootSegmentID = type;
											task.blockedBoundary = props;
											task.hoistableState = props.contentState;
											task.keyPath = key;
											task.formatContext = getSuspenseContentFormatContext(request.resumableState, prevContext);
											task.row = null;
											task.replay = {
												nodes: ref,
												slots: name,
												pendingTasks: 1
											};
											try {
												renderNode(request, task, content, -1);
												if (1 === task.replay.pendingTasks && 0 < task.replay.nodes.length) throw Error("Couldn't find all resumable slots by key/index during replaying. The tree doesn't match so React will fallback to client rendering.");
												task.replay.pendingTasks--;
												if (0 === props.pendingTasks && 0 === props.status) {
													props.status = 1;
													request.completedBoundaries.push(props);
													break b;
												}
											} catch (error) {
												props.status = 4, childNodes = getThrownInfo(task.componentStack), replay = logRecoverableError(request, error, childNodes), props.errorDigest = replay, task.replay.pendingTasks--, request.clientRenderedBoundaries.push(props);
											} finally {
												task.blockedBoundary = parentBoundary, task.hoistableState = parentHoistableState, task.replay = previousReplaySet, task.keyPath = prevKeyPath, task.formatContext = prevContext, task.row = prevRow;
											}
											childNodes = createReplayTask(request, null, {
												nodes: keyOrIndex,
												slots: node$jscomp$0,
												pendingTasks: 0
											}, fallback, -1, parentBoundary, props.fallbackState, fallbackAbortSet, [
												key[0],
												"Suspense Fallback",
												key[2]
											], getSuspenseFallbackFormatContext(request.resumableState, task.formatContext), task.context, task.treeContext, task.row, replaceSuspenseComponentStackWithSuspenseFallbackStack(task.componentStack));
											pushComponentStack(childNodes);
											request.pingedTasks.push(childNodes);
										}
									}
									childIndex.splice(node, 1);
									break a;
								}
							}
						}
						else renderElement(request, task, key, type, props, ref);
						return;
					case REACT_PORTAL_TYPE: throw Error("Portals are not currently supported by the server renderer. Render them conditionally so that they only appear on the client render.");
					case REACT_LAZY_TYPE:
						childNodes = node._init;
						node = childNodes(node._payload);
						if (12 === request.status) throw null;
						renderNodeDestructive(request, task, node, childIndex);
						return;
				}
				if (isArrayImpl(node)) {
					renderChildrenArray(request, task, node, childIndex);
					return;
				}
				if (childNodes = getIteratorFn(node)) {
					if (childNodes = childNodes.call(node)) {
						node = childNodes.next();
						if (!node.done) {
							props = [];
							do
								props.push(node.value), node = childNodes.next();
							while (!node.done);
							renderChildrenArray(request, task, props, childIndex);
						}
						return;
					}
				}
				if ("function" === typeof node.then) return task.thenableState = null, renderNodeDestructive(request, task, unwrapThenable(node), childIndex);
				if (node.$$typeof === REACT_CONTEXT_TYPE) return renderNodeDestructive(request, task, node._currentValue, childIndex);
				childIndex = Object.prototype.toString.call(node);
				throw Error("Objects are not valid as a React child (found: " + ("[object Object]" === childIndex ? "object with keys {" + Object.keys(node).join(", ") + "}" : childIndex) + "). If you meant to render a collection of children, use an array instead.");
			}
			if ("string" === typeof node) childIndex = task.blockedSegment, null !== childIndex && (childIndex.lastPushedText = pushTextInstance(childIndex.chunks, node, request.renderState, childIndex.lastPushedText));
			else if ("number" === typeof node || "bigint" === typeof node) childIndex = task.blockedSegment, null !== childIndex && (childIndex.lastPushedText = pushTextInstance(childIndex.chunks, "" + node, request.renderState, childIndex.lastPushedText));
		}
	}
	function renderChildrenArray(request, task, children, childIndex) {
		var prevKeyPath = task.keyPath;
		if (-1 !== childIndex && (task.keyPath = [
			task.keyPath,
			"Fragment",
			childIndex
		], null !== task.replay)) {
			for (var replay = task.replay, replayNodes = replay.nodes, j = 0; j < replayNodes.length; j++) {
				var node = replayNodes[j];
				if (node[1] === childIndex) {
					childIndex = node[2];
					node = node[3];
					task.replay = {
						nodes: childIndex,
						slots: node,
						pendingTasks: 1
					};
					try {
						renderChildrenArray(request, task, children, -1);
						if (1 === task.replay.pendingTasks && 0 < task.replay.nodes.length) throw Error("Couldn't find all resumable slots by key/index during replaying. The tree doesn't match so React will fallback to client rendering.");
						task.replay.pendingTasks--;
					} catch (x) {
						if ("object" === typeof x && null !== x && (x === SuspenseException || "function" === typeof x.then)) throw x;
						task.replay.pendingTasks--;
						children = getThrownInfo(task.componentStack);
						var boundary = task.blockedBoundary, error = x;
						children = logRecoverableError(request, error, children);
						abortRemainingReplayNodes(request, boundary, childIndex, node, error, children);
					}
					task.replay = replay;
					replayNodes.splice(j, 1);
					break;
				}
			}
			task.keyPath = prevKeyPath;
			return;
		}
		replay = task.treeContext;
		replayNodes = children.length;
		if (null !== task.replay && (j = task.replay.slots, null !== j && "object" === typeof j)) {
			for (childIndex = 0; childIndex < replayNodes; childIndex++) node = children[childIndex], task.treeContext = pushTreeContext(replay, replayNodes, childIndex), boundary = j[childIndex], "number" === typeof boundary ? (resumeNode(request, task, boundary, node, childIndex), delete j[childIndex]) : renderNode(request, task, node, childIndex);
			task.treeContext = replay;
			task.keyPath = prevKeyPath;
			return;
		}
		for (j = 0; j < replayNodes; j++) childIndex = children[j], task.treeContext = pushTreeContext(replay, replayNodes, j), renderNode(request, task, childIndex, j);
		task.treeContext = replay;
		task.keyPath = prevKeyPath;
	}
	function trackPostponedBoundary(request, trackedPostpones, boundary) {
		boundary.status = 5;
		boundary.rootSegmentID = request.nextSegmentId++;
		request = boundary.trackedContentKeyPath;
		if (null === request) throw Error("It should not be possible to postpone at the root. This is a bug in React.");
		var fallbackReplayNode = boundary.trackedFallbackNode, children = [], boundaryNode = trackedPostpones.workingMap.get(request);
		if (void 0 === boundaryNode) return boundary = [
			request[1],
			request[2],
			children,
			null,
			fallbackReplayNode,
			boundary.rootSegmentID
		], trackedPostpones.workingMap.set(request, boundary), addToReplayParent(boundary, request[0], trackedPostpones), boundary;
		boundaryNode[4] = fallbackReplayNode;
		boundaryNode[5] = boundary.rootSegmentID;
		return boundaryNode;
	}
	function trackPostpone(request, trackedPostpones, task, segment) {
		segment.status = 5;
		var keyPath = task.keyPath, boundary = task.blockedBoundary;
		if (null === boundary) segment.id = request.nextSegmentId++, trackedPostpones.rootSlots = segment.id, null !== request.completedRootSegment && (request.completedRootSegment.status = 5);
		else {
			if (null !== boundary && 0 === boundary.status) {
				var boundaryNode = trackPostponedBoundary(request, trackedPostpones, boundary);
				if (boundary.trackedContentKeyPath === keyPath && -1 === task.childIndex) {
					-1 === segment.id && (segment.id = segment.parentFlushed ? boundary.rootSegmentID : request.nextSegmentId++);
					boundaryNode[3] = segment.id;
					return;
				}
			}
			-1 === segment.id && (segment.id = segment.parentFlushed && null !== boundary ? boundary.rootSegmentID : request.nextSegmentId++);
			if (-1 === task.childIndex) null === keyPath ? trackedPostpones.rootSlots = segment.id : (task = trackedPostpones.workingMap.get(keyPath), void 0 === task ? (task = [
				keyPath[1],
				keyPath[2],
				[],
				segment.id
			], addToReplayParent(task, keyPath[0], trackedPostpones)) : task[3] = segment.id);
			else {
				if (null === keyPath) {
					if (request = trackedPostpones.rootSlots, null === request) request = trackedPostpones.rootSlots = {};
					else if ("number" === typeof request) throw Error("It should not be possible to postpone both at the root of an element as well as a slot below. This is a bug in React.");
				} else if (boundary = trackedPostpones.workingMap, boundaryNode = boundary.get(keyPath), void 0 === boundaryNode) request = {}, boundaryNode = [
					keyPath[1],
					keyPath[2],
					[],
					request
				], boundary.set(keyPath, boundaryNode), addToReplayParent(boundaryNode, keyPath[0], trackedPostpones);
				else if (request = boundaryNode[3], null === request) request = boundaryNode[3] = {};
				else if ("number" === typeof request) throw Error("It should not be possible to postpone both at the root of an element as well as a slot below. This is a bug in React.");
				request[task.childIndex] = segment.id;
			}
		}
	}
	function untrackBoundary(request, boundary) {
		request = request.trackedPostpones;
		null !== request && (boundary = boundary.trackedContentKeyPath, null !== boundary && (boundary = request.workingMap.get(boundary), void 0 !== boundary && (boundary.length = 4, boundary[2] = [], boundary[3] = null)));
	}
	function spawnNewSuspendedReplayTask(request, task, thenableState) {
		return createReplayTask(request, thenableState, task.replay, task.node, task.childIndex, task.blockedBoundary, task.hoistableState, task.abortSet, task.keyPath, task.formatContext, task.context, task.treeContext, task.row, task.componentStack);
	}
	function spawnNewSuspendedRenderTask(request, task, thenableState) {
		var segment = task.blockedSegment, newSegment = createPendingSegment(request, segment.chunks.length, null, task.formatContext, segment.lastPushedText, !0);
		segment.children.push(newSegment);
		segment.lastPushedText = !1;
		return createRenderTask(request, thenableState, task.node, task.childIndex, task.blockedBoundary, newSegment, task.blockedPreamble, task.hoistableState, task.abortSet, task.keyPath, task.formatContext, task.context, task.treeContext, task.row, task.componentStack);
	}
	function renderNode(request, task, node, childIndex) {
		var previousFormatContext = task.formatContext, previousContext = task.context, previousKeyPath = task.keyPath, previousTreeContext = task.treeContext, previousComponentStack = task.componentStack, segment = task.blockedSegment;
		if (null === segment) {
			segment = task.replay;
			try {
				return renderNodeDestructive(request, task, node, childIndex);
			} catch (thrownValue) {
				if (resetHooksState(), node = thrownValue === SuspenseException ? getSuspendedThenable() : thrownValue, 12 !== request.status && "object" === typeof node && null !== node) {
					if ("function" === typeof node.then) {
						childIndex = thrownValue === SuspenseException ? getThenableStateAfterSuspending() : null;
						request = spawnNewSuspendedReplayTask(request, task, childIndex).ping;
						node.then(request, request);
						task.formatContext = previousFormatContext;
						task.context = previousContext;
						task.keyPath = previousKeyPath;
						task.treeContext = previousTreeContext;
						task.componentStack = previousComponentStack;
						task.replay = segment;
						switchContext(previousContext);
						return;
					}
					if ("Maximum call stack size exceeded" === node.message) {
						node = thrownValue === SuspenseException ? getThenableStateAfterSuspending() : null;
						node = spawnNewSuspendedReplayTask(request, task, node);
						request.pingedTasks.push(node);
						task.formatContext = previousFormatContext;
						task.context = previousContext;
						task.keyPath = previousKeyPath;
						task.treeContext = previousTreeContext;
						task.componentStack = previousComponentStack;
						task.replay = segment;
						switchContext(previousContext);
						return;
					}
				}
			}
		} else {
			var childrenLength = segment.children.length, chunkLength = segment.chunks.length;
			try {
				return renderNodeDestructive(request, task, node, childIndex);
			} catch (thrownValue$63) {
				if (resetHooksState(), segment.children.length = childrenLength, segment.chunks.length = chunkLength, node = thrownValue$63 === SuspenseException ? getSuspendedThenable() : thrownValue$63, 12 !== request.status && "object" === typeof node && null !== node) {
					if ("function" === typeof node.then) {
						segment = node;
						node = thrownValue$63 === SuspenseException ? getThenableStateAfterSuspending() : null;
						request = spawnNewSuspendedRenderTask(request, task, node).ping;
						segment.then(request, request);
						task.formatContext = previousFormatContext;
						task.context = previousContext;
						task.keyPath = previousKeyPath;
						task.treeContext = previousTreeContext;
						task.componentStack = previousComponentStack;
						switchContext(previousContext);
						return;
					}
					if ("Maximum call stack size exceeded" === node.message) {
						segment = thrownValue$63 === SuspenseException ? getThenableStateAfterSuspending() : null;
						segment = spawnNewSuspendedRenderTask(request, task, segment);
						request.pingedTasks.push(segment);
						task.formatContext = previousFormatContext;
						task.context = previousContext;
						task.keyPath = previousKeyPath;
						task.treeContext = previousTreeContext;
						task.componentStack = previousComponentStack;
						switchContext(previousContext);
						return;
					}
				}
			}
		}
		task.formatContext = previousFormatContext;
		task.context = previousContext;
		task.keyPath = previousKeyPath;
		task.treeContext = previousTreeContext;
		switchContext(previousContext);
		throw node;
	}
	function abortTaskSoft(task) {
		var boundary = task.blockedBoundary, segment = task.blockedSegment;
		null !== segment && (segment.status = 3, finishedTask(this, boundary, task.row, segment));
	}
	function abortRemainingReplayNodes(request$jscomp$0, boundary, nodes, slots, error, errorDigest$jscomp$0) {
		for (var i = 0; i < nodes.length; i++) {
			var node = nodes[i];
			if (4 === node.length) abortRemainingReplayNodes(request$jscomp$0, boundary, node[2], node[3], error, errorDigest$jscomp$0);
			else {
				node = node[5];
				var request = request$jscomp$0, errorDigest = errorDigest$jscomp$0, resumedBoundary = createSuspenseBoundary(request, null, /* @__PURE__ */ new Set(), null, null);
				resumedBoundary.parentFlushed = !0;
				resumedBoundary.rootSegmentID = node;
				resumedBoundary.status = 4;
				resumedBoundary.errorDigest = errorDigest;
				resumedBoundary.parentFlushed && request.clientRenderedBoundaries.push(resumedBoundary);
			}
		}
		nodes.length = 0;
		if (null !== slots) {
			if (null === boundary) throw Error("We should not have any resumable nodes in the shell. This is a bug in React.");
			4 !== boundary.status && (boundary.status = 4, boundary.errorDigest = errorDigest$jscomp$0, boundary.parentFlushed && request$jscomp$0.clientRenderedBoundaries.push(boundary));
			if ("object" === typeof slots) for (var index in slots) delete slots[index];
		}
	}
	function abortTask(task, request, error) {
		var boundary = task.blockedBoundary, segment = task.blockedSegment;
		if (null !== segment) {
			if (6 === segment.status) return;
			segment.status = 3;
		}
		var errorInfo = getThrownInfo(task.componentStack);
		if (null === boundary) {
			if (13 !== request.status && 14 !== request.status) {
				boundary = task.replay;
				if (null === boundary) {
					null !== request.trackedPostpones && null !== segment ? (boundary = request.trackedPostpones, logRecoverableError(request, error, errorInfo), trackPostpone(request, boundary, task, segment), finishedTask(request, null, task.row, segment)) : (logRecoverableError(request, error, errorInfo), fatalError(request, error));
					return;
				}
				boundary.pendingTasks--;
				0 === boundary.pendingTasks && 0 < boundary.nodes.length && (segment = logRecoverableError(request, error, errorInfo), abortRemainingReplayNodes(request, null, boundary.nodes, boundary.slots, error, segment));
				request.pendingRootTasks--;
				0 === request.pendingRootTasks && completeShell(request);
			}
		} else {
			var trackedPostpones$64 = request.trackedPostpones;
			if (4 !== boundary.status) {
				if (null !== trackedPostpones$64 && null !== segment) return logRecoverableError(request, error, errorInfo), trackPostpone(request, trackedPostpones$64, task, segment), boundary.fallbackAbortableTasks.forEach(function(fallbackTask) {
					return abortTask(fallbackTask, request, error);
				}), boundary.fallbackAbortableTasks.clear(), finishedTask(request, boundary, task.row, segment);
				boundary.status = 4;
				segment = logRecoverableError(request, error, errorInfo);
				boundary.status = 4;
				boundary.errorDigest = segment;
				untrackBoundary(request, boundary);
				boundary.parentFlushed && request.clientRenderedBoundaries.push(boundary);
			}
			boundary.pendingTasks--;
			segment = boundary.row;
			null !== segment && 0 === --segment.pendingTasks && finishSuspenseListRow(request, segment);
			boundary.fallbackAbortableTasks.forEach(function(fallbackTask) {
				return abortTask(fallbackTask, request, error);
			});
			boundary.fallbackAbortableTasks.clear();
		}
		task = task.row;
		null !== task && 0 === --task.pendingTasks && finishSuspenseListRow(request, task);
		request.allPendingTasks--;
		0 === request.allPendingTasks && completeAll(request);
	}
	function safelyEmitEarlyPreloads(request, shellComplete) {
		try {
			var renderState = request.renderState, onHeaders = renderState.onHeaders;
			if (onHeaders) {
				var headers = renderState.headers;
				if (headers) {
					renderState.headers = null;
					var linkHeader = headers.preconnects;
					headers.fontPreloads && (linkHeader && (linkHeader += ", "), linkHeader += headers.fontPreloads);
					headers.highImagePreloads && (linkHeader && (linkHeader += ", "), linkHeader += headers.highImagePreloads);
					if (!shellComplete) {
						var queueIter = renderState.styles.values(), queueStep = queueIter.next();
						b: for (; 0 < headers.remainingCapacity && !queueStep.done; queueStep = queueIter.next()) for (var sheetIter = queueStep.value.sheets.values(), sheetStep = sheetIter.next(); 0 < headers.remainingCapacity && !sheetStep.done; sheetStep = sheetIter.next()) {
							var sheet = sheetStep.value, props = sheet.props, key = props.href, props$jscomp$0 = sheet.props, header = getPreloadAsHeader(props$jscomp$0.href, "style", {
								crossOrigin: props$jscomp$0.crossOrigin,
								integrity: props$jscomp$0.integrity,
								nonce: props$jscomp$0.nonce,
								type: props$jscomp$0.type,
								fetchPriority: props$jscomp$0.fetchPriority,
								referrerPolicy: props$jscomp$0.referrerPolicy,
								media: props$jscomp$0.media
							});
							if (0 <= (headers.remainingCapacity -= header.length + 2)) renderState.resets.style[key] = PRELOAD_NO_CREDS, linkHeader && (linkHeader += ", "), linkHeader += header, renderState.resets.style[key] = "string" === typeof props.crossOrigin || "string" === typeof props.integrity ? [props.crossOrigin, props.integrity] : PRELOAD_NO_CREDS;
							else break b;
						}
					}
					linkHeader ? onHeaders({ Link: linkHeader }) : onHeaders({});
				}
			}
		} catch (error) {
			logRecoverableError(request, error, {});
		}
	}
	function completeShell(request) {
		null === request.trackedPostpones && safelyEmitEarlyPreloads(request, !0);
		null === request.trackedPostpones && preparePreamble(request);
		request.onShellError = noop;
		request = request.onShellReady;
		request();
	}
	function completeAll(request) {
		safelyEmitEarlyPreloads(request, null === request.trackedPostpones ? !0 : null === request.completedRootSegment || 5 !== request.completedRootSegment.status);
		preparePreamble(request);
		request = request.onAllReady;
		request();
	}
	function queueCompletedSegment(boundary, segment) {
		if (0 === segment.chunks.length && 1 === segment.children.length && null === segment.children[0].boundary && -1 === segment.children[0].id) {
			var childSegment = segment.children[0];
			childSegment.id = segment.id;
			childSegment.parentFlushed = !0;
			1 !== childSegment.status && 3 !== childSegment.status && 4 !== childSegment.status || queueCompletedSegment(boundary, childSegment);
		} else boundary.completedSegments.push(segment);
	}
	function finishedSegment(request, boundary, segment) {
		if (null !== byteLengthOfChunk) {
			segment = segment.chunks;
			for (var segmentByteSize = 0, i = 0; i < segment.length; i++) segmentByteSize += segment[i].byteLength;
			null === boundary ? request.byteSize += segmentByteSize : boundary.byteSize += segmentByteSize;
		}
	}
	function finishedTask(request, boundary, row, segment) {
		null !== row && (0 === --row.pendingTasks ? finishSuspenseListRow(request, row) : row.together && tryToResolveTogetherRow(request, row));
		request.allPendingTasks--;
		if (null === boundary) {
			if (null !== segment && segment.parentFlushed) {
				if (null !== request.completedRootSegment) throw Error("There can only be one root segment. This is a bug in React.");
				request.completedRootSegment = segment;
			}
			request.pendingRootTasks--;
			0 === request.pendingRootTasks && completeShell(request);
		} else if (boundary.pendingTasks--, 4 !== boundary.status) if (0 === boundary.pendingTasks) {
			if (0 === boundary.status && (boundary.status = 1), null !== segment && segment.parentFlushed && (1 === segment.status || 3 === segment.status) && queueCompletedSegment(boundary, segment), boundary.parentFlushed && request.completedBoundaries.push(boundary), 1 === boundary.status) row = boundary.row, null !== row && hoistHoistables(row.hoistables, boundary.contentState), isEligibleForOutlining(request, boundary) || (boundary.fallbackAbortableTasks.forEach(abortTaskSoft, request), boundary.fallbackAbortableTasks.clear(), null !== row && 0 === --row.pendingTasks && finishSuspenseListRow(request, row)), 0 === request.pendingRootTasks && null === request.trackedPostpones && null !== boundary.contentPreamble && preparePreamble(request);
			else if (5 === boundary.status && (boundary = boundary.row, null !== boundary)) {
				if (null !== request.trackedPostpones) {
					row = request.trackedPostpones;
					var postponedRow = boundary.next;
					if (null !== postponedRow && (segment = postponedRow.boundaries, null !== segment)) for (postponedRow.boundaries = null, postponedRow = 0; postponedRow < segment.length; postponedRow++) {
						var postponedBoundary = segment[postponedRow];
						trackPostponedBoundary(request, row, postponedBoundary);
						finishedTask(request, postponedBoundary, null, null);
					}
				}
				0 === --boundary.pendingTasks && finishSuspenseListRow(request, boundary);
			}
		} else null === segment || !segment.parentFlushed || 1 !== segment.status && 3 !== segment.status || (queueCompletedSegment(boundary, segment), 1 === boundary.completedSegments.length && boundary.parentFlushed && request.partialBoundaries.push(boundary)), boundary = boundary.row, null !== boundary && boundary.together && tryToResolveTogetherRow(request, boundary);
		0 === request.allPendingTasks && completeAll(request);
	}
	function performWork(request$jscomp$2) {
		if (14 !== request$jscomp$2.status && 13 !== request$jscomp$2.status) {
			var prevContext = currentActiveSnapshot, prevDispatcher = ReactSharedInternals.H;
			ReactSharedInternals.H = HooksDispatcher;
			var prevAsyncDispatcher = ReactSharedInternals.A;
			ReactSharedInternals.A = DefaultAsyncDispatcher;
			var prevRequest = currentRequest;
			currentRequest = request$jscomp$2;
			var prevResumableState = currentResumableState;
			currentResumableState = request$jscomp$2.resumableState;
			try {
				var pingedTasks = request$jscomp$2.pingedTasks, i;
				for (i = 0; i < pingedTasks.length; i++) {
					var task = pingedTasks[i], request = request$jscomp$2, segment = task.blockedSegment;
					if (null === segment) {
						var request$jscomp$0 = request;
						if (0 !== task.replay.pendingTasks) {
							switchContext(task.context);
							try {
								"number" === typeof task.replay.slots ? resumeNode(request$jscomp$0, task, task.replay.slots, task.node, task.childIndex) : retryNode(request$jscomp$0, task);
								if (1 === task.replay.pendingTasks && 0 < task.replay.nodes.length) throw Error("Couldn't find all resumable slots by key/index during replaying. The tree doesn't match so React will fallback to client rendering.");
								task.replay.pendingTasks--;
								task.abortSet.delete(task);
								finishedTask(request$jscomp$0, task.blockedBoundary, task.row, null);
							} catch (thrownValue) {
								resetHooksState();
								var x = thrownValue === SuspenseException ? getSuspendedThenable() : thrownValue;
								if ("object" === typeof x && null !== x && "function" === typeof x.then) {
									var ping = task.ping;
									x.then(ping, ping);
									task.thenableState = thrownValue === SuspenseException ? getThenableStateAfterSuspending() : null;
								} else {
									task.replay.pendingTasks--;
									task.abortSet.delete(task);
									var errorInfo = getThrownInfo(task.componentStack);
									request = void 0;
									var request$jscomp$1 = request$jscomp$0, boundary = task.blockedBoundary, error$jscomp$0 = 12 === request$jscomp$0.status ? request$jscomp$0.fatalError : x, replayNodes = task.replay.nodes, resumeSlots = task.replay.slots;
									request = logRecoverableError(request$jscomp$1, error$jscomp$0, errorInfo);
									abortRemainingReplayNodes(request$jscomp$1, boundary, replayNodes, resumeSlots, error$jscomp$0, request);
									request$jscomp$0.pendingRootTasks--;
									0 === request$jscomp$0.pendingRootTasks && completeShell(request$jscomp$0);
									request$jscomp$0.allPendingTasks--;
									0 === request$jscomp$0.allPendingTasks && completeAll(request$jscomp$0);
								}
							}
						}
					} else if (request$jscomp$0 = void 0, request$jscomp$1 = segment, 0 === request$jscomp$1.status) {
						request$jscomp$1.status = 6;
						switchContext(task.context);
						var childrenLength = request$jscomp$1.children.length, chunkLength = request$jscomp$1.chunks.length;
						try {
							retryNode(request, task), request$jscomp$1.lastPushedText && request$jscomp$1.textEmbedded && request$jscomp$1.chunks.push(textSeparator), task.abortSet.delete(task), request$jscomp$1.status = 1, finishedSegment(request, task.blockedBoundary, request$jscomp$1), finishedTask(request, task.blockedBoundary, task.row, request$jscomp$1);
						} catch (thrownValue) {
							resetHooksState();
							request$jscomp$1.children.length = childrenLength;
							request$jscomp$1.chunks.length = chunkLength;
							var x$jscomp$0 = thrownValue === SuspenseException ? getSuspendedThenable() : 12 === request.status ? request.fatalError : thrownValue;
							if (12 === request.status && null !== request.trackedPostpones) {
								var trackedPostpones = request.trackedPostpones, thrownInfo = getThrownInfo(task.componentStack);
								task.abortSet.delete(task);
								logRecoverableError(request, x$jscomp$0, thrownInfo);
								trackPostpone(request, trackedPostpones, task, request$jscomp$1);
								finishedTask(request, task.blockedBoundary, task.row, request$jscomp$1);
							} else if ("object" === typeof x$jscomp$0 && null !== x$jscomp$0 && "function" === typeof x$jscomp$0.then) {
								request$jscomp$1.status = 0;
								task.thenableState = thrownValue === SuspenseException ? getThenableStateAfterSuspending() : null;
								var ping$jscomp$0 = task.ping;
								x$jscomp$0.then(ping$jscomp$0, ping$jscomp$0);
							} else {
								var errorInfo$jscomp$0 = getThrownInfo(task.componentStack);
								task.abortSet.delete(task);
								request$jscomp$1.status = 4;
								var boundary$jscomp$0 = task.blockedBoundary, row = task.row;
								null !== row && 0 === --row.pendingTasks && finishSuspenseListRow(request, row);
								request.allPendingTasks--;
								request$jscomp$0 = logRecoverableError(request, x$jscomp$0, errorInfo$jscomp$0);
								if (null === boundary$jscomp$0) fatalError(request, x$jscomp$0);
								else if (boundary$jscomp$0.pendingTasks--, 4 !== boundary$jscomp$0.status) {
									boundary$jscomp$0.status = 4;
									boundary$jscomp$0.errorDigest = request$jscomp$0;
									untrackBoundary(request, boundary$jscomp$0);
									var boundaryRow = boundary$jscomp$0.row;
									null !== boundaryRow && 0 === --boundaryRow.pendingTasks && finishSuspenseListRow(request, boundaryRow);
									boundary$jscomp$0.parentFlushed && request.clientRenderedBoundaries.push(boundary$jscomp$0);
									0 === request.pendingRootTasks && null === request.trackedPostpones && null !== boundary$jscomp$0.contentPreamble && preparePreamble(request);
								}
								0 === request.allPendingTasks && completeAll(request);
							}
						}
					}
				}
				pingedTasks.splice(0, i);
				null !== request$jscomp$2.destination && flushCompletedQueues(request$jscomp$2, request$jscomp$2.destination);
			} catch (error) {
				logRecoverableError(request$jscomp$2, error, {}), fatalError(request$jscomp$2, error);
			} finally {
				currentResumableState = prevResumableState, ReactSharedInternals.H = prevDispatcher, ReactSharedInternals.A = prevAsyncDispatcher, prevDispatcher === HooksDispatcher && switchContext(prevContext), currentRequest = prevRequest;
			}
		}
	}
	function preparePreambleFromSubtree(request, segment, collectedPreambleSegments) {
		segment.preambleChildren.length && collectedPreambleSegments.push(segment.preambleChildren);
		for (var pendingPreambles = !1, i = 0; i < segment.children.length; i++) pendingPreambles = preparePreambleFromSegment(request, segment.children[i], collectedPreambleSegments) || pendingPreambles;
		return pendingPreambles;
	}
	function preparePreambleFromSegment(request, segment, collectedPreambleSegments) {
		var boundary = segment.boundary;
		if (null === boundary) return preparePreambleFromSubtree(request, segment, collectedPreambleSegments);
		var preamble = boundary.contentPreamble, fallbackPreamble = boundary.fallbackPreamble;
		if (null === preamble || null === fallbackPreamble) return !1;
		switch (boundary.status) {
			case 1:
				hoistPreambleState(request.renderState, preamble);
				request.byteSize += boundary.byteSize;
				segment = boundary.completedSegments[0];
				if (!segment) throw Error("A previously unvisited boundary must have exactly one root segment. This is a bug in React.");
				return preparePreambleFromSubtree(request, segment, collectedPreambleSegments);
			case 5: if (null !== request.trackedPostpones) return !0;
			case 4: if (1 === segment.status) return hoistPreambleState(request.renderState, fallbackPreamble), preparePreambleFromSubtree(request, segment, collectedPreambleSegments);
			default: return !0;
		}
	}
	function preparePreamble(request) {
		if (request.completedRootSegment && null === request.completedPreambleSegments) {
			var collectedPreambleSegments = [], originalRequestByteSize = request.byteSize, hasPendingPreambles = preparePreambleFromSegment(request, request.completedRootSegment, collectedPreambleSegments), preamble = request.renderState.preamble;
			!1 === hasPendingPreambles || preamble.headChunks && preamble.bodyChunks ? request.completedPreambleSegments = collectedPreambleSegments : request.byteSize = originalRequestByteSize;
		}
	}
	function flushSubtree(request, destination, segment, hoistableState) {
		segment.parentFlushed = !0;
		switch (segment.status) {
			case 0: segment.id = request.nextSegmentId++;
			case 5: return hoistableState = segment.id, segment.lastPushedText = !1, segment.textEmbedded = !1, request = request.renderState, writeChunk(destination, placeholder1), writeChunk(destination, request.placeholderPrefix), request = stringToChunk(hoistableState.toString(16)), writeChunk(destination, request), writeChunkAndReturn(destination, placeholder2);
			case 1:
				segment.status = 2;
				var r = !0, chunks = segment.chunks, chunkIdx = 0;
				segment = segment.children;
				for (var childIdx = 0; childIdx < segment.length; childIdx++) {
					for (r = segment[childIdx]; chunkIdx < r.index; chunkIdx++) writeChunk(destination, chunks[chunkIdx]);
					r = flushSegment(request, destination, r, hoistableState);
				}
				for (; chunkIdx < chunks.length - 1; chunkIdx++) writeChunk(destination, chunks[chunkIdx]);
				chunkIdx < chunks.length && (r = writeChunkAndReturn(destination, chunks[chunkIdx]));
				return r;
			case 3: return !0;
			default: throw Error("Aborted, errored or already flushed boundaries should not be flushed again. This is a bug in React.");
		}
	}
	var flushedByteSize = 0;
	function flushSegment(request, destination, segment, hoistableState) {
		var boundary = segment.boundary;
		if (null === boundary) return flushSubtree(request, destination, segment, hoistableState);
		boundary.parentFlushed = !0;
		if (4 === boundary.status) {
			var row = boundary.row;
			null !== row && 0 === --row.pendingTasks && finishSuspenseListRow(request, row);
			boundary = boundary.errorDigest;
			writeChunkAndReturn(destination, startClientRenderedSuspenseBoundary);
			writeChunk(destination, clientRenderedSuspenseBoundaryError1);
			boundary && (writeChunk(destination, clientRenderedSuspenseBoundaryError1A), writeChunk(destination, stringToChunk(escapeTextForBrowser(boundary))), writeChunk(destination, clientRenderedSuspenseBoundaryErrorAttrInterstitial));
			writeChunkAndReturn(destination, clientRenderedSuspenseBoundaryError2);
			flushSubtree(request, destination, segment, hoistableState);
		} else if (1 !== boundary.status) 0 === boundary.status && (boundary.rootSegmentID = request.nextSegmentId++), 0 < boundary.completedSegments.length && request.partialBoundaries.push(boundary), writeStartPendingSuspenseBoundary(destination, request.renderState, boundary.rootSegmentID), hoistableState && hoistHoistables(hoistableState, boundary.fallbackState), flushSubtree(request, destination, segment, hoistableState);
		else if (!flushingPartialBoundaries && isEligibleForOutlining(request, boundary) && (flushedByteSize + boundary.byteSize > request.progressiveChunkSize || hasSuspenseyContent(boundary.contentState))) boundary.rootSegmentID = request.nextSegmentId++, request.completedBoundaries.push(boundary), writeStartPendingSuspenseBoundary(destination, request.renderState, boundary.rootSegmentID), flushSubtree(request, destination, segment, hoistableState);
		else {
			flushedByteSize += boundary.byteSize;
			hoistableState && hoistHoistables(hoistableState, boundary.contentState);
			segment = boundary.row;
			null !== segment && isEligibleForOutlining(request, boundary) && 0 === --segment.pendingTasks && finishSuspenseListRow(request, segment);
			writeChunkAndReturn(destination, startCompletedSuspenseBoundary);
			segment = boundary.completedSegments;
			if (1 !== segment.length) throw Error("A previously unvisited boundary must have exactly one root segment. This is a bug in React.");
			flushSegment(request, destination, segment[0], hoistableState);
		}
		return writeChunkAndReturn(destination, endSuspenseBoundary);
	}
	function flushSegmentContainer(request, destination, segment, hoistableState) {
		writeStartSegment(destination, request.renderState, segment.parentFormatContext, segment.id);
		flushSegment(request, destination, segment, hoistableState);
		return writeEndSegment(destination, segment.parentFormatContext);
	}
	function flushCompletedBoundary(request, destination, boundary) {
		flushedByteSize = boundary.byteSize;
		for (var completedSegments = boundary.completedSegments, i = 0; i < completedSegments.length; i++) flushPartiallyCompletedSegment(request, destination, boundary, completedSegments[i]);
		completedSegments.length = 0;
		completedSegments = boundary.row;
		null !== completedSegments && isEligibleForOutlining(request, boundary) && 0 === --completedSegments.pendingTasks && finishSuspenseListRow(request, completedSegments);
		writeHoistablesForBoundary(destination, boundary.contentState, request.renderState);
		completedSegments = request.resumableState;
		request = request.renderState;
		i = boundary.rootSegmentID;
		boundary = boundary.contentState;
		var requiresStyleInsertion = request.stylesToHoist;
		request.stylesToHoist = !1;
		writeChunk(destination, request.startInlineScript);
		writeChunk(destination, endOfStartTag);
		requiresStyleInsertion ? (0 === (completedSegments.instructions & 4) && (completedSegments.instructions |= 4, writeChunk(destination, clientRenderScriptFunctionOnly)), 0 === (completedSegments.instructions & 2) && (completedSegments.instructions |= 2, writeChunk(destination, completeBoundaryScriptFunctionOnly)), 0 === (completedSegments.instructions & 8) ? (completedSegments.instructions |= 8, writeChunk(destination, completeBoundaryWithStylesScript1FullPartial)) : writeChunk(destination, completeBoundaryWithStylesScript1Partial)) : (0 === (completedSegments.instructions & 2) && (completedSegments.instructions |= 2, writeChunk(destination, completeBoundaryScriptFunctionOnly)), writeChunk(destination, completeBoundaryScript1Partial));
		completedSegments = stringToChunk(i.toString(16));
		writeChunk(destination, request.boundaryPrefix);
		writeChunk(destination, completedSegments);
		writeChunk(destination, completeBoundaryScript2);
		writeChunk(destination, request.segmentPrefix);
		writeChunk(destination, completedSegments);
		requiresStyleInsertion ? (writeChunk(destination, completeBoundaryScript3a), writeStyleResourceDependenciesInJS(destination, boundary)) : writeChunk(destination, completeBoundaryScript3b);
		boundary = writeChunkAndReturn(destination, completeBoundaryScriptEnd);
		return writeBootstrap(destination, request) && boundary;
	}
	function flushPartiallyCompletedSegment(request, destination, boundary, segment) {
		if (2 === segment.status) return !0;
		var hoistableState = boundary.contentState, segmentID = segment.id;
		if (-1 === segmentID) {
			if (-1 === (segment.id = boundary.rootSegmentID)) throw Error("A root segment ID must have been assigned by now. This is a bug in React.");
			return flushSegmentContainer(request, destination, segment, hoistableState);
		}
		if (segmentID === boundary.rootSegmentID) return flushSegmentContainer(request, destination, segment, hoistableState);
		flushSegmentContainer(request, destination, segment, hoistableState);
		boundary = request.resumableState;
		request = request.renderState;
		writeChunk(destination, request.startInlineScript);
		writeChunk(destination, endOfStartTag);
		0 === (boundary.instructions & 1) ? (boundary.instructions |= 1, writeChunk(destination, completeSegmentScript1Full)) : writeChunk(destination, completeSegmentScript1Partial);
		writeChunk(destination, request.segmentPrefix);
		segmentID = stringToChunk(segmentID.toString(16));
		writeChunk(destination, segmentID);
		writeChunk(destination, completeSegmentScript2);
		writeChunk(destination, request.placeholderPrefix);
		writeChunk(destination, segmentID);
		destination = writeChunkAndReturn(destination, completeSegmentScriptEnd);
		return destination;
	}
	var flushingPartialBoundaries = !1;
	function flushCompletedQueues(request, destination) {
		currentView = new Uint8Array(2048);
		writtenBytes = 0;
		try {
			if (!(0 < request.pendingRootTasks)) {
				var i, completedRootSegment = request.completedRootSegment;
				if (null !== completedRootSegment) {
					if (5 === completedRootSegment.status) return;
					var completedPreambleSegments = request.completedPreambleSegments;
					if (null === completedPreambleSegments) return;
					flushedByteSize = request.byteSize;
					var resumableState = request.resumableState, renderState = request.renderState, preamble = renderState.preamble, htmlChunks = preamble.htmlChunks, headChunks = preamble.headChunks, i$jscomp$0;
					if (htmlChunks) {
						for (i$jscomp$0 = 0; i$jscomp$0 < htmlChunks.length; i$jscomp$0++) writeChunk(destination, htmlChunks[i$jscomp$0]);
						if (headChunks) for (i$jscomp$0 = 0; i$jscomp$0 < headChunks.length; i$jscomp$0++) writeChunk(destination, headChunks[i$jscomp$0]);
						else writeChunk(destination, startChunkForTag("head")), writeChunk(destination, endOfStartTag);
					} else if (headChunks) for (i$jscomp$0 = 0; i$jscomp$0 < headChunks.length; i$jscomp$0++) writeChunk(destination, headChunks[i$jscomp$0]);
					var charsetChunks = renderState.charsetChunks;
					for (i$jscomp$0 = 0; i$jscomp$0 < charsetChunks.length; i$jscomp$0++) writeChunk(destination, charsetChunks[i$jscomp$0]);
					charsetChunks.length = 0;
					renderState.preconnects.forEach(flushResource, destination);
					renderState.preconnects.clear();
					var viewportChunks = renderState.viewportChunks;
					for (i$jscomp$0 = 0; i$jscomp$0 < viewportChunks.length; i$jscomp$0++) writeChunk(destination, viewportChunks[i$jscomp$0]);
					viewportChunks.length = 0;
					renderState.fontPreloads.forEach(flushResource, destination);
					renderState.fontPreloads.clear();
					renderState.highImagePreloads.forEach(flushResource, destination);
					renderState.highImagePreloads.clear();
					currentlyFlushingRenderState = renderState;
					renderState.styles.forEach(flushStylesInPreamble, destination);
					currentlyFlushingRenderState = null;
					var importMapChunks = renderState.importMapChunks;
					for (i$jscomp$0 = 0; i$jscomp$0 < importMapChunks.length; i$jscomp$0++) writeChunk(destination, importMapChunks[i$jscomp$0]);
					importMapChunks.length = 0;
					renderState.bootstrapScripts.forEach(flushResource, destination);
					renderState.scripts.forEach(flushResource, destination);
					renderState.scripts.clear();
					renderState.bulkPreloads.forEach(flushResource, destination);
					renderState.bulkPreloads.clear();
					htmlChunks || headChunks || (resumableState.instructions |= 32);
					var hoistableChunks = renderState.hoistableChunks;
					for (i$jscomp$0 = 0; i$jscomp$0 < hoistableChunks.length; i$jscomp$0++) writeChunk(destination, hoistableChunks[i$jscomp$0]);
					for (resumableState = hoistableChunks.length = 0; resumableState < completedPreambleSegments.length; resumableState++) {
						var segments = completedPreambleSegments[resumableState];
						for (renderState = 0; renderState < segments.length; renderState++) flushSegment(request, destination, segments[renderState], null);
					}
					var preamble$jscomp$0 = request.renderState.preamble, headChunks$jscomp$0 = preamble$jscomp$0.headChunks;
					(preamble$jscomp$0.htmlChunks || headChunks$jscomp$0) && writeChunk(destination, endChunkForTag("head"));
					var bodyChunks = preamble$jscomp$0.bodyChunks;
					if (bodyChunks) for (completedPreambleSegments = 0; completedPreambleSegments < bodyChunks.length; completedPreambleSegments++) writeChunk(destination, bodyChunks[completedPreambleSegments]);
					flushSegment(request, destination, completedRootSegment, null);
					request.completedRootSegment = null;
					var renderState$jscomp$0 = request.renderState;
					if (0 !== request.allPendingTasks || 0 !== request.clientRenderedBoundaries.length || 0 !== request.completedBoundaries.length || null !== request.trackedPostpones && (0 !== request.trackedPostpones.rootNodes.length || null !== request.trackedPostpones.rootSlots)) {
						var resumableState$jscomp$0 = request.resumableState;
						if (0 === (resumableState$jscomp$0.instructions & 64)) {
							resumableState$jscomp$0.instructions |= 64;
							writeChunk(destination, renderState$jscomp$0.startInlineScript);
							if (0 === (resumableState$jscomp$0.instructions & 32)) {
								resumableState$jscomp$0.instructions |= 32;
								var shellId = "_" + resumableState$jscomp$0.idPrefix + "R_";
								writeChunk(destination, completedShellIdAttributeStart);
								writeChunk(destination, stringToChunk(escapeTextForBrowser(shellId)));
								writeChunk(destination, attributeEnd);
							}
							writeChunk(destination, endOfStartTag);
							writeChunk(destination, shellTimeRuntimeScript);
							writeChunkAndReturn(destination, endInlineScript);
						}
					}
					writeBootstrap(destination, renderState$jscomp$0);
				}
				var renderState$jscomp$1 = request.renderState;
				completedRootSegment = 0;
				var viewportChunks$jscomp$0 = renderState$jscomp$1.viewportChunks;
				for (completedRootSegment = 0; completedRootSegment < viewportChunks$jscomp$0.length; completedRootSegment++) writeChunk(destination, viewportChunks$jscomp$0[completedRootSegment]);
				viewportChunks$jscomp$0.length = 0;
				renderState$jscomp$1.preconnects.forEach(flushResource, destination);
				renderState$jscomp$1.preconnects.clear();
				renderState$jscomp$1.fontPreloads.forEach(flushResource, destination);
				renderState$jscomp$1.fontPreloads.clear();
				renderState$jscomp$1.highImagePreloads.forEach(flushResource, destination);
				renderState$jscomp$1.highImagePreloads.clear();
				renderState$jscomp$1.styles.forEach(preloadLateStyles, destination);
				renderState$jscomp$1.scripts.forEach(flushResource, destination);
				renderState$jscomp$1.scripts.clear();
				renderState$jscomp$1.bulkPreloads.forEach(flushResource, destination);
				renderState$jscomp$1.bulkPreloads.clear();
				var hoistableChunks$jscomp$0 = renderState$jscomp$1.hoistableChunks;
				for (completedRootSegment = 0; completedRootSegment < hoistableChunks$jscomp$0.length; completedRootSegment++) writeChunk(destination, hoistableChunks$jscomp$0[completedRootSegment]);
				hoistableChunks$jscomp$0.length = 0;
				var clientRenderedBoundaries = request.clientRenderedBoundaries;
				for (i = 0; i < clientRenderedBoundaries.length; i++) {
					var boundary = clientRenderedBoundaries[i];
					renderState$jscomp$1 = destination;
					var resumableState$jscomp$1 = request.resumableState, renderState$jscomp$2 = request.renderState, id = boundary.rootSegmentID, errorDigest = boundary.errorDigest;
					writeChunk(renderState$jscomp$1, renderState$jscomp$2.startInlineScript);
					writeChunk(renderState$jscomp$1, endOfStartTag);
					0 === (resumableState$jscomp$1.instructions & 4) ? (resumableState$jscomp$1.instructions |= 4, writeChunk(renderState$jscomp$1, clientRenderScript1Full)) : writeChunk(renderState$jscomp$1, clientRenderScript1Partial);
					writeChunk(renderState$jscomp$1, renderState$jscomp$2.boundaryPrefix);
					writeChunk(renderState$jscomp$1, stringToChunk(id.toString(16)));
					writeChunk(renderState$jscomp$1, clientRenderScript1A);
					errorDigest && (writeChunk(renderState$jscomp$1, clientRenderErrorScriptArgInterstitial), writeChunk(renderState$jscomp$1, stringToChunk(escapeJSStringsForInstructionScripts(errorDigest || ""))));
					var JSCompiler_inline_result = writeChunkAndReturn(renderState$jscomp$1, clientRenderScriptEnd);
					if (!JSCompiler_inline_result) {
						request.destination = null;
						i++;
						clientRenderedBoundaries.splice(0, i);
						return;
					}
				}
				clientRenderedBoundaries.splice(0, i);
				var completedBoundaries = request.completedBoundaries;
				for (i = 0; i < completedBoundaries.length; i++) if (!flushCompletedBoundary(request, destination, completedBoundaries[i])) {
					request.destination = null;
					i++;
					completedBoundaries.splice(0, i);
					return;
				}
				completedBoundaries.splice(0, i);
				completeWriting(destination);
				currentView = new Uint8Array(2048);
				writtenBytes = 0;
				flushingPartialBoundaries = !0;
				var partialBoundaries = request.partialBoundaries;
				for (i = 0; i < partialBoundaries.length; i++) {
					var boundary$70 = partialBoundaries[i];
					a: {
						clientRenderedBoundaries = request;
						boundary = destination;
						flushedByteSize = boundary$70.byteSize;
						var completedSegments = boundary$70.completedSegments;
						for (JSCompiler_inline_result = 0; JSCompiler_inline_result < completedSegments.length; JSCompiler_inline_result++) if (!flushPartiallyCompletedSegment(clientRenderedBoundaries, boundary, boundary$70, completedSegments[JSCompiler_inline_result])) {
							JSCompiler_inline_result++;
							completedSegments.splice(0, JSCompiler_inline_result);
							var JSCompiler_inline_result$jscomp$0 = !1;
							break a;
						}
						completedSegments.splice(0, JSCompiler_inline_result);
						var row = boundary$70.row;
						null !== row && row.together && 1 === boundary$70.pendingTasks && (1 === row.pendingTasks ? unblockSuspenseListRow(clientRenderedBoundaries, row, row.hoistables) : row.pendingTasks--);
						JSCompiler_inline_result$jscomp$0 = writeHoistablesForBoundary(boundary, boundary$70.contentState, clientRenderedBoundaries.renderState);
					}
					if (!JSCompiler_inline_result$jscomp$0) {
						request.destination = null;
						i++;
						partialBoundaries.splice(0, i);
						return;
					}
				}
				partialBoundaries.splice(0, i);
				flushingPartialBoundaries = !1;
				var largeBoundaries = request.completedBoundaries;
				for (i = 0; i < largeBoundaries.length; i++) if (!flushCompletedBoundary(request, destination, largeBoundaries[i])) {
					request.destination = null;
					i++;
					largeBoundaries.splice(0, i);
					return;
				}
				largeBoundaries.splice(0, i);
			}
		} finally {
			flushingPartialBoundaries = !1, 0 === request.allPendingTasks && 0 === request.clientRenderedBoundaries.length && 0 === request.completedBoundaries.length ? (request.flushScheduled = !1, i = request.resumableState, i.hasBody && writeChunk(destination, endChunkForTag("body")), i.hasHtml && writeChunk(destination, endChunkForTag("html")), completeWriting(destination), request.status = 14, destination.close(), request.destination = null) : completeWriting(destination);
		}
	}
	function startWork(request) {
		request.flushScheduled = null !== request.destination;
		supportsRequestStorage ? scheduleMicrotask(function() {
			return requestStorage.run(request, performWork, request);
		}) : scheduleMicrotask(function() {
			return performWork(request);
		});
		setTimeout(function() {
			10 === request.status && (request.status = 11);
			null === request.trackedPostpones && (supportsRequestStorage ? requestStorage.run(request, enqueueEarlyPreloadsAfterInitialWork, request) : enqueueEarlyPreloadsAfterInitialWork(request));
		}, 0);
	}
	function enqueueEarlyPreloadsAfterInitialWork(request) {
		safelyEmitEarlyPreloads(request, 0 === request.pendingRootTasks);
	}
	function enqueueFlush(request) {
		!1 === request.flushScheduled && 0 === request.pingedTasks.length && null !== request.destination && (request.flushScheduled = !0, setTimeout(function() {
			var destination = request.destination;
			destination ? flushCompletedQueues(request, destination) : request.flushScheduled = !1;
		}, 0));
	}
	function startFlowing(request, destination) {
		if (13 === request.status) request.status = 14, closeWithError(destination, request.fatalError);
		else if (14 !== request.status && null === request.destination) {
			request.destination = destination;
			try {
				flushCompletedQueues(request, destination);
			} catch (error) {
				logRecoverableError(request, error, {}), fatalError(request, error);
			}
		}
	}
	function abort(request, reason) {
		if (11 === request.status || 10 === request.status) request.status = 12;
		try {
			var abortableTasks = request.abortableTasks;
			if (0 < abortableTasks.size) {
				var error = void 0 === reason ? Error("The render was aborted by the server without a reason.") : "object" === typeof reason && null !== reason && "function" === typeof reason.then ? Error("The render was aborted by the server with a promise.") : reason;
				request.fatalError = error;
				abortableTasks.forEach(function(task) {
					return abortTask(task, request, error);
				});
				abortableTasks.clear();
			}
			null !== request.destination && flushCompletedQueues(request, request.destination);
		} catch (error$72) {
			logRecoverableError(request, error$72, {}), fatalError(request, error$72);
		}
	}
	function addToReplayParent(node, parentKeyPath, trackedPostpones) {
		if (null === parentKeyPath) trackedPostpones.rootNodes.push(node);
		else {
			var workingMap = trackedPostpones.workingMap, parentNode = workingMap.get(parentKeyPath);
			void 0 === parentNode && (parentNode = [
				parentKeyPath[1],
				parentKeyPath[2],
				[],
				null
			], workingMap.set(parentKeyPath, parentNode), addToReplayParent(parentNode, parentKeyPath[0], trackedPostpones));
			parentNode[2].push(node);
		}
	}
	function getPostponedState(request) {
		var trackedPostpones = request.trackedPostpones;
		if (null === trackedPostpones || 0 === trackedPostpones.rootNodes.length && null === trackedPostpones.rootSlots) return request.trackedPostpones = null;
		if (null === request.completedRootSegment || 5 !== request.completedRootSegment.status && null !== request.completedPreambleSegments) {
			var nextSegmentId = request.nextSegmentId;
			var replaySlots = trackedPostpones.rootSlots;
			var resumableState = request.resumableState;
			resumableState.bootstrapScriptContent = void 0;
			resumableState.bootstrapScripts = void 0;
			resumableState.bootstrapModules = void 0;
		} else {
			nextSegmentId = 0;
			replaySlots = -1;
			resumableState = request.resumableState;
			var renderState = request.renderState;
			resumableState.nextFormID = 0;
			resumableState.hasBody = !1;
			resumableState.hasHtml = !1;
			resumableState.unknownResources = { font: renderState.resets.font };
			resumableState.dnsResources = renderState.resets.dns;
			resumableState.connectResources = renderState.resets.connect;
			resumableState.imageResources = renderState.resets.image;
			resumableState.styleResources = renderState.resets.style;
			resumableState.scriptResources = {};
			resumableState.moduleUnknownResources = {};
			resumableState.moduleScriptResources = {};
			resumableState.instructions = 0;
		}
		return {
			nextSegmentId,
			rootFormatContext: request.rootFormatContext,
			progressiveChunkSize: request.progressiveChunkSize,
			resumableState: request.resumableState,
			replayNodes: trackedPostpones.rootNodes,
			replaySlots
		};
	}
	function ensureCorrectIsomorphicReactVersion() {
		var isomorphicReactPackageVersion = React.version;
		if ("19.2.5" !== isomorphicReactPackageVersion) throw Error("Incompatible React versions: The \"react\" and \"react-dom\" packages must have the exact same version. Instead got:\n  - react:      " + (isomorphicReactPackageVersion + "\n  - react-dom:  19.2.5\nLearn more: https://react.dev/warnings/version-mismatch"));
	}
	ensureCorrectIsomorphicReactVersion();
	ensureCorrectIsomorphicReactVersion();
	exports.prerender = function(children, options) {
		return new Promise(function(resolve, reject) {
			var onHeaders = options ? options.onHeaders : void 0, onHeadersImpl;
			onHeaders && (onHeadersImpl = function(headersDescriptor) {
				onHeaders(new Headers(headersDescriptor));
			});
			var resources = createResumableState(options ? options.identifierPrefix : void 0, options ? options.unstable_externalRuntimeSrc : void 0, options ? options.bootstrapScriptContent : void 0, options ? options.bootstrapScripts : void 0, options ? options.bootstrapModules : void 0), request = createPrerenderRequest(children, resources, createRenderState(resources, void 0, options ? options.unstable_externalRuntimeSrc : void 0, options ? options.importMap : void 0, onHeadersImpl, options ? options.maxHeadersLength : void 0), createRootFormatContext(options ? options.namespaceURI : void 0), options ? options.progressiveChunkSize : void 0, options ? options.onError : void 0, function() {
				var stream = new ReadableStream({
					type: "bytes",
					pull: function(controller) {
						startFlowing(request, controller);
					},
					cancel: function(reason) {
						request.destination = null;
						abort(request, reason);
					}
				}, { highWaterMark: 0 });
				stream = {
					postponed: getPostponedState(request),
					prelude: stream
				};
				resolve(stream);
			}, void 0, void 0, reject, options ? options.onPostpone : void 0);
			if (options && options.signal) {
				var signal = options.signal;
				if (signal.aborted) abort(request, signal.reason);
				else {
					var listener = function() {
						abort(request, signal.reason);
						signal.removeEventListener("abort", listener);
					};
					signal.addEventListener("abort", listener);
				}
			}
			startWork(request);
		});
	};
	exports.renderToReadableStream = function(children, options) {
		return new Promise(function(resolve, reject) {
			var onFatalError, onAllReady, allReady = new Promise(function(res, rej) {
				onAllReady = res;
				onFatalError = rej;
			}), onHeaders = options ? options.onHeaders : void 0, onHeadersImpl;
			onHeaders && (onHeadersImpl = function(headersDescriptor) {
				onHeaders(new Headers(headersDescriptor));
			});
			var resumableState = createResumableState(options ? options.identifierPrefix : void 0, options ? options.unstable_externalRuntimeSrc : void 0, options ? options.bootstrapScriptContent : void 0, options ? options.bootstrapScripts : void 0, options ? options.bootstrapModules : void 0), request = createRequest(children, resumableState, createRenderState(resumableState, options ? options.nonce : void 0, options ? options.unstable_externalRuntimeSrc : void 0, options ? options.importMap : void 0, onHeadersImpl, options ? options.maxHeadersLength : void 0), createRootFormatContext(options ? options.namespaceURI : void 0), options ? options.progressiveChunkSize : void 0, options ? options.onError : void 0, onAllReady, function() {
				var stream = new ReadableStream({
					type: "bytes",
					pull: function(controller) {
						startFlowing(request, controller);
					},
					cancel: function(reason) {
						request.destination = null;
						abort(request, reason);
					}
				}, { highWaterMark: 0 });
				stream.allReady = allReady;
				resolve(stream);
			}, function(error) {
				allReady.catch(function() {});
				reject(error);
			}, onFatalError, options ? options.onPostpone : void 0, options ? options.formState : void 0);
			if (options && options.signal) {
				var signal = options.signal;
				if (signal.aborted) abort(request, signal.reason);
				else {
					var listener = function() {
						abort(request, signal.reason);
						signal.removeEventListener("abort", listener);
					};
					signal.addEventListener("abort", listener);
				}
			}
			startWork(request);
		});
	};
	exports.resume = function(children, postponedState, options) {
		return new Promise(function(resolve, reject) {
			var onFatalError, onAllReady, allReady = new Promise(function(res, rej) {
				onAllReady = res;
				onFatalError = rej;
			}), request = resumeRequest(children, postponedState, createRenderState(postponedState.resumableState, options ? options.nonce : void 0, void 0, void 0, void 0, void 0), options ? options.onError : void 0, onAllReady, function() {
				var stream = new ReadableStream({
					type: "bytes",
					pull: function(controller) {
						startFlowing(request, controller);
					},
					cancel: function(reason) {
						request.destination = null;
						abort(request, reason);
					}
				}, { highWaterMark: 0 });
				stream.allReady = allReady;
				resolve(stream);
			}, function(error) {
				allReady.catch(function() {});
				reject(error);
			}, onFatalError, options ? options.onPostpone : void 0);
			if (options && options.signal) {
				var signal = options.signal;
				if (signal.aborted) abort(request, signal.reason);
				else {
					var listener = function() {
						abort(request, signal.reason);
						signal.removeEventListener("abort", listener);
					};
					signal.addEventListener("abort", listener);
				}
			}
			startWork(request);
		});
	};
	exports.resumeAndPrerender = function(children, postponedState, options) {
		return new Promise(function(resolve, reject) {
			var request = resumeAndPrerenderRequest(children, postponedState, createRenderState(postponedState.resumableState, void 0, void 0, void 0, void 0, void 0), options ? options.onError : void 0, function() {
				var stream = new ReadableStream({
					type: "bytes",
					pull: function(controller) {
						startFlowing(request, controller);
					},
					cancel: function(reason) {
						request.destination = null;
						abort(request, reason);
					}
				}, { highWaterMark: 0 });
				stream = {
					postponed: getPostponedState(request),
					prelude: stream
				};
				resolve(stream);
			}, void 0, void 0, reject, options ? options.onPostpone : void 0);
			if (options && options.signal) {
				var signal = options.signal;
				if (signal.aborted) abort(request, signal.reason);
				else {
					var listener = function() {
						abort(request, signal.reason);
						signal.removeEventListener("abort", listener);
					};
					signal.addEventListener("abort", listener);
				}
			}
			startWork(request);
		});
	};
	exports.version = "19.2.5";
}));
//#endregion
//#region node_modules/.pnpm/react-dom@19.2.5_react@19.2.5/node_modules/react-dom/cjs/react-dom-server-legacy.browser.production.js
/**
* @license React
* react-dom-server-legacy.browser.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_dom_server_legacy_browser_production = /* @__PURE__ */ __commonJSMin(((exports) => {
	var React = require_react(), ReactDOM = require_react_dom();
	function formatProdErrorMessage(code) {
		var url = "https://react.dev/errors/" + code;
		if (1 < arguments.length) {
			url += "?args[]=" + encodeURIComponent(arguments[1]);
			for (var i = 2; i < arguments.length; i++) url += "&args[]=" + encodeURIComponent(arguments[i]);
		}
		return "Minified React error #" + code + "; visit " + url + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
	}
	var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_SCOPE_TYPE = Symbol.for("react.scope"), REACT_ACTIVITY_TYPE = Symbol.for("react.activity"), REACT_LEGACY_HIDDEN_TYPE = Symbol.for("react.legacy_hidden"), REACT_MEMO_CACHE_SENTINEL = Symbol.for("react.memo_cache_sentinel"), REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition"), MAYBE_ITERATOR_SYMBOL = Symbol.iterator;
	function getIteratorFn(maybeIterable) {
		if (null === maybeIterable || "object" !== typeof maybeIterable) return null;
		maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
		return "function" === typeof maybeIterable ? maybeIterable : null;
	}
	var isArrayImpl = Array.isArray;
	function murmurhash3_32_gc(key, seed) {
		var remainder = key.length & 3;
		var bytes = key.length - remainder;
		var h1 = seed;
		for (seed = 0; seed < bytes;) {
			var k1 = key.charCodeAt(seed) & 255 | (key.charCodeAt(++seed) & 255) << 8 | (key.charCodeAt(++seed) & 255) << 16 | (key.charCodeAt(++seed) & 255) << 24;
			++seed;
			k1 = 3432918353 * (k1 & 65535) + ((3432918353 * (k1 >>> 16) & 65535) << 16) & 4294967295;
			k1 = k1 << 15 | k1 >>> 17;
			k1 = 461845907 * (k1 & 65535) + ((461845907 * (k1 >>> 16) & 65535) << 16) & 4294967295;
			h1 ^= k1;
			h1 = h1 << 13 | h1 >>> 19;
			h1 = 5 * (h1 & 65535) + ((5 * (h1 >>> 16) & 65535) << 16) & 4294967295;
			h1 = (h1 & 65535) + 27492 + (((h1 >>> 16) + 58964 & 65535) << 16);
		}
		k1 = 0;
		switch (remainder) {
			case 3: k1 ^= (key.charCodeAt(seed + 2) & 255) << 16;
			case 2: k1 ^= (key.charCodeAt(seed + 1) & 255) << 8;
			case 1: k1 ^= key.charCodeAt(seed) & 255, k1 = 3432918353 * (k1 & 65535) + ((3432918353 * (k1 >>> 16) & 65535) << 16) & 4294967295, k1 = k1 << 15 | k1 >>> 17, h1 ^= 461845907 * (k1 & 65535) + ((461845907 * (k1 >>> 16) & 65535) << 16) & 4294967295;
		}
		h1 ^= key.length;
		h1 ^= h1 >>> 16;
		h1 = 2246822507 * (h1 & 65535) + ((2246822507 * (h1 >>> 16) & 65535) << 16) & 4294967295;
		h1 ^= h1 >>> 13;
		h1 = 3266489909 * (h1 & 65535) + ((3266489909 * (h1 >>> 16) & 65535) << 16) & 4294967295;
		return (h1 ^ h1 >>> 16) >>> 0;
	}
	var assign = Object.assign, hasOwnProperty = Object.prototype.hasOwnProperty, VALID_ATTRIBUTE_NAME_REGEX = RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"), illegalAttributeNameCache = {}, validatedAttributeNameCache = {};
	function isAttributeNameSafe(attributeName) {
		if (hasOwnProperty.call(validatedAttributeNameCache, attributeName)) return !0;
		if (hasOwnProperty.call(illegalAttributeNameCache, attributeName)) return !1;
		if (VALID_ATTRIBUTE_NAME_REGEX.test(attributeName)) return validatedAttributeNameCache[attributeName] = !0;
		illegalAttributeNameCache[attributeName] = !0;
		return !1;
	}
	var unitlessNumbers = new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" ")), aliases = new Map([
		["acceptCharset", "accept-charset"],
		["htmlFor", "for"],
		["httpEquiv", "http-equiv"],
		["crossOrigin", "crossorigin"],
		["accentHeight", "accent-height"],
		["alignmentBaseline", "alignment-baseline"],
		["arabicForm", "arabic-form"],
		["baselineShift", "baseline-shift"],
		["capHeight", "cap-height"],
		["clipPath", "clip-path"],
		["clipRule", "clip-rule"],
		["colorInterpolation", "color-interpolation"],
		["colorInterpolationFilters", "color-interpolation-filters"],
		["colorProfile", "color-profile"],
		["colorRendering", "color-rendering"],
		["dominantBaseline", "dominant-baseline"],
		["enableBackground", "enable-background"],
		["fillOpacity", "fill-opacity"],
		["fillRule", "fill-rule"],
		["floodColor", "flood-color"],
		["floodOpacity", "flood-opacity"],
		["fontFamily", "font-family"],
		["fontSize", "font-size"],
		["fontSizeAdjust", "font-size-adjust"],
		["fontStretch", "font-stretch"],
		["fontStyle", "font-style"],
		["fontVariant", "font-variant"],
		["fontWeight", "font-weight"],
		["glyphName", "glyph-name"],
		["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
		["glyphOrientationVertical", "glyph-orientation-vertical"],
		["horizAdvX", "horiz-adv-x"],
		["horizOriginX", "horiz-origin-x"],
		["imageRendering", "image-rendering"],
		["letterSpacing", "letter-spacing"],
		["lightingColor", "lighting-color"],
		["markerEnd", "marker-end"],
		["markerMid", "marker-mid"],
		["markerStart", "marker-start"],
		["overlinePosition", "overline-position"],
		["overlineThickness", "overline-thickness"],
		["paintOrder", "paint-order"],
		["panose-1", "panose-1"],
		["pointerEvents", "pointer-events"],
		["renderingIntent", "rendering-intent"],
		["shapeRendering", "shape-rendering"],
		["stopColor", "stop-color"],
		["stopOpacity", "stop-opacity"],
		["strikethroughPosition", "strikethrough-position"],
		["strikethroughThickness", "strikethrough-thickness"],
		["strokeDasharray", "stroke-dasharray"],
		["strokeDashoffset", "stroke-dashoffset"],
		["strokeLinecap", "stroke-linecap"],
		["strokeLinejoin", "stroke-linejoin"],
		["strokeMiterlimit", "stroke-miterlimit"],
		["strokeOpacity", "stroke-opacity"],
		["strokeWidth", "stroke-width"],
		["textAnchor", "text-anchor"],
		["textDecoration", "text-decoration"],
		["textRendering", "text-rendering"],
		["transformOrigin", "transform-origin"],
		["underlinePosition", "underline-position"],
		["underlineThickness", "underline-thickness"],
		["unicodeBidi", "unicode-bidi"],
		["unicodeRange", "unicode-range"],
		["unitsPerEm", "units-per-em"],
		["vAlphabetic", "v-alphabetic"],
		["vHanging", "v-hanging"],
		["vIdeographic", "v-ideographic"],
		["vMathematical", "v-mathematical"],
		["vectorEffect", "vector-effect"],
		["vertAdvY", "vert-adv-y"],
		["vertOriginX", "vert-origin-x"],
		["vertOriginY", "vert-origin-y"],
		["wordSpacing", "word-spacing"],
		["writingMode", "writing-mode"],
		["xmlnsXlink", "xmlns:xlink"],
		["xHeight", "x-height"]
	]), matchHtmlRegExp = /["'&<>]/;
	function escapeTextForBrowser(text) {
		if ("boolean" === typeof text || "number" === typeof text || "bigint" === typeof text) return "" + text;
		text = "" + text;
		var match = matchHtmlRegExp.exec(text);
		if (match) {
			var html = "", index, lastIndex = 0;
			for (index = match.index; index < text.length; index++) {
				switch (text.charCodeAt(index)) {
					case 34:
						match = "&quot;";
						break;
					case 38:
						match = "&amp;";
						break;
					case 39:
						match = "&#x27;";
						break;
					case 60:
						match = "&lt;";
						break;
					case 62:
						match = "&gt;";
						break;
					default: continue;
				}
				lastIndex !== index && (html += text.slice(lastIndex, index));
				lastIndex = index + 1;
				html += match;
			}
			text = lastIndex !== index ? html + text.slice(lastIndex, index) : html;
		}
		return text;
	}
	var uppercasePattern = /([A-Z])/g, msPattern = /^ms-/, isJavaScriptProtocol = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
	function sanitizeURL(url) {
		return isJavaScriptProtocol.test("" + url) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : url;
	}
	var ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, ReactDOMSharedInternals = ReactDOM.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, sharedNotPendingObject = {
		pending: !1,
		data: null,
		method: null,
		action: null
	}, previousDispatcher = ReactDOMSharedInternals.d;
	ReactDOMSharedInternals.d = {
		f: previousDispatcher.f,
		r: previousDispatcher.r,
		D: prefetchDNS,
		C: preconnect,
		L: preload,
		m: preloadModule,
		X: preinitScript,
		S: preinitStyle,
		M: preinitModuleScript
	};
	var PRELOAD_NO_CREDS = [], currentlyFlushingRenderState = null, scriptRegex = /(<\/|<)(s)(cript)/gi;
	function scriptReplacer(match, prefix, s, suffix) {
		return "" + prefix + ("s" === s ? "\\u0073" : "\\u0053") + suffix;
	}
	function createResumableState(identifierPrefix, externalRuntimeConfig, bootstrapScriptContent, bootstrapScripts, bootstrapModules) {
		return {
			idPrefix: void 0 === identifierPrefix ? "" : identifierPrefix,
			nextFormID: 0,
			streamingFormat: 0,
			bootstrapScriptContent,
			bootstrapScripts,
			bootstrapModules,
			instructions: 0,
			hasBody: !1,
			hasHtml: !1,
			unknownResources: {},
			dnsResources: {},
			connectResources: {
				default: {},
				anonymous: {},
				credentials: {}
			},
			imageResources: {},
			styleResources: {},
			scriptResources: {},
			moduleUnknownResources: {},
			moduleScriptResources: {}
		};
	}
	function createFormatContext(insertionMode, selectedValue, tagScope, viewTransition) {
		return {
			insertionMode,
			selectedValue,
			tagScope,
			viewTransition
		};
	}
	function getChildFormatContext(parentContext, type, props) {
		var subtreeScope = parentContext.tagScope & -25;
		switch (type) {
			case "noscript": return createFormatContext(2, null, subtreeScope | 1, null);
			case "select": return createFormatContext(2, null != props.value ? props.value : props.defaultValue, subtreeScope, null);
			case "svg": return createFormatContext(4, null, subtreeScope, null);
			case "picture": return createFormatContext(2, null, subtreeScope | 2, null);
			case "math": return createFormatContext(5, null, subtreeScope, null);
			case "foreignObject": return createFormatContext(2, null, subtreeScope, null);
			case "table": return createFormatContext(6, null, subtreeScope, null);
			case "thead":
			case "tbody":
			case "tfoot": return createFormatContext(7, null, subtreeScope, null);
			case "colgroup": return createFormatContext(9, null, subtreeScope, null);
			case "tr": return createFormatContext(8, null, subtreeScope, null);
			case "head":
				if (2 > parentContext.insertionMode) return createFormatContext(3, null, subtreeScope, null);
				break;
			case "html": if (0 === parentContext.insertionMode) return createFormatContext(1, null, subtreeScope, null);
		}
		return 6 <= parentContext.insertionMode || 2 > parentContext.insertionMode ? createFormatContext(2, null, subtreeScope, null) : parentContext.tagScope !== subtreeScope ? createFormatContext(parentContext.insertionMode, parentContext.selectedValue, subtreeScope, null) : parentContext;
	}
	function getSuspenseViewTransition(parentViewTransition) {
		return null === parentViewTransition ? null : {
			update: parentViewTransition.update,
			enter: "none",
			exit: "none",
			share: parentViewTransition.update,
			name: parentViewTransition.autoName,
			autoName: parentViewTransition.autoName,
			nameIdx: 0
		};
	}
	function getSuspenseFallbackFormatContext(resumableState, parentContext) {
		parentContext.tagScope & 32 && (resumableState.instructions |= 128);
		return createFormatContext(parentContext.insertionMode, parentContext.selectedValue, parentContext.tagScope | 12, getSuspenseViewTransition(parentContext.viewTransition));
	}
	function getSuspenseContentFormatContext(resumableState, parentContext) {
		resumableState = getSuspenseViewTransition(parentContext.viewTransition);
		var subtreeScope = parentContext.tagScope | 16;
		null !== resumableState && "none" !== resumableState.share && (subtreeScope |= 64);
		return createFormatContext(parentContext.insertionMode, parentContext.selectedValue, subtreeScope, resumableState);
	}
	var styleNameCache = /* @__PURE__ */ new Map();
	function pushStyleAttribute(target, style) {
		if ("object" !== typeof style) throw Error(formatProdErrorMessage(62));
		var isFirst = !0, styleName;
		for (styleName in style) if (hasOwnProperty.call(style, styleName)) {
			var styleValue = style[styleName];
			if (null != styleValue && "boolean" !== typeof styleValue && "" !== styleValue) {
				if (0 === styleName.indexOf("--")) {
					var nameChunk = escapeTextForBrowser(styleName);
					styleValue = escapeTextForBrowser(("" + styleValue).trim());
				} else nameChunk = styleNameCache.get(styleName), void 0 === nameChunk && (nameChunk = escapeTextForBrowser(styleName.replace(uppercasePattern, "-$1").toLowerCase().replace(msPattern, "-ms-")), styleNameCache.set(styleName, nameChunk)), styleValue = "number" === typeof styleValue ? 0 === styleValue || unitlessNumbers.has(styleName) ? "" + styleValue : styleValue + "px" : escapeTextForBrowser(("" + styleValue).trim());
				isFirst ? (isFirst = !1, target.push(" style=\"", nameChunk, ":", styleValue)) : target.push(";", nameChunk, ":", styleValue);
			}
		}
		isFirst || target.push("\"");
	}
	function pushBooleanAttribute(target, name, value) {
		value && "function" !== typeof value && "symbol" !== typeof value && target.push(" ", name, "=\"\"");
	}
	function pushStringAttribute(target, name, value) {
		"function" !== typeof value && "symbol" !== typeof value && "boolean" !== typeof value && target.push(" ", name, "=\"", escapeTextForBrowser(value), "\"");
	}
	var actionJavaScriptURL = escapeTextForBrowser("javascript:throw new Error('React form unexpectedly submitted.')");
	function pushAdditionalFormField(value, key) {
		this.push("<input type=\"hidden\"");
		validateAdditionalFormField(value);
		pushStringAttribute(this, "name", key);
		pushStringAttribute(this, "value", value);
		this.push("/>");
	}
	function validateAdditionalFormField(value) {
		if ("string" !== typeof value) throw Error(formatProdErrorMessage(480));
	}
	function getCustomFormFields(resumableState, formAction) {
		if ("function" === typeof formAction.$$FORM_ACTION) {
			var id = resumableState.nextFormID++;
			resumableState = resumableState.idPrefix + id;
			try {
				var customFields = formAction.$$FORM_ACTION(resumableState);
				if (customFields) customFields.data?.forEach(validateAdditionalFormField);
				return customFields;
			} catch (x) {
				if ("object" === typeof x && null !== x && "function" === typeof x.then) throw x;
			}
		}
		return null;
	}
	function pushFormActionAttribute(target, resumableState, renderState, formAction, formEncType, formMethod, formTarget, name) {
		var formData = null;
		if ("function" === typeof formAction) {
			var customFields = getCustomFormFields(resumableState, formAction);
			null !== customFields ? (name = customFields.name, formAction = customFields.action || "", formEncType = customFields.encType, formMethod = customFields.method, formTarget = customFields.target, formData = customFields.data) : (target.push(" ", "formAction", "=\"", actionJavaScriptURL, "\""), formTarget = formMethod = formEncType = formAction = name = null, injectFormReplayingRuntime(resumableState, renderState));
		}
		null != name && pushAttribute(target, "name", name);
		null != formAction && pushAttribute(target, "formAction", formAction);
		null != formEncType && pushAttribute(target, "formEncType", formEncType);
		null != formMethod && pushAttribute(target, "formMethod", formMethod);
		null != formTarget && pushAttribute(target, "formTarget", formTarget);
		return formData;
	}
	function pushAttribute(target, name, value) {
		switch (name) {
			case "className":
				pushStringAttribute(target, "class", value);
				break;
			case "tabIndex":
				pushStringAttribute(target, "tabindex", value);
				break;
			case "dir":
			case "role":
			case "viewBox":
			case "width":
			case "height":
				pushStringAttribute(target, name, value);
				break;
			case "style":
				pushStyleAttribute(target, value);
				break;
			case "src":
			case "href": if ("" === value) break;
			case "action":
			case "formAction":
				if (null == value || "function" === typeof value || "symbol" === typeof value || "boolean" === typeof value) break;
				value = sanitizeURL("" + value);
				target.push(" ", name, "=\"", escapeTextForBrowser(value), "\"");
				break;
			case "defaultValue":
			case "defaultChecked":
			case "innerHTML":
			case "suppressContentEditableWarning":
			case "suppressHydrationWarning":
			case "ref": break;
			case "autoFocus":
			case "multiple":
			case "muted":
				pushBooleanAttribute(target, name.toLowerCase(), value);
				break;
			case "xlinkHref":
				if ("function" === typeof value || "symbol" === typeof value || "boolean" === typeof value) break;
				value = sanitizeURL("" + value);
				target.push(" ", "xlink:href", "=\"", escapeTextForBrowser(value), "\"");
				break;
			case "contentEditable":
			case "spellCheck":
			case "draggable":
			case "value":
			case "autoReverse":
			case "externalResourcesRequired":
			case "focusable":
			case "preserveAlpha":
				"function" !== typeof value && "symbol" !== typeof value && target.push(" ", name, "=\"", escapeTextForBrowser(value), "\"");
				break;
			case "inert":
			case "allowFullScreen":
			case "async":
			case "autoPlay":
			case "controls":
			case "default":
			case "defer":
			case "disabled":
			case "disablePictureInPicture":
			case "disableRemotePlayback":
			case "formNoValidate":
			case "hidden":
			case "loop":
			case "noModule":
			case "noValidate":
			case "open":
			case "playsInline":
			case "readOnly":
			case "required":
			case "reversed":
			case "scoped":
			case "seamless":
			case "itemScope":
				value && "function" !== typeof value && "symbol" !== typeof value && target.push(" ", name, "=\"\"");
				break;
			case "capture":
			case "download":
				!0 === value ? target.push(" ", name, "=\"\"") : !1 !== value && "function" !== typeof value && "symbol" !== typeof value && target.push(" ", name, "=\"", escapeTextForBrowser(value), "\"");
				break;
			case "cols":
			case "rows":
			case "size":
			case "span":
				"function" !== typeof value && "symbol" !== typeof value && !isNaN(value) && 1 <= value && target.push(" ", name, "=\"", escapeTextForBrowser(value), "\"");
				break;
			case "rowSpan":
			case "start":
				"function" === typeof value || "symbol" === typeof value || isNaN(value) || target.push(" ", name, "=\"", escapeTextForBrowser(value), "\"");
				break;
			case "xlinkActuate":
				pushStringAttribute(target, "xlink:actuate", value);
				break;
			case "xlinkArcrole":
				pushStringAttribute(target, "xlink:arcrole", value);
				break;
			case "xlinkRole":
				pushStringAttribute(target, "xlink:role", value);
				break;
			case "xlinkShow":
				pushStringAttribute(target, "xlink:show", value);
				break;
			case "xlinkTitle":
				pushStringAttribute(target, "xlink:title", value);
				break;
			case "xlinkType":
				pushStringAttribute(target, "xlink:type", value);
				break;
			case "xmlBase":
				pushStringAttribute(target, "xml:base", value);
				break;
			case "xmlLang":
				pushStringAttribute(target, "xml:lang", value);
				break;
			case "xmlSpace":
				pushStringAttribute(target, "xml:space", value);
				break;
			default: if (!(2 < name.length) || "o" !== name[0] && "O" !== name[0] || "n" !== name[1] && "N" !== name[1]) {
				if (name = aliases.get(name) || name, isAttributeNameSafe(name)) {
					switch (typeof value) {
						case "function":
						case "symbol": return;
						case "boolean":
							var prefix$8 = name.toLowerCase().slice(0, 5);
							if ("data-" !== prefix$8 && "aria-" !== prefix$8) return;
					}
					target.push(" ", name, "=\"", escapeTextForBrowser(value), "\"");
				}
			}
		}
	}
	function pushInnerHTML(target, innerHTML, children) {
		if (null != innerHTML) {
			if (null != children) throw Error(formatProdErrorMessage(60));
			if ("object" !== typeof innerHTML || !("__html" in innerHTML)) throw Error(formatProdErrorMessage(61));
			innerHTML = innerHTML.__html;
			null !== innerHTML && void 0 !== innerHTML && target.push("" + innerHTML);
		}
	}
	function flattenOptionChildren(children) {
		var content = "";
		React.Children.forEach(children, function(child) {
			null != child && (content += child);
		});
		return content;
	}
	function injectFormReplayingRuntime(resumableState, renderState) {
		if (0 === (resumableState.instructions & 16)) {
			resumableState.instructions |= 16;
			var preamble = renderState.preamble, bootstrapChunks = renderState.bootstrapChunks;
			(preamble.htmlChunks || preamble.headChunks) && 0 === bootstrapChunks.length ? (bootstrapChunks.push(renderState.startInlineScript), pushCompletedShellIdAttribute(bootstrapChunks, resumableState), bootstrapChunks.push(">", "addEventListener(\"submit\",function(a){if(!a.defaultPrevented){var c=a.target,d=a.submitter,e=c.action,b=d;if(d){var f=d.getAttribute(\"formAction\");null!=f&&(e=f,b=null)}\"javascript:throw new Error('React form unexpectedly submitted.')\"===e&&(a.preventDefault(),b?(a=document.createElement(\"input\"),a.name=b.name,a.value=b.value,b.parentNode.insertBefore(a,b),b=new FormData(c),a.parentNode.removeChild(a)):b=new FormData(c),a=c.ownerDocument||c,(a.$$reactFormReplay=a.$$reactFormReplay||[]).push(c,d,b))}});", "<\/script>")) : bootstrapChunks.unshift(renderState.startInlineScript, ">", "addEventListener(\"submit\",function(a){if(!a.defaultPrevented){var c=a.target,d=a.submitter,e=c.action,b=d;if(d){var f=d.getAttribute(\"formAction\");null!=f&&(e=f,b=null)}\"javascript:throw new Error('React form unexpectedly submitted.')\"===e&&(a.preventDefault(),b?(a=document.createElement(\"input\"),a.name=b.name,a.value=b.value,b.parentNode.insertBefore(a,b),b=new FormData(c),a.parentNode.removeChild(a)):b=new FormData(c),a=c.ownerDocument||c,(a.$$reactFormReplay=a.$$reactFormReplay||[]).push(c,d,b))}});", "<\/script>");
		}
	}
	function pushLinkImpl(target, props) {
		target.push(startChunkForTag("link"));
		for (var propKey in props) if (hasOwnProperty.call(props, propKey)) {
			var propValue = props[propKey];
			if (null != propValue) switch (propKey) {
				case "children":
				case "dangerouslySetInnerHTML": throw Error(formatProdErrorMessage(399, "link"));
				default: pushAttribute(target, propKey, propValue);
			}
		}
		target.push("/>");
		return null;
	}
	var styleRegex = /(<\/|<)(s)(tyle)/gi;
	function styleReplacer(match, prefix, s, suffix) {
		return "" + prefix + ("s" === s ? "\\73 " : "\\53 ") + suffix;
	}
	function pushSelfClosing(target, props, tag) {
		target.push(startChunkForTag(tag));
		for (var propKey in props) if (hasOwnProperty.call(props, propKey)) {
			var propValue = props[propKey];
			if (null != propValue) switch (propKey) {
				case "children":
				case "dangerouslySetInnerHTML": throw Error(formatProdErrorMessage(399, tag));
				default: pushAttribute(target, propKey, propValue);
			}
		}
		target.push("/>");
		return null;
	}
	function pushTitleImpl(target, props) {
		target.push(startChunkForTag("title"));
		var children = null, innerHTML = null, propKey;
		for (propKey in props) if (hasOwnProperty.call(props, propKey)) {
			var propValue = props[propKey];
			if (null != propValue) switch (propKey) {
				case "children":
					children = propValue;
					break;
				case "dangerouslySetInnerHTML":
					innerHTML = propValue;
					break;
				default: pushAttribute(target, propKey, propValue);
			}
		}
		target.push(">");
		props = Array.isArray(children) ? 2 > children.length ? children[0] : null : children;
		"function" !== typeof props && "symbol" !== typeof props && null !== props && void 0 !== props && target.push(escapeTextForBrowser("" + props));
		pushInnerHTML(target, innerHTML, children);
		target.push(endChunkForTag("title"));
		return null;
	}
	function pushScriptImpl(target, props) {
		target.push(startChunkForTag("script"));
		var children = null, innerHTML = null, propKey;
		for (propKey in props) if (hasOwnProperty.call(props, propKey)) {
			var propValue = props[propKey];
			if (null != propValue) switch (propKey) {
				case "children":
					children = propValue;
					break;
				case "dangerouslySetInnerHTML":
					innerHTML = propValue;
					break;
				default: pushAttribute(target, propKey, propValue);
			}
		}
		target.push(">");
		pushInnerHTML(target, innerHTML, children);
		"string" === typeof children && target.push(("" + children).replace(scriptRegex, scriptReplacer));
		target.push(endChunkForTag("script"));
		return null;
	}
	function pushStartSingletonElement(target, props, tag) {
		target.push(startChunkForTag(tag));
		var innerHTML = tag = null, propKey;
		for (propKey in props) if (hasOwnProperty.call(props, propKey)) {
			var propValue = props[propKey];
			if (null != propValue) switch (propKey) {
				case "children":
					tag = propValue;
					break;
				case "dangerouslySetInnerHTML":
					innerHTML = propValue;
					break;
				default: pushAttribute(target, propKey, propValue);
			}
		}
		target.push(">");
		pushInnerHTML(target, innerHTML, tag);
		return tag;
	}
	function pushStartGenericElement(target, props, tag) {
		target.push(startChunkForTag(tag));
		var innerHTML = tag = null, propKey;
		for (propKey in props) if (hasOwnProperty.call(props, propKey)) {
			var propValue = props[propKey];
			if (null != propValue) switch (propKey) {
				case "children":
					tag = propValue;
					break;
				case "dangerouslySetInnerHTML":
					innerHTML = propValue;
					break;
				default: pushAttribute(target, propKey, propValue);
			}
		}
		target.push(">");
		pushInnerHTML(target, innerHTML, tag);
		return "string" === typeof tag ? (target.push(escapeTextForBrowser(tag)), null) : tag;
	}
	var VALID_TAG_REGEX = /^[a-zA-Z][a-zA-Z:_\.\-\d]*$/, validatedTagCache = /* @__PURE__ */ new Map();
	function startChunkForTag(tag) {
		var tagStartChunk = validatedTagCache.get(tag);
		if (void 0 === tagStartChunk) {
			if (!VALID_TAG_REGEX.test(tag)) throw Error(formatProdErrorMessage(65, tag));
			tagStartChunk = "<" + tag;
			validatedTagCache.set(tag, tagStartChunk);
		}
		return tagStartChunk;
	}
	function pushStartInstance(target$jscomp$0, type, props, resumableState, renderState, preambleState, hoistableState, formatContext, textEmbedded) {
		switch (type) {
			case "div":
			case "span":
			case "svg":
			case "path": break;
			case "a":
				target$jscomp$0.push(startChunkForTag("a"));
				var children = null, innerHTML = null, propKey;
				for (propKey in props) if (hasOwnProperty.call(props, propKey)) {
					var propValue = props[propKey];
					if (null != propValue) switch (propKey) {
						case "children":
							children = propValue;
							break;
						case "dangerouslySetInnerHTML":
							innerHTML = propValue;
							break;
						case "href":
							"" === propValue ? pushStringAttribute(target$jscomp$0, "href", "") : pushAttribute(target$jscomp$0, propKey, propValue);
							break;
						default: pushAttribute(target$jscomp$0, propKey, propValue);
					}
				}
				target$jscomp$0.push(">");
				pushInnerHTML(target$jscomp$0, innerHTML, children);
				if ("string" === typeof children) {
					target$jscomp$0.push(escapeTextForBrowser(children));
					var JSCompiler_inline_result = null;
				} else JSCompiler_inline_result = children;
				return JSCompiler_inline_result;
			case "g":
			case "p":
			case "li": break;
			case "select":
				target$jscomp$0.push(startChunkForTag("select"));
				var children$jscomp$0 = null, innerHTML$jscomp$0 = null, propKey$jscomp$0;
				for (propKey$jscomp$0 in props) if (hasOwnProperty.call(props, propKey$jscomp$0)) {
					var propValue$jscomp$0 = props[propKey$jscomp$0];
					if (null != propValue$jscomp$0) switch (propKey$jscomp$0) {
						case "children":
							children$jscomp$0 = propValue$jscomp$0;
							break;
						case "dangerouslySetInnerHTML":
							innerHTML$jscomp$0 = propValue$jscomp$0;
							break;
						case "defaultValue":
						case "value": break;
						default: pushAttribute(target$jscomp$0, propKey$jscomp$0, propValue$jscomp$0);
					}
				}
				target$jscomp$0.push(">");
				pushInnerHTML(target$jscomp$0, innerHTML$jscomp$0, children$jscomp$0);
				return children$jscomp$0;
			case "option":
				var selectedValue = formatContext.selectedValue;
				target$jscomp$0.push(startChunkForTag("option"));
				var children$jscomp$1 = null, value = null, selected = null, innerHTML$jscomp$1 = null, propKey$jscomp$1;
				for (propKey$jscomp$1 in props) if (hasOwnProperty.call(props, propKey$jscomp$1)) {
					var propValue$jscomp$1 = props[propKey$jscomp$1];
					if (null != propValue$jscomp$1) switch (propKey$jscomp$1) {
						case "children":
							children$jscomp$1 = propValue$jscomp$1;
							break;
						case "selected":
							selected = propValue$jscomp$1;
							break;
						case "dangerouslySetInnerHTML":
							innerHTML$jscomp$1 = propValue$jscomp$1;
							break;
						case "value": value = propValue$jscomp$1;
						default: pushAttribute(target$jscomp$0, propKey$jscomp$1, propValue$jscomp$1);
					}
				}
				if (null != selectedValue) {
					var stringValue = null !== value ? "" + value : flattenOptionChildren(children$jscomp$1);
					if (isArrayImpl(selectedValue)) {
						for (var i = 0; i < selectedValue.length; i++) if ("" + selectedValue[i] === stringValue) {
							target$jscomp$0.push(" selected=\"\"");
							break;
						}
					} else "" + selectedValue === stringValue && target$jscomp$0.push(" selected=\"\"");
				} else selected && target$jscomp$0.push(" selected=\"\"");
				target$jscomp$0.push(">");
				pushInnerHTML(target$jscomp$0, innerHTML$jscomp$1, children$jscomp$1);
				return children$jscomp$1;
			case "textarea":
				target$jscomp$0.push(startChunkForTag("textarea"));
				var value$jscomp$0 = null, defaultValue = null, children$jscomp$2 = null, propKey$jscomp$2;
				for (propKey$jscomp$2 in props) if (hasOwnProperty.call(props, propKey$jscomp$2)) {
					var propValue$jscomp$2 = props[propKey$jscomp$2];
					if (null != propValue$jscomp$2) switch (propKey$jscomp$2) {
						case "children":
							children$jscomp$2 = propValue$jscomp$2;
							break;
						case "value":
							value$jscomp$0 = propValue$jscomp$2;
							break;
						case "defaultValue":
							defaultValue = propValue$jscomp$2;
							break;
						case "dangerouslySetInnerHTML": throw Error(formatProdErrorMessage(91));
						default: pushAttribute(target$jscomp$0, propKey$jscomp$2, propValue$jscomp$2);
					}
				}
				null === value$jscomp$0 && null !== defaultValue && (value$jscomp$0 = defaultValue);
				target$jscomp$0.push(">");
				if (null != children$jscomp$2) {
					if (null != value$jscomp$0) throw Error(formatProdErrorMessage(92));
					if (isArrayImpl(children$jscomp$2)) {
						if (1 < children$jscomp$2.length) throw Error(formatProdErrorMessage(93));
						value$jscomp$0 = "" + children$jscomp$2[0];
					}
					value$jscomp$0 = "" + children$jscomp$2;
				}
				"string" === typeof value$jscomp$0 && "\n" === value$jscomp$0[0] && target$jscomp$0.push("\n");
				null !== value$jscomp$0 && target$jscomp$0.push(escapeTextForBrowser("" + value$jscomp$0));
				return null;
			case "input":
				target$jscomp$0.push(startChunkForTag("input"));
				var name = null, formAction = null, formEncType = null, formMethod = null, formTarget = null, value$jscomp$1 = null, defaultValue$jscomp$0 = null, checked = null, defaultChecked = null, propKey$jscomp$3;
				for (propKey$jscomp$3 in props) if (hasOwnProperty.call(props, propKey$jscomp$3)) {
					var propValue$jscomp$3 = props[propKey$jscomp$3];
					if (null != propValue$jscomp$3) switch (propKey$jscomp$3) {
						case "children":
						case "dangerouslySetInnerHTML": throw Error(formatProdErrorMessage(399, "input"));
						case "name":
							name = propValue$jscomp$3;
							break;
						case "formAction":
							formAction = propValue$jscomp$3;
							break;
						case "formEncType":
							formEncType = propValue$jscomp$3;
							break;
						case "formMethod":
							formMethod = propValue$jscomp$3;
							break;
						case "formTarget":
							formTarget = propValue$jscomp$3;
							break;
						case "defaultChecked":
							defaultChecked = propValue$jscomp$3;
							break;
						case "defaultValue":
							defaultValue$jscomp$0 = propValue$jscomp$3;
							break;
						case "checked":
							checked = propValue$jscomp$3;
							break;
						case "value":
							value$jscomp$1 = propValue$jscomp$3;
							break;
						default: pushAttribute(target$jscomp$0, propKey$jscomp$3, propValue$jscomp$3);
					}
				}
				var formData = pushFormActionAttribute(target$jscomp$0, resumableState, renderState, formAction, formEncType, formMethod, formTarget, name);
				null !== checked ? pushBooleanAttribute(target$jscomp$0, "checked", checked) : null !== defaultChecked && pushBooleanAttribute(target$jscomp$0, "checked", defaultChecked);
				null !== value$jscomp$1 ? pushAttribute(target$jscomp$0, "value", value$jscomp$1) : null !== defaultValue$jscomp$0 && pushAttribute(target$jscomp$0, "value", defaultValue$jscomp$0);
				target$jscomp$0.push("/>");
				formData?.forEach(pushAdditionalFormField, target$jscomp$0);
				return null;
			case "button":
				target$jscomp$0.push(startChunkForTag("button"));
				var children$jscomp$3 = null, innerHTML$jscomp$2 = null, name$jscomp$0 = null, formAction$jscomp$0 = null, formEncType$jscomp$0 = null, formMethod$jscomp$0 = null, formTarget$jscomp$0 = null, propKey$jscomp$4;
				for (propKey$jscomp$4 in props) if (hasOwnProperty.call(props, propKey$jscomp$4)) {
					var propValue$jscomp$4 = props[propKey$jscomp$4];
					if (null != propValue$jscomp$4) switch (propKey$jscomp$4) {
						case "children":
							children$jscomp$3 = propValue$jscomp$4;
							break;
						case "dangerouslySetInnerHTML":
							innerHTML$jscomp$2 = propValue$jscomp$4;
							break;
						case "name":
							name$jscomp$0 = propValue$jscomp$4;
							break;
						case "formAction":
							formAction$jscomp$0 = propValue$jscomp$4;
							break;
						case "formEncType":
							formEncType$jscomp$0 = propValue$jscomp$4;
							break;
						case "formMethod":
							formMethod$jscomp$0 = propValue$jscomp$4;
							break;
						case "formTarget":
							formTarget$jscomp$0 = propValue$jscomp$4;
							break;
						default: pushAttribute(target$jscomp$0, propKey$jscomp$4, propValue$jscomp$4);
					}
				}
				var formData$jscomp$0 = pushFormActionAttribute(target$jscomp$0, resumableState, renderState, formAction$jscomp$0, formEncType$jscomp$0, formMethod$jscomp$0, formTarget$jscomp$0, name$jscomp$0);
				target$jscomp$0.push(">");
				formData$jscomp$0?.forEach(pushAdditionalFormField, target$jscomp$0);
				pushInnerHTML(target$jscomp$0, innerHTML$jscomp$2, children$jscomp$3);
				if ("string" === typeof children$jscomp$3) {
					target$jscomp$0.push(escapeTextForBrowser(children$jscomp$3));
					var JSCompiler_inline_result$jscomp$0 = null;
				} else JSCompiler_inline_result$jscomp$0 = children$jscomp$3;
				return JSCompiler_inline_result$jscomp$0;
			case "form":
				target$jscomp$0.push(startChunkForTag("form"));
				var children$jscomp$4 = null, innerHTML$jscomp$3 = null, formAction$jscomp$1 = null, formEncType$jscomp$1 = null, formMethod$jscomp$1 = null, formTarget$jscomp$1 = null, propKey$jscomp$5;
				for (propKey$jscomp$5 in props) if (hasOwnProperty.call(props, propKey$jscomp$5)) {
					var propValue$jscomp$5 = props[propKey$jscomp$5];
					if (null != propValue$jscomp$5) switch (propKey$jscomp$5) {
						case "children":
							children$jscomp$4 = propValue$jscomp$5;
							break;
						case "dangerouslySetInnerHTML":
							innerHTML$jscomp$3 = propValue$jscomp$5;
							break;
						case "action":
							formAction$jscomp$1 = propValue$jscomp$5;
							break;
						case "encType":
							formEncType$jscomp$1 = propValue$jscomp$5;
							break;
						case "method":
							formMethod$jscomp$1 = propValue$jscomp$5;
							break;
						case "target":
							formTarget$jscomp$1 = propValue$jscomp$5;
							break;
						default: pushAttribute(target$jscomp$0, propKey$jscomp$5, propValue$jscomp$5);
					}
				}
				var formData$jscomp$1 = null, formActionName = null;
				if ("function" === typeof formAction$jscomp$1) {
					var customFields = getCustomFormFields(resumableState, formAction$jscomp$1);
					null !== customFields ? (formAction$jscomp$1 = customFields.action || "", formEncType$jscomp$1 = customFields.encType, formMethod$jscomp$1 = customFields.method, formTarget$jscomp$1 = customFields.target, formData$jscomp$1 = customFields.data, formActionName = customFields.name) : (target$jscomp$0.push(" ", "action", "=\"", actionJavaScriptURL, "\""), formTarget$jscomp$1 = formMethod$jscomp$1 = formEncType$jscomp$1 = formAction$jscomp$1 = null, injectFormReplayingRuntime(resumableState, renderState));
				}
				null != formAction$jscomp$1 && pushAttribute(target$jscomp$0, "action", formAction$jscomp$1);
				null != formEncType$jscomp$1 && pushAttribute(target$jscomp$0, "encType", formEncType$jscomp$1);
				null != formMethod$jscomp$1 && pushAttribute(target$jscomp$0, "method", formMethod$jscomp$1);
				null != formTarget$jscomp$1 && pushAttribute(target$jscomp$0, "target", formTarget$jscomp$1);
				target$jscomp$0.push(">");
				null !== formActionName && (target$jscomp$0.push("<input type=\"hidden\""), pushStringAttribute(target$jscomp$0, "name", formActionName), target$jscomp$0.push("/>"), formData$jscomp$1?.forEach(pushAdditionalFormField, target$jscomp$0));
				pushInnerHTML(target$jscomp$0, innerHTML$jscomp$3, children$jscomp$4);
				if ("string" === typeof children$jscomp$4) {
					target$jscomp$0.push(escapeTextForBrowser(children$jscomp$4));
					var JSCompiler_inline_result$jscomp$1 = null;
				} else JSCompiler_inline_result$jscomp$1 = children$jscomp$4;
				return JSCompiler_inline_result$jscomp$1;
			case "menuitem":
				target$jscomp$0.push(startChunkForTag("menuitem"));
				for (var propKey$jscomp$6 in props) if (hasOwnProperty.call(props, propKey$jscomp$6)) {
					var propValue$jscomp$6 = props[propKey$jscomp$6];
					if (null != propValue$jscomp$6) switch (propKey$jscomp$6) {
						case "children":
						case "dangerouslySetInnerHTML": throw Error(formatProdErrorMessage(400));
						default: pushAttribute(target$jscomp$0, propKey$jscomp$6, propValue$jscomp$6);
					}
				}
				target$jscomp$0.push(">");
				return null;
			case "object":
				target$jscomp$0.push(startChunkForTag("object"));
				var children$jscomp$5 = null, innerHTML$jscomp$4 = null, propKey$jscomp$7;
				for (propKey$jscomp$7 in props) if (hasOwnProperty.call(props, propKey$jscomp$7)) {
					var propValue$jscomp$7 = props[propKey$jscomp$7];
					if (null != propValue$jscomp$7) switch (propKey$jscomp$7) {
						case "children":
							children$jscomp$5 = propValue$jscomp$7;
							break;
						case "dangerouslySetInnerHTML":
							innerHTML$jscomp$4 = propValue$jscomp$7;
							break;
						case "data":
							var sanitizedValue = sanitizeURL("" + propValue$jscomp$7);
							if ("" === sanitizedValue) break;
							target$jscomp$0.push(" ", "data", "=\"", escapeTextForBrowser(sanitizedValue), "\"");
							break;
						default: pushAttribute(target$jscomp$0, propKey$jscomp$7, propValue$jscomp$7);
					}
				}
				target$jscomp$0.push(">");
				pushInnerHTML(target$jscomp$0, innerHTML$jscomp$4, children$jscomp$5);
				if ("string" === typeof children$jscomp$5) {
					target$jscomp$0.push(escapeTextForBrowser(children$jscomp$5));
					var JSCompiler_inline_result$jscomp$2 = null;
				} else JSCompiler_inline_result$jscomp$2 = children$jscomp$5;
				return JSCompiler_inline_result$jscomp$2;
			case "title":
				var noscriptTagInScope = formatContext.tagScope & 1, isFallback = formatContext.tagScope & 4;
				if (4 === formatContext.insertionMode || noscriptTagInScope || null != props.itemProp) var JSCompiler_inline_result$jscomp$3 = pushTitleImpl(target$jscomp$0, props);
				else isFallback ? JSCompiler_inline_result$jscomp$3 = null : (pushTitleImpl(renderState.hoistableChunks, props), JSCompiler_inline_result$jscomp$3 = void 0);
				return JSCompiler_inline_result$jscomp$3;
			case "link":
				var noscriptTagInScope$jscomp$0 = formatContext.tagScope & 1, isFallback$jscomp$0 = formatContext.tagScope & 4, rel = props.rel, href = props.href, precedence = props.precedence;
				if (4 === formatContext.insertionMode || noscriptTagInScope$jscomp$0 || null != props.itemProp || "string" !== typeof rel || "string" !== typeof href || "" === href) {
					pushLinkImpl(target$jscomp$0, props);
					var JSCompiler_inline_result$jscomp$4 = null;
				} else if ("stylesheet" === props.rel) if ("string" !== typeof precedence || null != props.disabled || props.onLoad || props.onError) JSCompiler_inline_result$jscomp$4 = pushLinkImpl(target$jscomp$0, props);
				else {
					var styleQueue = renderState.styles.get(precedence), resourceState = resumableState.styleResources.hasOwnProperty(href) ? resumableState.styleResources[href] : void 0;
					if (null !== resourceState) {
						resumableState.styleResources[href] = null;
						styleQueue || (styleQueue = {
							precedence: escapeTextForBrowser(precedence),
							rules: [],
							hrefs: [],
							sheets: /* @__PURE__ */ new Map()
						}, renderState.styles.set(precedence, styleQueue));
						var resource = {
							state: 0,
							props: assign({}, props, {
								"data-precedence": props.precedence,
								precedence: null
							})
						};
						if (resourceState) {
							2 === resourceState.length && adoptPreloadCredentials(resource.props, resourceState);
							var preloadResource = renderState.preloads.stylesheets.get(href);
							preloadResource && 0 < preloadResource.length ? preloadResource.length = 0 : resource.state = 1;
						}
						styleQueue.sheets.set(href, resource);
						hoistableState && hoistableState.stylesheets.add(resource);
					} else if (styleQueue) {
						var resource$9 = styleQueue.sheets.get(href);
						resource$9 && hoistableState && hoistableState.stylesheets.add(resource$9);
					}
					textEmbedded && target$jscomp$0.push("<!-- -->");
					JSCompiler_inline_result$jscomp$4 = null;
				}
				else props.onLoad || props.onError ? JSCompiler_inline_result$jscomp$4 = pushLinkImpl(target$jscomp$0, props) : (textEmbedded && target$jscomp$0.push("<!-- -->"), JSCompiler_inline_result$jscomp$4 = isFallback$jscomp$0 ? null : pushLinkImpl(renderState.hoistableChunks, props));
				return JSCompiler_inline_result$jscomp$4;
			case "script":
				var noscriptTagInScope$jscomp$1 = formatContext.tagScope & 1, asyncProp = props.async;
				if ("string" !== typeof props.src || !props.src || !asyncProp || "function" === typeof asyncProp || "symbol" === typeof asyncProp || props.onLoad || props.onError || 4 === formatContext.insertionMode || noscriptTagInScope$jscomp$1 || null != props.itemProp) var JSCompiler_inline_result$jscomp$5 = pushScriptImpl(target$jscomp$0, props);
				else {
					var key = props.src;
					if ("module" === props.type) {
						var resources = resumableState.moduleScriptResources;
						var preloads = renderState.preloads.moduleScripts;
					} else resources = resumableState.scriptResources, preloads = renderState.preloads.scripts;
					var resourceState$jscomp$0 = resources.hasOwnProperty(key) ? resources[key] : void 0;
					if (null !== resourceState$jscomp$0) {
						resources[key] = null;
						var scriptProps = props;
						if (resourceState$jscomp$0) {
							2 === resourceState$jscomp$0.length && (scriptProps = assign({}, props), adoptPreloadCredentials(scriptProps, resourceState$jscomp$0));
							var preloadResource$jscomp$0 = preloads.get(key);
							preloadResource$jscomp$0 && (preloadResource$jscomp$0.length = 0);
						}
						var resource$jscomp$0 = [];
						renderState.scripts.add(resource$jscomp$0);
						pushScriptImpl(resource$jscomp$0, scriptProps);
					}
					textEmbedded && target$jscomp$0.push("<!-- -->");
					JSCompiler_inline_result$jscomp$5 = null;
				}
				return JSCompiler_inline_result$jscomp$5;
			case "style":
				var noscriptTagInScope$jscomp$2 = formatContext.tagScope & 1, precedence$jscomp$0 = props.precedence, href$jscomp$0 = props.href, nonce = props.nonce;
				if (4 === formatContext.insertionMode || noscriptTagInScope$jscomp$2 || null != props.itemProp || "string" !== typeof precedence$jscomp$0 || "string" !== typeof href$jscomp$0 || "" === href$jscomp$0) {
					target$jscomp$0.push(startChunkForTag("style"));
					var children$jscomp$6 = null, innerHTML$jscomp$5 = null, propKey$jscomp$8;
					for (propKey$jscomp$8 in props) if (hasOwnProperty.call(props, propKey$jscomp$8)) {
						var propValue$jscomp$8 = props[propKey$jscomp$8];
						if (null != propValue$jscomp$8) switch (propKey$jscomp$8) {
							case "children":
								children$jscomp$6 = propValue$jscomp$8;
								break;
							case "dangerouslySetInnerHTML":
								innerHTML$jscomp$5 = propValue$jscomp$8;
								break;
							default: pushAttribute(target$jscomp$0, propKey$jscomp$8, propValue$jscomp$8);
						}
					}
					target$jscomp$0.push(">");
					var child = Array.isArray(children$jscomp$6) ? 2 > children$jscomp$6.length ? children$jscomp$6[0] : null : children$jscomp$6;
					"function" !== typeof child && "symbol" !== typeof child && null !== child && void 0 !== child && target$jscomp$0.push(("" + child).replace(styleRegex, styleReplacer));
					pushInnerHTML(target$jscomp$0, innerHTML$jscomp$5, children$jscomp$6);
					target$jscomp$0.push(endChunkForTag("style"));
					var JSCompiler_inline_result$jscomp$6 = null;
				} else {
					var styleQueue$jscomp$0 = renderState.styles.get(precedence$jscomp$0);
					if (null !== (resumableState.styleResources.hasOwnProperty(href$jscomp$0) ? resumableState.styleResources[href$jscomp$0] : void 0)) {
						resumableState.styleResources[href$jscomp$0] = null;
						styleQueue$jscomp$0 || (styleQueue$jscomp$0 = {
							precedence: escapeTextForBrowser(precedence$jscomp$0),
							rules: [],
							hrefs: [],
							sheets: /* @__PURE__ */ new Map()
						}, renderState.styles.set(precedence$jscomp$0, styleQueue$jscomp$0));
						var nonceStyle = renderState.nonce.style;
						if (!nonceStyle || nonceStyle === nonce) {
							styleQueue$jscomp$0.hrefs.push(escapeTextForBrowser(href$jscomp$0));
							var target = styleQueue$jscomp$0.rules, children$jscomp$7 = null, innerHTML$jscomp$6 = null, propKey$jscomp$9;
							for (propKey$jscomp$9 in props) if (hasOwnProperty.call(props, propKey$jscomp$9)) {
								var propValue$jscomp$9 = props[propKey$jscomp$9];
								if (null != propValue$jscomp$9) switch (propKey$jscomp$9) {
									case "children":
										children$jscomp$7 = propValue$jscomp$9;
										break;
									case "dangerouslySetInnerHTML": innerHTML$jscomp$6 = propValue$jscomp$9;
								}
							}
							var child$jscomp$0 = Array.isArray(children$jscomp$7) ? 2 > children$jscomp$7.length ? children$jscomp$7[0] : null : children$jscomp$7;
							"function" !== typeof child$jscomp$0 && "symbol" !== typeof child$jscomp$0 && null !== child$jscomp$0 && void 0 !== child$jscomp$0 && target.push(("" + child$jscomp$0).replace(styleRegex, styleReplacer));
							pushInnerHTML(target, innerHTML$jscomp$6, children$jscomp$7);
						}
					}
					styleQueue$jscomp$0 && hoistableState && hoistableState.styles.add(styleQueue$jscomp$0);
					textEmbedded && target$jscomp$0.push("<!-- -->");
					JSCompiler_inline_result$jscomp$6 = void 0;
				}
				return JSCompiler_inline_result$jscomp$6;
			case "meta":
				var noscriptTagInScope$jscomp$3 = formatContext.tagScope & 1, isFallback$jscomp$1 = formatContext.tagScope & 4;
				if (4 === formatContext.insertionMode || noscriptTagInScope$jscomp$3 || null != props.itemProp) var JSCompiler_inline_result$jscomp$7 = pushSelfClosing(target$jscomp$0, props, "meta");
				else textEmbedded && target$jscomp$0.push("<!-- -->"), JSCompiler_inline_result$jscomp$7 = isFallback$jscomp$1 ? null : "string" === typeof props.charSet ? pushSelfClosing(renderState.charsetChunks, props, "meta") : "viewport" === props.name ? pushSelfClosing(renderState.viewportChunks, props, "meta") : pushSelfClosing(renderState.hoistableChunks, props, "meta");
				return JSCompiler_inline_result$jscomp$7;
			case "listing":
			case "pre":
				target$jscomp$0.push(startChunkForTag(type));
				var children$jscomp$8 = null, innerHTML$jscomp$7 = null, propKey$jscomp$10;
				for (propKey$jscomp$10 in props) if (hasOwnProperty.call(props, propKey$jscomp$10)) {
					var propValue$jscomp$10 = props[propKey$jscomp$10];
					if (null != propValue$jscomp$10) switch (propKey$jscomp$10) {
						case "children":
							children$jscomp$8 = propValue$jscomp$10;
							break;
						case "dangerouslySetInnerHTML":
							innerHTML$jscomp$7 = propValue$jscomp$10;
							break;
						default: pushAttribute(target$jscomp$0, propKey$jscomp$10, propValue$jscomp$10);
					}
				}
				target$jscomp$0.push(">");
				if (null != innerHTML$jscomp$7) {
					if (null != children$jscomp$8) throw Error(formatProdErrorMessage(60));
					if ("object" !== typeof innerHTML$jscomp$7 || !("__html" in innerHTML$jscomp$7)) throw Error(formatProdErrorMessage(61));
					var html = innerHTML$jscomp$7.__html;
					null !== html && void 0 !== html && ("string" === typeof html && 0 < html.length && "\n" === html[0] ? target$jscomp$0.push("\n", html) : target$jscomp$0.push("" + html));
				}
				"string" === typeof children$jscomp$8 && "\n" === children$jscomp$8[0] && target$jscomp$0.push("\n");
				return children$jscomp$8;
			case "img":
				var pictureOrNoScriptTagInScope = formatContext.tagScope & 3, src = props.src, srcSet = props.srcSet;
				if (!("lazy" === props.loading || !src && !srcSet || "string" !== typeof src && null != src || "string" !== typeof srcSet && null != srcSet || "low" === props.fetchPriority || pictureOrNoScriptTagInScope) && ("string" !== typeof src || ":" !== src[4] || "d" !== src[0] && "D" !== src[0] || "a" !== src[1] && "A" !== src[1] || "t" !== src[2] && "T" !== src[2] || "a" !== src[3] && "A" !== src[3]) && ("string" !== typeof srcSet || ":" !== srcSet[4] || "d" !== srcSet[0] && "D" !== srcSet[0] || "a" !== srcSet[1] && "A" !== srcSet[1] || "t" !== srcSet[2] && "T" !== srcSet[2] || "a" !== srcSet[3] && "A" !== srcSet[3])) {
					null !== hoistableState && formatContext.tagScope & 64 && (hoistableState.suspenseyImages = !0);
					var sizes = "string" === typeof props.sizes ? props.sizes : void 0, key$jscomp$0 = srcSet ? srcSet + "\n" + (sizes || "") : src, promotablePreloads = renderState.preloads.images, resource$jscomp$1 = promotablePreloads.get(key$jscomp$0);
					if (resource$jscomp$1) {
						if ("high" === props.fetchPriority || 10 > renderState.highImagePreloads.size) promotablePreloads.delete(key$jscomp$0), renderState.highImagePreloads.add(resource$jscomp$1);
					} else if (!resumableState.imageResources.hasOwnProperty(key$jscomp$0)) {
						resumableState.imageResources[key$jscomp$0] = PRELOAD_NO_CREDS;
						var input = props.crossOrigin;
						var JSCompiler_inline_result$jscomp$8 = "string" === typeof input ? "use-credentials" === input ? input : "" : void 0;
						var headers = renderState.headers, header;
						headers && 0 < headers.remainingCapacity && "string" !== typeof props.srcSet && ("high" === props.fetchPriority || 500 > headers.highImagePreloads.length) && (header = getPreloadAsHeader(src, "image", {
							imageSrcSet: props.srcSet,
							imageSizes: props.sizes,
							crossOrigin: JSCompiler_inline_result$jscomp$8,
							integrity: props.integrity,
							nonce: props.nonce,
							type: props.type,
							fetchPriority: props.fetchPriority,
							referrerPolicy: props.refererPolicy
						}), 0 <= (headers.remainingCapacity -= header.length + 2)) ? (renderState.resets.image[key$jscomp$0] = PRELOAD_NO_CREDS, headers.highImagePreloads && (headers.highImagePreloads += ", "), headers.highImagePreloads += header) : (resource$jscomp$1 = [], pushLinkImpl(resource$jscomp$1, {
							rel: "preload",
							as: "image",
							href: srcSet ? void 0 : src,
							imageSrcSet: srcSet,
							imageSizes: sizes,
							crossOrigin: JSCompiler_inline_result$jscomp$8,
							integrity: props.integrity,
							type: props.type,
							fetchPriority: props.fetchPriority,
							referrerPolicy: props.referrerPolicy
						}), "high" === props.fetchPriority || 10 > renderState.highImagePreloads.size ? renderState.highImagePreloads.add(resource$jscomp$1) : (renderState.bulkPreloads.add(resource$jscomp$1), promotablePreloads.set(key$jscomp$0, resource$jscomp$1)));
					}
				}
				return pushSelfClosing(target$jscomp$0, props, "img");
			case "base":
			case "area":
			case "br":
			case "col":
			case "embed":
			case "hr":
			case "keygen":
			case "param":
			case "source":
			case "track":
			case "wbr": return pushSelfClosing(target$jscomp$0, props, type);
			case "annotation-xml":
			case "color-profile":
			case "font-face":
			case "font-face-src":
			case "font-face-uri":
			case "font-face-format":
			case "font-face-name":
			case "missing-glyph": break;
			case "head":
				if (2 > formatContext.insertionMode) {
					var preamble = preambleState || renderState.preamble;
					if (preamble.headChunks) throw Error(formatProdErrorMessage(545, "`<head>`"));
					null !== preambleState && target$jscomp$0.push("<!--head-->");
					preamble.headChunks = [];
					var JSCompiler_inline_result$jscomp$9 = pushStartSingletonElement(preamble.headChunks, props, "head");
				} else JSCompiler_inline_result$jscomp$9 = pushStartGenericElement(target$jscomp$0, props, "head");
				return JSCompiler_inline_result$jscomp$9;
			case "body":
				if (2 > formatContext.insertionMode) {
					var preamble$jscomp$0 = preambleState || renderState.preamble;
					if (preamble$jscomp$0.bodyChunks) throw Error(formatProdErrorMessage(545, "`<body>`"));
					null !== preambleState && target$jscomp$0.push("<!--body-->");
					preamble$jscomp$0.bodyChunks = [];
					var JSCompiler_inline_result$jscomp$10 = pushStartSingletonElement(preamble$jscomp$0.bodyChunks, props, "body");
				} else JSCompiler_inline_result$jscomp$10 = pushStartGenericElement(target$jscomp$0, props, "body");
				return JSCompiler_inline_result$jscomp$10;
			case "html":
				if (0 === formatContext.insertionMode) {
					var preamble$jscomp$1 = preambleState || renderState.preamble;
					if (preamble$jscomp$1.htmlChunks) throw Error(formatProdErrorMessage(545, "`<html>`"));
					null !== preambleState && target$jscomp$0.push("<!--html-->");
					preamble$jscomp$1.htmlChunks = [""];
					var JSCompiler_inline_result$jscomp$11 = pushStartSingletonElement(preamble$jscomp$1.htmlChunks, props, "html");
				} else JSCompiler_inline_result$jscomp$11 = pushStartGenericElement(target$jscomp$0, props, "html");
				return JSCompiler_inline_result$jscomp$11;
			default: if (-1 !== type.indexOf("-")) {
				target$jscomp$0.push(startChunkForTag(type));
				var children$jscomp$9 = null, innerHTML$jscomp$8 = null, propKey$jscomp$11;
				for (propKey$jscomp$11 in props) if (hasOwnProperty.call(props, propKey$jscomp$11)) {
					var propValue$jscomp$11 = props[propKey$jscomp$11];
					if (null != propValue$jscomp$11) {
						var attributeName = propKey$jscomp$11;
						switch (propKey$jscomp$11) {
							case "children":
								children$jscomp$9 = propValue$jscomp$11;
								break;
							case "dangerouslySetInnerHTML":
								innerHTML$jscomp$8 = propValue$jscomp$11;
								break;
							case "style":
								pushStyleAttribute(target$jscomp$0, propValue$jscomp$11);
								break;
							case "suppressContentEditableWarning":
							case "suppressHydrationWarning":
							case "ref": break;
							case "className": attributeName = "class";
							default: if (isAttributeNameSafe(propKey$jscomp$11) && "function" !== typeof propValue$jscomp$11 && "symbol" !== typeof propValue$jscomp$11 && !1 !== propValue$jscomp$11) {
								if (!0 === propValue$jscomp$11) propValue$jscomp$11 = "";
								else if ("object" === typeof propValue$jscomp$11) continue;
								target$jscomp$0.push(" ", attributeName, "=\"", escapeTextForBrowser(propValue$jscomp$11), "\"");
							}
						}
					}
				}
				target$jscomp$0.push(">");
				pushInnerHTML(target$jscomp$0, innerHTML$jscomp$8, children$jscomp$9);
				return children$jscomp$9;
			}
		}
		return pushStartGenericElement(target$jscomp$0, props, type);
	}
	var endTagCache = /* @__PURE__ */ new Map();
	function endChunkForTag(tag) {
		var chunk = endTagCache.get(tag);
		void 0 === chunk && (chunk = "</" + tag + ">", endTagCache.set(tag, chunk));
		return chunk;
	}
	function hoistPreambleState(renderState, preambleState) {
		renderState = renderState.preamble;
		null === renderState.htmlChunks && preambleState.htmlChunks && (renderState.htmlChunks = preambleState.htmlChunks);
		null === renderState.headChunks && preambleState.headChunks && (renderState.headChunks = preambleState.headChunks);
		null === renderState.bodyChunks && preambleState.bodyChunks && (renderState.bodyChunks = preambleState.bodyChunks);
	}
	function writeBootstrap(destination, renderState) {
		renderState = renderState.bootstrapChunks;
		for (var i = 0; i < renderState.length - 1; i++) destination.push(renderState[i]);
		return i < renderState.length ? (i = renderState[i], renderState.length = 0, destination.push(i)) : !0;
	}
	function writeStartPendingSuspenseBoundary(destination, renderState, id) {
		destination.push("<!--$?--><template id=\"");
		if (null === id) throw Error(formatProdErrorMessage(395));
		destination.push(renderState.boundaryPrefix);
		renderState = id.toString(16);
		destination.push(renderState);
		return destination.push("\"></template>");
	}
	function writeStartSegment(destination, renderState, formatContext, id) {
		switch (formatContext.insertionMode) {
			case 0:
			case 1:
			case 3:
			case 2: return destination.push("<div hidden id=\""), destination.push(renderState.segmentPrefix), renderState = id.toString(16), destination.push(renderState), destination.push("\">");
			case 4: return destination.push("<svg aria-hidden=\"true\" style=\"display:none\" id=\""), destination.push(renderState.segmentPrefix), renderState = id.toString(16), destination.push(renderState), destination.push("\">");
			case 5: return destination.push("<math aria-hidden=\"true\" style=\"display:none\" id=\""), destination.push(renderState.segmentPrefix), renderState = id.toString(16), destination.push(renderState), destination.push("\">");
			case 6: return destination.push("<table hidden id=\""), destination.push(renderState.segmentPrefix), renderState = id.toString(16), destination.push(renderState), destination.push("\">");
			case 7: return destination.push("<table hidden><tbody id=\""), destination.push(renderState.segmentPrefix), renderState = id.toString(16), destination.push(renderState), destination.push("\">");
			case 8: return destination.push("<table hidden><tr id=\""), destination.push(renderState.segmentPrefix), renderState = id.toString(16), destination.push(renderState), destination.push("\">");
			case 9: return destination.push("<table hidden><colgroup id=\""), destination.push(renderState.segmentPrefix), renderState = id.toString(16), destination.push(renderState), destination.push("\">");
			default: throw Error(formatProdErrorMessage(397));
		}
	}
	function writeEndSegment(destination, formatContext) {
		switch (formatContext.insertionMode) {
			case 0:
			case 1:
			case 3:
			case 2: return destination.push("</div>");
			case 4: return destination.push("</svg>");
			case 5: return destination.push("</math>");
			case 6: return destination.push("</table>");
			case 7: return destination.push("</tbody></table>");
			case 8: return destination.push("</tr></table>");
			case 9: return destination.push("</colgroup></table>");
			default: throw Error(formatProdErrorMessage(397));
		}
	}
	var regexForJSStringsInInstructionScripts = /[<\u2028\u2029]/g;
	function escapeJSStringsForInstructionScripts(input) {
		return JSON.stringify(input).replace(regexForJSStringsInInstructionScripts, function(match) {
			switch (match) {
				case "<": return "\\u003c";
				case "\u2028": return "\\u2028";
				case "\u2029": return "\\u2029";
				default: throw Error("escapeJSStringsForInstructionScripts encountered a match it does not know how to replace. this means the match regex and the replacement characters are no longer in sync. This is a bug in React");
			}
		});
	}
	var regexForJSStringsInScripts = /[&><\u2028\u2029]/g;
	function escapeJSObjectForInstructionScripts(input) {
		return JSON.stringify(input).replace(regexForJSStringsInScripts, function(match) {
			switch (match) {
				case "&": return "\\u0026";
				case ">": return "\\u003e";
				case "<": return "\\u003c";
				case "\u2028": return "\\u2028";
				case "\u2029": return "\\u2029";
				default: throw Error("escapeJSObjectForInstructionScripts encountered a match it does not know how to replace. this means the match regex and the replacement characters are no longer in sync. This is a bug in React");
			}
		});
	}
	var currentlyRenderingBoundaryHasStylesToHoist = !1, destinationHasCapacity = !0;
	function flushStyleTagsLateForBoundary(styleQueue) {
		var rules = styleQueue.rules, hrefs = styleQueue.hrefs, i = 0;
		if (hrefs.length) {
			this.push(currentlyFlushingRenderState.startInlineStyle);
			this.push(" media=\"not all\" data-precedence=\"");
			this.push(styleQueue.precedence);
			for (this.push("\" data-href=\""); i < hrefs.length - 1; i++) this.push(hrefs[i]), this.push(" ");
			this.push(hrefs[i]);
			this.push("\">");
			for (i = 0; i < rules.length; i++) this.push(rules[i]);
			destinationHasCapacity = this.push("</style>");
			currentlyRenderingBoundaryHasStylesToHoist = !0;
			rules.length = 0;
			hrefs.length = 0;
		}
	}
	function hasStylesToHoist(stylesheet) {
		return 2 !== stylesheet.state ? currentlyRenderingBoundaryHasStylesToHoist = !0 : !1;
	}
	function writeHoistablesForBoundary(destination, hoistableState, renderState) {
		currentlyRenderingBoundaryHasStylesToHoist = !1;
		destinationHasCapacity = !0;
		currentlyFlushingRenderState = renderState;
		hoistableState.styles.forEach(flushStyleTagsLateForBoundary, destination);
		currentlyFlushingRenderState = null;
		hoistableState.stylesheets.forEach(hasStylesToHoist);
		currentlyRenderingBoundaryHasStylesToHoist && (renderState.stylesToHoist = !0);
		return destinationHasCapacity;
	}
	function flushResource(resource) {
		for (var i = 0; i < resource.length; i++) this.push(resource[i]);
		resource.length = 0;
	}
	var stylesheetFlushingQueue = [];
	function flushStyleInPreamble(stylesheet) {
		pushLinkImpl(stylesheetFlushingQueue, stylesheet.props);
		for (var i = 0; i < stylesheetFlushingQueue.length; i++) this.push(stylesheetFlushingQueue[i]);
		stylesheetFlushingQueue.length = 0;
		stylesheet.state = 2;
	}
	function flushStylesInPreamble(styleQueue) {
		var hasStylesheets = 0 < styleQueue.sheets.size;
		styleQueue.sheets.forEach(flushStyleInPreamble, this);
		styleQueue.sheets.clear();
		var rules = styleQueue.rules, hrefs = styleQueue.hrefs;
		if (!hasStylesheets || hrefs.length) {
			this.push(currentlyFlushingRenderState.startInlineStyle);
			this.push(" data-precedence=\"");
			this.push(styleQueue.precedence);
			styleQueue = 0;
			if (hrefs.length) {
				for (this.push("\" data-href=\""); styleQueue < hrefs.length - 1; styleQueue++) this.push(hrefs[styleQueue]), this.push(" ");
				this.push(hrefs[styleQueue]);
			}
			this.push("\">");
			for (styleQueue = 0; styleQueue < rules.length; styleQueue++) this.push(rules[styleQueue]);
			this.push("</style>");
			rules.length = 0;
			hrefs.length = 0;
		}
	}
	function preloadLateStyle(stylesheet) {
		if (0 === stylesheet.state) {
			stylesheet.state = 1;
			var props = stylesheet.props;
			pushLinkImpl(stylesheetFlushingQueue, {
				rel: "preload",
				as: "style",
				href: stylesheet.props.href,
				crossOrigin: props.crossOrigin,
				fetchPriority: props.fetchPriority,
				integrity: props.integrity,
				media: props.media,
				hrefLang: props.hrefLang,
				referrerPolicy: props.referrerPolicy
			});
			for (stylesheet = 0; stylesheet < stylesheetFlushingQueue.length; stylesheet++) this.push(stylesheetFlushingQueue[stylesheet]);
			stylesheetFlushingQueue.length = 0;
		}
	}
	function preloadLateStyles(styleQueue) {
		styleQueue.sheets.forEach(preloadLateStyle, this);
		styleQueue.sheets.clear();
	}
	function pushCompletedShellIdAttribute(target, resumableState) {
		0 === (resumableState.instructions & 32) && (resumableState.instructions |= 32, target.push(" id=\"", escapeTextForBrowser("_" + resumableState.idPrefix + "R_"), "\""));
	}
	function writeStyleResourceDependenciesInJS(destination, hoistableState) {
		destination.push("[");
		var nextArrayOpenBrackChunk = "[";
		hoistableState.stylesheets.forEach(function(resource) {
			if (2 !== resource.state) if (3 === resource.state) destination.push(nextArrayOpenBrackChunk), resource = escapeJSObjectForInstructionScripts("" + resource.props.href), destination.push(resource), destination.push("]"), nextArrayOpenBrackChunk = ",[";
			else {
				destination.push(nextArrayOpenBrackChunk);
				var precedence = resource.props["data-precedence"], props = resource.props, coercedHref = sanitizeURL("" + resource.props.href);
				coercedHref = escapeJSObjectForInstructionScripts(coercedHref);
				destination.push(coercedHref);
				precedence = "" + precedence;
				destination.push(",");
				precedence = escapeJSObjectForInstructionScripts(precedence);
				destination.push(precedence);
				for (var propKey in props) if (hasOwnProperty.call(props, propKey) && (precedence = props[propKey], null != precedence)) switch (propKey) {
					case "href":
					case "rel":
					case "precedence":
					case "data-precedence": break;
					case "children":
					case "dangerouslySetInnerHTML": throw Error(formatProdErrorMessage(399, "link"));
					default: writeStyleResourceAttributeInJS(destination, propKey, precedence);
				}
				destination.push("]");
				nextArrayOpenBrackChunk = ",[";
				resource.state = 3;
			}
		});
		destination.push("]");
	}
	function writeStyleResourceAttributeInJS(destination, name, value) {
		var attributeName = name.toLowerCase();
		switch (typeof value) {
			case "function":
			case "symbol": return;
		}
		switch (name) {
			case "innerHTML":
			case "dangerouslySetInnerHTML":
			case "suppressContentEditableWarning":
			case "suppressHydrationWarning":
			case "style":
			case "ref": return;
			case "className":
				attributeName = "class";
				name = "" + value;
				break;
			case "hidden":
				if (!1 === value) return;
				name = "";
				break;
			case "src":
			case "href":
				value = sanitizeURL(value);
				name = "" + value;
				break;
			default:
				if (2 < name.length && ("o" === name[0] || "O" === name[0]) && ("n" === name[1] || "N" === name[1]) || !isAttributeNameSafe(name)) return;
				name = "" + value;
		}
		destination.push(",");
		attributeName = escapeJSObjectForInstructionScripts(attributeName);
		destination.push(attributeName);
		destination.push(",");
		attributeName = escapeJSObjectForInstructionScripts(name);
		destination.push(attributeName);
	}
	function createHoistableState() {
		return {
			styles: /* @__PURE__ */ new Set(),
			stylesheets: /* @__PURE__ */ new Set(),
			suspenseyImages: !1
		};
	}
	function prefetchDNS(href) {
		var request = currentRequest ? currentRequest : null;
		if (request) {
			var resumableState = request.resumableState, renderState = request.renderState;
			if ("string" === typeof href && href) {
				if (!resumableState.dnsResources.hasOwnProperty(href)) {
					resumableState.dnsResources[href] = null;
					resumableState = renderState.headers;
					var header, JSCompiler_temp;
					if (JSCompiler_temp = resumableState && 0 < resumableState.remainingCapacity) JSCompiler_temp = (header = "<" + ("" + href).replace(regexForHrefInLinkHeaderURLContext, escapeHrefForLinkHeaderURLContextReplacer) + ">; rel=dns-prefetch", 0 <= (resumableState.remainingCapacity -= header.length + 2));
					JSCompiler_temp ? (renderState.resets.dns[href] = null, resumableState.preconnects && (resumableState.preconnects += ", "), resumableState.preconnects += header) : (header = [], pushLinkImpl(header, {
						href,
						rel: "dns-prefetch"
					}), renderState.preconnects.add(header));
				}
				enqueueFlush(request);
			}
		} else previousDispatcher.D(href);
	}
	function preconnect(href, crossOrigin) {
		var request = currentRequest ? currentRequest : null;
		if (request) {
			var resumableState = request.resumableState, renderState = request.renderState;
			if ("string" === typeof href && href) {
				var bucket = "use-credentials" === crossOrigin ? "credentials" : "string" === typeof crossOrigin ? "anonymous" : "default";
				if (!resumableState.connectResources[bucket].hasOwnProperty(href)) {
					resumableState.connectResources[bucket][href] = null;
					resumableState = renderState.headers;
					var header, JSCompiler_temp;
					if (JSCompiler_temp = resumableState && 0 < resumableState.remainingCapacity) {
						JSCompiler_temp = "<" + ("" + href).replace(regexForHrefInLinkHeaderURLContext, escapeHrefForLinkHeaderURLContextReplacer) + ">; rel=preconnect";
						if ("string" === typeof crossOrigin) {
							var escapedCrossOrigin = ("" + crossOrigin).replace(regexForLinkHeaderQuotedParamValueContext, escapeStringForLinkHeaderQuotedParamValueContextReplacer);
							JSCompiler_temp += "; crossorigin=\"" + escapedCrossOrigin + "\"";
						}
						JSCompiler_temp = (header = JSCompiler_temp, 0 <= (resumableState.remainingCapacity -= header.length + 2));
					}
					JSCompiler_temp ? (renderState.resets.connect[bucket][href] = null, resumableState.preconnects && (resumableState.preconnects += ", "), resumableState.preconnects += header) : (bucket = [], pushLinkImpl(bucket, {
						rel: "preconnect",
						href,
						crossOrigin
					}), renderState.preconnects.add(bucket));
				}
				enqueueFlush(request);
			}
		} else previousDispatcher.C(href, crossOrigin);
	}
	function preload(href, as, options) {
		var request = currentRequest ? currentRequest : null;
		if (request) {
			var resumableState = request.resumableState, renderState = request.renderState;
			if (as && href) {
				switch (as) {
					case "image":
						if (options) {
							var imageSrcSet = options.imageSrcSet;
							var imageSizes = options.imageSizes;
							var fetchPriority = options.fetchPriority;
						}
						var key = imageSrcSet ? imageSrcSet + "\n" + (imageSizes || "") : href;
						if (resumableState.imageResources.hasOwnProperty(key)) return;
						resumableState.imageResources[key] = PRELOAD_NO_CREDS;
						resumableState = renderState.headers;
						var header;
						resumableState && 0 < resumableState.remainingCapacity && "string" !== typeof imageSrcSet && "high" === fetchPriority && (header = getPreloadAsHeader(href, as, options), 0 <= (resumableState.remainingCapacity -= header.length + 2)) ? (renderState.resets.image[key] = PRELOAD_NO_CREDS, resumableState.highImagePreloads && (resumableState.highImagePreloads += ", "), resumableState.highImagePreloads += header) : (resumableState = [], pushLinkImpl(resumableState, assign({
							rel: "preload",
							href: imageSrcSet ? void 0 : href,
							as
						}, options)), "high" === fetchPriority ? renderState.highImagePreloads.add(resumableState) : (renderState.bulkPreloads.add(resumableState), renderState.preloads.images.set(key, resumableState)));
						break;
					case "style":
						if (resumableState.styleResources.hasOwnProperty(href)) return;
						imageSrcSet = [];
						pushLinkImpl(imageSrcSet, assign({
							rel: "preload",
							href,
							as
						}, options));
						resumableState.styleResources[href] = !options || "string" !== typeof options.crossOrigin && "string" !== typeof options.integrity ? PRELOAD_NO_CREDS : [options.crossOrigin, options.integrity];
						renderState.preloads.stylesheets.set(href, imageSrcSet);
						renderState.bulkPreloads.add(imageSrcSet);
						break;
					case "script":
						if (resumableState.scriptResources.hasOwnProperty(href)) return;
						imageSrcSet = [];
						renderState.preloads.scripts.set(href, imageSrcSet);
						renderState.bulkPreloads.add(imageSrcSet);
						pushLinkImpl(imageSrcSet, assign({
							rel: "preload",
							href,
							as
						}, options));
						resumableState.scriptResources[href] = !options || "string" !== typeof options.crossOrigin && "string" !== typeof options.integrity ? PRELOAD_NO_CREDS : [options.crossOrigin, options.integrity];
						break;
					default:
						if (resumableState.unknownResources.hasOwnProperty(as)) {
							if (imageSrcSet = resumableState.unknownResources[as], imageSrcSet.hasOwnProperty(href)) return;
						} else imageSrcSet = {}, resumableState.unknownResources[as] = imageSrcSet;
						imageSrcSet[href] = PRELOAD_NO_CREDS;
						if ((resumableState = renderState.headers) && 0 < resumableState.remainingCapacity && "font" === as && (key = getPreloadAsHeader(href, as, options), 0 <= (resumableState.remainingCapacity -= key.length + 2))) renderState.resets.font[href] = PRELOAD_NO_CREDS, resumableState.fontPreloads && (resumableState.fontPreloads += ", "), resumableState.fontPreloads += key;
						else switch (resumableState = [], href = assign({
							rel: "preload",
							href,
							as
						}, options), pushLinkImpl(resumableState, href), as) {
							case "font":
								renderState.fontPreloads.add(resumableState);
								break;
							default: renderState.bulkPreloads.add(resumableState);
						}
				}
				enqueueFlush(request);
			}
		} else previousDispatcher.L(href, as, options);
	}
	function preloadModule(href, options) {
		var request = currentRequest ? currentRequest : null;
		if (request) {
			var resumableState = request.resumableState, renderState = request.renderState;
			if (href) {
				var as = options && "string" === typeof options.as ? options.as : "script";
				switch (as) {
					case "script":
						if (resumableState.moduleScriptResources.hasOwnProperty(href)) return;
						as = [];
						resumableState.moduleScriptResources[href] = !options || "string" !== typeof options.crossOrigin && "string" !== typeof options.integrity ? PRELOAD_NO_CREDS : [options.crossOrigin, options.integrity];
						renderState.preloads.moduleScripts.set(href, as);
						break;
					default:
						if (resumableState.moduleUnknownResources.hasOwnProperty(as)) {
							var resources = resumableState.unknownResources[as];
							if (resources.hasOwnProperty(href)) return;
						} else resources = {}, resumableState.moduleUnknownResources[as] = resources;
						as = [];
						resources[href] = PRELOAD_NO_CREDS;
				}
				pushLinkImpl(as, assign({
					rel: "modulepreload",
					href
				}, options));
				renderState.bulkPreloads.add(as);
				enqueueFlush(request);
			}
		} else previousDispatcher.m(href, options);
	}
	function preinitStyle(href, precedence, options) {
		var request = currentRequest ? currentRequest : null;
		if (request) {
			var resumableState = request.resumableState, renderState = request.renderState;
			if (href) {
				precedence = precedence || "default";
				var styleQueue = renderState.styles.get(precedence), resourceState = resumableState.styleResources.hasOwnProperty(href) ? resumableState.styleResources[href] : void 0;
				null !== resourceState && (resumableState.styleResources[href] = null, styleQueue || (styleQueue = {
					precedence: escapeTextForBrowser(precedence),
					rules: [],
					hrefs: [],
					sheets: /* @__PURE__ */ new Map()
				}, renderState.styles.set(precedence, styleQueue)), precedence = {
					state: 0,
					props: assign({
						rel: "stylesheet",
						href,
						"data-precedence": precedence
					}, options)
				}, resourceState && (2 === resourceState.length && adoptPreloadCredentials(precedence.props, resourceState), (renderState = renderState.preloads.stylesheets.get(href)) && 0 < renderState.length ? renderState.length = 0 : precedence.state = 1), styleQueue.sheets.set(href, precedence), enqueueFlush(request));
			}
		} else previousDispatcher.S(href, precedence, options);
	}
	function preinitScript(src, options) {
		var request = currentRequest ? currentRequest : null;
		if (request) {
			var resumableState = request.resumableState, renderState = request.renderState;
			if (src) {
				var resourceState = resumableState.scriptResources.hasOwnProperty(src) ? resumableState.scriptResources[src] : void 0;
				null !== resourceState && (resumableState.scriptResources[src] = null, options = assign({
					src,
					async: !0
				}, options), resourceState && (2 === resourceState.length && adoptPreloadCredentials(options, resourceState), src = renderState.preloads.scripts.get(src)) && (src.length = 0), src = [], renderState.scripts.add(src), pushScriptImpl(src, options), enqueueFlush(request));
			}
		} else previousDispatcher.X(src, options);
	}
	function preinitModuleScript(src, options) {
		var request = currentRequest ? currentRequest : null;
		if (request) {
			var resumableState = request.resumableState, renderState = request.renderState;
			if (src) {
				var resourceState = resumableState.moduleScriptResources.hasOwnProperty(src) ? resumableState.moduleScriptResources[src] : void 0;
				null !== resourceState && (resumableState.moduleScriptResources[src] = null, options = assign({
					src,
					type: "module",
					async: !0
				}, options), resourceState && (2 === resourceState.length && adoptPreloadCredentials(options, resourceState), src = renderState.preloads.moduleScripts.get(src)) && (src.length = 0), src = [], renderState.scripts.add(src), pushScriptImpl(src, options), enqueueFlush(request));
			}
		} else previousDispatcher.M(src, options);
	}
	function adoptPreloadCredentials(target, preloadState) {
		target.crossOrigin ??= preloadState[0];
		target.integrity ??= preloadState[1];
	}
	function getPreloadAsHeader(href, as, params) {
		href = ("" + href).replace(regexForHrefInLinkHeaderURLContext, escapeHrefForLinkHeaderURLContextReplacer);
		as = ("" + as).replace(regexForLinkHeaderQuotedParamValueContext, escapeStringForLinkHeaderQuotedParamValueContextReplacer);
		as = "<" + href + ">; rel=preload; as=\"" + as + "\"";
		for (var paramName in params) hasOwnProperty.call(params, paramName) && (href = params[paramName], "string" === typeof href && (as += "; " + paramName.toLowerCase() + "=\"" + ("" + href).replace(regexForLinkHeaderQuotedParamValueContext, escapeStringForLinkHeaderQuotedParamValueContextReplacer) + "\""));
		return as;
	}
	var regexForHrefInLinkHeaderURLContext = /[<>\r\n]/g;
	function escapeHrefForLinkHeaderURLContextReplacer(match) {
		switch (match) {
			case "<": return "%3C";
			case ">": return "%3E";
			case "\n": return "%0A";
			case "\r": return "%0D";
			default: throw Error("escapeLinkHrefForHeaderContextReplacer encountered a match it does not know how to replace. this means the match regex and the replacement characters are no longer in sync. This is a bug in React");
		}
	}
	var regexForLinkHeaderQuotedParamValueContext = /["';,\r\n]/g;
	function escapeStringForLinkHeaderQuotedParamValueContextReplacer(match) {
		switch (match) {
			case "\"": return "%22";
			case "'": return "%27";
			case ";": return "%3B";
			case ",": return "%2C";
			case "\n": return "%0A";
			case "\r": return "%0D";
			default: throw Error("escapeStringForLinkHeaderQuotedParamValueContextReplacer encountered a match it does not know how to replace. this means the match regex and the replacement characters are no longer in sync. This is a bug in React");
		}
	}
	function hoistStyleQueueDependency(styleQueue) {
		this.styles.add(styleQueue);
	}
	function hoistStylesheetDependency(stylesheet) {
		this.stylesheets.add(stylesheet);
	}
	function hoistHoistables(parentState, childState) {
		childState.styles.forEach(hoistStyleQueueDependency, parentState);
		childState.stylesheets.forEach(hoistStylesheetDependency, parentState);
		childState.suspenseyImages && (parentState.suspenseyImages = !0);
	}
	function createRenderState(resumableState, generateStaticMarkup) {
		var idPrefix = resumableState.idPrefix, bootstrapChunks = [], bootstrapScriptContent = resumableState.bootstrapScriptContent, bootstrapScripts = resumableState.bootstrapScripts, bootstrapModules = resumableState.bootstrapModules;
		void 0 !== bootstrapScriptContent && (bootstrapChunks.push("<script"), pushCompletedShellIdAttribute(bootstrapChunks, resumableState), bootstrapChunks.push(">", ("" + bootstrapScriptContent).replace(scriptRegex, scriptReplacer), "<\/script>"));
		bootstrapScriptContent = idPrefix + "P:";
		var JSCompiler_object_inline_segmentPrefix_1673 = idPrefix + "S:";
		idPrefix += "B:";
		var JSCompiler_object_inline_preconnects_1687 = /* @__PURE__ */ new Set(), JSCompiler_object_inline_fontPreloads_1688 = /* @__PURE__ */ new Set(), JSCompiler_object_inline_highImagePreloads_1689 = /* @__PURE__ */ new Set(), JSCompiler_object_inline_styles_1690 = /* @__PURE__ */ new Map(), JSCompiler_object_inline_bootstrapScripts_1691 = /* @__PURE__ */ new Set(), JSCompiler_object_inline_scripts_1692 = /* @__PURE__ */ new Set(), JSCompiler_object_inline_bulkPreloads_1693 = /* @__PURE__ */ new Set(), JSCompiler_object_inline_preloads_1694 = {
			images: /* @__PURE__ */ new Map(),
			stylesheets: /* @__PURE__ */ new Map(),
			scripts: /* @__PURE__ */ new Map(),
			moduleScripts: /* @__PURE__ */ new Map()
		};
		if (void 0 !== bootstrapScripts) for (var i = 0; i < bootstrapScripts.length; i++) {
			var scriptConfig = bootstrapScripts[i], src, crossOrigin = void 0, integrity = void 0, props = {
				rel: "preload",
				as: "script",
				fetchPriority: "low",
				nonce: void 0
			};
			"string" === typeof scriptConfig ? props.href = src = scriptConfig : (props.href = src = scriptConfig.src, props.integrity = integrity = "string" === typeof scriptConfig.integrity ? scriptConfig.integrity : void 0, props.crossOrigin = crossOrigin = "string" === typeof scriptConfig || null == scriptConfig.crossOrigin ? void 0 : "use-credentials" === scriptConfig.crossOrigin ? "use-credentials" : "");
			scriptConfig = resumableState;
			var href = src;
			scriptConfig.scriptResources[href] = null;
			scriptConfig.moduleScriptResources[href] = null;
			scriptConfig = [];
			pushLinkImpl(scriptConfig, props);
			JSCompiler_object_inline_bootstrapScripts_1691.add(scriptConfig);
			bootstrapChunks.push("<script src=\"", escapeTextForBrowser(src), "\"");
			"string" === typeof integrity && bootstrapChunks.push(" integrity=\"", escapeTextForBrowser(integrity), "\"");
			"string" === typeof crossOrigin && bootstrapChunks.push(" crossorigin=\"", escapeTextForBrowser(crossOrigin), "\"");
			pushCompletedShellIdAttribute(bootstrapChunks, resumableState);
			bootstrapChunks.push(" async=\"\"><\/script>");
		}
		if (void 0 !== bootstrapModules) for (bootstrapScripts = 0; bootstrapScripts < bootstrapModules.length; bootstrapScripts++) props = bootstrapModules[bootstrapScripts], crossOrigin = src = void 0, integrity = {
			rel: "modulepreload",
			fetchPriority: "low",
			nonce: void 0
		}, "string" === typeof props ? integrity.href = i = props : (integrity.href = i = props.src, integrity.integrity = crossOrigin = "string" === typeof props.integrity ? props.integrity : void 0, integrity.crossOrigin = src = "string" === typeof props || null == props.crossOrigin ? void 0 : "use-credentials" === props.crossOrigin ? "use-credentials" : ""), props = resumableState, scriptConfig = i, props.scriptResources[scriptConfig] = null, props.moduleScriptResources[scriptConfig] = null, props = [], pushLinkImpl(props, integrity), JSCompiler_object_inline_bootstrapScripts_1691.add(props), bootstrapChunks.push("<script type=\"module\" src=\"", escapeTextForBrowser(i), "\""), "string" === typeof crossOrigin && bootstrapChunks.push(" integrity=\"", escapeTextForBrowser(crossOrigin), "\""), "string" === typeof src && bootstrapChunks.push(" crossorigin=\"", escapeTextForBrowser(src), "\""), pushCompletedShellIdAttribute(bootstrapChunks, resumableState), bootstrapChunks.push(" async=\"\"><\/script>");
		return {
			placeholderPrefix: bootstrapScriptContent,
			segmentPrefix: JSCompiler_object_inline_segmentPrefix_1673,
			boundaryPrefix: idPrefix,
			startInlineScript: "<script",
			startInlineStyle: "<style",
			preamble: {
				htmlChunks: null,
				headChunks: null,
				bodyChunks: null
			},
			externalRuntimeScript: null,
			bootstrapChunks,
			importMapChunks: [],
			onHeaders: void 0,
			headers: null,
			resets: {
				font: {},
				dns: {},
				connect: {
					default: {},
					anonymous: {},
					credentials: {}
				},
				image: {},
				style: {}
			},
			charsetChunks: [],
			viewportChunks: [],
			hoistableChunks: [],
			preconnects: JSCompiler_object_inline_preconnects_1687,
			fontPreloads: JSCompiler_object_inline_fontPreloads_1688,
			highImagePreloads: JSCompiler_object_inline_highImagePreloads_1689,
			styles: JSCompiler_object_inline_styles_1690,
			bootstrapScripts: JSCompiler_object_inline_bootstrapScripts_1691,
			scripts: JSCompiler_object_inline_scripts_1692,
			bulkPreloads: JSCompiler_object_inline_bulkPreloads_1693,
			preloads: JSCompiler_object_inline_preloads_1694,
			nonce: {
				script: void 0,
				style: void 0
			},
			stylesToHoist: !1,
			generateStaticMarkup
		};
	}
	function pushTextInstance(target, text, renderState, textEmbedded) {
		if (renderState.generateStaticMarkup) return target.push(escapeTextForBrowser(text)), !1;
		"" === text ? target = textEmbedded : (textEmbedded && target.push("<!-- -->"), target.push(escapeTextForBrowser(text)), target = !0);
		return target;
	}
	function pushSegmentFinale(target, renderState, lastPushedText, textEmbedded) {
		renderState.generateStaticMarkup || lastPushedText && textEmbedded && target.push("<!-- -->");
	}
	var bind = Function.prototype.bind, REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference");
	function getComponentNameFromType(type) {
		if (null == type) return null;
		if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
		if ("string" === typeof type) return type;
		switch (type) {
			case REACT_FRAGMENT_TYPE: return "Fragment";
			case REACT_PROFILER_TYPE: return "Profiler";
			case REACT_STRICT_MODE_TYPE: return "StrictMode";
			case REACT_SUSPENSE_TYPE: return "Suspense";
			case REACT_SUSPENSE_LIST_TYPE: return "SuspenseList";
			case REACT_ACTIVITY_TYPE: return "Activity";
		}
		if ("object" === typeof type) switch (type.$$typeof) {
			case REACT_PORTAL_TYPE: return "Portal";
			case REACT_CONTEXT_TYPE: return type.displayName || "Context";
			case REACT_CONSUMER_TYPE: return (type._context.displayName || "Context") + ".Consumer";
			case REACT_FORWARD_REF_TYPE:
				var innerType = type.render;
				type = type.displayName;
				type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
				return type;
			case REACT_MEMO_TYPE: return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
			case REACT_LAZY_TYPE:
				innerType = type._payload;
				type = type._init;
				try {
					return getComponentNameFromType(type(innerType));
				} catch (x) {}
		}
		return null;
	}
	var emptyContextObject = {}, currentActiveSnapshot = null;
	function popToNearestCommonAncestor(prev, next) {
		if (prev !== next) {
			prev.context._currentValue2 = prev.parentValue;
			prev = prev.parent;
			var parentNext = next.parent;
			if (null === prev) {
				if (null !== parentNext) throw Error(formatProdErrorMessage(401));
			} else {
				if (null === parentNext) throw Error(formatProdErrorMessage(401));
				popToNearestCommonAncestor(prev, parentNext);
			}
			next.context._currentValue2 = next.value;
		}
	}
	function popAllPrevious(prev) {
		prev.context._currentValue2 = prev.parentValue;
		prev = prev.parent;
		null !== prev && popAllPrevious(prev);
	}
	function pushAllNext(next) {
		var parentNext = next.parent;
		null !== parentNext && pushAllNext(parentNext);
		next.context._currentValue2 = next.value;
	}
	function popPreviousToCommonLevel(prev, next) {
		prev.context._currentValue2 = prev.parentValue;
		prev = prev.parent;
		if (null === prev) throw Error(formatProdErrorMessage(402));
		prev.depth === next.depth ? popToNearestCommonAncestor(prev, next) : popPreviousToCommonLevel(prev, next);
	}
	function popNextToCommonLevel(prev, next) {
		var parentNext = next.parent;
		if (null === parentNext) throw Error(formatProdErrorMessage(402));
		prev.depth === parentNext.depth ? popToNearestCommonAncestor(prev, parentNext) : popNextToCommonLevel(prev, parentNext);
		next.context._currentValue2 = next.value;
	}
	function switchContext(newSnapshot) {
		var prev = currentActiveSnapshot;
		prev !== newSnapshot && (null === prev ? pushAllNext(newSnapshot) : null === newSnapshot ? popAllPrevious(prev) : prev.depth === newSnapshot.depth ? popToNearestCommonAncestor(prev, newSnapshot) : prev.depth > newSnapshot.depth ? popPreviousToCommonLevel(prev, newSnapshot) : popNextToCommonLevel(prev, newSnapshot), currentActiveSnapshot = newSnapshot);
	}
	var classComponentUpdater = {
		enqueueSetState: function(inst, payload) {
			inst = inst._reactInternals;
			null !== inst.queue && inst.queue.push(payload);
		},
		enqueueReplaceState: function(inst, payload) {
			inst = inst._reactInternals;
			inst.replace = !0;
			inst.queue = [payload];
		},
		enqueueForceUpdate: function() {}
	}, emptyTreeContext = {
		id: 1,
		overflow: ""
	};
	function pushTreeContext(baseContext, totalChildren, index) {
		var baseIdWithLeadingBit = baseContext.id;
		baseContext = baseContext.overflow;
		var baseLength = 32 - clz32(baseIdWithLeadingBit) - 1;
		baseIdWithLeadingBit &= ~(1 << baseLength);
		index += 1;
		var length = 32 - clz32(totalChildren) + baseLength;
		if (30 < length) {
			var numberOfOverflowBits = baseLength - baseLength % 5;
			length = (baseIdWithLeadingBit & (1 << numberOfOverflowBits) - 1).toString(32);
			baseIdWithLeadingBit >>= numberOfOverflowBits;
			baseLength -= numberOfOverflowBits;
			return {
				id: 1 << 32 - clz32(totalChildren) + baseLength | index << baseLength | baseIdWithLeadingBit,
				overflow: length + baseContext
			};
		}
		return {
			id: 1 << length | index << baseLength | baseIdWithLeadingBit,
			overflow: baseContext
		};
	}
	var clz32 = Math.clz32 ? Math.clz32 : clz32Fallback, log = Math.log, LN2 = Math.LN2;
	function clz32Fallback(x) {
		x >>>= 0;
		return 0 === x ? 32 : 31 - (log(x) / LN2 | 0) | 0;
	}
	function noop() {}
	var SuspenseException = Error(formatProdErrorMessage(460));
	function trackUsedThenable(thenableState, thenable, index) {
		index = thenableState[index];
		void 0 === index ? thenableState.push(thenable) : index !== thenable && (thenable.then(noop, noop), thenable = index);
		switch (thenable.status) {
			case "fulfilled": return thenable.value;
			case "rejected": throw thenable.reason;
			default:
				"string" === typeof thenable.status ? thenable.then(noop, noop) : (thenableState = thenable, thenableState.status = "pending", thenableState.then(function(fulfilledValue) {
					if ("pending" === thenable.status) {
						var fulfilledThenable = thenable;
						fulfilledThenable.status = "fulfilled";
						fulfilledThenable.value = fulfilledValue;
					}
				}, function(error) {
					if ("pending" === thenable.status) {
						var rejectedThenable = thenable;
						rejectedThenable.status = "rejected";
						rejectedThenable.reason = error;
					}
				}));
				switch (thenable.status) {
					case "fulfilled": return thenable.value;
					case "rejected": throw thenable.reason;
				}
				suspendedThenable = thenable;
				throw SuspenseException;
		}
	}
	var suspendedThenable = null;
	function getSuspendedThenable() {
		if (null === suspendedThenable) throw Error(formatProdErrorMessage(459));
		var thenable = suspendedThenable;
		suspendedThenable = null;
		return thenable;
	}
	function is(x, y) {
		return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
	}
	var objectIs = "function" === typeof Object.is ? Object.is : is, currentlyRenderingComponent = null, currentlyRenderingTask = null, currentlyRenderingRequest = null, currentlyRenderingKeyPath = null, firstWorkInProgressHook = null, workInProgressHook = null, isReRender = !1, didScheduleRenderPhaseUpdate = !1, localIdCounter = 0, actionStateCounter = 0, actionStateMatchingIndex = -1, thenableIndexCounter = 0, thenableState = null, renderPhaseUpdates = null, numberOfReRenders = 0;
	function resolveCurrentlyRenderingComponent() {
		if (null === currentlyRenderingComponent) throw Error(formatProdErrorMessage(321));
		return currentlyRenderingComponent;
	}
	function createHook() {
		if (0 < numberOfReRenders) throw Error(formatProdErrorMessage(312));
		return {
			memoizedState: null,
			queue: null,
			next: null
		};
	}
	function createWorkInProgressHook() {
		null === workInProgressHook ? null === firstWorkInProgressHook ? (isReRender = !1, firstWorkInProgressHook = workInProgressHook = createHook()) : (isReRender = !0, workInProgressHook = firstWorkInProgressHook) : null === workInProgressHook.next ? (isReRender = !1, workInProgressHook = workInProgressHook.next = createHook()) : (isReRender = !0, workInProgressHook = workInProgressHook.next);
		return workInProgressHook;
	}
	function getThenableStateAfterSuspending() {
		var state = thenableState;
		thenableState = null;
		return state;
	}
	function resetHooksState() {
		currentlyRenderingKeyPath = currentlyRenderingRequest = currentlyRenderingTask = currentlyRenderingComponent = null;
		didScheduleRenderPhaseUpdate = !1;
		firstWorkInProgressHook = null;
		numberOfReRenders = 0;
		workInProgressHook = renderPhaseUpdates = null;
	}
	function basicStateReducer(state, action) {
		return "function" === typeof action ? action(state) : action;
	}
	function useReducer(reducer, initialArg, init) {
		currentlyRenderingComponent = resolveCurrentlyRenderingComponent();
		workInProgressHook = createWorkInProgressHook();
		if (isReRender) {
			var queue = workInProgressHook.queue;
			initialArg = queue.dispatch;
			if (null !== renderPhaseUpdates && (init = renderPhaseUpdates.get(queue), void 0 !== init)) {
				renderPhaseUpdates.delete(queue);
				queue = workInProgressHook.memoizedState;
				do
					queue = reducer(queue, init.action), init = init.next;
				while (null !== init);
				workInProgressHook.memoizedState = queue;
				return [queue, initialArg];
			}
			return [workInProgressHook.memoizedState, initialArg];
		}
		reducer = reducer === basicStateReducer ? "function" === typeof initialArg ? initialArg() : initialArg : void 0 !== init ? init(initialArg) : initialArg;
		workInProgressHook.memoizedState = reducer;
		reducer = workInProgressHook.queue = {
			last: null,
			dispatch: null
		};
		reducer = reducer.dispatch = dispatchAction.bind(null, currentlyRenderingComponent, reducer);
		return [workInProgressHook.memoizedState, reducer];
	}
	function useMemo(nextCreate, deps) {
		currentlyRenderingComponent = resolveCurrentlyRenderingComponent();
		workInProgressHook = createWorkInProgressHook();
		deps = void 0 === deps ? null : deps;
		if (null !== workInProgressHook) {
			var prevState = workInProgressHook.memoizedState;
			if (null !== prevState && null !== deps) {
				var prevDeps = prevState[1];
				a: if (null === prevDeps) prevDeps = !1;
				else {
					for (var i = 0; i < prevDeps.length && i < deps.length; i++) if (!objectIs(deps[i], prevDeps[i])) {
						prevDeps = !1;
						break a;
					}
					prevDeps = !0;
				}
				if (prevDeps) return prevState[0];
			}
		}
		nextCreate = nextCreate();
		workInProgressHook.memoizedState = [nextCreate, deps];
		return nextCreate;
	}
	function dispatchAction(componentIdentity, queue, action) {
		if (25 <= numberOfReRenders) throw Error(formatProdErrorMessage(301));
		if (componentIdentity === currentlyRenderingComponent) if (didScheduleRenderPhaseUpdate = !0, componentIdentity = {
			action,
			next: null
		}, null === renderPhaseUpdates && (renderPhaseUpdates = /* @__PURE__ */ new Map()), action = renderPhaseUpdates.get(queue), void 0 === action) renderPhaseUpdates.set(queue, componentIdentity);
		else {
			for (queue = action; null !== queue.next;) queue = queue.next;
			queue.next = componentIdentity;
		}
	}
	function throwOnUseEffectEventCall() {
		throw Error(formatProdErrorMessage(440));
	}
	function unsupportedStartTransition() {
		throw Error(formatProdErrorMessage(394));
	}
	function unsupportedSetOptimisticState() {
		throw Error(formatProdErrorMessage(479));
	}
	function useActionState(action, initialState, permalink) {
		resolveCurrentlyRenderingComponent();
		var actionStateHookIndex = actionStateCounter++, request = currentlyRenderingRequest;
		if ("function" === typeof action.$$FORM_ACTION) {
			var nextPostbackStateKey = null, componentKeyPath = currentlyRenderingKeyPath;
			request = request.formState;
			var isSignatureEqual = action.$$IS_SIGNATURE_EQUAL;
			if (null !== request && "function" === typeof isSignatureEqual) {
				var postbackKey = request[1];
				isSignatureEqual.call(action, request[2], request[3]) && (nextPostbackStateKey = void 0 !== permalink ? "p" + permalink : "k" + murmurhash3_32_gc(JSON.stringify([
					componentKeyPath,
					null,
					actionStateHookIndex
				]), 0), postbackKey === nextPostbackStateKey && (actionStateMatchingIndex = actionStateHookIndex, initialState = request[0]));
			}
			var boundAction = action.bind(null, initialState);
			action = function(payload) {
				boundAction(payload);
			};
			"function" === typeof boundAction.$$FORM_ACTION && (action.$$FORM_ACTION = function(prefix) {
				prefix = boundAction.$$FORM_ACTION(prefix);
				void 0 !== permalink && (permalink += "", prefix.action = permalink);
				var formData = prefix.data;
				formData && (null === nextPostbackStateKey && (nextPostbackStateKey = void 0 !== permalink ? "p" + permalink : "k" + murmurhash3_32_gc(JSON.stringify([
					componentKeyPath,
					null,
					actionStateHookIndex
				]), 0)), formData.append("$ACTION_KEY", nextPostbackStateKey));
				return prefix;
			});
			return [
				initialState,
				action,
				!1
			];
		}
		var boundAction$22 = action.bind(null, initialState);
		return [
			initialState,
			function(payload) {
				boundAction$22(payload);
			},
			!1
		];
	}
	function unwrapThenable(thenable) {
		var index = thenableIndexCounter;
		thenableIndexCounter += 1;
		null === thenableState && (thenableState = []);
		return trackUsedThenable(thenableState, thenable, index);
	}
	function unsupportedRefresh() {
		throw Error(formatProdErrorMessage(393));
	}
	var HooksDispatcher = {
		readContext: function(context) {
			return context._currentValue2;
		},
		use: function(usable) {
			if (null !== usable && "object" === typeof usable) {
				if ("function" === typeof usable.then) return unwrapThenable(usable);
				if (usable.$$typeof === REACT_CONTEXT_TYPE) return usable._currentValue2;
			}
			throw Error(formatProdErrorMessage(438, String(usable)));
		},
		useContext: function(context) {
			resolveCurrentlyRenderingComponent();
			return context._currentValue2;
		},
		useMemo,
		useReducer,
		useRef: function(initialValue) {
			currentlyRenderingComponent = resolveCurrentlyRenderingComponent();
			workInProgressHook = createWorkInProgressHook();
			var previousRef = workInProgressHook.memoizedState;
			return null === previousRef ? (initialValue = { current: initialValue }, workInProgressHook.memoizedState = initialValue) : previousRef;
		},
		useState: function(initialState) {
			return useReducer(basicStateReducer, initialState);
		},
		useInsertionEffect: noop,
		useLayoutEffect: noop,
		useCallback: function(callback, deps) {
			return useMemo(function() {
				return callback;
			}, deps);
		},
		useImperativeHandle: noop,
		useEffect: noop,
		useDebugValue: noop,
		useDeferredValue: function(value, initialValue) {
			resolveCurrentlyRenderingComponent();
			return void 0 !== initialValue ? initialValue : value;
		},
		useTransition: function() {
			resolveCurrentlyRenderingComponent();
			return [!1, unsupportedStartTransition];
		},
		useId: function() {
			var JSCompiler_inline_result = currentlyRenderingTask.treeContext;
			var overflow = JSCompiler_inline_result.overflow;
			JSCompiler_inline_result = JSCompiler_inline_result.id;
			JSCompiler_inline_result = (JSCompiler_inline_result & ~(1 << 32 - clz32(JSCompiler_inline_result) - 1)).toString(32) + overflow;
			var resumableState = currentResumableState;
			if (null === resumableState) throw Error(formatProdErrorMessage(404));
			overflow = localIdCounter++;
			JSCompiler_inline_result = "_" + resumableState.idPrefix + "R_" + JSCompiler_inline_result;
			0 < overflow && (JSCompiler_inline_result += "H" + overflow.toString(32));
			return JSCompiler_inline_result + "_";
		},
		useSyncExternalStore: function(subscribe, getSnapshot, getServerSnapshot) {
			if (void 0 === getServerSnapshot) throw Error(formatProdErrorMessage(407));
			return getServerSnapshot();
		},
		useOptimistic: function(passthrough) {
			resolveCurrentlyRenderingComponent();
			return [passthrough, unsupportedSetOptimisticState];
		},
		useActionState,
		useFormState: useActionState,
		useHostTransitionStatus: function() {
			resolveCurrentlyRenderingComponent();
			return sharedNotPendingObject;
		},
		useMemoCache: function(size) {
			for (var data = Array(size), i = 0; i < size; i++) data[i] = REACT_MEMO_CACHE_SENTINEL;
			return data;
		},
		useCacheRefresh: function() {
			return unsupportedRefresh;
		},
		useEffectEvent: function() {
			return throwOnUseEffectEventCall;
		}
	}, currentResumableState = null, DefaultAsyncDispatcher = {
		getCacheForType: function() {
			throw Error(formatProdErrorMessage(248));
		},
		cacheSignal: function() {
			throw Error(formatProdErrorMessage(248));
		}
	}, prefix, suffix;
	function describeBuiltInComponentFrame(name) {
		if (void 0 === prefix) try {
			throw Error();
		} catch (x) {
			var match = x.stack.trim().match(/\n( *(at )?)/);
			prefix = match && match[1] || "";
			suffix = -1 < x.stack.indexOf("\n    at") ? " (<anonymous>)" : -1 < x.stack.indexOf("@") ? "@unknown:0:0" : "";
		}
		return "\n" + prefix + name + suffix;
	}
	var reentry = !1;
	function describeNativeComponentFrame(fn, construct) {
		if (!fn || reentry) return "";
		reentry = !0;
		var previousPrepareStackTrace = Error.prepareStackTrace;
		Error.prepareStackTrace = void 0;
		try {
			var RunInRootFrame = { DetermineComponentFrameRoot: function() {
				try {
					if (construct) {
						var Fake = function() {
							throw Error();
						};
						Object.defineProperty(Fake.prototype, "props", { set: function() {
							throw Error();
						} });
						if ("object" === typeof Reflect && Reflect.construct) {
							try {
								Reflect.construct(Fake, []);
							} catch (x) {
								var control = x;
							}
							Reflect.construct(fn, [], Fake);
						} else {
							try {
								Fake.call();
							} catch (x$24) {
								control = x$24;
							}
							fn.call(Fake.prototype);
						}
					} else {
						try {
							throw Error();
						} catch (x$25) {
							control = x$25;
						}
						(Fake = fn()) && "function" === typeof Fake.catch && Fake.catch(function() {});
					}
				} catch (sample) {
					if (sample && control && "string" === typeof sample.stack) return [sample.stack, control.stack];
				}
				return [null, null];
			} };
			RunInRootFrame.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
			var namePropDescriptor = Object.getOwnPropertyDescriptor(RunInRootFrame.DetermineComponentFrameRoot, "name");
			namePropDescriptor && namePropDescriptor.configurable && Object.defineProperty(RunInRootFrame.DetermineComponentFrameRoot, "name", { value: "DetermineComponentFrameRoot" });
			var _RunInRootFrame$Deter = RunInRootFrame.DetermineComponentFrameRoot(), sampleStack = _RunInRootFrame$Deter[0], controlStack = _RunInRootFrame$Deter[1];
			if (sampleStack && controlStack) {
				var sampleLines = sampleStack.split("\n"), controlLines = controlStack.split("\n");
				for (namePropDescriptor = RunInRootFrame = 0; RunInRootFrame < sampleLines.length && !sampleLines[RunInRootFrame].includes("DetermineComponentFrameRoot");) RunInRootFrame++;
				for (; namePropDescriptor < controlLines.length && !controlLines[namePropDescriptor].includes("DetermineComponentFrameRoot");) namePropDescriptor++;
				if (RunInRootFrame === sampleLines.length || namePropDescriptor === controlLines.length) for (RunInRootFrame = sampleLines.length - 1, namePropDescriptor = controlLines.length - 1; 1 <= RunInRootFrame && 0 <= namePropDescriptor && sampleLines[RunInRootFrame] !== controlLines[namePropDescriptor];) namePropDescriptor--;
				for (; 1 <= RunInRootFrame && 0 <= namePropDescriptor; RunInRootFrame--, namePropDescriptor--) if (sampleLines[RunInRootFrame] !== controlLines[namePropDescriptor]) {
					if (1 !== RunInRootFrame || 1 !== namePropDescriptor) do
						if (RunInRootFrame--, namePropDescriptor--, 0 > namePropDescriptor || sampleLines[RunInRootFrame] !== controlLines[namePropDescriptor]) {
							var frame = "\n" + sampleLines[RunInRootFrame].replace(" at new ", " at ");
							fn.displayName && frame.includes("<anonymous>") && (frame = frame.replace("<anonymous>", fn.displayName));
							return frame;
						}
					while (1 <= RunInRootFrame && 0 <= namePropDescriptor);
					break;
				}
			}
		} finally {
			reentry = !1, Error.prepareStackTrace = previousPrepareStackTrace;
		}
		return (previousPrepareStackTrace = fn ? fn.displayName || fn.name : "") ? describeBuiltInComponentFrame(previousPrepareStackTrace) : "";
	}
	function describeComponentStackByType(type) {
		if ("string" === typeof type) return describeBuiltInComponentFrame(type);
		if ("function" === typeof type) return type.prototype && type.prototype.isReactComponent ? describeNativeComponentFrame(type, !0) : describeNativeComponentFrame(type, !1);
		if ("object" === typeof type && null !== type) {
			switch (type.$$typeof) {
				case REACT_FORWARD_REF_TYPE: return describeNativeComponentFrame(type.render, !1);
				case REACT_MEMO_TYPE: return describeNativeComponentFrame(type.type, !1);
				case REACT_LAZY_TYPE:
					var lazyComponent = type, payload = lazyComponent._payload;
					lazyComponent = lazyComponent._init;
					try {
						type = lazyComponent(payload);
					} catch (x) {
						return describeBuiltInComponentFrame("Lazy");
					}
					return describeComponentStackByType(type);
			}
			if ("string" === typeof type.name) {
				a: {
					payload = type.name;
					lazyComponent = type.env;
					var location = type.debugLocation;
					if (null != location && (type = Error.prepareStackTrace, Error.prepareStackTrace = void 0, location = location.stack, Error.prepareStackTrace = type, location.startsWith("Error: react-stack-top-frame\n") && (location = location.slice(29)), type = location.indexOf("\n"), -1 !== type && (location = location.slice(type + 1)), type = location.indexOf("react_stack_bottom_frame"), -1 !== type && (type = location.lastIndexOf("\n", type)), type = -1 !== type ? location = location.slice(0, type) : "", location = type.lastIndexOf("\n"), type = -1 === location ? type : type.slice(location + 1), -1 !== type.indexOf(payload))) {
						payload = "\n" + type;
						break a;
					}
					payload = describeBuiltInComponentFrame(payload + (lazyComponent ? " [" + lazyComponent + "]" : ""));
				}
				return payload;
			}
		}
		switch (type) {
			case REACT_SUSPENSE_LIST_TYPE: return describeBuiltInComponentFrame("SuspenseList");
			case REACT_SUSPENSE_TYPE: return describeBuiltInComponentFrame("Suspense");
		}
		return "";
	}
	function isEligibleForOutlining(request, boundary) {
		return (500 < boundary.byteSize || !1) && null === boundary.contentPreamble;
	}
	function defaultErrorHandler(error) {
		if ("object" === typeof error && null !== error && "string" === typeof error.environmentName) {
			var JSCompiler_inline_result = error.environmentName;
			error = [error].slice(0);
			"string" === typeof error[0] ? error.splice(0, 1, "[%s] " + error[0], " " + JSCompiler_inline_result + " ") : error.splice(0, 0, "[%s]", " " + JSCompiler_inline_result + " ");
			error.unshift(console);
			JSCompiler_inline_result = bind.apply(console.error, error);
			JSCompiler_inline_result();
		} else console.error(error);
		return null;
	}
	function RequestInstance(resumableState, renderState, rootFormatContext, progressiveChunkSize, onError, onAllReady, onShellReady, onShellError, onFatalError, onPostpone, formState) {
		var abortSet = /* @__PURE__ */ new Set();
		this.destination = null;
		this.flushScheduled = !1;
		this.resumableState = resumableState;
		this.renderState = renderState;
		this.rootFormatContext = rootFormatContext;
		this.progressiveChunkSize = void 0 === progressiveChunkSize ? 12800 : progressiveChunkSize;
		this.status = 10;
		this.fatalError = null;
		this.pendingRootTasks = this.allPendingTasks = this.nextSegmentId = 0;
		this.completedPreambleSegments = this.completedRootSegment = null;
		this.byteSize = 0;
		this.abortableTasks = abortSet;
		this.pingedTasks = [];
		this.clientRenderedBoundaries = [];
		this.completedBoundaries = [];
		this.partialBoundaries = [];
		this.trackedPostpones = null;
		this.onError = void 0 === onError ? defaultErrorHandler : onError;
		this.onPostpone = void 0 === onPostpone ? noop : onPostpone;
		this.onAllReady = void 0 === onAllReady ? noop : onAllReady;
		this.onShellReady = void 0 === onShellReady ? noop : onShellReady;
		this.onShellError = void 0 === onShellError ? noop : onShellError;
		this.onFatalError = void 0 === onFatalError ? noop : onFatalError;
		this.formState = void 0 === formState ? null : formState;
	}
	function createRequest(children, resumableState, renderState, rootFormatContext, progressiveChunkSize, onError, onAllReady, onShellReady, onShellError, onFatalError, onPostpone, formState) {
		resumableState = new RequestInstance(resumableState, renderState, rootFormatContext, progressiveChunkSize, onError, onAllReady, onShellReady, onShellError, onFatalError, onPostpone, formState);
		renderState = createPendingSegment(resumableState, 0, null, rootFormatContext, !1, !1);
		renderState.parentFlushed = !0;
		children = createRenderTask(resumableState, null, children, -1, null, renderState, null, null, resumableState.abortableTasks, null, rootFormatContext, null, emptyTreeContext, null, null);
		pushComponentStack(children);
		resumableState.pingedTasks.push(children);
		return resumableState;
	}
	var currentRequest = null;
	function pingTask(request, task) {
		request.pingedTasks.push(task);
		1 === request.pingedTasks.length && (request.flushScheduled = null !== request.destination, performWork(request));
	}
	function createSuspenseBoundary(request, row, fallbackAbortableTasks, contentPreamble, fallbackPreamble) {
		fallbackAbortableTasks = {
			status: 0,
			rootSegmentID: -1,
			parentFlushed: !1,
			pendingTasks: 0,
			row,
			completedSegments: [],
			byteSize: 0,
			fallbackAbortableTasks,
			errorDigest: null,
			contentState: createHoistableState(),
			fallbackState: createHoistableState(),
			contentPreamble,
			fallbackPreamble,
			trackedContentKeyPath: null,
			trackedFallbackNode: null
		};
		null !== row && (row.pendingTasks++, contentPreamble = row.boundaries, null !== contentPreamble && (request.allPendingTasks++, fallbackAbortableTasks.pendingTasks++, contentPreamble.push(fallbackAbortableTasks)), request = row.inheritedHoistables, null !== request && hoistHoistables(fallbackAbortableTasks.contentState, request));
		return fallbackAbortableTasks;
	}
	function createRenderTask(request, thenableState, node, childIndex, blockedBoundary, blockedSegment, blockedPreamble, hoistableState, abortSet, keyPath, formatContext, context, treeContext, row, componentStack) {
		request.allPendingTasks++;
		null === blockedBoundary ? request.pendingRootTasks++ : blockedBoundary.pendingTasks++;
		null !== row && row.pendingTasks++;
		var task = {
			replay: null,
			node,
			childIndex,
			ping: function() {
				return pingTask(request, task);
			},
			blockedBoundary,
			blockedSegment,
			blockedPreamble,
			hoistableState,
			abortSet,
			keyPath,
			formatContext,
			context,
			treeContext,
			row,
			componentStack,
			thenableState
		};
		abortSet.add(task);
		return task;
	}
	function createReplayTask(request, thenableState, replay, node, childIndex, blockedBoundary, hoistableState, abortSet, keyPath, formatContext, context, treeContext, row, componentStack) {
		request.allPendingTasks++;
		null === blockedBoundary ? request.pendingRootTasks++ : blockedBoundary.pendingTasks++;
		null !== row && row.pendingTasks++;
		replay.pendingTasks++;
		var task = {
			replay,
			node,
			childIndex,
			ping: function() {
				return pingTask(request, task);
			},
			blockedBoundary,
			blockedSegment: null,
			blockedPreamble: null,
			hoistableState,
			abortSet,
			keyPath,
			formatContext,
			context,
			treeContext,
			row,
			componentStack,
			thenableState
		};
		abortSet.add(task);
		return task;
	}
	function createPendingSegment(request, index, boundary, parentFormatContext, lastPushedText, textEmbedded) {
		return {
			status: 0,
			parentFlushed: !1,
			id: -1,
			index,
			chunks: [],
			children: [],
			preambleChildren: [],
			parentFormatContext,
			boundary,
			lastPushedText,
			textEmbedded
		};
	}
	function pushComponentStack(task) {
		var node = task.node;
		if ("object" === typeof node && null !== node) switch (node.$$typeof) {
			case REACT_ELEMENT_TYPE: task.componentStack = {
				parent: task.componentStack,
				type: node.type
			};
		}
	}
	function replaceSuspenseComponentStackWithSuspenseFallbackStack(componentStack) {
		return null === componentStack ? null : {
			parent: componentStack.parent,
			type: "Suspense Fallback"
		};
	}
	function getThrownInfo(node$jscomp$0) {
		var errorInfo = {};
		node$jscomp$0 && Object.defineProperty(errorInfo, "componentStack", {
			configurable: !0,
			enumerable: !0,
			get: function() {
				try {
					var info = "", node = node$jscomp$0;
					do
						info += describeComponentStackByType(node.type), node = node.parent;
					while (node);
					var JSCompiler_inline_result = info;
				} catch (x) {
					JSCompiler_inline_result = "\nError generating stack: " + x.message + "\n" + x.stack;
				}
				Object.defineProperty(errorInfo, "componentStack", { value: JSCompiler_inline_result });
				return JSCompiler_inline_result;
			}
		});
		return errorInfo;
	}
	function logRecoverableError(request, error, errorInfo) {
		request = request.onError;
		error = request(error, errorInfo);
		if (null == error || "string" === typeof error) return error;
	}
	function fatalError(request, error) {
		var onShellError = request.onShellError, onFatalError = request.onFatalError;
		onShellError(error);
		onFatalError(error);
		null !== request.destination ? (request.status = 14, request.destination.destroy(error)) : (request.status = 13, request.fatalError = error);
	}
	function finishSuspenseListRow(request, row) {
		unblockSuspenseListRow(request, row.next, row.hoistables);
	}
	function unblockSuspenseListRow(request, unblockedRow, inheritedHoistables) {
		for (; null !== unblockedRow;) {
			null !== inheritedHoistables && (hoistHoistables(unblockedRow.hoistables, inheritedHoistables), unblockedRow.inheritedHoistables = inheritedHoistables);
			var unblockedBoundaries = unblockedRow.boundaries;
			if (null !== unblockedBoundaries) {
				unblockedRow.boundaries = null;
				for (var i = 0; i < unblockedBoundaries.length; i++) {
					var unblockedBoundary = unblockedBoundaries[i];
					null !== inheritedHoistables && hoistHoistables(unblockedBoundary.contentState, inheritedHoistables);
					finishedTask(request, unblockedBoundary, null, null);
				}
			}
			unblockedRow.pendingTasks--;
			if (0 < unblockedRow.pendingTasks) break;
			inheritedHoistables = unblockedRow.hoistables;
			unblockedRow = unblockedRow.next;
		}
	}
	function tryToResolveTogetherRow(request, togetherRow) {
		var boundaries = togetherRow.boundaries;
		if (null !== boundaries && togetherRow.pendingTasks === boundaries.length) {
			for (var allCompleteAndInlinable = !0, i = 0; i < boundaries.length; i++) {
				var rowBoundary = boundaries[i];
				if (1 !== rowBoundary.pendingTasks || rowBoundary.parentFlushed || isEligibleForOutlining(request, rowBoundary)) {
					allCompleteAndInlinable = !1;
					break;
				}
			}
			allCompleteAndInlinable && unblockSuspenseListRow(request, togetherRow, togetherRow.hoistables);
		}
	}
	function createSuspenseListRow(previousRow) {
		var newRow = {
			pendingTasks: 1,
			boundaries: null,
			hoistables: createHoistableState(),
			inheritedHoistables: null,
			together: !1,
			next: null
		};
		null !== previousRow && 0 < previousRow.pendingTasks && (newRow.pendingTasks++, newRow.boundaries = [], previousRow.next = newRow);
		return newRow;
	}
	function renderSuspenseListRows(request, task, keyPath, rows, revealOrder) {
		var prevKeyPath = task.keyPath, prevTreeContext = task.treeContext, prevRow = task.row;
		task.keyPath = keyPath;
		keyPath = rows.length;
		var previousSuspenseListRow = null;
		if (null !== task.replay) {
			var resumeSlots = task.replay.slots;
			if (null !== resumeSlots && "object" === typeof resumeSlots) for (var n = 0; n < keyPath; n++) {
				var i = "backwards" !== revealOrder && "unstable_legacy-backwards" !== revealOrder ? n : keyPath - 1 - n, node = rows[i];
				task.row = previousSuspenseListRow = createSuspenseListRow(previousSuspenseListRow);
				task.treeContext = pushTreeContext(prevTreeContext, keyPath, i);
				var resumeSegmentID = resumeSlots[i];
				"number" === typeof resumeSegmentID ? (resumeNode(request, task, resumeSegmentID, node, i), delete resumeSlots[i]) : renderNode(request, task, node, i);
				0 === --previousSuspenseListRow.pendingTasks && finishSuspenseListRow(request, previousSuspenseListRow);
			}
			else for (resumeSlots = 0; resumeSlots < keyPath; resumeSlots++) n = "backwards" !== revealOrder && "unstable_legacy-backwards" !== revealOrder ? resumeSlots : keyPath - 1 - resumeSlots, i = rows[n], task.row = previousSuspenseListRow = createSuspenseListRow(previousSuspenseListRow), task.treeContext = pushTreeContext(prevTreeContext, keyPath, n), renderNode(request, task, i, n), 0 === --previousSuspenseListRow.pendingTasks && finishSuspenseListRow(request, previousSuspenseListRow);
		} else if ("backwards" !== revealOrder && "unstable_legacy-backwards" !== revealOrder) for (revealOrder = 0; revealOrder < keyPath; revealOrder++) resumeSlots = rows[revealOrder], task.row = previousSuspenseListRow = createSuspenseListRow(previousSuspenseListRow), task.treeContext = pushTreeContext(prevTreeContext, keyPath, revealOrder), renderNode(request, task, resumeSlots, revealOrder), 0 === --previousSuspenseListRow.pendingTasks && finishSuspenseListRow(request, previousSuspenseListRow);
		else {
			revealOrder = task.blockedSegment;
			resumeSlots = revealOrder.children.length;
			n = revealOrder.chunks.length;
			for (i = keyPath - 1; 0 <= i; i--) {
				node = rows[i];
				task.row = previousSuspenseListRow = createSuspenseListRow(previousSuspenseListRow);
				task.treeContext = pushTreeContext(prevTreeContext, keyPath, i);
				resumeSegmentID = createPendingSegment(request, n, null, task.formatContext, 0 === i ? revealOrder.lastPushedText : !0, !0);
				revealOrder.children.splice(resumeSlots, 0, resumeSegmentID);
				task.blockedSegment = resumeSegmentID;
				try {
					renderNode(request, task, node, i), pushSegmentFinale(resumeSegmentID.chunks, request.renderState, resumeSegmentID.lastPushedText, resumeSegmentID.textEmbedded), resumeSegmentID.status = 1, 0 === --previousSuspenseListRow.pendingTasks && finishSuspenseListRow(request, previousSuspenseListRow);
				} catch (thrownValue) {
					throw resumeSegmentID.status = 12 === request.status ? 3 : 4, thrownValue;
				}
			}
			task.blockedSegment = revealOrder;
			revealOrder.lastPushedText = !1;
		}
		null !== prevRow && null !== previousSuspenseListRow && 0 < previousSuspenseListRow.pendingTasks && (prevRow.pendingTasks++, previousSuspenseListRow.next = prevRow);
		task.treeContext = prevTreeContext;
		task.row = prevRow;
		task.keyPath = prevKeyPath;
	}
	function renderWithHooks(request, task, keyPath, Component, props, secondArg) {
		var prevThenableState = task.thenableState;
		task.thenableState = null;
		currentlyRenderingComponent = {};
		currentlyRenderingTask = task;
		currentlyRenderingRequest = request;
		currentlyRenderingKeyPath = keyPath;
		actionStateCounter = localIdCounter = 0;
		actionStateMatchingIndex = -1;
		thenableIndexCounter = 0;
		thenableState = prevThenableState;
		for (request = Component(props, secondArg); didScheduleRenderPhaseUpdate;) didScheduleRenderPhaseUpdate = !1, actionStateCounter = localIdCounter = 0, actionStateMatchingIndex = -1, thenableIndexCounter = 0, numberOfReRenders += 1, workInProgressHook = null, request = Component(props, secondArg);
		resetHooksState();
		return request;
	}
	function finishFunctionComponent(request, task, keyPath, children, hasId, actionStateCount, actionStateMatchingIndex) {
		var didEmitActionStateMarkers = !1;
		if (0 !== actionStateCount && null !== request.formState) {
			var segment = task.blockedSegment;
			if (null !== segment) {
				didEmitActionStateMarkers = !0;
				segment = segment.chunks;
				for (var i = 0; i < actionStateCount; i++) i === actionStateMatchingIndex ? segment.push("<!--F!-->") : segment.push("<!--F-->");
			}
		}
		actionStateCount = task.keyPath;
		task.keyPath = keyPath;
		hasId ? (keyPath = task.treeContext, task.treeContext = pushTreeContext(keyPath, 1, 0), renderNode(request, task, children, -1), task.treeContext = keyPath) : didEmitActionStateMarkers ? renderNode(request, task, children, -1) : renderNodeDestructive(request, task, children, -1);
		task.keyPath = actionStateCount;
	}
	function renderElement(request, task, keyPath, type, props, ref) {
		if ("function" === typeof type) if (type.prototype && type.prototype.isReactComponent) {
			var newProps = props;
			if ("ref" in props) {
				newProps = {};
				for (var propName in props) "ref" !== propName && (newProps[propName] = props[propName]);
			}
			var defaultProps = type.defaultProps;
			if (defaultProps) {
				newProps === props && (newProps = assign({}, newProps, props));
				for (var propName$43 in defaultProps) void 0 === newProps[propName$43] && (newProps[propName$43] = defaultProps[propName$43]);
			}
			props = newProps;
			newProps = emptyContextObject;
			defaultProps = type.contextType;
			"object" === typeof defaultProps && null !== defaultProps && (newProps = defaultProps._currentValue2);
			newProps = new type(props, newProps);
			var initialState = void 0 !== newProps.state ? newProps.state : null;
			newProps.updater = classComponentUpdater;
			newProps.props = props;
			newProps.state = initialState;
			defaultProps = {
				queue: [],
				replace: !1
			};
			newProps._reactInternals = defaultProps;
			ref = type.contextType;
			newProps.context = "object" === typeof ref && null !== ref ? ref._currentValue2 : emptyContextObject;
			ref = type.getDerivedStateFromProps;
			"function" === typeof ref && (ref = ref(props, initialState), initialState = null === ref || void 0 === ref ? initialState : assign({}, initialState, ref), newProps.state = initialState);
			if ("function" !== typeof type.getDerivedStateFromProps && "function" !== typeof newProps.getSnapshotBeforeUpdate && ("function" === typeof newProps.UNSAFE_componentWillMount || "function" === typeof newProps.componentWillMount)) if (type = newProps.state, "function" === typeof newProps.componentWillMount && newProps.componentWillMount(), "function" === typeof newProps.UNSAFE_componentWillMount && newProps.UNSAFE_componentWillMount(), type !== newProps.state && classComponentUpdater.enqueueReplaceState(newProps, newProps.state, null), null !== defaultProps.queue && 0 < defaultProps.queue.length) if (type = defaultProps.queue, ref = defaultProps.replace, defaultProps.queue = null, defaultProps.replace = !1, ref && 1 === type.length) newProps.state = type[0];
			else {
				defaultProps = ref ? type[0] : newProps.state;
				initialState = !0;
				for (ref = ref ? 1 : 0; ref < type.length; ref++) propName$43 = type[ref], propName$43 = "function" === typeof propName$43 ? propName$43.call(newProps, defaultProps, props, void 0) : propName$43, null != propName$43 && (initialState ? (initialState = !1, defaultProps = assign({}, defaultProps, propName$43)) : assign(defaultProps, propName$43));
				newProps.state = defaultProps;
			}
			else defaultProps.queue = null;
			type = newProps.render();
			if (12 === request.status) throw null;
			props = task.keyPath;
			task.keyPath = keyPath;
			renderNodeDestructive(request, task, type, -1);
			task.keyPath = props;
		} else {
			type = renderWithHooks(request, task, keyPath, type, props, void 0);
			if (12 === request.status) throw null;
			finishFunctionComponent(request, task, keyPath, type, 0 !== localIdCounter, actionStateCounter, actionStateMatchingIndex);
		}
		else if ("string" === typeof type) if (newProps = task.blockedSegment, null === newProps) newProps = props.children, defaultProps = task.formatContext, initialState = task.keyPath, task.formatContext = getChildFormatContext(defaultProps, type, props), task.keyPath = keyPath, renderNode(request, task, newProps, -1), task.formatContext = defaultProps, task.keyPath = initialState;
		else {
			initialState = pushStartInstance(newProps.chunks, type, props, request.resumableState, request.renderState, task.blockedPreamble, task.hoistableState, task.formatContext, newProps.lastPushedText);
			newProps.lastPushedText = !1;
			defaultProps = task.formatContext;
			ref = task.keyPath;
			task.keyPath = keyPath;
			if (3 === (task.formatContext = getChildFormatContext(defaultProps, type, props)).insertionMode) {
				keyPath = createPendingSegment(request, 0, null, task.formatContext, !1, !1);
				newProps.preambleChildren.push(keyPath);
				task.blockedSegment = keyPath;
				try {
					keyPath.status = 6, renderNode(request, task, initialState, -1), pushSegmentFinale(keyPath.chunks, request.renderState, keyPath.lastPushedText, keyPath.textEmbedded), keyPath.status = 1;
				} finally {
					task.blockedSegment = newProps;
				}
			} else renderNode(request, task, initialState, -1);
			task.formatContext = defaultProps;
			task.keyPath = ref;
			a: {
				task = newProps.chunks;
				request = request.resumableState;
				switch (type) {
					case "title":
					case "style":
					case "script":
					case "area":
					case "base":
					case "br":
					case "col":
					case "embed":
					case "hr":
					case "img":
					case "input":
					case "keygen":
					case "link":
					case "meta":
					case "param":
					case "source":
					case "track":
					case "wbr": break a;
					case "body":
						if (1 >= defaultProps.insertionMode) {
							request.hasBody = !0;
							break a;
						}
						break;
					case "html":
						if (0 === defaultProps.insertionMode) {
							request.hasHtml = !0;
							break a;
						}
						break;
					case "head": if (1 >= defaultProps.insertionMode) break a;
				}
				task.push(endChunkForTag(type));
			}
			newProps.lastPushedText = !1;
		}
		else {
			switch (type) {
				case REACT_LEGACY_HIDDEN_TYPE:
				case REACT_STRICT_MODE_TYPE:
				case REACT_PROFILER_TYPE:
				case REACT_FRAGMENT_TYPE:
					type = task.keyPath;
					task.keyPath = keyPath;
					renderNodeDestructive(request, task, props.children, -1);
					task.keyPath = type;
					return;
				case REACT_ACTIVITY_TYPE:
					type = task.blockedSegment;
					null === type ? "hidden" !== props.mode && (type = task.keyPath, task.keyPath = keyPath, renderNode(request, task, props.children, -1), task.keyPath = type) : "hidden" !== props.mode && (request.renderState.generateStaticMarkup || type.chunks.push("<!--&-->"), type.lastPushedText = !1, newProps = task.keyPath, task.keyPath = keyPath, renderNode(request, task, props.children, -1), task.keyPath = newProps, request.renderState.generateStaticMarkup || type.chunks.push("<!--/&-->"), type.lastPushedText = !1);
					return;
				case REACT_SUSPENSE_LIST_TYPE:
					a: {
						type = props.children;
						props = props.revealOrder;
						if ("forwards" === props || "backwards" === props || "unstable_legacy-backwards" === props) {
							if (isArrayImpl(type)) {
								renderSuspenseListRows(request, task, keyPath, type, props);
								break a;
							}
							if (newProps = getIteratorFn(type)) {
								if (newProps = newProps.call(type)) {
									defaultProps = newProps.next();
									if (!defaultProps.done) {
										do
											defaultProps = newProps.next();
										while (!defaultProps.done);
										renderSuspenseListRows(request, task, keyPath, type, props);
									}
									break a;
								}
							}
						}
						"together" === props ? (props = task.keyPath, newProps = task.row, defaultProps = task.row = createSuspenseListRow(null), defaultProps.boundaries = [], defaultProps.together = !0, task.keyPath = keyPath, renderNodeDestructive(request, task, type, -1), 0 === --defaultProps.pendingTasks && finishSuspenseListRow(request, defaultProps), task.keyPath = props, task.row = newProps, null !== newProps && 0 < defaultProps.pendingTasks && (newProps.pendingTasks++, defaultProps.next = newProps)) : (props = task.keyPath, task.keyPath = keyPath, renderNodeDestructive(request, task, type, -1), task.keyPath = props);
					}
					return;
				case REACT_VIEW_TRANSITION_TYPE:
				case REACT_SCOPE_TYPE: throw Error(formatProdErrorMessage(343));
				case REACT_SUSPENSE_TYPE:
					a: if (null !== task.replay) {
						type = task.keyPath;
						newProps = task.formatContext;
						defaultProps = task.row;
						task.keyPath = keyPath;
						task.formatContext = getSuspenseContentFormatContext(request.resumableState, newProps);
						task.row = null;
						keyPath = props.children;
						try {
							renderNode(request, task, keyPath, -1);
						} finally {
							task.keyPath = type, task.formatContext = newProps, task.row = defaultProps;
						}
					} else {
						type = task.keyPath;
						ref = task.formatContext;
						var prevRow = task.row, parentBoundary = task.blockedBoundary;
						propName$43 = task.blockedPreamble;
						var parentHoistableState = task.hoistableState;
						propName = task.blockedSegment;
						var fallback = props.fallback;
						props = props.children;
						var fallbackAbortSet = /* @__PURE__ */ new Set();
						var newBoundary = createSuspenseBoundary(request, task.row, fallbackAbortSet, null, null);
						null !== request.trackedPostpones && (newBoundary.trackedContentKeyPath = keyPath);
						var boundarySegment = createPendingSegment(request, propName.chunks.length, newBoundary, task.formatContext, !1, !1);
						propName.children.push(boundarySegment);
						propName.lastPushedText = !1;
						var contentRootSegment = createPendingSegment(request, 0, null, task.formatContext, !1, !1);
						contentRootSegment.parentFlushed = !0;
						if (null !== request.trackedPostpones) {
							newProps = task.componentStack;
							defaultProps = [
								keyPath[0],
								"Suspense Fallback",
								keyPath[2]
							];
							initialState = [
								defaultProps[1],
								defaultProps[2],
								[],
								null
							];
							request.trackedPostpones.workingMap.set(defaultProps, initialState);
							newBoundary.trackedFallbackNode = initialState;
							task.blockedSegment = boundarySegment;
							task.blockedPreamble = newBoundary.fallbackPreamble;
							task.keyPath = defaultProps;
							task.formatContext = getSuspenseFallbackFormatContext(request.resumableState, ref);
							task.componentStack = replaceSuspenseComponentStackWithSuspenseFallbackStack(newProps);
							boundarySegment.status = 6;
							try {
								renderNode(request, task, fallback, -1), pushSegmentFinale(boundarySegment.chunks, request.renderState, boundarySegment.lastPushedText, boundarySegment.textEmbedded), boundarySegment.status = 1;
							} catch (thrownValue) {
								throw boundarySegment.status = 12 === request.status ? 3 : 4, thrownValue;
							} finally {
								task.blockedSegment = propName, task.blockedPreamble = propName$43, task.keyPath = type, task.formatContext = ref;
							}
							task = createRenderTask(request, null, props, -1, newBoundary, contentRootSegment, newBoundary.contentPreamble, newBoundary.contentState, task.abortSet, keyPath, getSuspenseContentFormatContext(request.resumableState, task.formatContext), task.context, task.treeContext, null, newProps);
							pushComponentStack(task);
							request.pingedTasks.push(task);
						} else {
							task.blockedBoundary = newBoundary;
							task.blockedPreamble = newBoundary.contentPreamble;
							task.hoistableState = newBoundary.contentState;
							task.blockedSegment = contentRootSegment;
							task.keyPath = keyPath;
							task.formatContext = getSuspenseContentFormatContext(request.resumableState, ref);
							task.row = null;
							contentRootSegment.status = 6;
							try {
								if (renderNode(request, task, props, -1), pushSegmentFinale(contentRootSegment.chunks, request.renderState, contentRootSegment.lastPushedText, contentRootSegment.textEmbedded), contentRootSegment.status = 1, queueCompletedSegment(newBoundary, contentRootSegment), 0 === newBoundary.pendingTasks && 0 === newBoundary.status) {
									if (newBoundary.status = 1, !isEligibleForOutlining(request, newBoundary)) {
										null !== prevRow && 0 === --prevRow.pendingTasks && finishSuspenseListRow(request, prevRow);
										0 === request.pendingRootTasks && task.blockedPreamble && preparePreamble(request);
										break a;
									}
								} else null !== prevRow && prevRow.together && tryToResolveTogetherRow(request, prevRow);
							} catch (thrownValue$30) {
								newBoundary.status = 4, 12 === request.status ? (contentRootSegment.status = 3, newProps = request.fatalError) : (contentRootSegment.status = 4, newProps = thrownValue$30), defaultProps = getThrownInfo(task.componentStack), initialState = logRecoverableError(request, newProps, defaultProps), newBoundary.errorDigest = initialState, untrackBoundary(request, newBoundary);
							} finally {
								task.blockedBoundary = parentBoundary, task.blockedPreamble = propName$43, task.hoistableState = parentHoistableState, task.blockedSegment = propName, task.keyPath = type, task.formatContext = ref, task.row = prevRow;
							}
							task = createRenderTask(request, null, fallback, -1, parentBoundary, boundarySegment, newBoundary.fallbackPreamble, newBoundary.fallbackState, fallbackAbortSet, [
								keyPath[0],
								"Suspense Fallback",
								keyPath[2]
							], getSuspenseFallbackFormatContext(request.resumableState, task.formatContext), task.context, task.treeContext, task.row, replaceSuspenseComponentStackWithSuspenseFallbackStack(task.componentStack));
							pushComponentStack(task);
							request.pingedTasks.push(task);
						}
					}
					return;
			}
			if ("object" === typeof type && null !== type) switch (type.$$typeof) {
				case REACT_FORWARD_REF_TYPE:
					if ("ref" in props) for (fallback in newProps = {}, props) "ref" !== fallback && (newProps[fallback] = props[fallback]);
					else newProps = props;
					type = renderWithHooks(request, task, keyPath, type.render, newProps, ref);
					finishFunctionComponent(request, task, keyPath, type, 0 !== localIdCounter, actionStateCounter, actionStateMatchingIndex);
					return;
				case REACT_MEMO_TYPE:
					renderElement(request, task, keyPath, type.type, props, ref);
					return;
				case REACT_CONTEXT_TYPE:
					defaultProps = props.children;
					newProps = task.keyPath;
					props = props.value;
					initialState = type._currentValue2;
					type._currentValue2 = props;
					ref = currentActiveSnapshot;
					currentActiveSnapshot = type = {
						parent: ref,
						depth: null === ref ? 0 : ref.depth + 1,
						context: type,
						parentValue: initialState,
						value: props
					};
					task.context = type;
					task.keyPath = keyPath;
					renderNodeDestructive(request, task, defaultProps, -1);
					request = currentActiveSnapshot;
					if (null === request) throw Error(formatProdErrorMessage(403));
					request.context._currentValue2 = request.parentValue;
					request = currentActiveSnapshot = request.parent;
					task.context = request;
					task.keyPath = newProps;
					return;
				case REACT_CONSUMER_TYPE:
					props = props.children;
					type = props(type._context._currentValue2);
					props = task.keyPath;
					task.keyPath = keyPath;
					renderNodeDestructive(request, task, type, -1);
					task.keyPath = props;
					return;
				case REACT_LAZY_TYPE:
					newProps = type._init;
					type = newProps(type._payload);
					if (12 === request.status) throw null;
					renderElement(request, task, keyPath, type, props, ref);
					return;
			}
			throw Error(formatProdErrorMessage(130, null == type ? type : typeof type, ""));
		}
	}
	function resumeNode(request, task, segmentId, node, childIndex) {
		var prevReplay = task.replay, blockedBoundary = task.blockedBoundary, resumedSegment = createPendingSegment(request, 0, null, task.formatContext, !1, !1);
		resumedSegment.id = segmentId;
		resumedSegment.parentFlushed = !0;
		try {
			task.replay = null, task.blockedSegment = resumedSegment, renderNode(request, task, node, childIndex), resumedSegment.status = 1, null === blockedBoundary ? request.completedRootSegment = resumedSegment : (queueCompletedSegment(blockedBoundary, resumedSegment), blockedBoundary.parentFlushed && request.partialBoundaries.push(blockedBoundary));
		} finally {
			task.replay = prevReplay, task.blockedSegment = null;
		}
	}
	function renderNodeDestructive(request, task, node, childIndex) {
		null !== task.replay && "number" === typeof task.replay.slots ? resumeNode(request, task, task.replay.slots, node, childIndex) : (task.node = node, task.childIndex = childIndex, node = task.componentStack, pushComponentStack(task), retryNode(request, task), task.componentStack = node);
	}
	function retryNode(request, task) {
		var node = task.node, childIndex = task.childIndex;
		if (null !== node) {
			if ("object" === typeof node) {
				switch (node.$$typeof) {
					case REACT_ELEMENT_TYPE:
						var type = node.type, key = node.key, props = node.props;
						node = props.ref;
						var ref = void 0 !== node ? node : null, name = getComponentNameFromType(type), keyOrIndex = null == key ? -1 === childIndex ? 0 : childIndex : key;
						key = [
							task.keyPath,
							name,
							keyOrIndex
						];
						if (null !== task.replay) a: {
							var replay = task.replay;
							childIndex = replay.nodes;
							for (node = 0; node < childIndex.length; node++) {
								var node$jscomp$0 = childIndex[node];
								if (keyOrIndex === node$jscomp$0[1]) {
									if (4 === node$jscomp$0.length) {
										if (null !== name && name !== node$jscomp$0[0]) throw Error(formatProdErrorMessage(490, node$jscomp$0[0], name));
										var childNodes = node$jscomp$0[2];
										name = node$jscomp$0[3];
										keyOrIndex = task.node;
										task.replay = {
											nodes: childNodes,
											slots: name,
											pendingTasks: 1
										};
										try {
											renderElement(request, task, key, type, props, ref);
											if (1 === task.replay.pendingTasks && 0 < task.replay.nodes.length) throw Error(formatProdErrorMessage(488));
											task.replay.pendingTasks--;
										} catch (x) {
											if ("object" === typeof x && null !== x && (x === SuspenseException || "function" === typeof x.then)) throw task.node === keyOrIndex ? task.replay = replay : childIndex.splice(node, 1), x;
											task.replay.pendingTasks--;
											props = getThrownInfo(task.componentStack);
											key = request;
											request = task.blockedBoundary;
											type = x;
											props = logRecoverableError(key, type, props);
											abortRemainingReplayNodes(key, request, childNodes, name, type, props);
										}
										task.replay = replay;
									} else {
										if (type !== REACT_SUSPENSE_TYPE) throw Error(formatProdErrorMessage(490, "Suspense", getComponentNameFromType(type) || "Unknown"));
										b: {
											replay = void 0;
											type = node$jscomp$0[5];
											ref = node$jscomp$0[2];
											name = node$jscomp$0[3];
											keyOrIndex = null === node$jscomp$0[4] ? [] : node$jscomp$0[4][2];
											node$jscomp$0 = null === node$jscomp$0[4] ? null : node$jscomp$0[4][3];
											var prevKeyPath = task.keyPath, prevContext = task.formatContext, prevRow = task.row, previousReplaySet = task.replay, parentBoundary = task.blockedBoundary, parentHoistableState = task.hoistableState, content = props.children, fallback = props.fallback, fallbackAbortSet = /* @__PURE__ */ new Set();
											props = createSuspenseBoundary(request, task.row, fallbackAbortSet, null, null);
											props.parentFlushed = !0;
											props.rootSegmentID = type;
											task.blockedBoundary = props;
											task.hoistableState = props.contentState;
											task.keyPath = key;
											task.formatContext = getSuspenseContentFormatContext(request.resumableState, prevContext);
											task.row = null;
											task.replay = {
												nodes: ref,
												slots: name,
												pendingTasks: 1
											};
											try {
												renderNode(request, task, content, -1);
												if (1 === task.replay.pendingTasks && 0 < task.replay.nodes.length) throw Error(formatProdErrorMessage(488));
												task.replay.pendingTasks--;
												if (0 === props.pendingTasks && 0 === props.status) {
													props.status = 1;
													request.completedBoundaries.push(props);
													break b;
												}
											} catch (error) {
												props.status = 4, childNodes = getThrownInfo(task.componentStack), replay = logRecoverableError(request, error, childNodes), props.errorDigest = replay, task.replay.pendingTasks--, request.clientRenderedBoundaries.push(props);
											} finally {
												task.blockedBoundary = parentBoundary, task.hoistableState = parentHoistableState, task.replay = previousReplaySet, task.keyPath = prevKeyPath, task.formatContext = prevContext, task.row = prevRow;
											}
											childNodes = createReplayTask(request, null, {
												nodes: keyOrIndex,
												slots: node$jscomp$0,
												pendingTasks: 0
											}, fallback, -1, parentBoundary, props.fallbackState, fallbackAbortSet, [
												key[0],
												"Suspense Fallback",
												key[2]
											], getSuspenseFallbackFormatContext(request.resumableState, task.formatContext), task.context, task.treeContext, task.row, replaceSuspenseComponentStackWithSuspenseFallbackStack(task.componentStack));
											pushComponentStack(childNodes);
											request.pingedTasks.push(childNodes);
										}
									}
									childIndex.splice(node, 1);
									break a;
								}
							}
						}
						else renderElement(request, task, key, type, props, ref);
						return;
					case REACT_PORTAL_TYPE: throw Error(formatProdErrorMessage(257));
					case REACT_LAZY_TYPE:
						childNodes = node._init;
						node = childNodes(node._payload);
						if (12 === request.status) throw null;
						renderNodeDestructive(request, task, node, childIndex);
						return;
				}
				if (isArrayImpl(node)) {
					renderChildrenArray(request, task, node, childIndex);
					return;
				}
				if (childNodes = getIteratorFn(node)) {
					if (childNodes = childNodes.call(node)) {
						node = childNodes.next();
						if (!node.done) {
							props = [];
							do
								props.push(node.value), node = childNodes.next();
							while (!node.done);
							renderChildrenArray(request, task, props, childIndex);
						}
						return;
					}
				}
				if ("function" === typeof node.then) return task.thenableState = null, renderNodeDestructive(request, task, unwrapThenable(node), childIndex);
				if (node.$$typeof === REACT_CONTEXT_TYPE) return renderNodeDestructive(request, task, node._currentValue2, childIndex);
				childIndex = Object.prototype.toString.call(node);
				throw Error(formatProdErrorMessage(31, "[object Object]" === childIndex ? "object with keys {" + Object.keys(node).join(", ") + "}" : childIndex));
			}
			if ("string" === typeof node) childIndex = task.blockedSegment, null !== childIndex && (childIndex.lastPushedText = pushTextInstance(childIndex.chunks, node, request.renderState, childIndex.lastPushedText));
			else if ("number" === typeof node || "bigint" === typeof node) childIndex = task.blockedSegment, null !== childIndex && (childIndex.lastPushedText = pushTextInstance(childIndex.chunks, "" + node, request.renderState, childIndex.lastPushedText));
		}
	}
	function renderChildrenArray(request, task, children, childIndex) {
		var prevKeyPath = task.keyPath;
		if (-1 !== childIndex && (task.keyPath = [
			task.keyPath,
			"Fragment",
			childIndex
		], null !== task.replay)) {
			for (var replay = task.replay, replayNodes = replay.nodes, j = 0; j < replayNodes.length; j++) {
				var node = replayNodes[j];
				if (node[1] === childIndex) {
					childIndex = node[2];
					node = node[3];
					task.replay = {
						nodes: childIndex,
						slots: node,
						pendingTasks: 1
					};
					try {
						renderChildrenArray(request, task, children, -1);
						if (1 === task.replay.pendingTasks && 0 < task.replay.nodes.length) throw Error(formatProdErrorMessage(488));
						task.replay.pendingTasks--;
					} catch (x) {
						if ("object" === typeof x && null !== x && (x === SuspenseException || "function" === typeof x.then)) throw x;
						task.replay.pendingTasks--;
						children = getThrownInfo(task.componentStack);
						var boundary = task.blockedBoundary, error = x;
						children = logRecoverableError(request, error, children);
						abortRemainingReplayNodes(request, boundary, childIndex, node, error, children);
					}
					task.replay = replay;
					replayNodes.splice(j, 1);
					break;
				}
			}
			task.keyPath = prevKeyPath;
			return;
		}
		replay = task.treeContext;
		replayNodes = children.length;
		if (null !== task.replay && (j = task.replay.slots, null !== j && "object" === typeof j)) {
			for (childIndex = 0; childIndex < replayNodes; childIndex++) node = children[childIndex], task.treeContext = pushTreeContext(replay, replayNodes, childIndex), boundary = j[childIndex], "number" === typeof boundary ? (resumeNode(request, task, boundary, node, childIndex), delete j[childIndex]) : renderNode(request, task, node, childIndex);
			task.treeContext = replay;
			task.keyPath = prevKeyPath;
			return;
		}
		for (j = 0; j < replayNodes; j++) childIndex = children[j], task.treeContext = pushTreeContext(replay, replayNodes, j), renderNode(request, task, childIndex, j);
		task.treeContext = replay;
		task.keyPath = prevKeyPath;
	}
	function trackPostponedBoundary(request, trackedPostpones, boundary) {
		boundary.status = 5;
		boundary.rootSegmentID = request.nextSegmentId++;
		request = boundary.trackedContentKeyPath;
		if (null === request) throw Error(formatProdErrorMessage(486));
		var fallbackReplayNode = boundary.trackedFallbackNode, children = [], boundaryNode = trackedPostpones.workingMap.get(request);
		if (void 0 === boundaryNode) return boundary = [
			request[1],
			request[2],
			children,
			null,
			fallbackReplayNode,
			boundary.rootSegmentID
		], trackedPostpones.workingMap.set(request, boundary), addToReplayParent(boundary, request[0], trackedPostpones), boundary;
		boundaryNode[4] = fallbackReplayNode;
		boundaryNode[5] = boundary.rootSegmentID;
		return boundaryNode;
	}
	function trackPostpone(request, trackedPostpones, task, segment) {
		segment.status = 5;
		var keyPath = task.keyPath, boundary = task.blockedBoundary;
		if (null === boundary) segment.id = request.nextSegmentId++, trackedPostpones.rootSlots = segment.id, null !== request.completedRootSegment && (request.completedRootSegment.status = 5);
		else {
			if (null !== boundary && 0 === boundary.status) {
				var boundaryNode = trackPostponedBoundary(request, trackedPostpones, boundary);
				if (boundary.trackedContentKeyPath === keyPath && -1 === task.childIndex) {
					-1 === segment.id && (segment.id = segment.parentFlushed ? boundary.rootSegmentID : request.nextSegmentId++);
					boundaryNode[3] = segment.id;
					return;
				}
			}
			-1 === segment.id && (segment.id = segment.parentFlushed && null !== boundary ? boundary.rootSegmentID : request.nextSegmentId++);
			if (-1 === task.childIndex) null === keyPath ? trackedPostpones.rootSlots = segment.id : (task = trackedPostpones.workingMap.get(keyPath), void 0 === task ? (task = [
				keyPath[1],
				keyPath[2],
				[],
				segment.id
			], addToReplayParent(task, keyPath[0], trackedPostpones)) : task[3] = segment.id);
			else {
				if (null === keyPath) {
					if (request = trackedPostpones.rootSlots, null === request) request = trackedPostpones.rootSlots = {};
					else if ("number" === typeof request) throw Error(formatProdErrorMessage(491));
				} else if (boundary = trackedPostpones.workingMap, boundaryNode = boundary.get(keyPath), void 0 === boundaryNode) request = {}, boundaryNode = [
					keyPath[1],
					keyPath[2],
					[],
					request
				], boundary.set(keyPath, boundaryNode), addToReplayParent(boundaryNode, keyPath[0], trackedPostpones);
				else if (request = boundaryNode[3], null === request) request = boundaryNode[3] = {};
				else if ("number" === typeof request) throw Error(formatProdErrorMessage(491));
				request[task.childIndex] = segment.id;
			}
		}
	}
	function untrackBoundary(request, boundary) {
		request = request.trackedPostpones;
		null !== request && (boundary = boundary.trackedContentKeyPath, null !== boundary && (boundary = request.workingMap.get(boundary), void 0 !== boundary && (boundary.length = 4, boundary[2] = [], boundary[3] = null)));
	}
	function spawnNewSuspendedReplayTask(request, task, thenableState) {
		return createReplayTask(request, thenableState, task.replay, task.node, task.childIndex, task.blockedBoundary, task.hoistableState, task.abortSet, task.keyPath, task.formatContext, task.context, task.treeContext, task.row, task.componentStack);
	}
	function spawnNewSuspendedRenderTask(request, task, thenableState) {
		var segment = task.blockedSegment, newSegment = createPendingSegment(request, segment.chunks.length, null, task.formatContext, segment.lastPushedText, !0);
		segment.children.push(newSegment);
		segment.lastPushedText = !1;
		return createRenderTask(request, thenableState, task.node, task.childIndex, task.blockedBoundary, newSegment, task.blockedPreamble, task.hoistableState, task.abortSet, task.keyPath, task.formatContext, task.context, task.treeContext, task.row, task.componentStack);
	}
	function renderNode(request, task, node, childIndex) {
		var previousFormatContext = task.formatContext, previousContext = task.context, previousKeyPath = task.keyPath, previousTreeContext = task.treeContext, previousComponentStack = task.componentStack, segment = task.blockedSegment;
		if (null === segment) {
			segment = task.replay;
			try {
				return renderNodeDestructive(request, task, node, childIndex);
			} catch (thrownValue) {
				if (resetHooksState(), node = thrownValue === SuspenseException ? getSuspendedThenable() : thrownValue, 12 !== request.status && "object" === typeof node && null !== node) {
					if ("function" === typeof node.then) {
						childIndex = thrownValue === SuspenseException ? getThenableStateAfterSuspending() : null;
						request = spawnNewSuspendedReplayTask(request, task, childIndex).ping;
						node.then(request, request);
						task.formatContext = previousFormatContext;
						task.context = previousContext;
						task.keyPath = previousKeyPath;
						task.treeContext = previousTreeContext;
						task.componentStack = previousComponentStack;
						task.replay = segment;
						switchContext(previousContext);
						return;
					}
					if ("Maximum call stack size exceeded" === node.message) {
						node = thrownValue === SuspenseException ? getThenableStateAfterSuspending() : null;
						node = spawnNewSuspendedReplayTask(request, task, node);
						request.pingedTasks.push(node);
						task.formatContext = previousFormatContext;
						task.context = previousContext;
						task.keyPath = previousKeyPath;
						task.treeContext = previousTreeContext;
						task.componentStack = previousComponentStack;
						task.replay = segment;
						switchContext(previousContext);
						return;
					}
				}
			}
		} else {
			var childrenLength = segment.children.length, chunkLength = segment.chunks.length;
			try {
				return renderNodeDestructive(request, task, node, childIndex);
			} catch (thrownValue$62) {
				if (resetHooksState(), segment.children.length = childrenLength, segment.chunks.length = chunkLength, node = thrownValue$62 === SuspenseException ? getSuspendedThenable() : thrownValue$62, 12 !== request.status && "object" === typeof node && null !== node) {
					if ("function" === typeof node.then) {
						segment = node;
						node = thrownValue$62 === SuspenseException ? getThenableStateAfterSuspending() : null;
						request = spawnNewSuspendedRenderTask(request, task, node).ping;
						segment.then(request, request);
						task.formatContext = previousFormatContext;
						task.context = previousContext;
						task.keyPath = previousKeyPath;
						task.treeContext = previousTreeContext;
						task.componentStack = previousComponentStack;
						switchContext(previousContext);
						return;
					}
					if ("Maximum call stack size exceeded" === node.message) {
						segment = thrownValue$62 === SuspenseException ? getThenableStateAfterSuspending() : null;
						segment = spawnNewSuspendedRenderTask(request, task, segment);
						request.pingedTasks.push(segment);
						task.formatContext = previousFormatContext;
						task.context = previousContext;
						task.keyPath = previousKeyPath;
						task.treeContext = previousTreeContext;
						task.componentStack = previousComponentStack;
						switchContext(previousContext);
						return;
					}
				}
			}
		}
		task.formatContext = previousFormatContext;
		task.context = previousContext;
		task.keyPath = previousKeyPath;
		task.treeContext = previousTreeContext;
		switchContext(previousContext);
		throw node;
	}
	function abortTaskSoft(task) {
		var boundary = task.blockedBoundary, segment = task.blockedSegment;
		null !== segment && (segment.status = 3, finishedTask(this, boundary, task.row, segment));
	}
	function abortRemainingReplayNodes(request$jscomp$0, boundary, nodes, slots, error, errorDigest$jscomp$0) {
		for (var i = 0; i < nodes.length; i++) {
			var node = nodes[i];
			if (4 === node.length) abortRemainingReplayNodes(request$jscomp$0, boundary, node[2], node[3], error, errorDigest$jscomp$0);
			else {
				node = node[5];
				var request = request$jscomp$0, errorDigest = errorDigest$jscomp$0, resumedBoundary = createSuspenseBoundary(request, null, /* @__PURE__ */ new Set(), null, null);
				resumedBoundary.parentFlushed = !0;
				resumedBoundary.rootSegmentID = node;
				resumedBoundary.status = 4;
				resumedBoundary.errorDigest = errorDigest;
				resumedBoundary.parentFlushed && request.clientRenderedBoundaries.push(resumedBoundary);
			}
		}
		nodes.length = 0;
		if (null !== slots) {
			if (null === boundary) throw Error(formatProdErrorMessage(487));
			4 !== boundary.status && (boundary.status = 4, boundary.errorDigest = errorDigest$jscomp$0, boundary.parentFlushed && request$jscomp$0.clientRenderedBoundaries.push(boundary));
			if ("object" === typeof slots) for (var index in slots) delete slots[index];
		}
	}
	function abortTask(task, request, error) {
		var boundary = task.blockedBoundary, segment = task.blockedSegment;
		if (null !== segment) {
			if (6 === segment.status) return;
			segment.status = 3;
		}
		var errorInfo = getThrownInfo(task.componentStack);
		if (null === boundary) {
			if (13 !== request.status && 14 !== request.status) {
				boundary = task.replay;
				if (null === boundary) {
					null !== request.trackedPostpones && null !== segment ? (boundary = request.trackedPostpones, logRecoverableError(request, error, errorInfo), trackPostpone(request, boundary, task, segment), finishedTask(request, null, task.row, segment)) : (logRecoverableError(request, error, errorInfo), fatalError(request, error));
					return;
				}
				boundary.pendingTasks--;
				0 === boundary.pendingTasks && 0 < boundary.nodes.length && (segment = logRecoverableError(request, error, errorInfo), abortRemainingReplayNodes(request, null, boundary.nodes, boundary.slots, error, segment));
				request.pendingRootTasks--;
				0 === request.pendingRootTasks && completeShell(request);
			}
		} else {
			var trackedPostpones$63 = request.trackedPostpones;
			if (4 !== boundary.status) {
				if (null !== trackedPostpones$63 && null !== segment) return logRecoverableError(request, error, errorInfo), trackPostpone(request, trackedPostpones$63, task, segment), boundary.fallbackAbortableTasks.forEach(function(fallbackTask) {
					return abortTask(fallbackTask, request, error);
				}), boundary.fallbackAbortableTasks.clear(), finishedTask(request, boundary, task.row, segment);
				boundary.status = 4;
				segment = logRecoverableError(request, error, errorInfo);
				boundary.status = 4;
				boundary.errorDigest = segment;
				untrackBoundary(request, boundary);
				boundary.parentFlushed && request.clientRenderedBoundaries.push(boundary);
			}
			boundary.pendingTasks--;
			segment = boundary.row;
			null !== segment && 0 === --segment.pendingTasks && finishSuspenseListRow(request, segment);
			boundary.fallbackAbortableTasks.forEach(function(fallbackTask) {
				return abortTask(fallbackTask, request, error);
			});
			boundary.fallbackAbortableTasks.clear();
		}
		task = task.row;
		null !== task && 0 === --task.pendingTasks && finishSuspenseListRow(request, task);
		request.allPendingTasks--;
		0 === request.allPendingTasks && completeAll(request);
	}
	function safelyEmitEarlyPreloads(request, shellComplete) {
		try {
			var renderState = request.renderState, onHeaders = renderState.onHeaders;
			if (onHeaders) {
				var headers = renderState.headers;
				if (headers) {
					renderState.headers = null;
					var linkHeader = headers.preconnects;
					headers.fontPreloads && (linkHeader && (linkHeader += ", "), linkHeader += headers.fontPreloads);
					headers.highImagePreloads && (linkHeader && (linkHeader += ", "), linkHeader += headers.highImagePreloads);
					if (!shellComplete) {
						var queueIter = renderState.styles.values(), queueStep = queueIter.next();
						b: for (; 0 < headers.remainingCapacity && !queueStep.done; queueStep = queueIter.next()) for (var sheetIter = queueStep.value.sheets.values(), sheetStep = sheetIter.next(); 0 < headers.remainingCapacity && !sheetStep.done; sheetStep = sheetIter.next()) {
							var sheet = sheetStep.value, props = sheet.props, key = props.href, props$jscomp$0 = sheet.props, header = getPreloadAsHeader(props$jscomp$0.href, "style", {
								crossOrigin: props$jscomp$0.crossOrigin,
								integrity: props$jscomp$0.integrity,
								nonce: props$jscomp$0.nonce,
								type: props$jscomp$0.type,
								fetchPriority: props$jscomp$0.fetchPriority,
								referrerPolicy: props$jscomp$0.referrerPolicy,
								media: props$jscomp$0.media
							});
							if (0 <= (headers.remainingCapacity -= header.length + 2)) renderState.resets.style[key] = PRELOAD_NO_CREDS, linkHeader && (linkHeader += ", "), linkHeader += header, renderState.resets.style[key] = "string" === typeof props.crossOrigin || "string" === typeof props.integrity ? [props.crossOrigin, props.integrity] : PRELOAD_NO_CREDS;
							else break b;
						}
					}
					linkHeader ? onHeaders({ Link: linkHeader }) : onHeaders({});
				}
			}
		} catch (error) {
			logRecoverableError(request, error, {});
		}
	}
	function completeShell(request) {
		null === request.trackedPostpones && safelyEmitEarlyPreloads(request, !0);
		null === request.trackedPostpones && preparePreamble(request);
		request.onShellError = noop;
		request = request.onShellReady;
		request();
	}
	function completeAll(request) {
		safelyEmitEarlyPreloads(request, null === request.trackedPostpones ? !0 : null === request.completedRootSegment || 5 !== request.completedRootSegment.status);
		preparePreamble(request);
		request = request.onAllReady;
		request();
	}
	function queueCompletedSegment(boundary, segment) {
		if (0 === segment.chunks.length && 1 === segment.children.length && null === segment.children[0].boundary && -1 === segment.children[0].id) {
			var childSegment = segment.children[0];
			childSegment.id = segment.id;
			childSegment.parentFlushed = !0;
			1 !== childSegment.status && 3 !== childSegment.status && 4 !== childSegment.status || queueCompletedSegment(boundary, childSegment);
		} else boundary.completedSegments.push(segment);
	}
	function finishedTask(request, boundary, row, segment) {
		null !== row && (0 === --row.pendingTasks ? finishSuspenseListRow(request, row) : row.together && tryToResolveTogetherRow(request, row));
		request.allPendingTasks--;
		if (null === boundary) {
			if (null !== segment && segment.parentFlushed) {
				if (null !== request.completedRootSegment) throw Error(formatProdErrorMessage(389));
				request.completedRootSegment = segment;
			}
			request.pendingRootTasks--;
			0 === request.pendingRootTasks && completeShell(request);
		} else if (boundary.pendingTasks--, 4 !== boundary.status) if (0 === boundary.pendingTasks) {
			if (0 === boundary.status && (boundary.status = 1), null !== segment && segment.parentFlushed && (1 === segment.status || 3 === segment.status) && queueCompletedSegment(boundary, segment), boundary.parentFlushed && request.completedBoundaries.push(boundary), 1 === boundary.status) row = boundary.row, null !== row && hoistHoistables(row.hoistables, boundary.contentState), isEligibleForOutlining(request, boundary) || (boundary.fallbackAbortableTasks.forEach(abortTaskSoft, request), boundary.fallbackAbortableTasks.clear(), null !== row && 0 === --row.pendingTasks && finishSuspenseListRow(request, row)), 0 === request.pendingRootTasks && null === request.trackedPostpones && null !== boundary.contentPreamble && preparePreamble(request);
			else if (5 === boundary.status && (boundary = boundary.row, null !== boundary)) {
				if (null !== request.trackedPostpones) {
					row = request.trackedPostpones;
					var postponedRow = boundary.next;
					if (null !== postponedRow && (segment = postponedRow.boundaries, null !== segment)) for (postponedRow.boundaries = null, postponedRow = 0; postponedRow < segment.length; postponedRow++) {
						var postponedBoundary = segment[postponedRow];
						trackPostponedBoundary(request, row, postponedBoundary);
						finishedTask(request, postponedBoundary, null, null);
					}
				}
				0 === --boundary.pendingTasks && finishSuspenseListRow(request, boundary);
			}
		} else null === segment || !segment.parentFlushed || 1 !== segment.status && 3 !== segment.status || (queueCompletedSegment(boundary, segment), 1 === boundary.completedSegments.length && boundary.parentFlushed && request.partialBoundaries.push(boundary)), boundary = boundary.row, null !== boundary && boundary.together && tryToResolveTogetherRow(request, boundary);
		0 === request.allPendingTasks && completeAll(request);
	}
	function performWork(request$jscomp$2) {
		if (14 !== request$jscomp$2.status && 13 !== request$jscomp$2.status) {
			var prevContext = currentActiveSnapshot, prevDispatcher = ReactSharedInternals.H;
			ReactSharedInternals.H = HooksDispatcher;
			var prevAsyncDispatcher = ReactSharedInternals.A;
			ReactSharedInternals.A = DefaultAsyncDispatcher;
			var prevRequest = currentRequest;
			currentRequest = request$jscomp$2;
			var prevResumableState = currentResumableState;
			currentResumableState = request$jscomp$2.resumableState;
			try {
				var pingedTasks = request$jscomp$2.pingedTasks, i;
				for (i = 0; i < pingedTasks.length; i++) {
					var task = pingedTasks[i], request = request$jscomp$2, segment = task.blockedSegment;
					if (null === segment) {
						var request$jscomp$0 = request;
						if (0 !== task.replay.pendingTasks) {
							switchContext(task.context);
							try {
								"number" === typeof task.replay.slots ? resumeNode(request$jscomp$0, task, task.replay.slots, task.node, task.childIndex) : retryNode(request$jscomp$0, task);
								if (1 === task.replay.pendingTasks && 0 < task.replay.nodes.length) throw Error(formatProdErrorMessage(488));
								task.replay.pendingTasks--;
								task.abortSet.delete(task);
								finishedTask(request$jscomp$0, task.blockedBoundary, task.row, null);
							} catch (thrownValue) {
								resetHooksState();
								var x = thrownValue === SuspenseException ? getSuspendedThenable() : thrownValue;
								if ("object" === typeof x && null !== x && "function" === typeof x.then) {
									var ping = task.ping;
									x.then(ping, ping);
									task.thenableState = thrownValue === SuspenseException ? getThenableStateAfterSuspending() : null;
								} else {
									task.replay.pendingTasks--;
									task.abortSet.delete(task);
									var errorInfo = getThrownInfo(task.componentStack);
									request = void 0;
									var request$jscomp$1 = request$jscomp$0, boundary = task.blockedBoundary, error$jscomp$0 = 12 === request$jscomp$0.status ? request$jscomp$0.fatalError : x, replayNodes = task.replay.nodes, resumeSlots = task.replay.slots;
									request = logRecoverableError(request$jscomp$1, error$jscomp$0, errorInfo);
									abortRemainingReplayNodes(request$jscomp$1, boundary, replayNodes, resumeSlots, error$jscomp$0, request);
									request$jscomp$0.pendingRootTasks--;
									0 === request$jscomp$0.pendingRootTasks && completeShell(request$jscomp$0);
									request$jscomp$0.allPendingTasks--;
									0 === request$jscomp$0.allPendingTasks && completeAll(request$jscomp$0);
								}
							}
						}
					} else if (request$jscomp$0 = void 0, request$jscomp$1 = segment, 0 === request$jscomp$1.status) {
						request$jscomp$1.status = 6;
						switchContext(task.context);
						var childrenLength = request$jscomp$1.children.length, chunkLength = request$jscomp$1.chunks.length;
						try {
							retryNode(request, task), pushSegmentFinale(request$jscomp$1.chunks, request.renderState, request$jscomp$1.lastPushedText, request$jscomp$1.textEmbedded), task.abortSet.delete(task), request$jscomp$1.status = 1, finishedTask(request, task.blockedBoundary, task.row, request$jscomp$1);
						} catch (thrownValue) {
							resetHooksState();
							request$jscomp$1.children.length = childrenLength;
							request$jscomp$1.chunks.length = chunkLength;
							var x$jscomp$0 = thrownValue === SuspenseException ? getSuspendedThenable() : 12 === request.status ? request.fatalError : thrownValue;
							if (12 === request.status && null !== request.trackedPostpones) {
								var trackedPostpones = request.trackedPostpones, thrownInfo = getThrownInfo(task.componentStack);
								task.abortSet.delete(task);
								logRecoverableError(request, x$jscomp$0, thrownInfo);
								trackPostpone(request, trackedPostpones, task, request$jscomp$1);
								finishedTask(request, task.blockedBoundary, task.row, request$jscomp$1);
							} else if ("object" === typeof x$jscomp$0 && null !== x$jscomp$0 && "function" === typeof x$jscomp$0.then) {
								request$jscomp$1.status = 0;
								task.thenableState = thrownValue === SuspenseException ? getThenableStateAfterSuspending() : null;
								var ping$jscomp$0 = task.ping;
								x$jscomp$0.then(ping$jscomp$0, ping$jscomp$0);
							} else {
								var errorInfo$jscomp$0 = getThrownInfo(task.componentStack);
								task.abortSet.delete(task);
								request$jscomp$1.status = 4;
								var boundary$jscomp$0 = task.blockedBoundary, row = task.row;
								null !== row && 0 === --row.pendingTasks && finishSuspenseListRow(request, row);
								request.allPendingTasks--;
								request$jscomp$0 = logRecoverableError(request, x$jscomp$0, errorInfo$jscomp$0);
								if (null === boundary$jscomp$0) fatalError(request, x$jscomp$0);
								else if (boundary$jscomp$0.pendingTasks--, 4 !== boundary$jscomp$0.status) {
									boundary$jscomp$0.status = 4;
									boundary$jscomp$0.errorDigest = request$jscomp$0;
									untrackBoundary(request, boundary$jscomp$0);
									var boundaryRow = boundary$jscomp$0.row;
									null !== boundaryRow && 0 === --boundaryRow.pendingTasks && finishSuspenseListRow(request, boundaryRow);
									boundary$jscomp$0.parentFlushed && request.clientRenderedBoundaries.push(boundary$jscomp$0);
									0 === request.pendingRootTasks && null === request.trackedPostpones && null !== boundary$jscomp$0.contentPreamble && preparePreamble(request);
								}
								0 === request.allPendingTasks && completeAll(request);
							}
						}
					}
				}
				pingedTasks.splice(0, i);
				null !== request$jscomp$2.destination && flushCompletedQueues(request$jscomp$2, request$jscomp$2.destination);
			} catch (error) {
				logRecoverableError(request$jscomp$2, error, {}), fatalError(request$jscomp$2, error);
			} finally {
				currentResumableState = prevResumableState, ReactSharedInternals.H = prevDispatcher, ReactSharedInternals.A = prevAsyncDispatcher, prevDispatcher === HooksDispatcher && switchContext(prevContext), currentRequest = prevRequest;
			}
		}
	}
	function preparePreambleFromSubtree(request, segment, collectedPreambleSegments) {
		segment.preambleChildren.length && collectedPreambleSegments.push(segment.preambleChildren);
		for (var pendingPreambles = !1, i = 0; i < segment.children.length; i++) pendingPreambles = preparePreambleFromSegment(request, segment.children[i], collectedPreambleSegments) || pendingPreambles;
		return pendingPreambles;
	}
	function preparePreambleFromSegment(request, segment, collectedPreambleSegments) {
		var boundary = segment.boundary;
		if (null === boundary) return preparePreambleFromSubtree(request, segment, collectedPreambleSegments);
		var preamble = boundary.contentPreamble, fallbackPreamble = boundary.fallbackPreamble;
		if (null === preamble || null === fallbackPreamble) return !1;
		switch (boundary.status) {
			case 1:
				hoistPreambleState(request.renderState, preamble);
				request.byteSize += boundary.byteSize;
				segment = boundary.completedSegments[0];
				if (!segment) throw Error(formatProdErrorMessage(391));
				return preparePreambleFromSubtree(request, segment, collectedPreambleSegments);
			case 5: if (null !== request.trackedPostpones) return !0;
			case 4: if (1 === segment.status) return hoistPreambleState(request.renderState, fallbackPreamble), preparePreambleFromSubtree(request, segment, collectedPreambleSegments);
			default: return !0;
		}
	}
	function preparePreamble(request) {
		if (request.completedRootSegment && null === request.completedPreambleSegments) {
			var collectedPreambleSegments = [], originalRequestByteSize = request.byteSize, hasPendingPreambles = preparePreambleFromSegment(request, request.completedRootSegment, collectedPreambleSegments), preamble = request.renderState.preamble;
			!1 === hasPendingPreambles || preamble.headChunks && preamble.bodyChunks ? request.completedPreambleSegments = collectedPreambleSegments : request.byteSize = originalRequestByteSize;
		}
	}
	function flushSubtree(request, destination, segment, hoistableState) {
		segment.parentFlushed = !0;
		switch (segment.status) {
			case 0: segment.id = request.nextSegmentId++;
			case 5: return hoistableState = segment.id, segment.lastPushedText = !1, segment.textEmbedded = !1, request = request.renderState, destination.push("<template id=\""), destination.push(request.placeholderPrefix), request = hoistableState.toString(16), destination.push(request), destination.push("\"></template>");
			case 1:
				segment.status = 2;
				var r = !0, chunks = segment.chunks, chunkIdx = 0;
				segment = segment.children;
				for (var childIdx = 0; childIdx < segment.length; childIdx++) {
					for (r = segment[childIdx]; chunkIdx < r.index; chunkIdx++) destination.push(chunks[chunkIdx]);
					r = flushSegment(request, destination, r, hoistableState);
				}
				for (; chunkIdx < chunks.length - 1; chunkIdx++) destination.push(chunks[chunkIdx]);
				chunkIdx < chunks.length && (r = destination.push(chunks[chunkIdx]));
				return r;
			case 3: return !0;
			default: throw Error(formatProdErrorMessage(390));
		}
	}
	var flushedByteSize = 0;
	function flushSegment(request, destination, segment, hoistableState) {
		var boundary = segment.boundary;
		if (null === boundary) return flushSubtree(request, destination, segment, hoistableState);
		boundary.parentFlushed = !0;
		if (4 === boundary.status) {
			var row = boundary.row;
			null !== row && 0 === --row.pendingTasks && finishSuspenseListRow(request, row);
			request.renderState.generateStaticMarkup || (boundary = boundary.errorDigest, destination.push("<!--$!-->"), destination.push("<template"), boundary && (destination.push(" data-dgst=\""), boundary = escapeTextForBrowser(boundary), destination.push(boundary), destination.push("\"")), destination.push("></template>"));
			flushSubtree(request, destination, segment, hoistableState);
			request = request.renderState.generateStaticMarkup ? !0 : destination.push("<!--/$-->");
			return request;
		}
		if (1 !== boundary.status) return 0 === boundary.status && (boundary.rootSegmentID = request.nextSegmentId++), 0 < boundary.completedSegments.length && request.partialBoundaries.push(boundary), writeStartPendingSuspenseBoundary(destination, request.renderState, boundary.rootSegmentID), hoistableState && hoistHoistables(hoistableState, boundary.fallbackState), flushSubtree(request, destination, segment, hoistableState), destination.push("<!--/$-->");
		if (!flushingPartialBoundaries && isEligibleForOutlining(request, boundary) && flushedByteSize + boundary.byteSize > request.progressiveChunkSize) return boundary.rootSegmentID = request.nextSegmentId++, request.completedBoundaries.push(boundary), writeStartPendingSuspenseBoundary(destination, request.renderState, boundary.rootSegmentID), flushSubtree(request, destination, segment, hoistableState), destination.push("<!--/$-->");
		flushedByteSize += boundary.byteSize;
		hoistableState && hoistHoistables(hoistableState, boundary.contentState);
		segment = boundary.row;
		null !== segment && isEligibleForOutlining(request, boundary) && 0 === --segment.pendingTasks && finishSuspenseListRow(request, segment);
		request.renderState.generateStaticMarkup || destination.push("<!--$-->");
		segment = boundary.completedSegments;
		if (1 !== segment.length) throw Error(formatProdErrorMessage(391));
		flushSegment(request, destination, segment[0], hoistableState);
		request = request.renderState.generateStaticMarkup ? !0 : destination.push("<!--/$-->");
		return request;
	}
	function flushSegmentContainer(request, destination, segment, hoistableState) {
		writeStartSegment(destination, request.renderState, segment.parentFormatContext, segment.id);
		flushSegment(request, destination, segment, hoistableState);
		return writeEndSegment(destination, segment.parentFormatContext);
	}
	function flushCompletedBoundary(request, destination, boundary) {
		flushedByteSize = boundary.byteSize;
		for (var completedSegments = boundary.completedSegments, i = 0; i < completedSegments.length; i++) flushPartiallyCompletedSegment(request, destination, boundary, completedSegments[i]);
		completedSegments.length = 0;
		completedSegments = boundary.row;
		null !== completedSegments && isEligibleForOutlining(request, boundary) && 0 === --completedSegments.pendingTasks && finishSuspenseListRow(request, completedSegments);
		writeHoistablesForBoundary(destination, boundary.contentState, request.renderState);
		completedSegments = request.resumableState;
		request = request.renderState;
		i = boundary.rootSegmentID;
		boundary = boundary.contentState;
		var requiresStyleInsertion = request.stylesToHoist;
		request.stylesToHoist = !1;
		destination.push(request.startInlineScript);
		destination.push(">");
		requiresStyleInsertion ? (0 === (completedSegments.instructions & 4) && (completedSegments.instructions |= 4, destination.push("$RX=function(b,c,d,e,f){var a=document.getElementById(b);a&&(b=a.previousSibling,b.data=\"$!\",a=a.dataset,c&&(a.dgst=c),d&&(a.msg=d),e&&(a.stck=e),f&&(a.cstck=f),b._reactRetry&&b._reactRetry())};")), 0 === (completedSegments.instructions & 2) && (completedSegments.instructions |= 2, destination.push("$RB=[];$RV=function(a){$RT=performance.now();for(var b=0;b<a.length;b+=2){var c=a[b],e=a[b+1];null!==e.parentNode&&e.parentNode.removeChild(e);var f=c.parentNode;if(f){var g=c.previousSibling,h=0;do{if(c&&8===c.nodeType){var d=c.data;if(\"/$\"===d||\"/&\"===d)if(0===h)break;else h--;else\"$\"!==d&&\"$?\"!==d&&\"$~\"!==d&&\"$!\"!==d&&\"&\"!==d||h++}d=c.nextSibling;f.removeChild(c);c=d}while(c);for(;e.firstChild;)f.insertBefore(e.firstChild,c);g.data=\"$\";g._reactRetry&&requestAnimationFrame(g._reactRetry)}}a.length=0};\n$RC=function(a,b){if(b=document.getElementById(b))(a=document.getElementById(a))?(a.previousSibling.data=\"$~\",$RB.push(a,b),2===$RB.length&&(\"number\"!==typeof $RT?requestAnimationFrame($RV.bind(null,$RB)):(a=performance.now(),setTimeout($RV.bind(null,$RB),2300>a&&2E3<a?2300-a:$RT+300-a)))):b.parentNode.removeChild(b)};")), 0 === (completedSegments.instructions & 8) ? (completedSegments.instructions |= 8, destination.push("$RM=new Map;$RR=function(n,w,p){function u(q){this._p=null;q()}for(var r=new Map,t=document,h,b,e=t.querySelectorAll(\"link[data-precedence],style[data-precedence]\"),v=[],k=0;b=e[k++];)\"not all\"===b.getAttribute(\"media\")?v.push(b):(\"LINK\"===b.tagName&&$RM.set(b.getAttribute(\"href\"),b),r.set(b.dataset.precedence,h=b));e=0;b=[];var l,a;for(k=!0;;){if(k){var f=p[e++];if(!f){k=!1;e=0;continue}var c=!1,m=0;var d=f[m++];if(a=$RM.get(d)){var g=a._p;c=!0}else{a=t.createElement(\"link\");a.href=d;a.rel=\n\"stylesheet\";for(a.dataset.precedence=l=f[m++];g=f[m++];)a.setAttribute(g,f[m++]);g=a._p=new Promise(function(q,x){a.onload=u.bind(a,q);a.onerror=u.bind(a,x)});$RM.set(d,a)}d=a.getAttribute(\"media\");!g||d&&!matchMedia(d).matches||b.push(g);if(c)continue}else{a=v[e++];if(!a)break;l=a.getAttribute(\"data-precedence\");a.removeAttribute(\"media\")}c=r.get(l)||h;c===h&&(h=a);r.set(l,a);c?c.parentNode.insertBefore(a,c.nextSibling):(c=t.head,c.insertBefore(a,c.firstChild))}if(p=document.getElementById(n))p.previousSibling.data=\n\"$~\";Promise.all(b).then($RC.bind(null,n,w),$RX.bind(null,n,\"CSS failed to load\"))};$RR(\"")) : destination.push("$RR(\"")) : (0 === (completedSegments.instructions & 2) && (completedSegments.instructions |= 2, destination.push("$RB=[];$RV=function(a){$RT=performance.now();for(var b=0;b<a.length;b+=2){var c=a[b],e=a[b+1];null!==e.parentNode&&e.parentNode.removeChild(e);var f=c.parentNode;if(f){var g=c.previousSibling,h=0;do{if(c&&8===c.nodeType){var d=c.data;if(\"/$\"===d||\"/&\"===d)if(0===h)break;else h--;else\"$\"!==d&&\"$?\"!==d&&\"$~\"!==d&&\"$!\"!==d&&\"&\"!==d||h++}d=c.nextSibling;f.removeChild(c);c=d}while(c);for(;e.firstChild;)f.insertBefore(e.firstChild,c);g.data=\"$\";g._reactRetry&&requestAnimationFrame(g._reactRetry)}}a.length=0};\n$RC=function(a,b){if(b=document.getElementById(b))(a=document.getElementById(a))?(a.previousSibling.data=\"$~\",$RB.push(a,b),2===$RB.length&&(\"number\"!==typeof $RT?requestAnimationFrame($RV.bind(null,$RB)):(a=performance.now(),setTimeout($RV.bind(null,$RB),2300>a&&2E3<a?2300-a:$RT+300-a)))):b.parentNode.removeChild(b)};")), destination.push("$RC(\""));
		completedSegments = i.toString(16);
		destination.push(request.boundaryPrefix);
		destination.push(completedSegments);
		destination.push("\",\"");
		destination.push(request.segmentPrefix);
		destination.push(completedSegments);
		requiresStyleInsertion ? (destination.push("\","), writeStyleResourceDependenciesInJS(destination, boundary)) : destination.push("\"");
		boundary = destination.push(")<\/script>");
		return writeBootstrap(destination, request) && boundary;
	}
	function flushPartiallyCompletedSegment(request, destination, boundary, segment) {
		if (2 === segment.status) return !0;
		var hoistableState = boundary.contentState, segmentID = segment.id;
		if (-1 === segmentID) {
			if (-1 === (segment.id = boundary.rootSegmentID)) throw Error(formatProdErrorMessage(392));
			return flushSegmentContainer(request, destination, segment, hoistableState);
		}
		if (segmentID === boundary.rootSegmentID) return flushSegmentContainer(request, destination, segment, hoistableState);
		flushSegmentContainer(request, destination, segment, hoistableState);
		boundary = request.resumableState;
		request = request.renderState;
		destination.push(request.startInlineScript);
		destination.push(">");
		0 === (boundary.instructions & 1) ? (boundary.instructions |= 1, destination.push("$RS=function(a,b){a=document.getElementById(a);b=document.getElementById(b);for(a.parentNode.removeChild(a);a.firstChild;)b.parentNode.insertBefore(a.firstChild,b);b.parentNode.removeChild(b)};$RS(\"")) : destination.push("$RS(\"");
		destination.push(request.segmentPrefix);
		segmentID = segmentID.toString(16);
		destination.push(segmentID);
		destination.push("\",\"");
		destination.push(request.placeholderPrefix);
		destination.push(segmentID);
		destination = destination.push("\")<\/script>");
		return destination;
	}
	var flushingPartialBoundaries = !1;
	function flushCompletedQueues(request, destination) {
		try {
			if (!(0 < request.pendingRootTasks)) {
				var i, completedRootSegment = request.completedRootSegment;
				if (null !== completedRootSegment) {
					if (5 === completedRootSegment.status) return;
					var completedPreambleSegments = request.completedPreambleSegments;
					if (null === completedPreambleSegments) return;
					flushedByteSize = request.byteSize;
					var resumableState = request.resumableState, renderState = request.renderState, preamble = renderState.preamble, htmlChunks = preamble.htmlChunks, headChunks = preamble.headChunks, i$jscomp$0;
					if (htmlChunks) {
						for (i$jscomp$0 = 0; i$jscomp$0 < htmlChunks.length; i$jscomp$0++) destination.push(htmlChunks[i$jscomp$0]);
						if (headChunks) for (i$jscomp$0 = 0; i$jscomp$0 < headChunks.length; i$jscomp$0++) destination.push(headChunks[i$jscomp$0]);
						else {
							var chunk = startChunkForTag("head");
							destination.push(chunk);
							destination.push(">");
						}
					} else if (headChunks) for (i$jscomp$0 = 0; i$jscomp$0 < headChunks.length; i$jscomp$0++) destination.push(headChunks[i$jscomp$0]);
					var charsetChunks = renderState.charsetChunks;
					for (i$jscomp$0 = 0; i$jscomp$0 < charsetChunks.length; i$jscomp$0++) destination.push(charsetChunks[i$jscomp$0]);
					charsetChunks.length = 0;
					renderState.preconnects.forEach(flushResource, destination);
					renderState.preconnects.clear();
					var viewportChunks = renderState.viewportChunks;
					for (i$jscomp$0 = 0; i$jscomp$0 < viewportChunks.length; i$jscomp$0++) destination.push(viewportChunks[i$jscomp$0]);
					viewportChunks.length = 0;
					renderState.fontPreloads.forEach(flushResource, destination);
					renderState.fontPreloads.clear();
					renderState.highImagePreloads.forEach(flushResource, destination);
					renderState.highImagePreloads.clear();
					currentlyFlushingRenderState = renderState;
					renderState.styles.forEach(flushStylesInPreamble, destination);
					currentlyFlushingRenderState = null;
					var importMapChunks = renderState.importMapChunks;
					for (i$jscomp$0 = 0; i$jscomp$0 < importMapChunks.length; i$jscomp$0++) destination.push(importMapChunks[i$jscomp$0]);
					importMapChunks.length = 0;
					renderState.bootstrapScripts.forEach(flushResource, destination);
					renderState.scripts.forEach(flushResource, destination);
					renderState.scripts.clear();
					renderState.bulkPreloads.forEach(flushResource, destination);
					renderState.bulkPreloads.clear();
					resumableState.instructions |= 32;
					var hoistableChunks = renderState.hoistableChunks;
					for (i$jscomp$0 = 0; i$jscomp$0 < hoistableChunks.length; i$jscomp$0++) destination.push(hoistableChunks[i$jscomp$0]);
					for (resumableState = hoistableChunks.length = 0; resumableState < completedPreambleSegments.length; resumableState++) {
						var segments = completedPreambleSegments[resumableState];
						for (renderState = 0; renderState < segments.length; renderState++) flushSegment(request, destination, segments[renderState], null);
					}
					var preamble$jscomp$0 = request.renderState.preamble, headChunks$jscomp$0 = preamble$jscomp$0.headChunks;
					if (preamble$jscomp$0.htmlChunks || headChunks$jscomp$0) {
						var chunk$jscomp$0 = endChunkForTag("head");
						destination.push(chunk$jscomp$0);
					}
					var bodyChunks = preamble$jscomp$0.bodyChunks;
					if (bodyChunks) for (completedPreambleSegments = 0; completedPreambleSegments < bodyChunks.length; completedPreambleSegments++) destination.push(bodyChunks[completedPreambleSegments]);
					flushSegment(request, destination, completedRootSegment, null);
					request.completedRootSegment = null;
					var renderState$jscomp$0 = request.renderState;
					if (0 !== request.allPendingTasks || 0 !== request.clientRenderedBoundaries.length || 0 !== request.completedBoundaries.length || null !== request.trackedPostpones && (0 !== request.trackedPostpones.rootNodes.length || null !== request.trackedPostpones.rootSlots)) {
						var resumableState$jscomp$0 = request.resumableState;
						if (0 === (resumableState$jscomp$0.instructions & 64)) {
							resumableState$jscomp$0.instructions |= 64;
							destination.push(renderState$jscomp$0.startInlineScript);
							if (0 === (resumableState$jscomp$0.instructions & 32)) {
								resumableState$jscomp$0.instructions |= 32;
								var shellId = "_" + resumableState$jscomp$0.idPrefix + "R_";
								destination.push(" id=\"");
								var chunk$jscomp$1 = escapeTextForBrowser(shellId);
								destination.push(chunk$jscomp$1);
								destination.push("\"");
							}
							destination.push(">");
							destination.push("requestAnimationFrame(function(){$RT=performance.now()});");
							destination.push("<\/script>");
						}
					}
					writeBootstrap(destination, renderState$jscomp$0);
				}
				var renderState$jscomp$1 = request.renderState;
				completedRootSegment = 0;
				var viewportChunks$jscomp$0 = renderState$jscomp$1.viewportChunks;
				for (completedRootSegment = 0; completedRootSegment < viewportChunks$jscomp$0.length; completedRootSegment++) destination.push(viewportChunks$jscomp$0[completedRootSegment]);
				viewportChunks$jscomp$0.length = 0;
				renderState$jscomp$1.preconnects.forEach(flushResource, destination);
				renderState$jscomp$1.preconnects.clear();
				renderState$jscomp$1.fontPreloads.forEach(flushResource, destination);
				renderState$jscomp$1.fontPreloads.clear();
				renderState$jscomp$1.highImagePreloads.forEach(flushResource, destination);
				renderState$jscomp$1.highImagePreloads.clear();
				renderState$jscomp$1.styles.forEach(preloadLateStyles, destination);
				renderState$jscomp$1.scripts.forEach(flushResource, destination);
				renderState$jscomp$1.scripts.clear();
				renderState$jscomp$1.bulkPreloads.forEach(flushResource, destination);
				renderState$jscomp$1.bulkPreloads.clear();
				var hoistableChunks$jscomp$0 = renderState$jscomp$1.hoistableChunks;
				for (completedRootSegment = 0; completedRootSegment < hoistableChunks$jscomp$0.length; completedRootSegment++) destination.push(hoistableChunks$jscomp$0[completedRootSegment]);
				hoistableChunks$jscomp$0.length = 0;
				var clientRenderedBoundaries = request.clientRenderedBoundaries;
				for (i = 0; i < clientRenderedBoundaries.length; i++) {
					var boundary = clientRenderedBoundaries[i];
					renderState$jscomp$1 = destination;
					var resumableState$jscomp$1 = request.resumableState, renderState$jscomp$2 = request.renderState, id = boundary.rootSegmentID, errorDigest = boundary.errorDigest;
					renderState$jscomp$1.push(renderState$jscomp$2.startInlineScript);
					renderState$jscomp$1.push(">");
					0 === (resumableState$jscomp$1.instructions & 4) ? (resumableState$jscomp$1.instructions |= 4, renderState$jscomp$1.push("$RX=function(b,c,d,e,f){var a=document.getElementById(b);a&&(b=a.previousSibling,b.data=\"$!\",a=a.dataset,c&&(a.dgst=c),d&&(a.msg=d),e&&(a.stck=e),f&&(a.cstck=f),b._reactRetry&&b._reactRetry())};;$RX(\"")) : renderState$jscomp$1.push("$RX(\"");
					renderState$jscomp$1.push(renderState$jscomp$2.boundaryPrefix);
					var chunk$jscomp$2 = id.toString(16);
					renderState$jscomp$1.push(chunk$jscomp$2);
					renderState$jscomp$1.push("\"");
					if (errorDigest) {
						renderState$jscomp$1.push(",");
						var chunk$jscomp$3 = escapeJSStringsForInstructionScripts(errorDigest || "");
						renderState$jscomp$1.push(chunk$jscomp$3);
					}
					var JSCompiler_inline_result = renderState$jscomp$1.push(")<\/script>");
					if (!JSCompiler_inline_result) {
						request.destination = null;
						i++;
						clientRenderedBoundaries.splice(0, i);
						return;
					}
				}
				clientRenderedBoundaries.splice(0, i);
				var completedBoundaries = request.completedBoundaries;
				for (i = 0; i < completedBoundaries.length; i++) if (!flushCompletedBoundary(request, destination, completedBoundaries[i])) {
					request.destination = null;
					i++;
					completedBoundaries.splice(0, i);
					return;
				}
				completedBoundaries.splice(0, i);
				flushingPartialBoundaries = !0;
				var partialBoundaries = request.partialBoundaries;
				for (i = 0; i < partialBoundaries.length; i++) {
					var boundary$69 = partialBoundaries[i];
					a: {
						clientRenderedBoundaries = request;
						boundary = destination;
						flushedByteSize = boundary$69.byteSize;
						var completedSegments = boundary$69.completedSegments;
						for (JSCompiler_inline_result = 0; JSCompiler_inline_result < completedSegments.length; JSCompiler_inline_result++) if (!flushPartiallyCompletedSegment(clientRenderedBoundaries, boundary, boundary$69, completedSegments[JSCompiler_inline_result])) {
							JSCompiler_inline_result++;
							completedSegments.splice(0, JSCompiler_inline_result);
							var JSCompiler_inline_result$jscomp$0 = !1;
							break a;
						}
						completedSegments.splice(0, JSCompiler_inline_result);
						var row = boundary$69.row;
						null !== row && row.together && 1 === boundary$69.pendingTasks && (1 === row.pendingTasks ? unblockSuspenseListRow(clientRenderedBoundaries, row, row.hoistables) : row.pendingTasks--);
						JSCompiler_inline_result$jscomp$0 = writeHoistablesForBoundary(boundary, boundary$69.contentState, clientRenderedBoundaries.renderState);
					}
					if (!JSCompiler_inline_result$jscomp$0) {
						request.destination = null;
						i++;
						partialBoundaries.splice(0, i);
						return;
					}
				}
				partialBoundaries.splice(0, i);
				flushingPartialBoundaries = !1;
				var largeBoundaries = request.completedBoundaries;
				for (i = 0; i < largeBoundaries.length; i++) if (!flushCompletedBoundary(request, destination, largeBoundaries[i])) {
					request.destination = null;
					i++;
					largeBoundaries.splice(0, i);
					return;
				}
				largeBoundaries.splice(0, i);
			}
		} finally {
			flushingPartialBoundaries = !1, 0 === request.allPendingTasks && 0 === request.clientRenderedBoundaries.length && 0 === request.completedBoundaries.length && (request.flushScheduled = !1, i = request.resumableState, i.hasBody && (partialBoundaries = endChunkForTag("body"), destination.push(partialBoundaries)), i.hasHtml && (i = endChunkForTag("html"), destination.push(i)), request.status = 14, destination.push(null), request.destination = null);
		}
	}
	function enqueueFlush(request) {
		if (!1 === request.flushScheduled && 0 === request.pingedTasks.length && null !== request.destination) {
			request.flushScheduled = !0;
			var destination = request.destination;
			destination ? flushCompletedQueues(request, destination) : request.flushScheduled = !1;
		}
	}
	function startFlowing(request, destination) {
		if (13 === request.status) request.status = 14, destination.destroy(request.fatalError);
		else if (14 !== request.status && null === request.destination) {
			request.destination = destination;
			try {
				flushCompletedQueues(request, destination);
			} catch (error) {
				logRecoverableError(request, error, {}), fatalError(request, error);
			}
		}
	}
	function abort(request, reason) {
		if (11 === request.status || 10 === request.status) request.status = 12;
		try {
			var abortableTasks = request.abortableTasks;
			if (0 < abortableTasks.size) {
				var error = void 0 === reason ? Error(formatProdErrorMessage(432)) : "object" === typeof reason && null !== reason && "function" === typeof reason.then ? Error(formatProdErrorMessage(530)) : reason;
				request.fatalError = error;
				abortableTasks.forEach(function(task) {
					return abortTask(task, request, error);
				});
				abortableTasks.clear();
			}
			null !== request.destination && flushCompletedQueues(request, request.destination);
		} catch (error$71) {
			logRecoverableError(request, error$71, {}), fatalError(request, error$71);
		}
	}
	function addToReplayParent(node, parentKeyPath, trackedPostpones) {
		if (null === parentKeyPath) trackedPostpones.rootNodes.push(node);
		else {
			var workingMap = trackedPostpones.workingMap, parentNode = workingMap.get(parentKeyPath);
			void 0 === parentNode && (parentNode = [
				parentKeyPath[1],
				parentKeyPath[2],
				[],
				null
			], workingMap.set(parentKeyPath, parentNode), addToReplayParent(parentNode, parentKeyPath[0], trackedPostpones));
			parentNode[2].push(node);
		}
	}
	function onError() {}
	function renderToStringImpl(children, options, generateStaticMarkup, abortReason) {
		var didFatal = !1, fatalError = null, result = "", readyToStream = !1;
		options = createResumableState(options ? options.identifierPrefix : void 0);
		children = createRequest(children, options, createRenderState(options, generateStaticMarkup), createFormatContext(0, null, 0, null), Infinity, onError, void 0, function() {
			readyToStream = !0;
		}, void 0, void 0, void 0);
		children.flushScheduled = null !== children.destination;
		performWork(children);
		10 === children.status && (children.status = 11);
		null === children.trackedPostpones && safelyEmitEarlyPreloads(children, 0 === children.pendingRootTasks);
		abort(children, abortReason);
		startFlowing(children, {
			push: function(chunk) {
				null !== chunk && (result += chunk);
				return !0;
			},
			destroy: function(error) {
				didFatal = !0;
				fatalError = error;
			}
		});
		if (didFatal && fatalError !== abortReason) throw fatalError;
		if (!readyToStream) throw Error(formatProdErrorMessage(426));
		return result;
	}
	exports.renderToStaticMarkup = function(children, options) {
		return renderToStringImpl(children, options, !0, "The server used \"renderToStaticMarkup\" which does not support Suspense. If you intended to have the server wait for the suspended component please switch to \"renderToReadableStream\" which supports Suspense on the server");
	};
	exports.renderToString = function(children, options) {
		return renderToStringImpl(children, options, !1, "The server used \"renderToString\" which does not support Suspense. If you intended for this Suspense boundary to render the fallback content on the server consider throwing an Error somewhere within the Suspense boundary. If you intended to have the server wait for the suspended component please switch to \"renderToReadableStream\" which supports Suspense on the server");
	};
	exports.version = "19.2.5";
}));
//#endregion
//#region node_modules/.pnpm/react-dom@19.2.5_react@19.2.5/node_modules/react-dom/server.edge.js
var require_server_edge = /* @__PURE__ */ __commonJSMin(((exports) => {
	var b;
	var l;
	b = require_react_dom_server_edge_production();
	l = require_react_dom_server_legacy_browser_production();
	exports.version = b.version;
	exports.renderToReadableStream = b.renderToReadableStream;
	exports.renderToString = l.renderToString;
	exports.renderToStaticMarkup = l.renderToStaticMarkup;
	exports.resume = b.resume;
}));
//#endregion
//#region node_modules/.pnpm/react@19.2.5/node_modules/react/cjs/react-jsx-runtime.production.js
/**
* @license React
* react-jsx-runtime.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_jsx_runtime_production = /* @__PURE__ */ __commonJSMin(((exports) => {
	var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
	function jsxProd(type, config, maybeKey) {
		var key = null;
		void 0 !== maybeKey && (key = "" + maybeKey);
		void 0 !== config.key && (key = "" + config.key);
		if ("key" in config) {
			maybeKey = {};
			for (var propName in config) "key" !== propName && (maybeKey[propName] = config[propName]);
		} else maybeKey = config;
		config = maybeKey.ref;
		return {
			$$typeof: REACT_ELEMENT_TYPE,
			type,
			key,
			ref: void 0 !== config ? config : null,
			props: maybeKey
		};
	}
	exports.Fragment = REACT_FRAGMENT_TYPE;
	exports.jsx = jsxProd;
	exports.jsxs = jsxProd;
}));
//#endregion
//#region node_modules/.pnpm/react@19.2.5/node_modules/react/jsx-runtime.js
var require_jsx_runtime = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_react_jsx_runtime_production();
}));
//#endregion
//#region app/entry.server.tsx
var entry_server_exports = /* @__PURE__ */ __exportAll({ default: () => handleRequest });
var import_server_edge = require_server_edge();
var import_jsx_runtime = require_jsx_runtime();
async function handleRequest(request, responseStatusCode, responseHeaders, routerContext, _loadContext) {
	let shellRendered = false;
	const userAgent = request.headers.get("user-agent");
	const body = await (0, import_server_edge.renderToReadableStream)(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServerRouter, {
		context: routerContext,
		url: request.url
	}), { onError(error) {
		responseStatusCode = 500;
		if (shellRendered) console.error(error);
	} });
	shellRendered = true;
	if (userAgent && isbot(userAgent) || routerContext.isSpaMode) await body.allReady;
	responseHeaders.set("Content-Type", "text/html");
	return new Response(body, {
		headers: responseHeaders,
		status: responseStatusCode
	});
}
var SUPPORTED_LOCALES = [
	"en",
	"zh",
	"es",
	"fr",
	"de",
	"ja",
	"ko",
	"ru",
	"pt",
	"ar"
];
var RTL_LOCALES = new Set(["ar"]);
var LOCALE_LABELS = {
	en: "English",
	zh: "中文",
	es: "Español",
	fr: "Français",
	de: "Deutsch",
	ja: "日本語",
	ko: "한국어",
	ru: "Русский",
	pt: "Português",
	ar: "العربية"
};
function normalizePathname(pathname) {
	if (!pathname) return "/";
	if (pathname !== "/" && pathname.endsWith("/")) return pathname.slice(0, -1);
	return pathname;
}
function escapeRegExp(value) {
	return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function stripLeadingLocalePrefix(pathname, locale) {
	const normalized = normalizePathname(pathname);
	if (!new RegExp(`^/${escapeRegExp(locale)}(?:/|$)`).test(normalized)) return normalized;
	const stripped = normalized.slice(locale.length + 1);
	if (!stripped) return "/";
	return stripped.startsWith("/") ? stripped : `/${stripped}`;
}
function stripDefaultLocalePrefix(pathname) {
	return stripLeadingLocalePrefix(pathname, "en");
}
function getLocaleFromPathname(pathname) {
	const normalized = normalizePathname(pathname);
	for (const locale of SUPPORTED_LOCALES) {
		if (locale === "en") continue;
		if (normalized === `/${locale}` || normalized.startsWith(`/${locale}/`)) return locale;
	}
	return "en";
}
function stripLocalePrefix(pathname) {
	const normalized = normalizePathname(pathname);
	for (const locale of SUPPORTED_LOCALES) if (normalized === `/${locale}` || normalized.startsWith(`/${locale}/`)) {
		const stripped = normalized.slice(locale.length + 1);
		return stripped.length > 0 ? stripped : "/";
	}
	return normalized;
}
function toLocalePath(pathname, locale) {
	const basePath = stripLocalePrefix(pathname);
	if (locale === "en") return basePath;
	return basePath === "/" ? `/${locale}` : `/${locale}${basePath}`;
}
function getLocaleDirection(locale) {
	return RTL_LOCALES.has(locale) ? "rtl" : "ltr";
}
function toIntlLocale(locale) {
	switch (locale) {
		case "en": return "en-US";
		case "zh": return "zh-CN";
		case "pt": return "pt-BR";
		default: return locale;
	}
}
function resolveLocaleParam(lang) {
	if (!lang) return {
		locale: "en",
		shouldRedirectToDefault: false,
		isInvalid: false
	};
	if (!isKnownLocale(lang)) return {
		locale: "en",
		shouldRedirectToDefault: false,
		isInvalid: true
	};
	if (lang === "en") return {
		locale: "en",
		shouldRedirectToDefault: true,
		isInvalid: false
	};
	return {
		locale: lang,
		shouldRedirectToDefault: false,
		isInvalid: false
	};
}
function isKnownLocale(value) {
	if (!value) return false;
	return SUPPORTED_LOCALES.includes(value);
}
//#endregion
//#region app/blog/data.ts
var BLOG_LOCALES = [
	"en",
	"zh",
	"es",
	"fr",
	"de",
	"ja",
	"ko",
	"ru",
	"pt",
	"ar"
];
var BLOG_POSTS = {
	en: [
		{
			slug: "temporary-email-best-practices",
			title: "Temporary Email Best Practices for Safer Sign-Ups",
			description: "Learn practical temporary email best practices to reduce spam, avoid lockouts, and protect your primary inbox.",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		},
		{
			slug: "temporary-email-vs-email-alias",
			title: "Temporary Email vs Email Alias: Which One Should You Use?",
			description: "Compare temporary inboxes and email aliases by privacy, recovery, and long-term account safety.",
			publishedAt: "2026-02-12",
			readingMinutes: 5
		},
		{
			slug: "otp-email-not-arriving-fixes",
			title: "OTP Email Not Arriving? 8 Fast Fixes That Usually Work",
			description: "Troubleshoot delayed verification emails with a practical checklist for resend issues, sender blocks, and inbox refresh flow.",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		}
	],
	zh: [
		{
			slug: "temporary-email-best-practices",
			title: "临时邮箱最佳实践：更安全地完成注册",
			description: "用一套可执行的方法减少垃圾邮件、避免账号锁死，并保护你的主邮箱。",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		},
		{
			slug: "temporary-email-vs-email-alias",
			title: "临时邮箱 vs 邮箱别名：到底该用哪种？",
			description: "从隐私、可恢复性、长期账号安全三个角度，比较临时邮箱与邮箱别名。",
			publishedAt: "2026-02-12",
			readingMinutes: 5
		},
		{
			slug: "otp-email-not-arriving-fixes",
			title: "收不到验证码邮件？8 个高效排查方法",
			description: "快速定位验证码邮件延迟或丢失问题：重发、拦截、刷新策略与备用方案。",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		}
	],
	es: [
		{
			slug: "temporary-email-best-practices",
			title: "Buenas prácticas de correo temporal para registros más seguros",
			description: "Aprende prácticas de correo temporal para reducir spam, evitar bloqueos y proteger tu bandeja principal.",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		},
		{
			slug: "temporary-email-vs-email-alias",
			title: "Correo temporal vs alias de correo: ¿cuál te conviene?",
			description: "Compara correo temporal y alias por privacidad, recuperación y seguridad de cuentas a largo plazo.",
			publishedAt: "2026-02-12",
			readingMinutes: 5
		},
		{
			slug: "otp-email-not-arriving-fixes",
			title: "¿No llega el correo OTP? 8 soluciones rápidas que funcionan",
			description: "Resuelve correos de verificación retrasados con una lista práctica de reenvío, bloqueos del remitente y refresco del buzón.",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		}
	],
	fr: [
		{
			slug: "temporary-email-best-practices",
			title: "Bonnes pratiques d'email temporaire pour des inscriptions plus sûres",
			description: "Découvrez des pratiques concrètes pour réduire le spam, éviter les blocages et protéger votre boîte principale.",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		},
		{
			slug: "temporary-email-vs-email-alias",
			title: "Email temporaire vs alias email : lequel choisir ?",
			description: "Comparez email temporaire et alias selon la confidentialité, la récupération et la sécurité à long terme.",
			publishedAt: "2026-02-12",
			readingMinutes: 5
		},
		{
			slug: "otp-email-not-arriving-fixes",
			title: "Email OTP non reçu ? 8 solutions rapides qui marchent",
			description: "Résolvez les retards d'emails de vérification avec une checklist pratique : renvoi, filtrage et rafraîchissement.",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		}
	],
	de: [
		{
			slug: "temporary-email-best-practices",
			title: "Best Practices für temporäre E-Mails bei sicheren Registrierungen",
			description: "Praktische Regeln, um Spam zu reduzieren, Kontosperren zu vermeiden und dein Hauptpostfach zu schützen.",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		},
		{
			slug: "temporary-email-vs-email-alias",
			title: "Temporäre E-Mail vs E-Mail-Alias: Was ist besser?",
			description: "Vergleiche temporäre Postfächer und Aliase nach Datenschutz, Wiederherstellung und Kontosicherheit.",
			publishedAt: "2026-02-12",
			readingMinutes: 5
		},
		{
			slug: "otp-email-not-arriving-fixes",
			title: "OTP-Mail kommt nicht an? 8 schnelle Lösungen",
			description: "Behebe verzögerte Verifizierungsmails mit einer klaren Checkliste für Neuversand, Blocklisten und Postfach-Refresh.",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		}
	],
	ja: [
		{
			slug: "temporary-email-best-practices",
			title: "安全な登録のための一時メール運用ベストプラクティス",
			description: "スパム削減、ロックアウト回避、メイン受信箱保護のための実践的な一時メール運用を解説します。",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		},
		{
			slug: "temporary-email-vs-email-alias",
			title: "一時メールとメールエイリアスの違い：どちらを使うべき？",
			description: "プライバシー、復旧性、長期アカウント安全性の観点で一時メールとエイリアスを比較します。",
			publishedAt: "2026-02-12",
			readingMinutes: 5
		},
		{
			slug: "otp-email-not-arriving-fixes",
			title: "OTPメールが届かない？効果的な8つの対処法",
			description: "再送、送信元ポリシー、受信箱更新の順で確認できる実用チェックリストを紹介します。",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		}
	],
	ko: [
		{
			slug: "temporary-email-best-practices",
			title: "더 안전한 가입을 위한 임시 이메일 모범 사례",
			description: "스팸을 줄이고 계정 잠금을 피하며 기본 받은편지함을 보호하는 실전형 임시 이메일 전략입니다.",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		},
		{
			slug: "temporary-email-vs-email-alias",
			title: "임시 이메일 vs 이메일 별칭: 무엇을 써야 할까?",
			description: "개인정보 보호, 복구 가능성, 장기 계정 안정성 기준으로 임시 이메일과 별칭을 비교합니다.",
			publishedAt: "2026-02-12",
			readingMinutes: 5
		},
		{
			slug: "otp-email-not-arriving-fixes",
			title: "OTP 메일이 안 오나요? 빠르게 해결하는 8가지 방법",
			description: "재전송, 발신 도메인 정책, 받은편지함 새로고침을 중심으로 지연된 인증 메일을 해결하세요.",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		}
	],
	ru: [
		{
			slug: "temporary-email-best-practices",
			title: "Лучшие практики временной почты для более безопасных регистраций",
			description: "Практические рекомендации, как снизить спам, избежать блокировок и защитить основной почтовый ящик.",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		},
		{
			slug: "temporary-email-vs-email-alias",
			title: "Временная почта vs почтовый алиас: что выбрать?",
			description: "Сравнение временной почты и алиасов по приватности, восстановлению доступа и долгосрочной безопасности.",
			publishedAt: "2026-02-12",
			readingMinutes: 5
		},
		{
			slug: "otp-email-not-arriving-fixes",
			title: "OTP-письмо не приходит? 8 быстрых решений",
			description: "Пошаговый чеклист для задержек писем подтверждения: повторная отправка, политика отправителя и обновление ящика.",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		}
	],
	pt: [
		{
			slug: "temporary-email-best-practices",
			title: "Boas práticas de email temporário para cadastros mais seguros",
			description: "Aprenda práticas para reduzir spam, evitar bloqueios e proteger sua caixa principal com email temporário.",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		},
		{
			slug: "temporary-email-vs-email-alias",
			title: "Email temporário vs alias de email: qual usar?",
			description: "Compare email temporário e alias por privacidade, recuperação e segurança de conta no longo prazo.",
			publishedAt: "2026-02-12",
			readingMinutes: 5
		},
		{
			slug: "otp-email-not-arriving-fixes",
			title: "Email OTP não chega? 8 correções rápidas",
			description: "Resolva atrasos de email de verificação com checklist prático de reenvio, bloqueios do remetente e atualização da caixa.",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		}
	],
	ar: [
		{
			slug: "temporary-email-best-practices",
			title: "أفضل ممارسات البريد المؤقت لتسجيلات أكثر أمانًا",
			description: "تعرف على ممارسات عملية لتقليل الرسائل المزعجة وتجنب قفل الحسابات وحماية صندوق بريدك الأساسي.",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		},
		{
			slug: "temporary-email-vs-email-alias",
			title: "البريد المؤقت مقابل الاسم المستعار للبريد: أيهما تختار؟",
			description: "مقارنة بين البريد المؤقت والاسم المستعار من حيث الخصوصية واستعادة الحساب وأمان الاستخدام طويل المدى.",
			publishedAt: "2026-02-12",
			readingMinutes: 5
		},
		{
			slug: "otp-email-not-arriving-fixes",
			title: "لا تصلك رسالة OTP؟ 8 حلول سريعة وفعالة",
			description: "عالج تأخر رسائل التحقق عبر قائمة عملية تشمل إعادة الإرسال وسياسة المرسل وتحديث صندوق الوارد.",
			publishedAt: "2026-02-12",
			readingMinutes: 4
		}
	]
};
function toBlogLocale(locale) {
	if (BLOG_LOCALES.includes(locale)) return locale;
	return "en";
}
function listBlogPosts(locale) {
	return BLOG_POSTS[toBlogLocale(locale)];
}
function getBlogPageCount(locale) {
	const totalPosts = listBlogPosts(locale).length;
	return Math.max(1, Math.ceil(totalPosts / 6));
}
function getBlogPostsByPage(locale, page) {
	const start = (Math.max(1, page) - 1) * 6;
	return listBlogPosts(locale).slice(start, start + 6);
}
function getBlogPostMeta(locale, slug) {
	return listBlogPosts(locale).find((post) => post.slug === slug) ?? null;
}
function getAllBlogSlugs() {
	const slugs = /* @__PURE__ */ new Set();
	for (const locale of BLOG_LOCALES) for (const post of BLOG_POSTS[locale]) slugs.add(post.slug);
	return Array.from(slugs);
}
//#endregion
//#region app/seo.config.ts
var BASE_URL = "https://smail.pw";
var MARKDOWN_BASE_PATHS = [
	"/about",
	"/faq",
	"/privacy",
	"/terms",
	"/temporary-email-24-hours",
	"/temporary-email-no-registration",
	"/disposable-email-for-verification",
	"/temporary-email-for-registration",
	"/online-temporary-email",
	"/domestic-temporary-email",
	"/can-temporary-email-send",
	"/smail-vs-smailpro"
];
var BLOG_BASE_PATH = "/blog";
var MARKDOWN_INDEXABLE_LOCALES = SUPPORTED_LOCALES;
var BLOG_INDEXABLE_LOCALES = BLOG_LOCALES;
function isMarkdownBasePath(pathname) {
	return MARKDOWN_BASE_PATHS.includes(pathname);
}
function isMarkdownLocaleIndexable(locale) {
	return MARKDOWN_INDEXABLE_LOCALES.includes(locale);
}
function isBlogBasePath(pathname) {
	return pathname === "/blog" || pathname.startsWith(`/blog/`);
}
function isBlogLocaleIndexable(locale) {
	return BLOG_INDEXABLE_LOCALES.includes(locale);
}
//#endregion
//#region app/utils/theme.ts
var DEFAULT_THEME = "light";
var THEME_COOKIE_NAME = "smail-theme";
var THEME_COOKIE_MAX_AGE = 3600 * 24 * 365;
function isThemeMode(value) {
	return value === "dark" || value === "light";
}
function parseThemeFromCookieHeader(cookieHeader) {
	if (!cookieHeader) return DEFAULT_THEME;
	const pairs = cookieHeader.split(";");
	for (const pair of pairs) {
		const [name, rawValue] = pair.trim().split("=");
		if (name !== "smail-theme") continue;
		if (isThemeMode(rawValue)) return rawValue;
	}
	return DEFAULT_THEME;
}
function createThemeCookie(theme) {
	return `${THEME_COOKIE_NAME}=${theme}; Path=/; Max-Age=${THEME_COOKIE_MAX_AGE}; SameSite=Lax`;
}
//#endregion
//#region app/root.tsx
var root_exports = /* @__PURE__ */ __exportAll({
	ErrorBoundary: () => ErrorBoundary,
	Layout: () => Layout,
	default: () => root_default,
	loader: () => loader$11,
	meta: () => meta$6
});
var SITE_OG_TITLE = "smail.pw · 24-Hour Temporary Email";
var SITE_OG_DESCRIPTION = "Free disposable email inbox with 24-hour auto-expiry. Use a temporary address for sign-ups and verification.";
async function loader$11({ request }) {
	return { theme: parseThemeFromCookieHeader(request.headers.get("Cookie")) };
}
function meta$6({ location }) {
	const pathname = normalizePathname(location.pathname);
	const locale = getLocaleFromPathname(pathname);
	const basePath = stripLocalePrefix(pathname);
	const isMarkdownPage = isMarkdownBasePath(basePath);
	const isBlogPage = isBlogBasePath(basePath);
	const canonicalLocale = isMarkdownPage && !isMarkdownLocaleIndexable(locale) ? "en" : isBlogPage && !isBlogLocaleIndexable(locale) ? "en" : locale;
	const canonicalPath = toLocalePath(basePath, canonicalLocale);
	const rssLocale = canonicalLocale === "zh" ? "zh" : "en";
	const canonicalUrl = `${BASE_URL}${canonicalPath}`;
	const alternateLinks = (isMarkdownPage ? MARKDOWN_INDEXABLE_LOCALES : isBlogPage ? BLOG_INDEXABLE_LOCALES : SUPPORTED_LOCALES).map((supportedLocale) => ({
		tagName: "link",
		rel: "alternate",
		hrefLang: supportedLocale,
		href: `${BASE_URL}${toLocalePath(basePath, supportedLocale)}`
	}));
	return [
		{
			tagName: "link",
			rel: "canonical",
			href: canonicalUrl
		},
		...alternateLinks,
		{
			tagName: "link",
			rel: "alternate",
			hrefLang: "x-default",
			href: `${BASE_URL}${toLocalePath(basePath, "en")}`
		},
		{
			tagName: "link",
			rel: "alternate",
			type: "application/rss+xml",
			title: "smail.pw Blog RSS",
			href: `${BASE_URL}${toLocalePath("/rss.xml", rssLocale)}`
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			property: "og:site_name",
			content: "smail.pw"
		},
		{
			property: "og:url",
			content: canonicalUrl
		},
		{
			property: "og:title",
			content: SITE_OG_TITLE
		},
		{
			property: "og:description",
			content: SITE_OG_DESCRIPTION
		},
		{
			name: "twitter:card",
			content: "summary"
		},
		{
			name: "twitter:title",
			content: SITE_OG_TITLE
		},
		{
			name: "twitter:description",
			content: SITE_OG_DESCRIPTION
		}
	];
}
function Layout({ children }) {
	const location = useLocation();
	const { theme } = useLoaderData();
	const locale = getLocaleFromPathname(location.pathname);
	const resolvedTheme = theme ?? "light";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: locale,
		dir: getLocaleDirection(locale),
		"data-theme": resolvedTheme === "light" ? "light" : void 0,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", { charSet: "utf-8" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", {
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meta, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Links, {})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			children,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollRestoration, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var root_default = withComponentProps(function App() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
});
var ErrorBoundary = withErrorBoundaryProps(function ErrorBoundary({ error }) {
	const homePath = toLocalePath("/", getLocaleFromPathname(useLocation().pathname));
	if (isRouteErrorResponse(error) && error.status === 404) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, {
		to: homePath,
		replace: true
	});
	let message = "Oops!";
	let details = "An unexpected error occurred.";
	let stack;
	if (isRouteErrorResponse(error)) {
		message = error.status === 404 ? "404" : "Error";
		details = error.status === 404 ? "The requested page could not be found." : error.statusText || details;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "pt-16 p-4 container mx-auto",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: message }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: details }),
			stack
		]
	});
});
//#endregion
//#region app/routes/locale-zh-cn-redirect.tsx
var locale_zh_cn_redirect_exports = /* @__PURE__ */ __exportAll({
	default: () => locale_zh_cn_redirect_default,
	loader: () => loader$10
});
function toZhPath(splat) {
	if (!splat || splat === "/") return "/zh";
	return `/zh${splat.startsWith("/") ? splat : `/${splat}`}`;
}
async function loader$10({ request, params }) {
	const url = new URL(request.url);
	throw redirect(`${toZhPath(params["*"])}${url.search}`, 301);
}
var locale_zh_cn_redirect_default = withComponentProps(function LocaleZhCnRedirect() {
	return null;
});
//#endregion
//#region app/routes/robots.txt.tsx
var robots_txt_exports = /* @__PURE__ */ __exportAll({ loader: () => loader$9 });
async function loader$9() {
	const body = [
		"User-agent: *",
		"Allow: /",
		"Disallow: /api/",
		"",
		`Sitemap: ${BASE_URL}/sitemap.xml`,
		`Feed: ${BASE_URL}/rss.xml`,
		`Feed: ${BASE_URL}/zh/rss.xml`,
		""
	].join("\n");
	return new Response(body, {
		status: 200,
		headers: { "Content-Type": "text/plain; charset=utf-8" }
	});
}
//#endregion
//#region app/routes/sitemap.xml.tsx
var sitemap_xml_exports = /* @__PURE__ */ __exportAll({ loader: () => loader$8 });
var STATIC_PATHS = ["/", "/contact"];
async function loader$8() {
	const lastmod = (/* @__PURE__ */ new Date()).toISOString();
	const seen = /* @__PURE__ */ new Set();
	const allPaths = [];
	for (const locale of SUPPORTED_LOCALES) for (const staticPath of STATIC_PATHS) {
		const localizedPath = toLocalePath(staticPath, locale);
		if (seen.has(localizedPath)) continue;
		seen.add(localizedPath);
		allPaths.push(localizedPath);
	}
	for (const locale of MARKDOWN_INDEXABLE_LOCALES) for (const basePath of MARKDOWN_BASE_PATHS) {
		const localizedPath = toLocalePath(basePath, locale);
		if (seen.has(localizedPath)) continue;
		seen.add(localizedPath);
		allPaths.push(localizedPath);
	}
	const blogSlugs = getAllBlogSlugs();
	for (const locale of BLOG_INDEXABLE_LOCALES) {
		const blogListPath = toLocalePath(BLOG_BASE_PATH, locale);
		if (!seen.has(blogListPath)) {
			seen.add(blogListPath);
			allPaths.push(blogListPath);
		}
		const totalPages = getBlogPageCount(locale);
		for (let page = 2; page <= totalPages; page++) {
			const pagedPath = toLocalePath(`${BLOG_BASE_PATH}/page/${page}`, locale);
			if (seen.has(pagedPath)) continue;
			seen.add(pagedPath);
			allPaths.push(pagedPath);
		}
		for (const slug of blogSlugs) {
			const blogPostPath = toLocalePath(`${BLOG_BASE_PATH}/${slug}`, locale);
			if (seen.has(blogPostPath)) continue;
			seen.add(blogPostPath);
			allPaths.push(blogPostPath);
		}
	}
	const body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">" + allPaths.map((path) => {
		return `\n  <url>\n    <loc>${BASE_URL}${path}</loc>\n    <lastmod>${lastmod}</lastmod>\n  </url>`;
	}).join("") + "\n</urlset>\n";
	return new Response(body, {
		status: 200,
		headers: { "Content-Type": "application/xml; charset=utf-8" }
	});
}
//#endregion
//#region app/routes/rss.xml.tsx
var rss_xml_exports = /* @__PURE__ */ __exportAll({ loader: () => loader$7 });
function getFeedLocale(lang) {
	const { locale, isInvalid } = resolveLocaleParam(lang);
	if (isInvalid) throw new Response("Not Found", { status: 404 });
	return locale;
}
function normalizeFeedLocale(locale) {
	return locale === "zh" ? "zh" : "en";
}
function toRfc822Date(value) {
	return new Date(value).toUTCString();
}
function getFeedCopy(locale) {
	if (locale === "zh") return {
		title: "smail.pw 博客",
		description: "临时邮箱使用指南、排障手册与隐私实践文章。",
		language: "zh-CN"
	};
	return {
		title: "smail.pw Blog",
		description: "Temporary email guides, troubleshooting, and privacy best practices.",
		language: "en-US"
	};
}
async function loader$7({ params, request }) {
	const requestedLocale = getFeedLocale(params.lang);
	const normalizedLocale = normalizeFeedLocale(requestedLocale);
	const { shouldRedirectToDefault } = resolveLocaleParam(params.lang);
	const url = new URL(request.url);
	if (shouldRedirectToDefault || requestedLocale !== normalizedLocale) throw new Response(null, {
		status: 301,
		headers: { Location: `${toLocalePath("/rss.xml", normalizedLocale)}${url.search}` }
	});
	const feedCopy = getFeedCopy(normalizedLocale);
	const posts = listBlogPosts(normalizedLocale);
	const feedUrl = `${BASE_URL}${toLocalePath("/rss.xml", normalizedLocale)}`;
	const blogUrl = `${BASE_URL}${toLocalePath("/blog", normalizedLocale)}`;
	const body = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
<channel>
<title>${escapeXml(feedCopy.title)}</title>\n<link>${escapeXml(blogUrl)}</link>\n<description>${escapeXml(feedCopy.description)}</description>\n<language>${feedCopy.language}</language>\n<atom:link xmlns:atom="http://www.w3.org/2005/Atom" href="${escapeXml(feedUrl)}" rel="self" type="application/rss+xml" />\n` + posts.map((post) => {
		const postUrl = `${BASE_URL}${toLocalePath(`/blog/${post.slug}`, normalizedLocale)}`;
		const updated = post.updatedAt ?? post.publishedAt;
		return `<item>\n<title>${escapeXml(post.title)}</title>\n<link>${escapeXml(postUrl)}</link>\n<guid isPermaLink="true">${escapeXml(postUrl)}</guid>\n<description>${escapeXml(post.description)}</description>\n<pubDate>${toRfc822Date(post.publishedAt)}</pubDate>\n<lastBuildDate>${toRfc822Date(updated)}</lastBuildDate>\n</item>\n`;
	}).join("") + "</channel>\n</rss>\n";
	return new Response(body, {
		status: 200,
		headers: {
			"Content-Type": "application/rss+xml; charset=utf-8",
			"Cache-Control": "public, max-age=1800"
		}
	});
}
function escapeXml(value) {
	return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("'", "&apos;");
}
//#endregion
//#region app/i18n/messages.ts
var import_react = /* @__PURE__ */ __toESM$1(require_react(), 1);
var messages = {
	en: {
		home: {
			title: "smail.pw Temporary Email (24h) - Free Temp Mail for OTP & Sign-Ups",
			description: "Generate free temporary email (temp mail) instantly on smail.pw. Use a 24-hour disposable inbox for OTP verification, quick sign-ups, and spam control.",
			keywords: "smail, smail temp mail, temporary email, temp mail, disposable email, temporary email generator, 24 hour temporary email, no registration email, otp email, smail.pw",
			heroTag: "Disposable mailbox",
			heroTitle: "Create a 24-hour temporary email inbox in one tap.",
			heroDescription: "Generate a temp mail address for sign-ups and OTP links in seconds. Messages auto-expire after 24 hours to reduce data exposure.",
			loadingAddresses: "Loading addresses...",
			currentAddress: "Current disposable address",
			copy: "Copy",
			copied: "Copied",
			deleteAddress: "Delete address",
			deleting: "Deleting...",
			generateNew: "Generate new",
			generating: "Generating...",
			noAddressTitle: "No disposable email yet",
			noAddressDescription: "Generate a temporary address to use for sign-ups and one-off verifications.",
			generateAddress: "Generate address",
			stats: {
				lifetimeValue: "24h",
				refreshValue: "Instant",
				registrationValue: "Zero",
				lifetime: "Email retention",
				refresh: "Inbox refresh",
				registration: "Registration"
			},
			inboxTag: "Inbox",
			inboxTitle: "Latest emails",
			tapToOpen: "Tap to open",
			loadingEmails: "Loading emails...",
			emptyInboxTitle: "Your inbox is waiting",
			emptyInboxDescription: "No emails yet. Messages will appear here instantly.",
			refreshInbox: "Refresh",
			refreshingInbox: "Refreshing...",
			lastRefresh: "Last refresh",
			safetyHint: "Do not use this address for banking, work, or critical account codes. Messages are automatically removed after 24 hours.",
			modal: {
				title: "Message preview",
				from: "From",
				time: "Time",
				loading: "Loading...",
				empty: "No content"
			}
		},
		layout: {
			siteSubtitle: "temporary inbox",
			nav: {
				home: "Home",
				about: "About",
				faq: "FAQ"
			},
			footerTag: "privacy-first utilities",
			footerDescription: "Disposable inbox for sign-up verification, app testing, and short-lived communication without exposing your personal mailbox.",
			footerLinks: {
				faq: "FAQ",
				privacy: "Privacy Policy",
				terms: "Terms of Use",
				about: "About smail.pw"
			},
			copyright: "Clean inbox, clean identity.",
			themeToLight: "☀ Light",
			themeToDark: "🌙 Dark"
		}
	},
	zh: {
		home: {
			title: "临时邮箱生成器（24小时）- 免费一次性邮箱免注册收验证码 | smail.pw",
			description: "免费临时邮箱生成器，一键创建 24 小时一次性邮箱。适合临时邮箱注册、验证码接收与在线临时收信，减少垃圾邮件。",
			keywords: "临时邮箱, 一次性邮箱, 临时邮箱生成器, 免费临时邮箱, 24小时临时邮箱, 24小时邮箱, 验证码邮箱, 免注册临时邮箱, 在线临时邮箱, 国内临时邮箱, 临时邮箱注册, 邮箱生成器",
			heroTag: "一次性邮箱",
			heroTitle: "免费临时邮箱生成器：一键创建 24 小时收件箱。",
			heroDescription: "适合临时邮箱注册、验证码与一次性下载。邮件 24 小时后自动清理，减少真实邮箱暴露。",
			loadingAddresses: "正在加载邮箱地址...",
			currentAddress: "当前临时邮箱",
			copy: "复制",
			copied: "已复制",
			deleteAddress: "删除地址",
			deleting: "删除中...",
			generateNew: "生成新地址",
			generating: "生成中...",
			noAddressTitle: "还没有临时邮箱",
			noAddressDescription: "生成一个临时邮箱，用于注册和一次性验证。",
			generateAddress: "生成地址",
			stats: {
				lifetimeValue: "24小时",
				refreshValue: "即时",
				registrationValue: "零门槛",
				lifetime: "邮件保留",
				refresh: "收件箱刷新",
				registration: "无需注册"
			},
			inboxTag: "收件箱",
			inboxTitle: "最新邮件",
			tapToOpen: "点击查看",
			loadingEmails: "正在加载邮件...",
			emptyInboxTitle: "收件箱等待中",
			emptyInboxDescription: "暂时没有邮件，收到后会立即显示在这里。",
			refreshInbox: "刷新",
			refreshingInbox: "刷新中...",
			lastRefresh: "最近刷新",
			safetyHint: "请勿用于银行、工作或重要账号验证码。邮件会在 24 小时后自动删除。",
			modal: {
				title: "邮件预览",
				from: "发件人",
				time: "时间",
				loading: "加载中...",
				empty: "暂无内容"
			}
		},
		layout: {
			siteSubtitle: "临时收件箱",
			nav: {
				home: "首页",
				about: "关于",
				faq: "常见问题"
			},
			footerTag: "隐私优先工具",
			footerDescription: "用于注册验证、测试和短期收信的临时邮箱服务，避免泄露你的个人邮箱地址。",
			footerLinks: {
				faq: "常见问题",
				privacy: "隐私政策",
				terms: "使用条款",
				about: "关于 smail.pw"
			},
			copyright: "让邮箱更干净，让身份更安全。",
			themeToLight: "☀ 浅色",
			themeToDark: "🌙 深色"
		}
	},
	es: {
		home: {
			title: "Correo temporal gratis 24h sin registro para OTP | smail.pw",
			description: "Generador de correo temporal gratis (temp mail) para registros y códigos OTP. Crea un buzón desechable de 24 horas al instante.",
			keywords: "correo temporal, correo temporal gratis, email temporal, email desechable, temp mail, 24 horas, sin registro, codigo otp, smail.pw",
			heroTag: "Buzón temporal",
			heroTitle: "Protege tu privacidad con un buzón en un clic.",
			heroDescription: "Genera una dirección temporal para registros y verificaciones, y elimínala cuando termines.",
			loadingAddresses: "Cargando direcciones...",
			currentAddress: "Dirección temporal actual",
			copy: "Copiar",
			copied: "Copiado",
			deleteAddress: "Eliminar dirección",
			deleting: "Eliminando...",
			generateNew: "Generar nueva",
			generating: "Generando...",
			noAddressTitle: "Aún no tienes correo temporal",
			noAddressDescription: "Genera una dirección temporal para registros y verificaciones rápidas.",
			generateAddress: "Generar dirección",
			stats: {
				lifetimeValue: "24h",
				refreshValue: "Instantáneo",
				registrationValue: "Cero",
				lifetime: "Vida útil",
				refresh: "Actualización",
				registration: "Registro"
			},
			inboxTag: "Bandeja",
			inboxTitle: "Últimos correos",
			tapToOpen: "Pulsa para abrir",
			loadingEmails: "Cargando correos...",
			emptyInboxTitle: "Tu bandeja te espera",
			emptyInboxDescription: "Aún no hay correos. Aparecerán aquí al instante.",
			refreshInbox: "Actualizar",
			refreshingInbox: "Actualizando...",
			lastRefresh: "Última actualización",
			safetyHint: "No uses esta dirección para banca, trabajo o códigos de cuentas importantes.",
			modal: {
				title: "Vista previa",
				from: "De",
				time: "Hora",
				loading: "Cargando...",
				empty: "Sin contenido"
			}
		},
		layout: {
			siteSubtitle: "buzón temporal",
			nav: {
				home: "Inicio",
				about: "Acerca de",
				faq: "FAQ"
			},
			footerTag: "utilidades centradas en privacidad",
			footerDescription: "Buzón desechable para verificaciones, pruebas y comunicaciones cortas sin exponer tu correo principal.",
			footerLinks: {
				faq: "FAQ",
				privacy: "Privacidad",
				terms: "Términos",
				about: "Sobre smail.pw"
			},
			copyright: "Bandeja limpia, identidad limpia.",
			themeToLight: "☀ Claro",
			themeToDark: "🌙 Oscuro"
		}
	},
	fr: {
		home: {
			title: "Email temporaire gratuit 24h sans inscription | smail.pw",
			description: "Générateur d'email temporaire gratuit (temp mail) pour inscriptions rapides et codes OTP. Créez une boîte jetable 24h immédiatement.",
			keywords: "email temporaire, email jetable, temp mail, 24h, sans inscription, code otp, boite mail temporaire, smail.pw",
			heroTag: "Boîte temporaire",
			heroTitle: "Protégez votre vie privée en un clic.",
			heroDescription: "Créez une adresse temporaire pour les inscriptions et vérifications, puis supprimez-la quand c'est fini.",
			loadingAddresses: "Chargement des adresses...",
			currentAddress: "Adresse temporaire actuelle",
			copy: "Copier",
			copied: "Copié",
			deleteAddress: "Supprimer l'adresse",
			deleting: "Suppression...",
			generateNew: "Nouvelle adresse",
			generating: "Génération...",
			noAddressTitle: "Aucune adresse temporaire",
			noAddressDescription: "Générez une adresse temporaire pour inscriptions et vérifications.",
			generateAddress: "Générer une adresse",
			stats: {
				lifetimeValue: "24h",
				refreshValue: "Instantané",
				registrationValue: "Zéro",
				lifetime: "Durée",
				refresh: "Rafraîchissement",
				registration: "Inscription"
			},
			inboxTag: "Boîte",
			inboxTitle: "Derniers emails",
			tapToOpen: "Ouvrir",
			loadingEmails: "Chargement des emails...",
			emptyInboxTitle: "Votre boîte vous attend",
			emptyInboxDescription: "Aucun email pour l'instant. Ils apparaîtront ici immédiatement.",
			refreshInbox: "Rafraîchir",
			refreshingInbox: "Actualisation...",
			lastRefresh: "Dernière mise à jour",
			safetyHint: "N’utilisez pas cette adresse pour la banque, le travail ou des codes de comptes importants.",
			modal: {
				title: "Aperçu du message",
				from: "De",
				time: "Heure",
				loading: "Chargement...",
				empty: "Aucun contenu"
			}
		},
		layout: {
			siteSubtitle: "boîte temporaire",
			nav: {
				home: "Accueil",
				about: "À propos",
				faq: "FAQ"
			},
			footerTag: "outils orientés confidentialité",
			footerDescription: "Boîte jetable pour vérifications, tests et messages courts sans exposer votre boîte principale.",
			footerLinks: {
				faq: "FAQ",
				privacy: "Confidentialité",
				terms: "Conditions",
				about: "À propos de smail.pw"
			},
			copyright: "Boîte propre, identité propre.",
			themeToLight: "☀ Clair",
			themeToDark: "🌙 Sombre"
		}
	},
	de: {
		home: {
			title: "Temporäre E-Mail kostenlos (24h) ohne Registrierung | smail.pw",
			description: "Kostenloser Temp-Mail-Generator für Registrierungen und OTP-Codes. Erstelle sofort ein 24h Wegwerf-Postfach ohne Konto.",
			keywords: "temporäre email, wegwerf-email, temp mail, 24h email, ohne registrierung, otp code email, smail.pw",
			heroTag: "Temporäres Postfach",
			heroTitle: "Schütze deine Privatsphäre mit einem Klick.",
			heroDescription: "Erstelle eine temporäre Adresse für Registrierungen und Bestätigungen und lösche sie danach.",
			loadingAddresses: "Adressen werden geladen...",
			currentAddress: "Aktuelle Wegwerfadresse",
			copy: "Kopieren",
			copied: "Kopiert",
			deleteAddress: "Adresse löschen",
			deleting: "Wird gelöscht...",
			generateNew: "Neu generieren",
			generating: "Wird generiert...",
			noAddressTitle: "Noch keine Wegwerfadresse",
			noAddressDescription: "Erzeuge eine temporäre Adresse für schnelle Registrierungen und Verifizierungen.",
			generateAddress: "Adresse erzeugen",
			stats: {
				lifetimeValue: "24h",
				refreshValue: "Sofort",
				registrationValue: "Null",
				lifetime: "Lebensdauer",
				refresh: "Aktualisierung",
				registration: "Registrierung"
			},
			inboxTag: "Posteingang",
			inboxTitle: "Neueste E-Mails",
			tapToOpen: "Zum Öffnen tippen",
			loadingEmails: "E-Mails werden geladen...",
			emptyInboxTitle: "Dein Posteingang wartet",
			emptyInboxDescription: "Noch keine E-Mails. Neue Nachrichten erscheinen sofort hier.",
			refreshInbox: "Aktualisieren",
			refreshingInbox: "Wird aktualisiert...",
			lastRefresh: "Zuletzt aktualisiert",
			safetyHint: "Nicht für Banking, Arbeit oder wichtige Kontocodes verwenden.",
			modal: {
				title: "Nachrichtenvorschau",
				from: "Von",
				time: "Zeit",
				loading: "Lädt...",
				empty: "Kein Inhalt"
			}
		},
		layout: {
			siteSubtitle: "temporäres Postfach",
			nav: {
				home: "Start",
				about: "Über",
				faq: "FAQ"
			},
			footerTag: "datenschutzorientierte tools",
			footerDescription: "Wegwerf-Postfach für Verifizierungen, Tests und kurze Kommunikation ohne dein Hauptpostfach preiszugeben.",
			footerLinks: {
				faq: "FAQ",
				privacy: "Datenschutz",
				terms: "Nutzungsbedingungen",
				about: "Über smail.pw"
			},
			copyright: "Sauberes Postfach, saubere Identität.",
			themeToLight: "☀ Hell",
			themeToDark: "🌙 Dunkel"
		}
	},
	ja: {
		home: {
			title: "一時メール（24時間）無料・登録不要でOTP受信 | smail.pw",
			description: "無料の一時メール（temp mail）生成サービス。登録不要で24時間の使い捨て受信箱を作成し、認証コードを受け取れます。",
			keywords: "一時メール, 使い捨てメール, テンプメール, 24時間メール, 登録不要メール, OTP, 認証メール, smail.pw",
			heroTag: "一時メールボックス",
			heroTitle: "ワンクリックでプライバシーを保護。",
			heroDescription: "登録や認証用に一時アドレスを作成し、不要になったら削除できます。",
			loadingAddresses: "アドレスを読み込み中...",
			currentAddress: "現在の一時アドレス",
			copy: "コピー",
			copied: "コピー済み",
			deleteAddress: "アドレス削除",
			deleting: "削除中...",
			generateNew: "新規生成",
			generating: "生成中...",
			noAddressTitle: "一時メールがまだありません",
			noAddressDescription: "登録や認証のために一時アドレスを生成してください。",
			generateAddress: "アドレス生成",
			stats: {
				lifetimeValue: "24時間",
				refreshValue: "即時",
				registrationValue: "不要",
				lifetime: "有効期間",
				refresh: "受信更新",
				registration: "登録"
			},
			inboxTag: "受信箱",
			inboxTitle: "最新メール",
			tapToOpen: "タップして開く",
			loadingEmails: "メールを読み込み中...",
			emptyInboxTitle: "受信箱は準備完了です",
			emptyInboxDescription: "まだメールはありません。届くとすぐここに表示されます。",
			refreshInbox: "更新",
			refreshingInbox: "更新中...",
			lastRefresh: "最終更新",
			safetyHint: "銀行・仕事・重要アカウントの認証コードには使用しないでください。",
			modal: {
				title: "メッセージプレビュー",
				from: "差出人",
				time: "時刻",
				loading: "読み込み中...",
				empty: "内容なし"
			}
		},
		layout: {
			siteSubtitle: "一時受信箱",
			nav: {
				home: "ホーム",
				about: "概要",
				faq: "FAQ"
			},
			footerTag: "プライバシー重視のツール",
			footerDescription: "主要メールを公開せず、認証・テスト・短期利用に使える使い捨て受信箱です。",
			footerLinks: {
				faq: "FAQ",
				privacy: "プライバシー",
				terms: "利用規約",
				about: "smail.pw について"
			},
			copyright: "受信箱をクリーンに、アイデンティティもクリーンに。",
			themeToLight: "☀ ライト",
			themeToDark: "🌙 ダーク"
		}
	},
	ko: {
		home: {
			title: "임시 이메일 24시간 무료, 가입 없이 OTP 수신 | smail.pw",
			description: "무료 임시 이메일(temp mail) 생성기. 가입 없이 24시간 일회용 메일함을 만들고 인증 코드(OTP)를 빠르게 받으세요.",
			keywords: "임시 이메일, 일회용 이메일, 템프 메일, 24시간 메일, 가입 없는 이메일, OTP 메일, 인증 메일, smail.pw",
			heroTag: "임시 메일함",
			heroTitle: "한 번의 클릭으로 개인정보 보호.",
			heroDescription: "회원가입 및 인증용 임시 주소를 만들고, 사용 후 바로 삭제하세요.",
			loadingAddresses: "주소 불러오는 중...",
			currentAddress: "현재 임시 주소",
			copy: "복사",
			copied: "복사됨",
			deleteAddress: "주소 삭제",
			deleting: "삭제 중...",
			generateNew: "새로 생성",
			generating: "생성 중...",
			noAddressTitle: "아직 임시 이메일이 없습니다",
			noAddressDescription: "가입 및 인증에 사용할 임시 주소를 생성하세요.",
			generateAddress: "주소 생성",
			stats: {
				lifetimeValue: "24시간",
				refreshValue: "즉시",
				registrationValue: "없음",
				lifetime: "유효기간",
				refresh: "새로고침",
				registration: "가입"
			},
			inboxTag: "받은편지함",
			inboxTitle: "최신 메일",
			tapToOpen: "탭하여 열기",
			loadingEmails: "메일 불러오는 중...",
			emptyInboxTitle: "받은편지함이 준비되었습니다",
			emptyInboxDescription: "아직 메일이 없습니다. 도착하면 즉시 표시됩니다.",
			refreshInbox: "새로고침",
			refreshingInbox: "새로고침 중...",
			lastRefresh: "최근 새로고침",
			safetyHint: "은행·업무·중요 계정 인증코드에는 사용하지 마세요.",
			modal: {
				title: "메일 미리보기",
				from: "보낸사람",
				time: "시간",
				loading: "불러오는 중...",
				empty: "내용 없음"
			}
		},
		layout: {
			siteSubtitle: "임시 받은편지함",
			nav: {
				home: "홈",
				about: "소개",
				faq: "FAQ"
			},
			footerTag: "프라이버시 중심 도구",
			footerDescription: "주 이메일을 노출하지 않고 인증, 테스트, 단기 사용에 적합한 일회용 메일함입니다.",
			footerLinks: {
				faq: "FAQ",
				privacy: "개인정보",
				terms: "이용약관",
				about: "smail.pw 소개"
			},
			copyright: "깔끔한 메일함, 깔끔한 신원.",
			themeToLight: "☀ 라이트",
			themeToDark: "🌙 다크"
		}
	},
	ru: {
		home: {
			title: "Временная почта 24 часа бесплатно без регистрации | smail.pw",
			description: "Бесплатный temp mail для регистраций и OTP-кодов. Создайте одноразовый почтовый ящик на 24 часа без аккаунта.",
			keywords: "временная почта, одноразовая почта, temp mail, почта 24 часа, без регистрации, otp код, smail.pw",
			heroTag: "Временный ящик",
			heroTitle: "Защитите приватность в один клик.",
			heroDescription: "Создайте временный адрес для регистраций и подтверждений, затем удалите его, когда закончите.",
			loadingAddresses: "Загрузка адресов...",
			currentAddress: "Текущий временный адрес",
			copy: "Копировать",
			copied: "Скопировано",
			deleteAddress: "Удалить адрес",
			deleting: "Удаление...",
			generateNew: "Создать новый",
			generating: "Создание...",
			noAddressTitle: "Пока нет временного адреса",
			noAddressDescription: "Создайте временный адрес для регистраций и разовых проверок.",
			generateAddress: "Создать адрес",
			stats: {
				lifetimeValue: "24ч",
				refreshValue: "Мгновенно",
				registrationValue: "Ноль",
				lifetime: "Срок",
				refresh: "Обновление",
				registration: "Регистрация"
			},
			inboxTag: "Входящие",
			inboxTitle: "Последние письма",
			tapToOpen: "Нажмите, чтобы открыть",
			loadingEmails: "Загрузка писем...",
			emptyInboxTitle: "Ваш ящик готов",
			emptyInboxDescription: "Писем пока нет. Новые сообщения появятся здесь мгновенно.",
			refreshInbox: "Обновить",
			refreshingInbox: "Обновление...",
			lastRefresh: "Последнее обновление",
			safetyHint: "Не используйте этот адрес для банковских, рабочих или важных кодов аккаунтов.",
			modal: {
				title: "Предпросмотр",
				from: "От",
				time: "Время",
				loading: "Загрузка...",
				empty: "Нет содержимого"
			}
		},
		layout: {
			siteSubtitle: "временный ящик",
			nav: {
				home: "Главная",
				about: "О сервисе",
				faq: "FAQ"
			},
			footerTag: "инструменты с фокусом на приватность",
			footerDescription: "Одноразовый ящик для подтверждений, тестов и коротких сообщений без раскрытия вашей основной почты.",
			footerLinks: {
				faq: "FAQ",
				privacy: "Конфиденциальность",
				terms: "Условия",
				about: "О smail.pw"
			},
			copyright: "Чистый ящик, чистая идентичность.",
			themeToLight: "☀ Светлая",
			themeToDark: "🌙 Тёмная"
		}
	},
	pt: {
		home: {
			title: "Email temporário grátis 24h sem cadastro para OTP | smail.pw",
			description: "Gerador de temp mail grátis para cadastro e códigos OTP. Crie uma caixa descartável de 24h instantaneamente.",
			keywords: "email temporario, email temporário, email descartavel, temp mail, 24h, sem cadastro, codigo otp, smail.pw",
			heroTag: "Caixa temporária",
			heroTitle: "Proteja sua privacidade com um clique.",
			heroDescription: "Gere um endereço temporário para cadastros e verificações e exclua quando terminar.",
			loadingAddresses: "Carregando endereços...",
			currentAddress: "Endereço temporário atual",
			copy: "Copiar",
			copied: "Copiado",
			deleteAddress: "Excluir endereço",
			deleting: "Excluindo...",
			generateNew: "Gerar novo",
			generating: "Gerando...",
			noAddressTitle: "Ainda não há e-mail temporário",
			noAddressDescription: "Gere um endereço temporário para cadastros e verificações rápidas.",
			generateAddress: "Gerar endereço",
			stats: {
				lifetimeValue: "24h",
				refreshValue: "Instantâneo",
				registrationValue: "Zero",
				lifetime: "Duração",
				refresh: "Atualização",
				registration: "Cadastro"
			},
			inboxTag: "Caixa de entrada",
			inboxTitle: "E-mails recentes",
			tapToOpen: "Toque para abrir",
			loadingEmails: "Carregando e-mails...",
			emptyInboxTitle: "Sua caixa está pronta",
			emptyInboxDescription: "Ainda não há e-mails. Eles aparecerão aqui instantaneamente.",
			refreshInbox: "Atualizar",
			refreshingInbox: "Atualizando...",
			lastRefresh: "Última atualização",
			safetyHint: "Não use este endereço para banco, trabalho ou códigos de contas importantes.",
			modal: {
				title: "Pré-visualização",
				from: "De",
				time: "Hora",
				loading: "Carregando...",
				empty: "Sem conteúdo"
			}
		},
		layout: {
			siteSubtitle: "caixa temporária",
			nav: {
				home: "Início",
				about: "Sobre",
				faq: "FAQ"
			},
			footerTag: "utilitários com foco em privacidade",
			footerDescription: "Caixa descartável para verificações, testes e comunicações curtas sem expor seu e-mail principal.",
			footerLinks: {
				faq: "FAQ",
				privacy: "Privacidade",
				terms: "Termos",
				about: "Sobre smail.pw"
			},
			copyright: "Caixa limpa, identidade limpa.",
			themeToLight: "☀ Claro",
			themeToDark: "🌙 Escuro"
		}
	},
	ar: {
		home: {
			title: "بريد مؤقت مجاني 24 ساعة بدون تسجيل لاستلام OTP | smail.pw",
			description: "مولّد بريد مؤقت مجاني (temp mail) للتسجيل السريع ورموز OTP. أنشئ صندوقًا للاستخدام مرة واحدة لمدة 24 ساعة فورًا.",
			keywords: "بريد مؤقت, بريد مؤقت مجاني, بريد للاستخدام مرة واحدة, temp mail, بريد 24 ساعة, بدون تسجيل, رمز otp, smail.pw",
			heroTag: "صندوق مؤقت",
			heroTitle: "احمِ خصوصيتك بنقرة واحدة.",
			heroDescription: "أنشئ عنوانًا مؤقتًا للتسجيلات ورسائل التحقق ثم احذفه عند الانتهاء.",
			loadingAddresses: "جارٍ تحميل العناوين...",
			currentAddress: "العنوان المؤقت الحالي",
			copy: "نسخ",
			copied: "تم النسخ",
			deleteAddress: "حذف العنوان",
			deleting: "جارٍ الحذف...",
			generateNew: "إنشاء جديد",
			generating: "جارٍ الإنشاء...",
			noAddressTitle: "لا يوجد بريد مؤقت بعد",
			noAddressDescription: "أنشئ عنوانًا مؤقتًا للتسجيل والتحقق السريع.",
			generateAddress: "إنشاء عنوان",
			stats: {
				lifetimeValue: "24س",
				refreshValue: "فوري",
				registrationValue: "صفر",
				lifetime: "مدة الصلاحية",
				refresh: "التحديث",
				registration: "التسجيل"
			},
			inboxTag: "الوارد",
			inboxTitle: "أحدث الرسائل",
			tapToOpen: "اضغط للفتح",
			loadingEmails: "جارٍ تحميل الرسائل...",
			emptyInboxTitle: "صندوقك بانتظارك",
			emptyInboxDescription: "لا توجد رسائل بعد. ستظهر هنا فور وصولها.",
			refreshInbox: "تحديث",
			refreshingInbox: "جارٍ التحديث...",
			lastRefresh: "آخر تحديث",
			safetyHint: "لا تستخدم هذا العنوان للبنوك أو العمل أو رموز الحسابات المهمة.",
			modal: {
				title: "معاينة الرسالة",
				from: "من",
				time: "الوقت",
				loading: "جارٍ التحميل...",
				empty: "لا يوجد محتوى"
			}
		},
		layout: {
			siteSubtitle: "صندوق مؤقت",
			nav: {
				home: "الرئيسية",
				about: "حول",
				faq: "الأسئلة الشائعة"
			},
			footerTag: "أدوات تركز على الخصوصية",
			footerDescription: "صندوق بريد مؤقت للتحقق والاختبار والتواصل القصير دون كشف بريدك الأساسي.",
			footerLinks: {
				faq: "الأسئلة الشائعة",
				privacy: "الخصوصية",
				terms: "الشروط",
				about: "حول smail.pw"
			},
			copyright: "صندوق نظيف، هوية أنظف.",
			themeToLight: "☀ فاتح",
			themeToDark: "🌙 داكن"
		}
	}
};
function getDictionary(locale) {
	return messages[locale];
}
//#endregion
//#region app/routes/layout.tsx
var layout_exports = /* @__PURE__ */ __exportAll({
	default: () => layout_default,
	loader: () => loader$6
});
var CONTACT_LABELS = {
	en: "Contact",
	zh: "联系",
	es: "Contacto",
	fr: "Contact",
	de: "Kontakt",
	ja: "お問い合わせ",
	ko: "문의",
	ru: "Контакты",
	pt: "Contato",
	ar: "اتصل بنا"
};
async function loader$6({ params, request }) {
	const { locale, shouldRedirectToDefault, isInvalid } = resolveLocaleParam(params.lang);
	if (isInvalid) throw new Response("Not Found", { status: 404 });
	if (shouldRedirectToDefault) {
		const url = new URL(request.url);
		throw redirect(`${stripDefaultLocalePrefix(url.pathname)}${url.search}`, 301);
	}
	return {
		locale,
		theme: parseThemeFromCookieHeader(request.headers.get("Cookie")),
		renderedYear: (/* @__PURE__ */ new Date()).getUTCFullYear()
	};
}
var layout_default = withComponentProps(function Layout({ loaderData }) {
	const [theme, setTheme] = (0, import_react.useState)(loaderData.theme);
	const [isLanguageMenuOpen, setIsLanguageMenuOpen] = (0, import_react.useState)(false);
	const [isMobileMenuOpen, setIsMobileMenuOpen] = (0, import_react.useState)(false);
	const languageMenuRef = (0, import_react.useRef)(null);
	const mobileMenuRef = (0, import_react.useRef)(null);
	const location = useLocation();
	const navigate = useNavigate();
	const locale = loaderData.locale;
	const copy = getDictionary(locale).layout;
	const localeEntries = Object.entries(LOCALE_LABELS);
	const currentLocaleLabel = LOCALE_LABELS[locale];
	const blogLabel = locale === "zh" ? "博客" : "Blog";
	const contactLabel = CONTACT_LABELS[locale] ?? CONTACT_LABELS.en;
	const mobileLanguageLabel = locale === "zh" ? "语言" : "Language";
	const mobileAppearanceLabel = locale === "zh" ? "界面" : "Appearance";
	const localizeLink = (path) => toLocalePath(path, locale);
	(0, import_react.useEffect)(() => {
		if (typeof document === "undefined") return;
		if (theme === "light") document.documentElement.dataset.theme = "light";
		else delete document.documentElement.dataset.theme;
	}, [theme]);
	(0, import_react.useEffect)(() => {
		setIsLanguageMenuOpen(false);
		setIsMobileMenuOpen(false);
	}, [
		location.pathname,
		location.search,
		location.hash
	]);
	(0, import_react.useEffect)(() => {
		if (!isLanguageMenuOpen && !isMobileMenuOpen) return;
		const handlePointerDown = (event) => {
			const target = event.target;
			if (!(target instanceof Node)) return;
			if (isLanguageMenuOpen && !languageMenuRef.current?.contains(target)) setIsLanguageMenuOpen(false);
			if (isMobileMenuOpen && !mobileMenuRef.current?.contains(target)) setIsMobileMenuOpen(false);
		};
		const handleEscape = (event) => {
			if (event.key === "Escape") {
				setIsLanguageMenuOpen(false);
				setIsMobileMenuOpen(false);
			}
		};
		window.addEventListener("pointerdown", handlePointerDown);
		window.addEventListener("keydown", handleEscape);
		return () => {
			window.removeEventListener("pointerdown", handlePointerDown);
			window.removeEventListener("keydown", handleEscape);
		};
	}, [isLanguageMenuOpen, isMobileMenuOpen]);
	const toggleTheme = () => {
		const nextTheme = theme === "dark" ? "light" : "dark";
		setTheme(nextTheme);
		document.cookie = createThemeCookie(nextTheme);
	};
	const switchLocale = (nextLocale) => {
		if (nextLocale === locale) {
			setIsLanguageMenuOpen(false);
			setIsMobileMenuOpen(false);
			return;
		}
		navigate(`${toLocalePath(location.pathname, nextLocale)}${location.search}${location.hash}`);
		setIsLanguageMenuOpen(false);
		setIsMobileMenuOpen(false);
	};
	const closeMobileMenu = () => {
		setIsMobileMenuOpen(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh px-4 py-4 sm:px-6 sm:py-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "site-frame flex min-h-[calc(100dvh-2rem)] flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: "glass-panel sticky top-2 z-40 px-4 py-3 sm:px-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 sm:gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: localizeLink("/"),
								prefetch: "viewport",
								className: "group inline-flex items-center gap-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "brand-badge relative inline-flex size-[36px]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/favicon.ico",
										alt: "smail.pw logo",
										className: "size-[20px]"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -inset-px -z-10 rounded-xl bg-blue-500/25 blur-sm transition group-hover:bg-cyan-400/35" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display block text-base font-bold tracking-tight text-theme-primary",
										children: "smail.pw"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-[10px] uppercase tracking-[0.2em] text-theme-faint",
										children: copy.siteSubtitle
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-1" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
								className: "hidden items-center gap-2 text-xs font-semibold sm:flex",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
										to: localizeLink("/"),
										end: true,
										prefetch: "viewport",
										className: ({ isActive }) => isActive ? "nav-pill-active" : "nav-pill",
										children: copy.nav.home
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
										to: localizeLink("/about"),
										prefetch: "viewport",
										className: ({ isActive }) => isActive ? "nav-pill-active" : "nav-pill",
										children: copy.nav.about
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
										to: localizeLink("/faq"),
										prefetch: "viewport",
										className: ({ isActive }) => isActive ? "nav-pill-active" : "nav-pill",
										children: copy.nav.faq
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
										to: localizeLink("/blog"),
										prefetch: "viewport",
										className: ({ isActive }) => isActive ? "nav-pill-active" : "nav-pill",
										children: blogLabel
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
										to: localizeLink("/contact"),
										prefetch: "viewport",
										className: ({ isActive }) => isActive ? "nav-pill-active" : "nav-pill",
										children: contactLabel
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mobile-menu sm:hidden",
								ref: mobileMenuRef,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "mobile-menu-trigger",
									"aria-haspopup": "menu",
									"aria-label": "Toggle navigation menu",
									"aria-expanded": isMobileMenuOpen,
									"aria-controls": "mobile-nav-panel",
									onClick: () => {
										setIsLanguageMenuOpen(false);
										setIsMobileMenuOpen((open) => !open);
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
										viewBox: "0 0 20 20",
										fill: "none",
										"aria-hidden": "true",
										className: "mobile-menu-icon",
										children: isMobileMenuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
											d: "M5 5L15 15M15 5L5 15",
											stroke: "currentColor",
											strokeWidth: "1.8",
											strokeLinecap: "round"
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
											d: "M3.5 5.75H16.5M3.5 10H16.5M3.5 14.25H16.5",
											stroke: "currentColor",
											strokeWidth: "1.8",
											strokeLinecap: "round"
										})
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									id: "mobile-nav-panel",
									className: "mobile-menu-panel",
									role: "menu",
									"aria-label": "Site navigation",
									"aria-hidden": !isMobileMenuOpen,
									"data-open": isMobileMenuOpen ? "true" : "false",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
											to: localizeLink("/"),
											end: true,
											prefetch: "viewport",
											onClick: closeMobileMenu,
											className: ({ isActive }) => isActive ? "mobile-menu-link-active" : "mobile-menu-link",
											children: copy.nav.home
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
											to: localizeLink("/about"),
											prefetch: "viewport",
											onClick: closeMobileMenu,
											className: ({ isActive }) => isActive ? "mobile-menu-link-active" : "mobile-menu-link",
											children: copy.nav.about
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
											to: localizeLink("/faq"),
											prefetch: "viewport",
											onClick: closeMobileMenu,
											className: ({ isActive }) => isActive ? "mobile-menu-link-active" : "mobile-menu-link",
											children: copy.nav.faq
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
											to: localizeLink("/blog"),
											prefetch: "viewport",
											onClick: closeMobileMenu,
											className: ({ isActive }) => isActive ? "mobile-menu-link-active" : "mobile-menu-link",
											children: blogLabel
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
											to: localizeLink("/contact"),
											prefetch: "viewport",
											onClick: closeMobileMenu,
											className: ({ isActive }) => isActive ? "mobile-menu-link-active" : "mobile-menu-link",
											children: contactLabel
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mobile-menu-section",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mobile-menu-section-label",
												children: mobileAppearanceLabel
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "mobile-menu-link",
												onClick: () => {
													toggleTheme();
													closeMobileMenu();
												},
												children: theme === "dark" ? copy.themeToLight : copy.themeToDark
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mobile-menu-section",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mobile-menu-section-label",
												children: mobileLanguageLabel
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mobile-menu-locale-grid",
												children: localeEntries.map(([localeCode, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													className: "mobile-locale-chip",
													title: label,
													"aria-label": label,
													"data-active": localeCode === locale,
													onClick: () => switchLocale(localeCode),
													children: localeCode
												}, `mobile-${localeCode}`))
											})]
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "language-menu hidden sm:block",
								ref: languageMenuRef,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "language-menu-trigger",
									"aria-haspopup": "menu",
									"aria-expanded": isLanguageMenuOpen,
									onClick: () => {
										setIsMobileMenuOpen(false);
										setIsLanguageMenuOpen((open) => !open);
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "language-menu-icon",
											"aria-hidden": "true",
											children: "🌐"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "language-menu-label",
											children: currentLocaleLabel
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "language-menu-caret",
											"aria-hidden": "true",
											"data-open": isLanguageMenuOpen,
											children: "▾"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "language-menu-panel",
									role: "menu",
									"aria-label": "Select language",
									"aria-hidden": !isLanguageMenuOpen,
									"data-open": isLanguageMenuOpen ? "true" : "false",
									children: localeEntries.map(([localeCode, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										role: "menuitemradio",
										"aria-checked": localeCode === locale,
										className: "language-menu-option",
										"data-active": localeCode === locale,
										onClick: () => switchLocale(localeCode),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "language-menu-check",
												"aria-hidden": "true",
												children: localeCode === locale ? "✓" : ""
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "language-menu-option-label",
												children: label
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "language-menu-option-code",
												children: localeCode
											})
										]
									}, localeCode))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "theme-toggle hidden sm:inline-flex",
								onClick: toggleTheme,
								children: theme === "dark" ? copy.themeToLight : copy.themeToDark
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex flex-1 flex-col",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "glass-panel mt-auto px-4 py-5 sm:px-6 sm:py-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-6 sm:flex-row sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-sm space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "soft-tag",
								children: copy.footerTag
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-relaxed text-theme-secondary",
								children: copy.footerDescription
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-x-10 gap-y-2 text-xs font-medium",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
									to: localizeLink("/faq"),
									prefetch: "viewport",
									className: "footer-link",
									children: copy.footerLinks.faq
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
									to: localizeLink("/privacy"),
									prefetch: "viewport",
									className: "footer-link",
									children: copy.footerLinks.privacy
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
									to: localizeLink("/terms"),
									prefetch: "viewport",
									className: "footer-link",
									children: copy.footerLinks.terms
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: localizeLink("/about"),
									prefetch: "viewport",
									className: "footer-link",
									children: copy.footerLinks.about
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: localizeLink("/blog"),
									prefetch: "viewport",
									className: "footer-link",
									children: blogLabel
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: localizeLink("/contact"),
									prefetch: "viewport",
									className: "footer-link",
									children: contactLabel
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "https://smail.now/",
									target: "_blank",
									rel: "noopener noreferrer",
									className: "footer-link",
									children: "smail.now"
								})
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 border-t border-theme-soft pt-4 text-[11px] text-theme-faint",
						children: [
							"© ",
							loaderData.renderedYear,
							" smail.pw · ",
							copy.copyright
						]
					})]
				})
			]
		})
	});
});
var MAIL_RETENTION_MS = 1440 * 60 * 1e3;
//#endregion
//#region app/.server/session.ts
var sessionStorage = null;
function getSessionSecrets(env) {
	const rotatedSecrets = (env.SESSION_SECRETS ?? "").split(",").map((secret) => secret.trim()).filter(Boolean);
	if (rotatedSecrets && rotatedSecrets.length > 0) return rotatedSecrets;
	throw new Error("Missing session cookie secret. Set SESSION_SECRETS or SESSION_SECRET before starting the app.");
}
async function getSessionStorage() {
	if (!sessionStorage) {
		const { env } = await import("cloudflare:workers");
		sessionStorage = createCookieSessionStorage({ cookie: {
			name: "__session",
			httpOnly: true,
			maxAge: 1440 * 60,
			path: "/",
			sameSite: "lax",
			secrets: getSessionSecrets(env),
			secure: true
		} });
	}
	return sessionStorage;
}
async function getSession(...args) {
	return (await getSessionStorage()).getSession(...args);
}
async function commitSession(...args) {
	return (await getSessionStorage()).commitSession(...args);
}
//#endregion
//#region node_modules/.pnpm/@scaleway+random-name@5.1.4/node_modules/@scaleway/random-name/dist/index.js
var ADJECTIVES = [
	"admiring",
	"adoring",
	"affectionate",
	"agitated",
	"amazing",
	"angry",
	"awesome",
	"beautiful",
	"blissful",
	"bold",
	"boring",
	"brave",
	"busy",
	"charming",
	"clever",
	"cool",
	"compassionate",
	"competent",
	"condescending",
	"confident",
	"cranky",
	"crazy",
	"dazzling",
	"determined",
	"distracted",
	"dreamy",
	"eager",
	"ecstatic",
	"elastic",
	"elated",
	"elegant",
	"eloquent",
	"epic",
	"exciting",
	"fervent",
	"festive",
	"flamboyant",
	"focused",
	"friendly",
	"frosty",
	"funny",
	"gallant",
	"gifted",
	"goofy",
	"gracious",
	"great",
	"happy",
	"hardcore",
	"heuristic",
	"hopeful",
	"hungry",
	"infallible",
	"inspiring",
	"interesting",
	"intelligent",
	"jolly",
	"jovial",
	"keen",
	"kind",
	"laughing",
	"loving",
	"lucid",
	"magical",
	"mystifying",
	"modest",
	"musing",
	"naughty",
	"nervous",
	"nice",
	"nifty",
	"nostalgic",
	"objective",
	"optimistic",
	"peaceful",
	"pedantic",
	"pensive",
	"practical",
	"priceless",
	"quirky",
	"quizzical",
	"recursing",
	"relaxed",
	"reverent",
	"romantic",
	"sad",
	"serene",
	"sharp",
	"silly",
	"sleepy",
	"stoic",
	"strange",
	"stupefied",
	"suspicious",
	"sweet",
	"tender",
	"thirsty",
	"trusting",
	"unruffled",
	"upbeat",
	"vibrant",
	"vigilant",
	"vigorous",
	"wizardly",
	"wonderful",
	"xenodochial",
	"youthful",
	"zealous",
	"zen"
];
var NAMES = [
	"albattani",
	"allen",
	"almeida",
	"antonelli",
	"agnesi",
	"archimedes",
	"ardinghelli",
	"aryabhata",
	"austin",
	"babbage",
	"banach",
	"banzai",
	"bardeen",
	"bartik",
	"bassi",
	"beaver",
	"bell",
	"benz",
	"bhabha",
	"bhaskara",
	"black",
	"blackburn",
	"blackwell",
	"bohr",
	"booth",
	"borg",
	"bose",
	"bouman",
	"boyd",
	"brahmagupta",
	"brattain",
	"brown",
	"buck",
	"burnell",
	"cannon",
	"carson",
	"cartwright",
	"carver",
	"cerf",
	"chandrasekhar",
	"chaplygin",
	"chatelet",
	"chatterjee",
	"chebyshev",
	"cohen",
	"chaum",
	"clarke",
	"colden",
	"cori",
	"cray",
	"curran",
	"curie",
	"darwin",
	"davinci",
	"dewdney",
	"dhawan",
	"diffie",
	"dijkstra",
	"dirac",
	"driscoll",
	"dubinsky",
	"easley",
	"edison",
	"einstein",
	"elbakyan",
	"elgamal",
	"elion",
	"ellis",
	"engelbart",
	"euclid",
	"euler",
	"faraday",
	"feistel",
	"fermat",
	"fermi",
	"feynman",
	"franklin",
	"gagarin",
	"galileo",
	"galois",
	"ganguly",
	"gates",
	"gauss",
	"germain",
	"goldberg",
	"goldstine",
	"goldwasser",
	"golick",
	"goodall",
	"gould",
	"greider",
	"grothendieck",
	"haibt",
	"hamilton",
	"haslett",
	"hawking",
	"hellman",
	"heisenberg",
	"hermann",
	"herschel",
	"hertz",
	"heyrovsky",
	"hodgkin",
	"hofstadter",
	"hoover",
	"hopper",
	"hugle",
	"hypatia",
	"ishizaka",
	"jackson",
	"jang",
	"jemison",
	"jennings",
	"jepsen",
	"johnson",
	"joliot",
	"jones",
	"kalam",
	"kapitsa",
	"kare",
	"keldysh",
	"keller",
	"kepler",
	"khayyam",
	"khorana",
	"kilby",
	"kirch",
	"knuth",
	"kowalevski",
	"lalande",
	"lamarr",
	"lamport",
	"leakey",
	"leavitt",
	"lederberg",
	"lehmann",
	"lewin",
	"lichterman",
	"liskov",
	"lovelace",
	"lumiere",
	"mahavira",
	"margulis",
	"matsumoto",
	"maxwell",
	"mayer",
	"mccarthy",
	"mcclintock",
	"mclaren",
	"mclean",
	"mcnulty",
	"mendel",
	"mendeleev",
	"meitner",
	"meninsky",
	"merkle",
	"mestorf",
	"mirzakhani",
	"montalcini",
	"moore",
	"morse",
	"murdock",
	"moser",
	"napier",
	"nash",
	"neumann",
	"newton",
	"nightingale",
	"nobel",
	"noether",
	"northcutt",
	"noyce",
	"panini",
	"pare",
	"pascal",
	"pasteur",
	"payne",
	"perlman",
	"pike",
	"poincare",
	"poitras",
	"proskuriakova",
	"ptolemy",
	"raman",
	"ramanujan",
	"ride",
	"ritchie",
	"rhodes",
	"robinson",
	"roentgen",
	"rosalind",
	"rubin",
	"saha",
	"sammet",
	"sanderson",
	"satoshi",
	"shamir",
	"shannon",
	"shaw",
	"shirley",
	"shockley",
	"shtern",
	"sinoussi",
	"snyder",
	"solomon",
	"spence",
	"stonebraker",
	"sutherland",
	"swanson",
	"swartz",
	"swirles",
	"taussig",
	"tereshkova",
	"tesla",
	"tharp",
	"thompson",
	"torvalds",
	"tu",
	"turing",
	"varahamihira",
	"vaughan",
	"visvesvaraya",
	"volhard",
	"villani",
	"wescoff",
	"wilbur",
	"wiles",
	"williams",
	"williamson",
	"wilson",
	"wing",
	"wozniak",
	"wright",
	"wu",
	"yalow",
	"yonath",
	"zhukovsky"
];
var randomName = (prefix = "", separator = "-") => {
	const name = `${ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)] ?? ""}${separator}${NAMES[Math.floor(Math.random() * NAMES.length)] ?? ""}`;
	if (name === `boring${separator}wozniak`) return randomName(prefix, separator);
	return prefix.length > 0 ? `${prefix}${separator}${name}` : name;
};
//#endregion
//#region app/utils/mail.ts
var nanoSuffix = customAlphabet("abcdefghijklmnopqrstuvwxyz0123456789", 6);
function generateEmailAddress() {
	return `${randomName()}-${nanoSuffix()}@smail.pw`;
}
//#endregion
//#region app/utils/meta.ts
function isString(value) {
	return typeof value === "string";
}
function getMetaDescriptorKey(metaDescriptor) {
	if ("title" in metaDescriptor) return "title";
	if ("charSet" in metaDescriptor || "charset" in metaDescriptor) return "charSet";
	if ("name" in metaDescriptor && isString(metaDescriptor.name)) return `name:${metaDescriptor.name}`;
	if ("property" in metaDescriptor && isString(metaDescriptor.property)) return `property:${metaDescriptor.property}`;
	if ("httpEquiv" in metaDescriptor && isString(metaDescriptor.httpEquiv)) return `http-equiv:${metaDescriptor.httpEquiv}`;
	if ("script:ld+json" in metaDescriptor) return "script:ld+json";
	if ("tagName" in metaDescriptor && metaDescriptor.tagName === "link") {
		const rel = isString(metaDescriptor.rel) ? metaDescriptor.rel : "";
		if (rel === "canonical") return "link:canonical";
		const hrefLang = isString(metaDescriptor.hrefLang) ? metaDescriptor.hrefLang : "";
		if (rel === "alternate" && hrefLang) return `link:alternate:${hrefLang}`;
		const type = isString(metaDescriptor.type) ? metaDescriptor.type : "";
		if (rel === "alternate" && type === "application/rss+xml") return "link:alternate:rss";
		return `link:${rel}:${isString(metaDescriptor.href) ? metaDescriptor.href : ""}`;
	}
	return `raw:${JSON.stringify(metaDescriptor)}`;
}
function mergeRouteMeta(matches, routeMeta) {
	const parentMeta = (matches ?? []).flatMap((match) => match?.meta ?? []);
	const mergedByKey = /* @__PURE__ */ new Map();
	for (const metaDescriptor of [...parentMeta, ...routeMeta]) mergedByKey.set(getMetaDescriptorKey(metaDescriptor), metaDescriptor);
	return [...mergedByKey.values()];
}
//#endregion
//#region app/routes/home.tsx
var home_exports = /* @__PURE__ */ __exportAll({
	action: () => action,
	default: () => home_default,
	loader: () => loader$5,
	meta: () => meta$5
});
function getLocaleFromParams$3(lang) {
	const { locale } = resolveLocaleParam(lang);
	return locale;
}
function formatRefreshTime(timestamp, locale) {
	return new Date(timestamp).toLocaleTimeString(toIntlLocale(locale), {
		hour: "2-digit",
		minute: "2-digit",
		timeZone: "UTC"
	});
}
var SEO_GUIDES_COPY = {
	en: {
		title: "Popular temporary email guides",
		items: [
			{
				label: "24 Hour Temporary Email",
				path: "/temporary-email-24-hours"
			},
			{
				label: "Temporary Email No Registration",
				path: "/temporary-email-no-registration"
			},
			{
				label: "Disposable Email for Verification",
				path: "/disposable-email-for-verification"
			},
			{
				label: "Temporary Email for Registration",
				path: "/temporary-email-for-registration"
			},
			{
				label: "Online Temporary Email",
				path: "/online-temporary-email"
			}
		]
	},
	zh: {
		title: "热门临时邮箱指南",
		items: [
			{
				label: "24 小时临时邮箱",
				path: "/temporary-email-24-hours"
			},
			{
				label: "免注册临时邮箱",
				path: "/temporary-email-no-registration"
			},
			{
				label: "验证码一次性邮箱",
				path: "/disposable-email-for-verification"
			},
			{
				label: "临时邮箱注册指南",
				path: "/temporary-email-for-registration"
			},
			{
				label: "在线临时邮箱",
				path: "/online-temporary-email"
			}
		]
	},
	es: {
		title: "Guías populares de correo temporal",
		items: [
			{
				label: "Correo temporal 24 horas",
				path: "/temporary-email-24-hours"
			},
			{
				label: "Correo temporal sin registro",
				path: "/temporary-email-no-registration"
			},
			{
				label: "Correo desechable para verificación",
				path: "/disposable-email-for-verification"
			},
			{
				label: "Correo temporal para registro",
				path: "/temporary-email-for-registration"
			},
			{
				label: "Correo temporal online",
				path: "/online-temporary-email"
			}
		]
	},
	fr: {
		title: "Guides populaires d'email temporaire",
		items: [
			{
				label: "Email temporaire 24 heures",
				path: "/temporary-email-24-hours"
			},
			{
				label: "Email temporaire sans inscription",
				path: "/temporary-email-no-registration"
			},
			{
				label: "Email jetable pour vérification",
				path: "/disposable-email-for-verification"
			},
			{
				label: "Email temporaire pour inscription",
				path: "/temporary-email-for-registration"
			},
			{
				label: "Email temporaire en ligne",
				path: "/online-temporary-email"
			}
		]
	},
	de: {
		title: "Beliebte Temp-Mail-Anleitungen",
		items: [
			{
				label: "24-Stunden-Temporäre E-Mail",
				path: "/temporary-email-24-hours"
			},
			{
				label: "Temporäre E-Mail ohne Registrierung",
				path: "/temporary-email-no-registration"
			},
			{
				label: "Wegwerf-E-Mail für Verifizierung",
				path: "/disposable-email-for-verification"
			},
			{
				label: "Temporäre E-Mail für Registrierung",
				path: "/temporary-email-for-registration"
			},
			{
				label: "Online-Temporäre E-Mail",
				path: "/online-temporary-email"
			}
		]
	},
	ja: {
		title: "人気の一時メールガイド",
		items: [
			{
				label: "24時間一時メール",
				path: "/temporary-email-24-hours"
			},
			{
				label: "登録不要の一時メール",
				path: "/temporary-email-no-registration"
			},
			{
				label: "認証用使い捨てメール",
				path: "/disposable-email-for-verification"
			},
			{
				label: "登録向け一時メール",
				path: "/temporary-email-for-registration"
			},
			{
				label: "オンライン一時メール",
				path: "/online-temporary-email"
			}
		]
	},
	ko: {
		title: "인기 임시 이메일 가이드",
		items: [
			{
				label: "24시간 임시 이메일",
				path: "/temporary-email-24-hours"
			},
			{
				label: "가입 없는 임시 이메일",
				path: "/temporary-email-no-registration"
			},
			{
				label: "인증용 일회용 이메일",
				path: "/disposable-email-for-verification"
			},
			{
				label: "가입용 임시 이메일",
				path: "/temporary-email-for-registration"
			},
			{
				label: "온라인 임시 이메일",
				path: "/online-temporary-email"
			}
		]
	},
	ru: {
		title: "Популярные гайды по временной почте",
		items: [
			{
				label: "Временная почта на 24 часа",
				path: "/temporary-email-24-hours"
			},
			{
				label: "Временная почта без регистрации",
				path: "/temporary-email-no-registration"
			},
			{
				label: "Одноразовая почта для верификации",
				path: "/disposable-email-for-verification"
			},
			{
				label: "Временная почта для регистрации",
				path: "/temporary-email-for-registration"
			},
			{
				label: "Онлайн временная почта",
				path: "/online-temporary-email"
			}
		]
	},
	pt: {
		title: "Guias populares de email temporário",
		items: [
			{
				label: "Email temporário 24 horas",
				path: "/temporary-email-24-hours"
			},
			{
				label: "Email temporário sem cadastro",
				path: "/temporary-email-no-registration"
			},
			{
				label: "Email descartável para verificação",
				path: "/disposable-email-for-verification"
			},
			{
				label: "Email temporário para cadastro",
				path: "/temporary-email-for-registration"
			},
			{
				label: "Email temporário online",
				path: "/online-temporary-email"
			}
		]
	},
	ar: {
		title: "أدلة البريد المؤقت الشائعة",
		items: [
			{
				label: "بريد مؤقت لمدة 24 ساعة",
				path: "/temporary-email-24-hours"
			},
			{
				label: "بريد مؤقت بدون تسجيل",
				path: "/temporary-email-no-registration"
			},
			{
				label: "بريد مؤقت لرموز التحقق",
				path: "/disposable-email-for-verification"
			},
			{
				label: "بريد مؤقت للتسجيل",
				path: "/temporary-email-for-registration"
			},
			{
				label: "بريد مؤقت أونلاين",
				path: "/online-temporary-email"
			}
		]
	}
};
function getSeoGuides(locale) {
	return SEO_GUIDES_COPY[locale] ?? SEO_GUIDES_COPY.en;
}
var SEO_NARRATIVE_COPY = {
	en: {
		title: "Why use smail.pw temporary email",
		description: "smail.pw is a free temporary email generator (temp mail) for low-risk sign-ups, OTP verification, and one-time downloads. Create a 24-hour disposable inbox in seconds.",
		points: [
			"Works well for temporary email registration and verification code workflows",
			"No sign-up or password setup for quick temp mail access",
			"Useful when users search smail temp mail or no-registration disposable inbox",
			"Use a permanent mailbox for banking, work, and identity-critical accounts"
		]
	},
	zh: {
		title: "为什么选择 smail.pw 临时邮箱",
		description: "smail.pw 是免费临时邮箱生成器，覆盖临时邮箱、一次性邮箱、24小时邮箱等常见场景。适合临时邮箱注册、验证码（OTP）接收和在线临时收信。",
		points: [
			"适合临时邮箱注册、活动领取、下载验证等低风险场景",
			"免注册、免密码，作为免费临时邮箱快速使用，减少真实邮箱暴露",
			"部分站点会限制临时邮箱域名，收不到信可尝试重发与刷新",
			"银行、工作和重要账号请务必使用长期邮箱"
		]
	},
	es: {
		title: "Por qué usar el correo temporal de smail.pw",
		description: "smail.pw ofrece correo temporal gratis (temp mail) para registros rápidos, verificación OTP y descargas puntuales con retención de 24 horas.",
		points: [
			"Útil para flujos de registro y verificación de bajo riesgo",
			"Sin cuenta ni contraseña para empezar de inmediato",
			"Si no llega el correo, prueba reenviar y actualizar la bandeja"
		]
	},
	fr: {
		title: "Pourquoi utiliser l'email temporaire smail.pw",
		description: "smail.pw fournit un email temporaire gratuit (temp mail) pour inscription rapide, OTP et usages ponctuels avec rétention de 24h.",
		points: [
			"Adapté aux inscriptions et vérifications à faible risque",
			"Aucun compte ni mot de passe requis pour commencer",
			"En cas de non-réception, renvoyez le code puis rafraîchissez la boîte"
		]
	},
	de: {
		title: "Warum temporäre E-Mail von smail.pw",
		description: "smail.pw bietet kostenlose Temp Mail für schnelle Registrierungen, OTP-Verifizierung und einmalige Nutzung mit 24h Aufbewahrung.",
		points: [
			"Ideal für risikoarme Registrierung und Verifizierung",
			"Kein Konto und kein Passwort für den Sofortstart",
			"Bei fehlender Zustellung: erneut senden und Posteingang aktualisieren"
		]
	},
	ja: {
		title: "smail.pw の一時メールを使う理由",
		description: "smail.pw は無料の一時メール（temp mail）です。登録・OTP認証・短期利用向けに24時間の受信箱をすぐ作成できます。",
		points: [
			"低リスクの登録と認証フローに最適",
			"アカウント登録やパスワード設定が不要",
			"届かない場合は再送と受信箱更新を試してください"
		]
	},
	ko: {
		title: "smail.pw 임시 이메일을 쓰는 이유",
		description: "smail.pw는 무료 임시 이메일(temp mail) 서비스로, 가입/OTP 인증/일회성 사용에 맞춘 24시간 메일함을 즉시 제공합니다.",
		points: [
			"저위험 가입 및 인증 흐름에 적합",
			"계정 생성과 비밀번호 없이 바로 사용",
			"메일이 안 오면 재전송 후 받은편지함을 새로고침"
		]
	},
	ru: {
		title: "Почему стоит использовать временную почту smail.pw",
		description: "smail.pw — бесплатный temp mail для быстрых регистраций, OTP-подтверждений и одноразовых задач с хранением до 24 часов.",
		points: [
			"Подходит для низкорисковых регистраций и подтверждений",
			"Без аккаунта и пароля — можно начать сразу",
			"Если письмо не пришло, попробуйте повторную отправку и обновление"
		]
	},
	pt: {
		title: "Por que usar o email temporário do smail.pw",
		description: "smail.pw oferece temp mail grátis para cadastro rápido, OTP e uso pontual, com caixa descartável por 24 horas.",
		points: [
			"Bom para cadastro e verificação de baixo risco",
			"Sem conta e sem senha para começar imediatamente",
			"Se o email atrasar, reenvie e atualize a caixa de entrada"
		]
	},
	ar: {
		title: "لماذا تستخدم البريد المؤقت من smail.pw",
		description: "يوفر smail.pw بريدًا مؤقتًا مجانيًا (temp mail) للتسجيل السريع ورموز OTP والاستخدام القصير مع احتفاظ لمدة 24 ساعة.",
		points: [
			"مناسب لعمليات التسجيل والتحقق منخفضة المخاطر",
			"بدون حساب أو كلمة مرور لبدء الاستخدام فورًا",
			"عند تأخر الرسالة جرّب إعادة الإرسال ثم تحديث الوارد"
		]
	}
};
function getSeoNarrative(locale) {
	return SEO_NARRATIVE_COPY[locale] ?? SEO_NARRATIVE_COPY.en;
}
function getHomeJsonLd(locale) {
	const localizedHomeUrl = `${BASE_URL}${toLocalePath("/", locale)}`;
	const descriptionByLocale = {
		en: "smail.pw provides free temporary email (temp mail) inboxes for sign-up and OTP verification with 24-hour auto cleanup.",
		zh: "smail.pw 提供免费临时邮箱（一次性邮箱）服务，适合临时邮箱注册和验证码接收，邮件 24 小时后自动清理。",
		es: "smail.pw ofrece correo temporal gratis (temp mail) para registros y códigos OTP con limpieza automática en 24 horas.",
		fr: "smail.pw propose un email temporaire gratuit (temp mail) pour inscription et OTP avec suppression automatique après 24h.",
		de: "smail.pw bietet kostenlose temporäre E-Mail (Temp Mail) für Registrierung und OTP mit automatischer 24h-Bereinigung.",
		ja: "smail.pw は登録とOTP認証に使える無料の一時メール（temp mail）を提供し、24時間後に自動削除されます。",
		ko: "smail.pw는 가입과 OTP 인증에 쓰는 무료 임시 이메일(temp mail)을 제공하며 24시간 후 자동 정리됩니다.",
		ru: "smail.pw предоставляет бесплатную временную почту (temp mail) для регистрации и OTP с автоочисткой через 24 часа.",
		pt: "smail.pw oferece email temporário grátis (temp mail) para cadastro e OTP com limpeza automática após 24h.",
		ar: "يوفر smail.pw بريدًا مؤقتًا مجانيًا (temp mail) للتسجيل ورموز OTP مع حذف تلقائي بعد 24 ساعة."
	};
	const description = descriptionByLocale[locale] ?? descriptionByLocale.en;
	return {
		"@context": "https://schema.org",
		"@graph": [{
			"@type": "WebSite",
			name: "smail.pw",
			url: localizedHomeUrl,
			inLanguage: locale,
			description,
			potentialAction: {
				"@type": "UseAction",
				target: localizedHomeUrl
			}
		}, {
			"@type": "WebApplication",
			name: "smail.pw Temporary Email",
			url: localizedHomeUrl,
			applicationCategory: "UtilitiesApplication",
			operatingSystem: "Web",
			inLanguage: locale,
			description,
			offers: {
				"@type": "Offer",
				price: "0",
				priceCurrency: "USD"
			}
		}]
	};
}
function meta$5({ params, matches }) {
	const copy = getDictionary(getLocaleFromParams$3(params.lang)).home;
	return mergeRouteMeta(matches, [
		{ title: copy.title },
		{
			name: "description",
			content: copy.description
		},
		{
			name: "keywords",
			content: copy.keywords
		},
		{
			name: "robots",
			content: "index, follow"
		}
	]);
}
function isAddressExpired(addressIssuedAt, now = Date.now()) {
	if (!addressIssuedAt) return false;
	return now - addressIssuedAt >= MAIL_RETENTION_MS;
}
function EmailModal({ email, onClose, copy }) {
	const [detail, setDetail] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		setLoading(true);
		fetch(`/api/email/${email.id}`, { credentials: "include" }).then((res) => res.json()).then((emailDetail) => {
			setDetail(emailDetail);
			setLoading(false);
		}).catch(() => setLoading(false));
	}, [email.id]);
	(0, import_react.useEffect)(() => {
		const handleKeyDown = (e) => {
			if (e.key === "Escape") onClose();
		};
		document.addEventListener("keydown", handleKeyDown);
		return () => document.removeEventListener("keydown", handleKeyDown);
	}, [onClose]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "modal-backdrop fixed inset-0 z-50 flex items-center justify-center px-4 backdrop-blur-sm",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "email-preview-title",
			className: "glass-panel modal-sheet flex max-h-[90vh] w-full max-w-3xl flex-col overflow-hidden",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-theme-soft flex items-start justify-between gap-3 border-b px-4 py-4 sm:px-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-theme-faint text-[11px] font-semibold uppercase tracking-[0.16em]",
							children: copy.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							id: "email-preview-title",
							className: "text-theme-primary font-display max-w-xl truncate pr-2 text-base font-semibold sm:text-[1.05rem]",
							children: email.subject
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Close email preview",
						onClick: onClose,
						className: "border-theme-strong text-theme-secondary bg-theme-soft inline-flex h-8 w-8 items-center justify-center rounded-full border hover:brightness-95",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
							viewBox: "0 0 20 20",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "1.8",
							className: "h-4 w-4",
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								d: "M5 5L15 15M15 5L5 15",
								strokeLinecap: "round"
							})
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-theme-soft text-theme-secondary grid gap-2.5 border-b px-4 py-3 text-[12px] leading-relaxed sm:grid-cols-2 sm:px-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-theme-soft bg-theme-subtle min-w-0 rounded-lg border px-3 py-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-theme-faint block text-[11px] font-semibold uppercase tracking-[0.1em]",
							children: copy.from
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 break-all",
							children: [
								email.from_name,
								" <",
								email.from_address,
								">"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-theme-soft bg-theme-subtle rounded-lg border px-3 py-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-theme-faint block text-[11px] font-semibold uppercase tracking-[0.1em]",
							children: copy.time
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1",
							children: new Date(email.time).toLocaleString()
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-4 sm:p-5",
					children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-theme-muted flex h-[min(62vh,700px)] items-center justify-center rounded-xl border border-dashed border-theme-soft text-[13px]",
						children: copy.loading
					}) : detail?.body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
						srcDoc: detail.body,
						title: "Email content",
						className: "border-theme-soft h-[min(62vh,700px)] w-full overflow-hidden rounded-xl border bg-white",
						sandbox: "",
						referrerPolicy: "no-referrer"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-theme-muted flex h-[min(62vh,700px)] items-center justify-center rounded-xl border border-dashed border-theme-soft text-[13px]",
						children: copy.empty
					})
				})
			]
		})
	});
}
function formatTime(timestamp, locale, referenceNow) {
	const intlLocale = toIntlLocale(locale);
	const relative = new Intl.RelativeTimeFormat(intlLocale, { numeric: "auto" });
	const diffSeconds = Math.round((timestamp - referenceNow) / 1e3);
	if (Math.abs(diffSeconds) < 60) return relative.format(diffSeconds, "second");
	const diffMinutes = Math.round(diffSeconds / 60);
	if (Math.abs(diffMinutes) < 60) return relative.format(diffMinutes, "minute");
	const diffHours = Math.round(diffMinutes / 60);
	if (Math.abs(diffHours) < 24) return relative.format(diffHours, "hour");
	const diffDays = Math.round(diffHours / 24);
	if (Math.abs(diffDays) < 7) return relative.format(diffDays, "day");
	return new Date(timestamp).toLocaleDateString(intlLocale, { timeZone: "UTC" });
}
async function getEmails(d1, toAddress) {
	const { results } = await d1.prepare("SELECT * FROM emails WHERE to_address = ? ORDER BY time DESC LIMIT 100").bind(toAddress).all();
	return results;
}
async function loader$5({ request, context, params }) {
	const { locale, shouldRedirectToDefault, isInvalid } = resolveLocaleParam(params.lang);
	if (isInvalid) throw new Response("Not Found", { status: 404 });
	if (shouldRedirectToDefault) {
		const url = new URL(request.url);
		throw redirect(`${stripDefaultLocalePrefix(url.pathname)}${url.search}`, 301);
	}
	const session = await getSession(request.headers.get("Cookie"));
	let addresses = session.get("addresses") || [];
	const addressIssuedAt = session.get("addressIssuedAt");
	const now = Date.now();
	let shouldCommitSession = false;
	if (addresses.length > 0 && isAddressExpired(addressIssuedAt, now)) {
		addresses = [generateEmailAddress()];
		session.set("addresses", addresses);
		session.set("addressIssuedAt", now);
		shouldCommitSession = true;
	} else if (addresses.length > 0 && !addressIssuedAt) {
		session.set("addressIssuedAt", now);
		shouldCommitSession = true;
	}
	const emails = addresses.length > 0 ? await getEmails(context.cloudflare.env.D1, addresses[0]) : [];
	if (shouldCommitSession) {
		const headers = new Headers();
		headers.set("Set-Cookie", await commitSession(session));
		return data({
			addresses,
			emails,
			locale,
			renderedAt: now
		}, { headers });
	}
	return {
		addresses,
		emails,
		locale,
		renderedAt: now
	};
}
async function action({ request }) {
	const intent = (await request.formData()).get("intent");
	const session = await getSession(request.headers.get("Cookie"));
	let addresses = session.get("addresses") || [];
	switch (intent) {
		case "generate":
			addresses = [generateEmailAddress()];
			session.set("addressIssuedAt", Date.now());
			break;
		case "delete":
			addresses = [];
			session.unset("addressIssuedAt");
			break;
	}
	session.set("addresses", addresses);
	const cookie = await commitSession(session);
	const headers = new Headers();
	headers.set("Set-Cookie", cookie);
	return data({ addresses: session.get("addresses") || [] }, { headers });
}
var home_default = withComponentProps(function Home({ loaderData, actionData }) {
	const fetcher = useFetcher();
	const revalidator = useRevalidator();
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [selectedEmail, setSelectedEmail] = (0, import_react.useState)(null);
	const [lastInboxRefreshAt, setLastInboxRefreshAt] = (0, import_react.useState)(() => loaderData.renderedAt);
	const locale = loaderData.locale || "en";
	const copy = getDictionary(locale).home;
	const seoGuides = getSeoGuides(locale);
	const seoNarrative = getSeoNarrative(locale);
	const homeJsonLd = getHomeJsonLd(locale);
	const addresses = fetcher.data?.addresses || loaderData.addresses;
	const emails = loaderData.emails;
	const isSubmitting = fetcher.state === "submitting";
	const submittingIntent = fetcher.formData?.get("intent");
	const isRefreshingInbox = revalidator.state !== "idle";
	(0, import_react.useEffect)(() => {
		setLastInboxRefreshAt(loaderData.renderedAt);
	}, [loaderData.renderedAt]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 py-3 sm:py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
				type: "application/ld+json",
				dangerouslySetInnerHTML: { __html: JSON.stringify(homeJsonLd) }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid w-full gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "glass-panel relative overflow-hidden px-4 py-4 sm:px-6 sm:py-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute -left-20 -top-24 h-44 w-44 rounded-full opacity-80 blur-[88px]",
								style: { background: "var(--accent-a)" }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute -right-14 top-20 h-36 w-36 rounded-full opacity-75 blur-[82px]",
								style: { background: "var(--accent-b)" }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
									className: "space-y-2.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "soft-tag",
											children: copy.heroTag
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "text-theme-primary font-display max-w-2xl text-xl leading-tight font-bold sm:text-3xl",
											children: copy.heroTitle
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-theme-secondary max-w-xl text-sm leading-relaxed",
											children: copy.heroDescription
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "theme-badge flex flex-wrap items-center gap-x-3 gap-y-1 px-3 py-1.5 text-[10px] sm:text-[11px]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-theme-faint",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-theme-primary font-display font-semibold",
													children: copy.stats.lifetimeValue
												}),
												" ",
												copy.stats.lifetime
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-theme-faint",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-theme-primary font-display font-semibold",
													children: copy.stats.refreshValue
												}),
												" ",
												copy.stats.refresh
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-theme-faint",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-theme-primary font-display font-semibold",
													children: copy.stats.registrationValue
												}),
												" ",
												copy.stats.registration
											]
										})
									]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "glass-panel px-4 py-4 sm:px-5 sm:py-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3 space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-theme-faint text-[11px] font-semibold uppercase tracking-[0.16em]",
									children: copy.currentAddress
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-theme-muted hidden text-xs sm:block",
									children: copy.noAddressDescription
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-4",
								children: addresses.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "theme-card p-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "border-theme-soft bg-theme-subtle flex flex-col gap-2 rounded-xl border px-3 py-2.5 sm:flex-row sm:items-center sm:justify-between sm:gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-theme-primary min-w-0 text-sm font-semibold break-all sm:truncate",
												children: addresses[0]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "neo-button-secondary w-full sm:w-auto sm:min-w-20",
												onClick: async () => {
													if (typeof navigator !== "undefined" && navigator.clipboard) try {
														await navigator.clipboard.writeText(addresses[0] ?? "");
														setCopied(true);
														setTimeout(() => setCopied(false), 1500);
													} catch {}
												},
												children: copied ? copy.copied : copy.copy
											})]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col gap-2 sm:flex-row sm:flex-wrap",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											name: "intent",
											value: "generate",
											className: "neo-button w-full justify-center sm:min-w-[10.5rem] sm:w-auto",
											onClick: () => {
												fetcher.submit({ intent: "generate" }, { method: "post" });
											},
											disabled: isSubmitting,
											children: submittingIntent === "generate" && isSubmitting ? copy.generating : copy.generateNew
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											name: "intent",
											value: "delete",
											className: "neo-button-secondary w-full justify-center sm:w-auto",
											onClick: () => {
												fetcher.submit({ intent: "delete" }, { method: "post" });
											},
											disabled: isSubmitting,
											children: submittingIntent === "delete" && isSubmitting ? copy.deleting : copy.deleteAddress
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "border-theme-soft bg-theme-subtle text-theme-faint rounded-lg border px-3 py-2 text-[11px] leading-relaxed",
										children: copy.safetyHint
									})
								] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "theme-card p-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-theme-primary text-sm font-semibold",
											children: copy.noAddressTitle
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-theme-muted mt-1 text-xs leading-relaxed",
											children: copy.noAddressDescription
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											name: "intent",
											value: "generate",
											className: "neo-button mt-3 w-full justify-center sm:w-auto sm:min-w-[10.5rem]",
											onClick: () => {
												fetcher.submit({ intent: "generate" }, { method: "post" });
											},
											disabled: isSubmitting,
											children: submittingIntent === "generate" && isSubmitting ? copy.generating : copy.generateAddress
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "border-theme-soft bg-theme-subtle text-theme-faint mt-3 rounded-lg border px-3 py-2 text-[11px] leading-relaxed",
											children: copy.safetyHint
										})
									]
								})
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-theme-soft border-t border-dashed pt-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-3 flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-theme-faint text-[11px] font-semibold uppercase tracking-[0.16em]",
											children: copy.inboxTag
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-theme-primary font-display text-xl font-semibold",
											children: copy.inboxTitle
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-theme-faint mt-1 text-[11px]",
											children: [
												copy.lastRefresh,
												":",
												" ",
												formatRefreshTime(lastInboxRefreshAt, locale)
											]
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col items-end gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "theme-badge hidden px-3 py-1 text-[11px] font-medium sm:inline-flex",
											children: copy.tapToOpen
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "theme-badge px-3 py-1 text-[11px] font-semibold disabled:cursor-not-allowed disabled:opacity-60",
											onClick: () => {
												revalidator.revalidate();
											},
											disabled: isRefreshingInbox,
											children: isRefreshingInbox ? copy.refreshingInbox : copy.refreshInbox
										})]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex min-h-[360px] flex-col gap-2.5 overflow-y-auto py-1 pr-0.5",
									children: emails.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "border-theme-strong bg-theme-subtle mt-6 rounded-2xl border border-dashed px-4 py-10 text-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-theme-primary font-display text-lg font-semibold",
											children: copy.emptyInboxTitle
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-theme-muted mt-1 text-sm",
											children: copy.emptyInboxDescription
										})]
									}) : emails.map((email) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "email-item",
										onClick: () => setSelectedEmail(email),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-start justify-between gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-theme-primary font-display truncate text-sm font-semibold",
													children: email.subject
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-theme-faint whitespace-nowrap text-[11px]",
													children: formatTime(email.time, locale, loaderData.renderedAt)
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-theme-muted mt-1 truncate text-xs",
												children: [email.from_name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-theme-faint",
													children: [
														" ",
														"<",
														email.from_address,
														">"
													]
												})]
											})]
										})
									}, email.id))
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "glass-panel px-4 py-4 sm:px-5 sm:py-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-theme-primary font-display mb-3 text-lg font-semibold sm:text-xl",
							children: seoNarrative.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 lg:grid-cols-[0.92fr,1.08fr]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "theme-card space-y-3 p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-theme-faint text-[11px] font-semibold uppercase tracking-[0.16em]",
									children: seoGuides.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid gap-2 sm:grid-cols-2",
									children: seoGuides.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: toLocalePath(item.path, locale),
										prefetch: "viewport",
										className: "theme-badge flex items-center justify-between px-3 py-1.5 text-[11px] font-medium",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											"aria-hidden": "true",
											children: "->"
										})]
									}, item.path))
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "theme-card space-y-3 p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-theme-secondary text-xs leading-relaxed sm:text-sm",
									children: seoNarrative.description
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "text-theme-muted list-disc space-y-1 pl-5 text-[11px] leading-relaxed sm:text-xs",
									children: seoNarrative.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: point }, point))
								})]
							})]
						})]
					})
				]
			}),
			selectedEmail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmailModal, {
				email: selectedEmail,
				onClose: () => setSelectedEmail(null),
				copy: copy.modal
			})
		]
	});
});
//#endregion
//#region app/routes/contact.tsx
var contact_exports = /* @__PURE__ */ __exportAll({
	default: () => contact_default,
	meta: () => meta$4
});
var SUPPORT_EMAIL = "support@smail.pw";
var CONTACT_COPY = {
	en: {
		metaTitle: "Contact | smail.pw",
		metaDescription: "Contact smail.pw support by email.",
		tag: "Support",
		title: "Contact support",
		description: "For support, feedback, or cooperation requests, please email us directly.",
		emailLabel: "Support email",
		emailCta: "Send email",
		faqHint: "Before contacting us, please check the FAQ page first. Your answer may already be there.",
		faqCta: "Open FAQ",
		homeCta: "Back to homepage"
	},
	zh: {
		metaTitle: "联系我们 | smail.pw",
		metaDescription: "通过邮箱联系 smail.pw 支持团队。",
		tag: "支持",
		title: "联系支持团队",
		description: "如需技术支持、反馈建议或合作咨询，请直接发送邮件联系我们。",
		emailLabel: "支持邮箱",
		emailCta: "发送邮件",
		faqHint: "在联系我们之前，您可以先查看我们的常见问题页面，也许能找到您要的答案。",
		faqCta: "查看常见问题",
		homeCta: "返回首页"
	},
	es: {
		metaTitle: "Contacto | smail.pw",
		metaDescription: "Contacta con soporte de smail.pw por correo.",
		tag: "Soporte",
		title: "Contactar soporte",
		description: "Para soporte, comentarios o colaboración, contáctanos por correo electrónico.",
		emailLabel: "Correo de soporte",
		emailCta: "Enviar correo",
		faqHint: "Antes de contactarnos, revisa la página de preguntas frecuentes; puede que ya esté tu respuesta.",
		faqCta: "Ver FAQ",
		homeCta: "Volver al inicio"
	},
	fr: {
		metaTitle: "Contact | smail.pw",
		metaDescription: "Contacter le support smail.pw par email.",
		tag: "Support",
		title: "Contacter le support",
		description: "Pour le support, les retours ou la coopération, contactez-nous par email.",
		emailLabel: "Email support",
		emailCta: "Envoyer un email",
		faqHint: "Avant de nous contacter, consultez d'abord notre FAQ : vous y trouverez peut-être déjà la réponse.",
		faqCta: "Voir la FAQ",
		homeCta: "Retour à l'accueil"
	},
	de: {
		metaTitle: "Kontakt | smail.pw",
		metaDescription: "Kontaktiere den smail.pw Support per E-Mail.",
		tag: "Support",
		title: "Support kontaktieren",
		description: "Für Support, Feedback oder Kooperation kontaktiere uns bitte per E-Mail.",
		emailLabel: "Support-E-Mail",
		emailCta: "E-Mail senden",
		faqHint: "Bevor du uns kontaktierst, schau bitte zuerst in unsere FAQ. Vielleicht findest du dort bereits die Antwort.",
		faqCta: "FAQ öffnen",
		homeCta: "Zur Startseite"
	},
	ja: {
		metaTitle: "お問い合わせ | smail.pw",
		metaDescription: "smail.pw サポートへの連絡先メール。",
		tag: "サポート",
		title: "サポートへ連絡",
		description: "サポート、フィードバック、提携のご相談はメールでご連絡ください。",
		emailLabel: "サポートメール",
		emailCta: "メールを送信",
		faqHint: "お問い合わせ前に、まずよくある質問ページをご確認ください。解決策が見つかる場合があります。",
		faqCta: "FAQを見る",
		homeCta: "ホームへ戻る"
	},
	ko: {
		metaTitle: "문의하기 | smail.pw",
		metaDescription: "smail.pw 지원팀에 이메일로 문의하세요.",
		tag: "지원",
		title: "지원팀 문의",
		description: "지원, 피드백, 협업 문의는 이메일로 연락해 주세요.",
		emailLabel: "지원 이메일",
		emailCta: "이메일 보내기",
		faqHint: "문의하시기 전에 먼저 자주 묻는 질문 페이지를 확인해 주세요. 원하는 답변이 이미 있을 수 있습니다.",
		faqCta: "FAQ 보기",
		homeCta: "홈으로 돌아가기"
	},
	ru: {
		metaTitle: "Контакты | smail.pw",
		metaDescription: "Свяжитесь с поддержкой smail.pw по email.",
		tag: "Поддержка",
		title: "Связаться с поддержкой",
		description: "По вопросам поддержки, обратной связи и сотрудничества пишите на email.",
		emailLabel: "Email поддержки",
		emailCta: "Отправить письмо",
		faqHint: "Перед обращением в поддержку проверьте страницу FAQ — возможно, нужный ответ уже есть.",
		faqCta: "Открыть FAQ",
		homeCta: "На главную"
	},
	pt: {
		metaTitle: "Contato | smail.pw",
		metaDescription: "Entre em contato com o suporte da smail.pw por email.",
		tag: "Suporte",
		title: "Falar com o suporte",
		description: "Para suporte, feedback ou parceria, envie um email diretamente.",
		emailLabel: "Email de suporte",
		emailCta: "Enviar email",
		faqHint: "Antes de entrar em contato, veja nossa página de FAQ; a resposta pode já estar lá.",
		faqCta: "Ver FAQ",
		homeCta: "Voltar para início"
	},
	ar: {
		metaTitle: "اتصل بنا | smail.pw",
		metaDescription: "تواصل مع دعم smail.pw عبر البريد الإلكتروني.",
		tag: "الدعم",
		title: "التواصل مع الدعم",
		description: "للدعم أو الملاحظات أو التعاون، يرجى مراسلتنا مباشرة عبر البريد الإلكتروني.",
		emailLabel: "بريد الدعم",
		emailCta: "إرسال بريد",
		faqHint: "قبل التواصل معنا، يمكنك الاطلاع أولاً على صفحة الأسئلة الشائعة، فقد تجد الإجابة التي تحتاجها.",
		faqCta: "عرض الأسئلة الشائعة",
		homeCta: "العودة إلى الرئيسية"
	}
};
function getContactCopy(locale) {
	return CONTACT_COPY[locale] ?? CONTACT_COPY["en"];
}
function meta$4({ params, matches }) {
	const { locale } = resolveLocaleParam(params.lang);
	const copy = getContactCopy(locale);
	return mergeRouteMeta(matches, [
		{ title: copy.metaTitle },
		{
			name: "description",
			content: copy.metaDescription
		},
		{
			name: "robots",
			content: "index, follow"
		}
	]);
}
var contact_default = withComponentProps(function ContactPage({ params }) {
	const { locale } = resolveLocaleParam(params.lang);
	const copy = getContactCopy(locale);
	const contactJsonLd = {
		"@context": "https://schema.org",
		"@type": "ContactPage",
		url: `${BASE_URL}${toLocalePath("/contact", locale)}`,
		name: copy.title,
		description: copy.description,
		mainEntity: {
			"@type": "Organization",
			name: "smail.pw",
			email: SUPPORT_EMAIL
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 py-3 sm:py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
			type: "application/ld+json",
			dangerouslySetInnerHTML: { __html: JSON.stringify(contactJsonLd) }
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "glass-panel w-full space-y-4 px-4 py-5 sm:px-6 sm:py-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "soft-tag",
					children: copy.tag
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-theme-primary font-display text-2xl font-bold sm:text-3xl",
					children: copy.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-theme-secondary max-w-2xl text-sm leading-relaxed",
					children: copy.description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "theme-card space-y-2 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-theme-faint text-[11px] font-semibold uppercase tracking-[0.16em]",
						children: copy.emailLabel
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `mailto:${SUPPORT_EMAIL}`,
						className: "theme-badge inline-flex items-center gap-2 px-3 py-2 text-xs font-semibold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copy.emailCta }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-theme-faint",
								children: "·"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: SUPPORT_EMAIL }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": "true",
								children: "->"
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "theme-card space-y-2 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-theme-muted text-sm leading-relaxed",
						children: copy.faqHint
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: toLocalePath("/faq", locale),
						prefetch: "viewport",
						className: "theme-badge inline-flex px-3 py-2 text-xs font-semibold",
						children: copy.faqCta
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: toLocalePath("/", locale),
					prefetch: "viewport",
					className: "theme-badge inline-flex px-3 py-2 text-xs font-semibold",
					children: copy.homeCta
				})
			]
		})]
	});
});
//#endregion
//#region app/routes/blog.tsx
var blog_exports = /* @__PURE__ */ __exportAll({
	default: () => blog_default,
	formatBlogPageTitle: () => formatBlogPageTitle,
	formatBlogPaginationSummary: () => formatBlogPaginationSummary,
	formatBlogPublishedDate: () => formatBlogPublishedDate,
	getBlogListCopy: () => getBlogListCopy,
	getBlogNotFoundMetaTitle: () => getBlogNotFoundMetaTitle,
	getBlogPagePath: () => getBlogPagePath,
	getBlogPostMetaTitle: () => getBlogPostMetaTitle,
	getBlogUiCopy: () => getBlogUiCopy,
	loader: () => loader$4,
	meta: () => meta$3,
	toLanguageTag: () => toLanguageTag
});
function getLocaleFromParams$2(lang) {
	const { locale } = resolveLocaleParam(lang);
	return locale;
}
var BLOG_COPY = {
	en: {
		title: "Temporary Email Guides, Tips & Fixes | smail.pw",
		description: "Temporary email guides, best practices, and troubleshooting tips for verification and disposable inbox workflows.",
		header: "smail.pw Blog",
		subheader: "Guides and troubleshooting for temporary email users",
		tag: "Blog",
		readArticle: "Read article",
		prevPage: "Prev",
		nextPage: "Next",
		backToBlog: "Back to blog",
		relatedPosts: "Related posts",
		currentArticle: "Current article",
		postTitleSuffix: " | smail.pw Blog"
	},
	zh: {
		title: "临时邮箱博客：注册、验证码、隐私保护与收信排障实用完整指南 | smail.pw",
		description: "临时邮箱使用指南：最佳实践、收信排障、临时邮箱与邮箱别名对比。",
		header: "smail.pw 博客",
		subheader: "临时邮箱使用指南与实用排障手册",
		tag: "博客",
		readArticle: "阅读全文",
		prevPage: "上一页",
		nextPage: "下一页",
		backToBlog: "返回博客",
		relatedPosts: "相关文章",
		currentArticle: "当前文章",
		postTitleSuffix: " | smail.pw 临时邮箱博客实用指南"
	},
	es: {
		title: "Blog de correo temporal: guías y soluciones | smail.pw",
		description: "Guías de correo temporal, buenas prácticas y pasos de solución para registros, verificación y bandejas desechables.",
		header: "Blog de smail.pw",
		subheader: "Guías y resolución de problemas para usuarios de correo temporal",
		tag: "Blog",
		readArticle: "Leer artículo",
		prevPage: "Anterior",
		nextPage: "Siguiente",
		backToBlog: "Volver al blog",
		relatedPosts: "Artículos relacionados",
		currentArticle: "Artículo actual",
		postTitleSuffix: " | Blog de smail.pw"
	},
	fr: {
		title: "Blog email temporaire: guides et dépannage | smail.pw",
		description: "Guides d'email temporaire, bonnes pratiques et dépannage pour l'inscription, la vérification et les boîtes jetables.",
		header: "Blog smail.pw",
		subheader: "Guides et dépannage pour les utilisateurs d'email temporaire",
		tag: "Blog",
		readArticle: "Lire l'article",
		prevPage: "Précédent",
		nextPage: "Suivant",
		backToBlog: "Retour au blog",
		relatedPosts: "Articles liés",
		currentArticle: "Article actuel",
		postTitleSuffix: " | Blog smail.pw"
	},
	de: {
		title: "Temporäre E-Mail Blog: Ratgeber und Hilfe | smail.pw",
		description: "Ratgeber, Best Practices und Fehlerbehebung für temporäre E-Mails bei Registrierung und Verifizierung.",
		header: "smail.pw Blog",
		subheader: "Leitfäden und Fehlerbehebung für Nutzer temporärer E-Mails",
		tag: "Blog",
		readArticle: "Artikel lesen",
		prevPage: "Zurück",
		nextPage: "Weiter",
		backToBlog: "Zurück zum Blog",
		relatedPosts: "Ähnliche Artikel",
		currentArticle: "Aktueller Artikel",
		postTitleSuffix: " | smail.pw Blog"
	},
	ja: {
		title: "一時メールブログ：登録・認証・受信トラブルの実用解決ガイド | smail.pw",
		description: "一時メールの使い方、ベストプラクティス、認証や受信トラブルの解決手順をまとめたガイドです。",
		header: "smail.pw ブログ",
		subheader: "一時メール利用者向けガイドとトラブル解決",
		tag: "ブログ",
		readArticle: "記事を読む",
		prevPage: "前へ",
		nextPage: "次へ",
		backToBlog: "ブログに戻る",
		relatedPosts: "関連記事",
		currentArticle: "現在の記事",
		postTitleSuffix: " | smail.pw 一時メールブログ"
	},
	ko: {
		title: "임시 이메일 블로그: 가입·인증·수신 문제 해결 가이드 | smail.pw",
		description: "임시 이메일 사용 가이드, 모범 사례, 가입·인증·수신 문제 해결 방법을 제공합니다.",
		header: "smail.pw 블로그",
		subheader: "임시 이메일 사용자를 위한 가이드와 문제 해결",
		tag: "블로그",
		readArticle: "기사 읽기",
		prevPage: "이전",
		nextPage: "다음",
		backToBlog: "블로그로 돌아가기",
		relatedPosts: "관련 글",
		currentArticle: "현재 글",
		postTitleSuffix: " | smail.pw 임시 이메일 블로그"
	},
	ru: {
		title: "Блог временной почты: руководства и решения | smail.pw",
		description: "Руководства по временной почте, лучшие практики и устранение проблем для регистрации и подтверждений.",
		header: "Блог smail.pw",
		subheader: "Гайды и устранение проблем для пользователей временной почты",
		tag: "Блог",
		readArticle: "Читать статью",
		prevPage: "Назад",
		nextPage: "Далее",
		backToBlog: "Назад в блог",
		relatedPosts: "Похожие статьи",
		currentArticle: "Текущая статья",
		postTitleSuffix: " | Блог smail.pw"
	},
	pt: {
		title: "Blog de email temporário: guias e soluções | smail.pw",
		description: "Guias de email temporário, boas práticas e resolução de problemas para cadastro, verificação e caixas descartáveis.",
		header: "Blog smail.pw",
		subheader: "Guias e solução de problemas para usuários de email temporário",
		tag: "Blog",
		readArticle: "Ler artigo",
		prevPage: "Anterior",
		nextPage: "Próxima",
		backToBlog: "Voltar ao blog",
		relatedPosts: "Artigos relacionados",
		currentArticle: "Artigo atual",
		postTitleSuffix: " | Blog smail.pw"
	},
	ar: {
		title: "مدونة البريد المؤقت: أدلة وحلول للمشكلات | smail.pw",
		description: "أدلة البريد المؤقت، أفضل الممارسات، وحلول مشكلات التسجيل والتحقق واستقبال الرسائل.",
		header: "مدونة smail.pw",
		subheader: "أدلة وحلول لمستخدمي البريد المؤقت",
		tag: "مدونة",
		readArticle: "اقرأ المقال",
		prevPage: "السابق",
		nextPage: "التالي",
		backToBlog: "العودة إلى المدونة",
		relatedPosts: "مقالات ذات صلة",
		currentArticle: "المقال الحالي",
		postTitleSuffix: " | مدونة smail.pw"
	}
};
function getBlogCopy(locale) {
	return BLOG_COPY[locale];
}
function getBlogListCopy(locale) {
	const copy = getBlogCopy(locale);
	return {
		title: copy.title,
		description: copy.description,
		header: copy.header,
		subheader: copy.subheader
	};
}
function getBlogUiCopy(locale) {
	const { tag, readArticle, prevPage, nextPage, backToBlog, relatedPosts, currentArticle } = getBlogCopy(locale);
	return {
		tag,
		readArticle,
		prevPage,
		nextPage,
		backToBlog,
		relatedPosts,
		currentArticle
	};
}
function getBlogPostMetaTitle(locale, postTitle) {
	const maxTitleLength = 60;
	const titleWithLocalizedSuffix = `${postTitle}${getBlogCopy(locale).postTitleSuffix}`;
	if (titleWithLocalizedSuffix.length <= maxTitleLength) return titleWithLocalizedSuffix;
	const titleWithFallbackSuffix = `${postTitle} | smail.pw`;
	if (titleWithFallbackSuffix.length <= maxTitleLength) return titleWithFallbackSuffix;
	if (postTitle.length <= maxTitleLength) return postTitle;
	return `${postTitle.slice(0, maxTitleLength - 1)}…`;
}
function getBlogNotFoundMetaTitle(locale) {
	return getBlogCopy(locale).title;
}
function formatBlogPageTitle(_locale, baseTitle, page) {
	return `${baseTitle} · ${page}`;
}
function formatBlogPaginationSummary(locale, page, totalPages) {
	switch (locale) {
		case "zh": return `第 ${page} / ${totalPages} 页 · 每页 6 篇`;
		case "es": return `Página ${page} de ${totalPages} · 6 artículos por página`;
		case "fr": return `Page ${page} sur ${totalPages} · 6 articles par page`;
		case "de": return `Seite ${page} von ${totalPages} · 6 Artikel pro Seite`;
		case "ja": return `${page}/${totalPages}ページ · 1ページあたり6件`;
		case "ko": return `${page} / ${totalPages}페이지 · 페이지당 6개`;
		case "ru": return `Страница ${page} из ${totalPages} · 6 статей на странице`;
		case "pt": return `Página ${page} de ${totalPages} · 6 artigos por página`;
		case "ar": return `الصفحة ${page} من ${totalPages} · 6 مقالات لكل صفحة`;
		default: return `Page ${page} of ${totalPages} · 6 posts per page`;
	}
}
function toLanguageTag(locale) {
	return toIntlLocale(locale);
}
function formatBlogPublishedDate(publishedAt, locale) {
	return new Date(publishedAt).toLocaleDateString(toIntlLocale(locale), { timeZone: "UTC" });
}
function getBlogPagePath(page) {
	return page <= 1 ? "/blog" : `/blog/page/${page}`;
}
function meta$3({ params, matches }) {
	const locale = getLocaleFromParams$2(params.lang);
	const copy = getBlogListCopy(locale);
	return mergeRouteMeta(matches, [
		{ title: copy.title },
		{
			name: "description",
			content: copy.description
		},
		{
			name: "robots",
			content: isBlogLocaleIndexable(locale) ? "index, follow" : "noindex, follow"
		}
	]);
}
async function loader$4({ params, request }) {
	const { locale, shouldRedirectToDefault, isInvalid } = resolveLocaleParam(params.lang);
	if (isInvalid) throw new Response("Not Found", { status: 404 });
	if (shouldRedirectToDefault) {
		const url = new URL(request.url);
		throw redirect(`${stripDefaultLocalePrefix(url.pathname)}${url.search}`, 301);
	}
	return {
		locale,
		page: 1,
		totalPosts: listBlogPosts(locale).length,
		totalPages: getBlogPageCount(locale),
		posts: getBlogPostsByPage(locale, 1)
	};
}
var blog_default = withComponentProps(function BlogListPage({ loaderData }) {
	const locale = loaderData.locale || "en";
	const copy = getBlogListCopy(locale);
	const uiCopy = getBlogUiCopy(locale);
	const blogUrl = `${BASE_URL}${toLocalePath(getBlogPagePath(loaderData.page), locale)}`;
	const itemListJsonLd = {
		"@context": "https://schema.org",
		"@type": "ItemList",
		name: copy.header,
		description: copy.description,
		inLanguage: toLanguageTag(locale),
		url: blogUrl,
		numberOfItems: loaderData.totalPosts,
		itemListElement: loaderData.posts.map((post, index) => ({
			"@type": "ListItem",
			position: index + 1,
			url: `${BASE_URL}${toLocalePath(`/blog/${post.slug}`, locale)}`,
			name: post.title
		}))
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 py-3 sm:py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
			type: "application/ld+json",
			dangerouslySetInnerHTML: { __html: JSON.stringify(itemListJsonLd) }
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass-panel w-full px-4 py-5 sm:px-6 sm:py-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "mb-6 space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "soft-tag",
							children: uiCopy.tag
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-theme-primary font-display text-2xl font-bold sm:text-3xl",
							children: copy.header
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-theme-secondary text-sm",
							children: copy.subheader
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-3",
					children: loaderData.posts.map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "theme-card flex h-full flex-col p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-theme-faint text-[11px]",
								children: [
									formatBlogPublishedDate(post.publishedAt, locale),
									" ",
									"· ",
									post.readingMinutes,
									" min"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-theme-primary font-display mt-2 line-clamp-2 text-base font-semibold",
								children: post.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-theme-muted mt-2 line-clamp-4 text-sm",
								children: post.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: toLocalePath(`/blog/${post.slug}`, locale),
									prefetch: "viewport",
									className: "theme-badge inline-flex px-3 py-1.5 text-[11px] font-semibold",
									children: uiCopy.readArticle
								})
							})
						]
					}, post.slug))
				}),
				loaderData.totalPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "mt-6 flex flex-wrap items-center gap-2",
					"aria-label": "Blog pagination",
					children: [Array.from({ length: loaderData.totalPages }, (_, index) => index + 1).map((pageNumber) => {
						const isCurrent = pageNumber === loaderData.page;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: toLocalePath(getBlogPagePath(pageNumber), locale),
							prefetch: "viewport",
							"aria-current": isCurrent ? "page" : void 0,
							className: `theme-badge px-3 py-1.5 text-[11px] font-semibold ${isCurrent ? "brightness-95" : "hover:brightness-95"}`,
							children: pageNumber
						}, pageNumber);
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: toLocalePath(getBlogPagePath(2), locale),
						prefetch: "viewport",
						className: "theme-badge ml-1 px-3 py-1.5 text-[11px] font-semibold hover:brightness-95",
						children: uiCopy.nextPage
					})]
				}),
				loaderData.totalPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-theme-faint mt-3 text-[11px]",
					children: formatBlogPaginationSummary(locale, loaderData.page, loaderData.totalPages)
				})
			]
		})]
	});
});
//#endregion
//#region app/routes/blog.page.tsx
var blog_page_exports = /* @__PURE__ */ __exportAll({
	default: () => blog_page_default,
	loader: () => loader$3,
	meta: () => meta$2
});
function getLocaleFromParams$1(lang) {
	const { locale } = resolveLocaleParam(lang);
	return locale;
}
function parsePageParam(pageParam) {
	if (!pageParam) return null;
	if (!/^\d+$/.test(pageParam)) return null;
	const parsed = Number.parseInt(pageParam, 10);
	if (!Number.isSafeInteger(parsed) || parsed < 1) return null;
	return parsed;
}
function meta$2({ params, loaderData, matches }) {
	const locale = getLocaleFromParams$1(params.lang);
	const copy = getBlogListCopy(locale);
	const currentPage = loaderData?.page ?? parsePageParam(params.page) ?? 2;
	return mergeRouteMeta(matches, [
		{ title: formatBlogPageTitle(locale, copy.title, currentPage) },
		{
			name: "description",
			content: copy.description
		},
		{
			name: "robots",
			content: isBlogLocaleIndexable(locale) ? "index, follow" : "noindex, follow"
		}
	]);
}
async function loader$3({ params, request }) {
	const { locale, shouldRedirectToDefault, isInvalid } = resolveLocaleParam(params.lang);
	if (isInvalid) throw new Response("Not Found", { status: 404 });
	const page = parsePageParam(params.page);
	if (!page) throw new Response("Not Found", { status: 404 });
	const url = new URL(request.url);
	if (shouldRedirectToDefault) throw redirect(`${stripDefaultLocalePrefix(url.pathname)}${url.search}`, 301);
	if (page === 1) throw redirect(`${toLocalePath("/blog", locale)}${url.search}`, 301);
	const totalPosts = listBlogPosts(locale).length;
	const totalPages = getBlogPageCount(locale);
	if (page > totalPages) throw new Response("Not Found", { status: 404 });
	return {
		locale,
		page,
		totalPosts,
		totalPages,
		posts: getBlogPostsByPage(locale, page)
	};
}
var blog_page_default = withComponentProps(function BlogPagedListPage({ loaderData }) {
	const locale = loaderData.locale || "en";
	const copy = getBlogListCopy(locale);
	const uiCopy = getBlogUiCopy(locale);
	const blogUrl = `${BASE_URL}${toLocalePath(getBlogPagePath(loaderData.page), locale)}`;
	const itemListJsonLd = {
		"@context": "https://schema.org",
		"@type": "ItemList",
		name: copy.header,
		description: copy.description,
		inLanguage: toLanguageTag(locale),
		url: blogUrl,
		numberOfItems: loaderData.totalPosts,
		itemListElement: loaderData.posts.map((post, index) => ({
			"@type": "ListItem",
			position: (loaderData.page - 1) * 6 + index + 1,
			url: `${BASE_URL}${toLocalePath(`/blog/${post.slug}`, locale)}`,
			name: post.title
		}))
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 py-3 sm:py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
			type: "application/ld+json",
			dangerouslySetInnerHTML: { __html: JSON.stringify(itemListJsonLd) }
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass-panel w-full px-4 py-5 sm:px-6 sm:py-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "mb-6 space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "soft-tag",
							children: uiCopy.tag
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-theme-primary font-display text-2xl font-bold sm:text-3xl",
							children: copy.header
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-theme-secondary text-sm",
							children: copy.subheader
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-3",
					children: loaderData.posts.map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "theme-card flex h-full flex-col p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-theme-faint text-[11px]",
								children: [
									formatBlogPublishedDate(post.publishedAt, locale),
									" ",
									"· ",
									post.readingMinutes,
									" min"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-theme-primary font-display mt-2 line-clamp-2 text-base font-semibold",
								children: post.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-theme-muted mt-2 line-clamp-4 text-sm",
								children: post.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: toLocalePath(`/blog/${post.slug}`, locale),
									prefetch: "viewport",
									className: "theme-badge inline-flex px-3 py-1.5 text-[11px] font-semibold",
									children: uiCopy.readArticle
								})
							})
						]
					}, post.slug))
				}),
				loaderData.totalPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "mt-6 flex flex-wrap items-center gap-2",
					"aria-label": "Blog pagination",
					children: [
						loaderData.page > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: toLocalePath(getBlogPagePath(loaderData.page - 1), locale),
							prefetch: "viewport",
							className: "theme-badge px-3 py-1.5 text-[11px] font-semibold hover:brightness-95",
							children: uiCopy.prevPage
						}),
						Array.from({ length: loaderData.totalPages }, (_, index) => index + 1).map((pageNumber) => {
							const isCurrent = pageNumber === loaderData.page;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: toLocalePath(getBlogPagePath(pageNumber), locale),
								prefetch: "viewport",
								"aria-current": isCurrent ? "page" : void 0,
								className: `theme-badge px-3 py-1.5 text-[11px] font-semibold ${isCurrent ? "brightness-95" : "hover:brightness-95"}`,
								children: pageNumber
							}, pageNumber);
						}),
						loaderData.page < loaderData.totalPages && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: toLocalePath(getBlogPagePath(loaderData.page + 1), locale),
							prefetch: "viewport",
							className: "theme-badge ml-1 px-3 py-1.5 text-[11px] font-semibold hover:brightness-95",
							children: uiCopy.nextPage
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-theme-faint mt-3 text-[11px]",
					children: formatBlogPaginationSummary(locale, loaderData.page, loaderData.totalPages)
				})
			]
		})]
	});
});
//#endregion
//#region node_modules/.pnpm/@markdoc+markdoc@0.5.7_@types+react@19.2.14_react@19.2.5/node_modules/@markdoc/markdoc/dist/index.mjs
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
	return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
};
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") {
		for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: () => from[key],
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
var require_tag = __commonJS({ "src/grammar/tag.js"(exports, module) {
	"use strict";
	function peg$subclass(child, parent) {
		function C() {
			this.constructor = child;
		}
		C.prototype = parent.prototype;
		child.prototype = new C();
	}
	function peg$SyntaxError(message, expected, found, location) {
		this.message = message;
		this.expected = expected;
		this.found = found;
		this.location = location;
		this.name = "SyntaxError";
		if (typeof Error.captureStackTrace === "function") Error.captureStackTrace(this, peg$SyntaxError);
	}
	peg$subclass(peg$SyntaxError, Error);
	peg$SyntaxError.buildMessage = function(expected, found, location) {
		var DESCRIBE_EXPECTATION_FNS = {
			literal: function(expectation) {
				return "\"" + literalEscape(expectation.text) + "\"";
			},
			class: function(expectation) {
				var escapedParts = expectation.parts.map(function(part) {
					return Array.isArray(part) ? classEscape(part[0]) + "-" + classEscape(part[1]) : classEscape(part);
				});
				return "[" + (expectation.inverted ? "^" : "") + escapedParts + "]";
			},
			any: function() {
				return "any character";
			},
			end: function() {
				return "end of input";
			},
			other: function(expectation) {
				return expectation.description;
			},
			not: function(expectation) {
				return "not " + describeExpectation(expectation.expected);
			}
		};
		function hex(ch) {
			return ch.charCodeAt(0).toString(16).toUpperCase();
		}
		function literalEscape(s2) {
			return s2.replace(/\\/g, "\\\\").replace(/"/g, "\\\"").replace(/\0/g, "\\0").replace(/\t/g, "\\t").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/[\x00-\x0F]/g, function(ch) {
				return "\\x0" + hex(ch);
			}).replace(/[\x10-\x1F\x7F-\x9F]/g, function(ch) {
				return "\\x" + hex(ch);
			});
		}
		function classEscape(s2) {
			return s2.replace(/\\/g, "\\\\").replace(/\]/g, "\\]").replace(/\^/g, "\\^").replace(/-/g, "\\-").replace(/\0/g, "\\0").replace(/\t/g, "\\t").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/[\x00-\x0F]/g, function(ch) {
				return "\\x0" + hex(ch);
			}).replace(/[\x10-\x1F\x7F-\x9F]/g, function(ch) {
				return "\\x" + hex(ch);
			});
		}
		function describeExpectation(expectation) {
			return DESCRIBE_EXPECTATION_FNS[expectation.type](expectation);
		}
		function describeExpected(expected2) {
			var descriptions = expected2.map(describeExpectation);
			var i, j;
			descriptions.sort();
			if (descriptions.length > 0) {
				for (i = 1, j = 1; i < descriptions.length; i++) if (descriptions[i - 1] !== descriptions[i]) {
					descriptions[j] = descriptions[i];
					j++;
				}
				descriptions.length = j;
			}
			switch (descriptions.length) {
				case 1: return descriptions[0];
				case 2: return descriptions[0] + " or " + descriptions[1];
				default: return descriptions.slice(0, -1).join(", ") + ", or " + descriptions[descriptions.length - 1];
			}
		}
		function describeFound(found2) {
			return found2 ? "\"" + literalEscape(found2) + "\"" : "end of input";
		}
		return "Expected " + describeExpected(expected) + " but " + describeFound(found) + " found.";
	};
	function peg$parse(input, options) {
		options = options !== void 0 ? options : {};
		var peg$FAILED = {};
		var peg$startRuleFunctions = { Top: peg$parseTop };
		var peg$startRuleFunction = peg$parseTop;
		var peg$c0 = "/";
		var peg$c1 = ".";
		var peg$c2 = "#";
		var peg$c3 = "=";
		var peg$c4 = "(";
		var peg$c5 = ")";
		var peg$c6 = ",";
		var peg$c7 = "[";
		var peg$c8 = "]";
		var peg$c9 = "null";
		var peg$c10 = "true";
		var peg$c11 = "false";
		var peg$c12 = "{";
		var peg$c13 = "}";
		var peg$c14 = ":";
		var peg$c15 = "-";
		var peg$c16 = "\"";
		var peg$c17 = "\\";
		var peg$c18 = "n";
		var peg$c19 = "r";
		var peg$c20 = "t";
		var peg$r0 = /^[$@]/;
		var peg$r1 = /^[0-9]/;
		var peg$r2 = /^[^\0-\x1F"\\]/;
		var peg$r3 = /^[a-zA-Z0-9_\-]/;
		var peg$r4 = /^[ \n\t]/;
		var peg$e0 = peg$literalExpectation("/", false);
		var peg$e1 = peg$otherExpectation("tag name");
		var peg$e2 = peg$otherExpectation("class");
		var peg$e3 = peg$otherExpectation("id");
		var peg$e4 = peg$literalExpectation("=", false);
		var peg$e5 = peg$literalExpectation("(", false);
		var peg$e6 = peg$literalExpectation(")", false);
		var peg$e7 = peg$literalExpectation(",", false);
		var peg$e8 = peg$otherExpectation("variable");
		var peg$e9 = peg$otherExpectation("null");
		var peg$e10 = peg$otherExpectation("boolean");
		var peg$e11 = peg$literalExpectation("[", false);
		var peg$e12 = peg$literalExpectation("]", false);
		var peg$e13 = peg$literalExpectation("{", false);
		var peg$e14 = peg$literalExpectation("}", false);
		var peg$e15 = peg$literalExpectation(":", false);
		var peg$e16 = peg$otherExpectation("number");
		var peg$e17 = peg$otherExpectation("string");
		var peg$e18 = peg$otherExpectation("identifier");
		var peg$e19 = peg$otherExpectation("whitespace");
		var peg$f0 = function(variable) {
			return {
				type: "variable",
				meta: { variable }
			};
		};
		var peg$f1 = function(attributes) {
			return {
				type: "annotation",
				meta: { attributes }
			};
		};
		var peg$f2 = function(tag, value) {
			return value;
		};
		var peg$f3 = function(tag, primary, attributes, close) {
			if (primary) {
				attributes = attributes || [];
				attributes.unshift({
					type: "attribute",
					name: "primary",
					value: primary
				});
			}
			const [type, nesting] = close ? ["tag", 0] : ["tag_open", 1];
			return {
				type,
				nesting,
				meta: {
					tag,
					attributes
				}
			};
		};
		var peg$f4 = function(tag) {
			return {
				type: "tag_close",
				nesting: -1,
				meta: { tag }
			};
		};
		var peg$f5 = function(head, tail) {
			return !head ? [] : [head, ...tail];
		};
		var peg$f6 = function(item2) {
			return item2;
		};
		var peg$f7 = function(ids) {
			return ids;
		};
		var peg$f8 = function(classes) {
			return classes;
		};
		var peg$f9 = function(attribute) {
			return attribute;
		};
		var peg$f10 = function(name) {
			return {
				type: "class",
				name,
				value: true
			};
		};
		var peg$f11 = function(value) {
			return {
				type: "attribute",
				name: "id",
				value
			};
		};
		var peg$f12 = function(name, value) {
			return {
				type: "attribute",
				name,
				value
			};
		};
		var peg$f13 = function(name, head, tail) {
			return head ? [head, ...tail] : [];
		};
		var peg$f14 = function(name, params) {
			let parameters = {};
			for (let [index, { name: name2, value }] of params.entries()) parameters[name2 || index] = value;
			return new Function3(name, parameters);
		};
		var peg$f15 = function(name) {
			return name;
		};
		var peg$f16 = function(name, value) {
			return {
				name,
				value
			};
		};
		var peg$f17 = function(value) {
			return value;
		};
		var peg$f18 = function(prefix, head, tail) {
			if (prefix === "@") return [head, ...tail];
			return new Variable2([head, ...tail]);
		};
		var peg$f19 = function() {
			return null;
		};
		var peg$f20 = function() {
			return true;
		};
		var peg$f21 = function() {
			return false;
		};
		var peg$f22 = function(head, tail) {
			return [head, ...tail];
		};
		var peg$f23 = function(value) {
			return value || [];
		};
		var peg$f24 = function(head, tail) {
			return Object.assign(head, ...tail);
		};
		var peg$f25 = function(value) {
			return value || {};
		};
		var peg$f26 = function(key, value) {
			return key === "$$mdtype" ? {} : { [key]: value };
		};
		var peg$f27 = function() {
			return parseFloat(text2());
		};
		var peg$f28 = function(value) {
			return value.join("");
		};
		var peg$f29 = function() {
			return "\n";
		};
		var peg$f30 = function() {
			return "\r";
		};
		var peg$f31 = function() {
			return "	";
		};
		var peg$f32 = function(sequence) {
			return sequence;
		};
		var peg$currPos = 0;
		var peg$savedPos = 0;
		var peg$posDetailsCache = [{
			line: 1,
			column: 1
		}];
		var peg$expected = [];
		var peg$silentFails = 0;
		var peg$result;
		if ("startRule" in options) {
			if (!(options.startRule in peg$startRuleFunctions)) throw new Error(`Can't start parsing from rule "` + options.startRule + "\".");
			peg$startRuleFunction = peg$startRuleFunctions[options.startRule];
		}
		function text2() {
			return input.substring(peg$savedPos, peg$currPos);
		}
		function peg$literalExpectation(text3, ignoreCase) {
			return {
				type: "literal",
				text: text3,
				ignoreCase
			};
		}
		function peg$endExpectation() {
			return { type: "end" };
		}
		function peg$otherExpectation(description) {
			return {
				type: "other",
				description
			};
		}
		function peg$computePosDetails(pos) {
			var details = peg$posDetailsCache[pos];
			var p;
			if (details) return details;
			else {
				p = pos - 1;
				while (!peg$posDetailsCache[p]) p--;
				details = peg$posDetailsCache[p];
				details = {
					line: details.line,
					column: details.column
				};
				while (p < pos) {
					if (input.charCodeAt(p) === 10) {
						details.line++;
						details.column = 1;
					} else details.column++;
					p++;
				}
				peg$posDetailsCache[pos] = details;
				return details;
			}
		}
		var peg$VALIDFILENAME = typeof options.filename === "string" && options.filename.length > 0;
		function peg$computeLocation(startPos, endPos) {
			var loc = {};
			if (peg$VALIDFILENAME) loc.filename = options.filename;
			var startPosDetails = peg$computePosDetails(startPos);
			loc.start = {
				offset: startPos,
				line: startPosDetails.line,
				column: startPosDetails.column
			};
			var endPosDetails = peg$computePosDetails(endPos);
			loc.end = {
				offset: endPos,
				line: endPosDetails.line,
				column: endPosDetails.column
			};
			return loc;
		}
		function peg$begin() {
			peg$expected.push({
				pos: peg$currPos,
				variants: []
			});
		}
		function peg$expect(expected2) {
			var top = peg$expected[peg$expected.length - 1];
			if (peg$currPos < top.pos) return;
			if (peg$currPos > top.pos) {
				top.pos = peg$currPos;
				top.variants = [];
			}
			top.variants.push(expected2);
		}
		function peg$buildStructuredError(expected2, found, location2) {
			return new peg$SyntaxError(peg$SyntaxError.buildMessage(expected2, found, location2), expected2, found, location2);
		}
		function peg$buildError() {
			var expected2 = peg$expected[0];
			var failPos = expected2.pos;
			return peg$buildStructuredError(expected2.variants, failPos < input.length ? input.charAt(failPos) : null, failPos < input.length ? peg$computeLocation(failPos, failPos + 1) : peg$computeLocation(failPos, failPos));
		}
		function peg$parseTop() {
			var s0 = peg$parseTopLevelValue();
			if (s0 === peg$FAILED) {
				s0 = peg$parseAnnotation();
				if (s0 === peg$FAILED) {
					s0 = peg$parseTagOpen();
					if (s0 === peg$FAILED) s0 = peg$parseTagClose();
				}
			}
			return s0;
		}
		function peg$parseTopLevelValue() {
			var s0 = peg$currPos, s1 = peg$parseVariable();
			if (s1 === peg$FAILED) s1 = peg$parseFunction();
			if (s1 !== peg$FAILED) {
				peg$savedPos = s0;
				s1 = peg$f0(s1);
			}
			s0 = s1;
			return s0;
		}
		function peg$parseAnnotation() {
			var s0 = peg$currPos, s1 = peg$parseTagAttributes(), s2, s3;
			if (s1 !== peg$FAILED) {
				s2 = [];
				s3 = peg$parse_();
				while (s3 !== peg$FAILED) {
					s2.push(s3);
					s3 = peg$parse_();
				}
				peg$savedPos = s0;
				s0 = peg$f1(s1);
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			return s0;
		}
		function peg$parseTagOpen() {
			var s0, s1, s2, s3, s4, s5, s6;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			s0 = peg$currPos;
			s1 = peg$parseTagName();
			if (s1 !== peg$FAILED) {
				s2 = [];
				s3 = peg$parse_();
				while (s3 !== peg$FAILED) {
					s2.push(s3);
					s3 = peg$parse_();
				}
				s3 = peg$currPos;
				s4 = peg$parseValue();
				if (s4 !== peg$FAILED) {
					s5 = peg$parse_();
					if (s5 === peg$FAILED) s5 = null;
					peg$savedPos = s3;
					s3 = peg$f2(s1, s4);
				} else {
					peg$currPos = s3;
					s3 = peg$FAILED;
				}
				if (s3 === peg$FAILED) s3 = null;
				s4 = peg$parseTagAttributes();
				if (s4 === peg$FAILED) s4 = null;
				s5 = [];
				s6 = peg$parse_();
				while (s6 !== peg$FAILED) {
					s5.push(s6);
					s6 = peg$parse_();
				}
				rule$expects(peg$e0);
				if (input.charCodeAt(peg$currPos) === 47) {
					s6 = peg$c0;
					peg$currPos++;
				} else s6 = peg$FAILED;
				if (s6 === peg$FAILED) s6 = null;
				peg$savedPos = s0;
				s0 = peg$f3(s1, s3, s4, s6);
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			return s0;
		}
		function peg$parseTagClose() {
			var s0, s1, s2;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			s0 = peg$currPos;
			rule$expects(peg$e0);
			if (input.charCodeAt(peg$currPos) === 47) {
				s1 = peg$c0;
				peg$currPos++;
			} else s1 = peg$FAILED;
			if (s1 !== peg$FAILED) {
				s2 = peg$parseTagName();
				if (s2 !== peg$FAILED) {
					peg$savedPos = s0;
					s0 = peg$f4(s2);
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			return s0;
		}
		function peg$parseTagName() {
			var s0;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			rule$expects(peg$e1);
			peg$silentFails++;
			s0 = peg$parseIdentifier();
			peg$silentFails--;
			return s0;
		}
		function peg$parseTagAttributes() {
			var s0 = peg$currPos, s1 = peg$parseTagAttributesItem(), s2, s3;
			if (s1 !== peg$FAILED) {
				s2 = [];
				s3 = peg$parseTagAttributesTail();
				while (s3 !== peg$FAILED) {
					s2.push(s3);
					s3 = peg$parseTagAttributesTail();
				}
				peg$savedPos = s0;
				s0 = peg$f5(s1, s2);
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			return s0;
		}
		function peg$parseTagAttributesTail() {
			var s0 = peg$currPos, s1 = [], s2 = peg$parse_();
			if (s2 !== peg$FAILED) while (s2 !== peg$FAILED) {
				s1.push(s2);
				s2 = peg$parse_();
			}
			else s1 = peg$FAILED;
			if (s1 !== peg$FAILED) {
				s2 = peg$parseTagAttributesItem();
				if (s2 !== peg$FAILED) {
					peg$savedPos = s0;
					s0 = peg$f6(s2);
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			return s0;
		}
		function peg$parseTagAttributesItem() {
			var s0 = peg$currPos, s1 = peg$parseTagShortcutId();
			if (s1 !== peg$FAILED) {
				peg$savedPos = s0;
				s1 = peg$f7(s1);
			}
			s0 = s1;
			if (s0 === peg$FAILED) {
				s0 = peg$currPos;
				s1 = peg$parseTagShortcutClass();
				if (s1 !== peg$FAILED) {
					peg$savedPos = s0;
					s1 = peg$f8(s1);
				}
				s0 = s1;
				if (s0 === peg$FAILED) {
					s0 = peg$currPos;
					s1 = peg$parseTagAttribute();
					if (s1 !== peg$FAILED) {
						peg$savedPos = s0;
						s1 = peg$f9(s1);
					}
					s0 = s1;
				}
			}
			return s0;
		}
		function peg$parseTagShortcutClass() {
			var s0, s1, s2;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			rule$expects(peg$e2);
			peg$silentFails++;
			s0 = peg$currPos;
			if (input.charCodeAt(peg$currPos) === 46) {
				s1 = peg$c1;
				peg$currPos++;
			} else s1 = peg$FAILED;
			if (s1 !== peg$FAILED) {
				s2 = peg$parseIdentifier();
				if (s2 !== peg$FAILED) {
					peg$savedPos = s0;
					s0 = peg$f10(s2);
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			peg$silentFails--;
			return s0;
		}
		function peg$parseTagShortcutId() {
			var s0, s1, s2;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			rule$expects(peg$e3);
			peg$silentFails++;
			s0 = peg$currPos;
			if (input.charCodeAt(peg$currPos) === 35) {
				s1 = peg$c2;
				peg$currPos++;
			} else s1 = peg$FAILED;
			if (s1 !== peg$FAILED) {
				s2 = peg$parseIdentifier();
				if (s2 !== peg$FAILED) {
					peg$savedPos = s0;
					s0 = peg$f11(s2);
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			peg$silentFails--;
			return s0;
		}
		function peg$parseTagAttribute() {
			var s0, s1, s2, s3;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			s0 = peg$currPos;
			s1 = peg$parseIdentifier();
			if (s1 !== peg$FAILED) {
				rule$expects(peg$e4);
				if (input.charCodeAt(peg$currPos) === 61) {
					s2 = peg$c3;
					peg$currPos++;
				} else s2 = peg$FAILED;
				if (s2 !== peg$FAILED) {
					s3 = peg$parseValue();
					if (s3 !== peg$FAILED) {
						peg$savedPos = s0;
						s0 = peg$f12(s1, s3);
					} else {
						peg$currPos = s0;
						s0 = peg$FAILED;
					}
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			return s0;
		}
		function peg$parseFunction() {
			var s0, s1, s2, s3, s4, s5, s6, s7;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			s0 = peg$currPos;
			s1 = peg$parseIdentifier();
			if (s1 !== peg$FAILED) {
				rule$expects(peg$e5);
				if (input.charCodeAt(peg$currPos) === 40) {
					s2 = peg$c4;
					peg$currPos++;
				} else s2 = peg$FAILED;
				if (s2 !== peg$FAILED) {
					s3 = [];
					s4 = peg$parse_();
					while (s4 !== peg$FAILED) {
						s3.push(s4);
						s4 = peg$parse_();
					}
					s4 = peg$currPos;
					s5 = peg$parseFunctionParameter();
					if (s5 === peg$FAILED) s5 = null;
					s6 = [];
					s7 = peg$parseFunctionParameterTail();
					while (s7 !== peg$FAILED) {
						s6.push(s7);
						s7 = peg$parseFunctionParameterTail();
					}
					peg$savedPos = s4;
					s4 = peg$f13(s1, s5, s6);
					rule$expects(peg$e6);
					if (input.charCodeAt(peg$currPos) === 41) {
						s5 = peg$c5;
						peg$currPos++;
					} else s5 = peg$FAILED;
					if (s5 !== peg$FAILED) {
						peg$savedPos = s0;
						s0 = peg$f14(s1, s4);
					} else {
						peg$currPos = s0;
						s0 = peg$FAILED;
					}
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			return s0;
		}
		function peg$parseFunctionParameter() {
			var s0, s1, s2, s3;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			s0 = peg$currPos;
			s1 = peg$currPos;
			s2 = peg$parseIdentifier();
			if (s2 !== peg$FAILED) {
				rule$expects(peg$e4);
				if (input.charCodeAt(peg$currPos) === 61) {
					s3 = peg$c3;
					peg$currPos++;
				} else s3 = peg$FAILED;
				if (s3 !== peg$FAILED) {
					peg$savedPos = s1;
					s1 = peg$f15(s2);
				} else {
					peg$currPos = s1;
					s1 = peg$FAILED;
				}
			} else {
				peg$currPos = s1;
				s1 = peg$FAILED;
			}
			if (s1 === peg$FAILED) s1 = null;
			s2 = peg$parseValue();
			if (s2 !== peg$FAILED) {
				peg$savedPos = s0;
				s0 = peg$f16(s1, s2);
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			return s0;
		}
		function peg$parseFunctionParameterTail() {
			var s0, s1, s2, s3, s4;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			s0 = peg$currPos;
			s1 = [];
			s2 = peg$parse_();
			while (s2 !== peg$FAILED) {
				s1.push(s2);
				s2 = peg$parse_();
			}
			rule$expects(peg$e7);
			if (input.charCodeAt(peg$currPos) === 44) {
				s2 = peg$c6;
				peg$currPos++;
			} else s2 = peg$FAILED;
			if (s2 !== peg$FAILED) {
				s3 = [];
				s4 = peg$parse_();
				while (s4 !== peg$FAILED) {
					s3.push(s4);
					s4 = peg$parse_();
				}
				s4 = peg$parseFunctionParameter();
				if (s4 !== peg$FAILED) {
					peg$savedPos = s0;
					s0 = peg$f17(s4);
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			return s0;
		}
		function peg$parseTrailingComma() {
			var s0, s1, s2;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			s0 = peg$currPos;
			s1 = [];
			s2 = peg$parse_();
			while (s2 !== peg$FAILED) {
				s1.push(s2);
				s2 = peg$parse_();
			}
			rule$expects(peg$e7);
			if (input.charCodeAt(peg$currPos) === 44) {
				s2 = peg$c6;
				peg$currPos++;
			} else s2 = peg$FAILED;
			if (s2 !== peg$FAILED) {
				s1 = [s1, s2];
				s0 = s1;
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			if (s0 === peg$FAILED) s0 = null;
			return s0;
		}
		function peg$parseVariable() {
			var s0, s1, s2, s3, s4;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			rule$expects(peg$e8);
			peg$silentFails++;
			s0 = peg$currPos;
			if (peg$r0.test(input.charAt(peg$currPos))) {
				s1 = input.charAt(peg$currPos);
				peg$currPos++;
			} else s1 = peg$FAILED;
			if (s1 !== peg$FAILED) {
				s2 = peg$parseIdentifier();
				if (s2 !== peg$FAILED) {
					s3 = [];
					s4 = peg$parseVariableTail();
					while (s4 !== peg$FAILED) {
						s3.push(s4);
						s4 = peg$parseVariableTail();
					}
					peg$savedPos = s0;
					s0 = peg$f18(s1, s2, s3);
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			peg$silentFails--;
			return s0;
		}
		function peg$parseVariableTail() {
			var s0 = peg$currPos, s1, s2, s3;
			if (input.charCodeAt(peg$currPos) === 46) {
				s1 = peg$c1;
				peg$currPos++;
			} else s1 = peg$FAILED;
			if (s1 !== peg$FAILED) {
				s2 = peg$parseIdentifier();
				if (s2 !== peg$FAILED) {
					peg$savedPos = s0;
					s0 = peg$f15(s2);
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			if (s0 === peg$FAILED) {
				s0 = peg$currPos;
				if (input.charCodeAt(peg$currPos) === 91) {
					s1 = peg$c7;
					peg$currPos++;
				} else s1 = peg$FAILED;
				if (s1 !== peg$FAILED) {
					s2 = peg$parseValueNumber();
					if (s2 === peg$FAILED) s2 = peg$parseValueString();
					if (s2 !== peg$FAILED) {
						if (input.charCodeAt(peg$currPos) === 93) {
							s3 = peg$c8;
							peg$currPos++;
						} else s3 = peg$FAILED;
						if (s3 !== peg$FAILED) {
							peg$savedPos = s0;
							s0 = peg$f17(s2);
						} else {
							peg$currPos = s0;
							s0 = peg$FAILED;
						}
					} else {
						peg$currPos = s0;
						s0 = peg$FAILED;
					}
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			}
			return s0;
		}
		function peg$parseValue() {
			var s0 = peg$parseValueNull();
			if (s0 === peg$FAILED) {
				s0 = peg$parseValueBoolean();
				if (s0 === peg$FAILED) {
					s0 = peg$parseValueString();
					if (s0 === peg$FAILED) {
						s0 = peg$parseValueNumber();
						if (s0 === peg$FAILED) {
							s0 = peg$parseValueArray();
							if (s0 === peg$FAILED) {
								s0 = peg$parseValueHash();
								if (s0 === peg$FAILED) {
									s0 = peg$parseFunction();
									if (s0 === peg$FAILED) s0 = peg$parseVariable();
								}
							}
						}
					}
				}
			}
			return s0;
		}
		function peg$parseValueNull() {
			var s0, s1;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			rule$expects(peg$e9);
			peg$silentFails++;
			s0 = peg$currPos;
			if (input.substr(peg$currPos, 4) === peg$c9) {
				s1 = peg$c9;
				peg$currPos += 4;
			} else s1 = peg$FAILED;
			if (s1 !== peg$FAILED) {
				peg$savedPos = s0;
				s1 = peg$f19();
			}
			s0 = s1;
			peg$silentFails--;
			return s0;
		}
		function peg$parseValueBoolean() {
			var s0, s1;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			rule$expects(peg$e10);
			peg$silentFails++;
			s0 = peg$currPos;
			if (input.substr(peg$currPos, 4) === peg$c10) {
				s1 = peg$c10;
				peg$currPos += 4;
			} else s1 = peg$FAILED;
			if (s1 !== peg$FAILED) {
				peg$savedPos = s0;
				s1 = peg$f20();
			}
			s0 = s1;
			if (s0 === peg$FAILED) {
				s0 = peg$currPos;
				if (input.substr(peg$currPos, 5) === peg$c11) {
					s1 = peg$c11;
					peg$currPos += 5;
				} else s1 = peg$FAILED;
				if (s1 !== peg$FAILED) {
					peg$savedPos = s0;
					s1 = peg$f21();
				}
				s0 = s1;
			}
			peg$silentFails--;
			return s0;
		}
		function peg$parseValueArray() {
			var s0, s1, s2, s3, s4, s5, s6;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			s0 = peg$currPos;
			rule$expects(peg$e11);
			if (input.charCodeAt(peg$currPos) === 91) {
				s1 = peg$c7;
				peg$currPos++;
			} else s1 = peg$FAILED;
			if (s1 !== peg$FAILED) {
				s2 = [];
				s3 = peg$parse_();
				while (s3 !== peg$FAILED) {
					s2.push(s3);
					s3 = peg$parse_();
				}
				s3 = peg$currPos;
				s4 = peg$parseValue();
				if (s4 !== peg$FAILED) {
					s5 = [];
					s6 = peg$parseValueArrayTail();
					while (s6 !== peg$FAILED) {
						s5.push(s6);
						s6 = peg$parseValueArrayTail();
					}
					s6 = peg$parseTrailingComma();
					peg$savedPos = s3;
					s3 = peg$f22(s4, s5);
				} else {
					peg$currPos = s3;
					s3 = peg$FAILED;
				}
				if (s3 === peg$FAILED) s3 = null;
				s4 = [];
				s5 = peg$parse_();
				while (s5 !== peg$FAILED) {
					s4.push(s5);
					s5 = peg$parse_();
				}
				rule$expects(peg$e12);
				if (input.charCodeAt(peg$currPos) === 93) {
					s5 = peg$c8;
					peg$currPos++;
				} else s5 = peg$FAILED;
				if (s5 !== peg$FAILED) {
					peg$savedPos = s0;
					s0 = peg$f23(s3);
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			return s0;
		}
		function peg$parseValueArrayTail() {
			var s0, s1, s2, s3, s4;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			s0 = peg$currPos;
			s1 = [];
			s2 = peg$parse_();
			while (s2 !== peg$FAILED) {
				s1.push(s2);
				s2 = peg$parse_();
			}
			rule$expects(peg$e7);
			if (input.charCodeAt(peg$currPos) === 44) {
				s2 = peg$c6;
				peg$currPos++;
			} else s2 = peg$FAILED;
			if (s2 !== peg$FAILED) {
				s3 = [];
				s4 = peg$parse_();
				while (s4 !== peg$FAILED) {
					s3.push(s4);
					s4 = peg$parse_();
				}
				s4 = peg$parseValue();
				if (s4 !== peg$FAILED) {
					peg$savedPos = s0;
					s0 = peg$f17(s4);
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			return s0;
		}
		function peg$parseValueHash() {
			var s0, s1, s2, s3, s4, s5, s6;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			s0 = peg$currPos;
			rule$expects(peg$e13);
			if (input.charCodeAt(peg$currPos) === 123) {
				s1 = peg$c12;
				peg$currPos++;
			} else s1 = peg$FAILED;
			if (s1 !== peg$FAILED) {
				s2 = [];
				s3 = peg$parse_();
				while (s3 !== peg$FAILED) {
					s2.push(s3);
					s3 = peg$parse_();
				}
				s3 = peg$currPos;
				s4 = peg$parseValueHashItem();
				if (s4 !== peg$FAILED) {
					s5 = [];
					s6 = peg$parseValueHashTail();
					while (s6 !== peg$FAILED) {
						s5.push(s6);
						s6 = peg$parseValueHashTail();
					}
					s6 = peg$parseTrailingComma();
					peg$savedPos = s3;
					s3 = peg$f24(s4, s5);
				} else {
					peg$currPos = s3;
					s3 = peg$FAILED;
				}
				if (s3 === peg$FAILED) s3 = null;
				s4 = [];
				s5 = peg$parse_();
				while (s5 !== peg$FAILED) {
					s4.push(s5);
					s5 = peg$parse_();
				}
				rule$expects(peg$e14);
				if (input.charCodeAt(peg$currPos) === 125) {
					s5 = peg$c13;
					peg$currPos++;
				} else s5 = peg$FAILED;
				if (s5 !== peg$FAILED) {
					peg$savedPos = s0;
					s0 = peg$f25(s3);
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			return s0;
		}
		function peg$parseValueHashTail() {
			var s0, s1, s2, s3, s4;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			s0 = peg$currPos;
			s1 = [];
			s2 = peg$parse_();
			while (s2 !== peg$FAILED) {
				s1.push(s2);
				s2 = peg$parse_();
			}
			rule$expects(peg$e7);
			if (input.charCodeAt(peg$currPos) === 44) {
				s2 = peg$c6;
				peg$currPos++;
			} else s2 = peg$FAILED;
			if (s2 !== peg$FAILED) {
				s3 = [];
				s4 = peg$parse_();
				while (s4 !== peg$FAILED) {
					s3.push(s4);
					s4 = peg$parse_();
				}
				s4 = peg$parseValueHashItem();
				if (s4 !== peg$FAILED) {
					peg$savedPos = s0;
					s0 = peg$f6(s4);
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			return s0;
		}
		function peg$parseValueHashItem() {
			var s0, s1, s2, s3, s4;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			s0 = peg$currPos;
			s1 = peg$parseIdentifier();
			if (s1 === peg$FAILED) s1 = peg$parseValueString();
			if (s1 !== peg$FAILED) {
				rule$expects(peg$e15);
				if (input.charCodeAt(peg$currPos) === 58) {
					s2 = peg$c14;
					peg$currPos++;
				} else s2 = peg$FAILED;
				if (s2 !== peg$FAILED) {
					s3 = [];
					s4 = peg$parse_();
					while (s4 !== peg$FAILED) {
						s3.push(s4);
						s4 = peg$parse_();
					}
					s4 = peg$parseValue();
					if (s4 !== peg$FAILED) {
						peg$savedPos = s0;
						s0 = peg$f26(s1, s4);
					} else {
						peg$currPos = s0;
						s0 = peg$FAILED;
					}
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			return s0;
		}
		function peg$parseValueNumber() {
			var s0, s1, s2, s3, s4, s5, s6;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			rule$expects(peg$e16);
			peg$silentFails++;
			s0 = peg$currPos;
			if (input.charCodeAt(peg$currPos) === 45) {
				s1 = peg$c15;
				peg$currPos++;
			} else s1 = peg$FAILED;
			if (s1 === peg$FAILED) s1 = null;
			s2 = [];
			if (peg$r1.test(input.charAt(peg$currPos))) {
				s3 = input.charAt(peg$currPos);
				peg$currPos++;
			} else s3 = peg$FAILED;
			if (s3 !== peg$FAILED) while (s3 !== peg$FAILED) {
				s2.push(s3);
				if (peg$r1.test(input.charAt(peg$currPos))) {
					s3 = input.charAt(peg$currPos);
					peg$currPos++;
				} else s3 = peg$FAILED;
			}
			else s2 = peg$FAILED;
			if (s2 !== peg$FAILED) {
				s3 = peg$currPos;
				if (input.charCodeAt(peg$currPos) === 46) {
					s4 = peg$c1;
					peg$currPos++;
				} else s4 = peg$FAILED;
				if (s4 !== peg$FAILED) {
					s5 = [];
					if (peg$r1.test(input.charAt(peg$currPos))) {
						s6 = input.charAt(peg$currPos);
						peg$currPos++;
					} else s6 = peg$FAILED;
					if (s6 !== peg$FAILED) while (s6 !== peg$FAILED) {
						s5.push(s6);
						if (peg$r1.test(input.charAt(peg$currPos))) {
							s6 = input.charAt(peg$currPos);
							peg$currPos++;
						} else s6 = peg$FAILED;
					}
					else s5 = peg$FAILED;
					if (s5 !== peg$FAILED) {
						s4 = [s4, s5];
						s3 = s4;
					} else {
						peg$currPos = s3;
						s3 = peg$FAILED;
					}
				} else {
					peg$currPos = s3;
					s3 = peg$FAILED;
				}
				if (s3 === peg$FAILED) s3 = null;
				peg$savedPos = s0;
				s0 = peg$f27();
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			peg$silentFails--;
			return s0;
		}
		function peg$parseValueString() {
			var s0, s1, s2, s3;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			rule$expects(peg$e17);
			peg$silentFails++;
			s0 = peg$currPos;
			if (input.charCodeAt(peg$currPos) === 34) {
				s1 = peg$c16;
				peg$currPos++;
			} else s1 = peg$FAILED;
			if (s1 !== peg$FAILED) {
				s2 = [];
				s3 = peg$parseValueStringChars();
				while (s3 !== peg$FAILED) {
					s2.push(s3);
					s3 = peg$parseValueStringChars();
				}
				if (input.charCodeAt(peg$currPos) === 34) {
					s3 = peg$c16;
					peg$currPos++;
				} else s3 = peg$FAILED;
				if (s3 !== peg$FAILED) {
					peg$savedPos = s0;
					s0 = peg$f28(s2);
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			peg$silentFails--;
			return s0;
		}
		function peg$parseValueStringChars() {
			var s0;
			if (peg$r2.test(input.charAt(peg$currPos))) {
				s0 = input.charAt(peg$currPos);
				peg$currPos++;
			} else s0 = peg$FAILED;
			if (s0 === peg$FAILED) s0 = peg$parseValueStringEscapes();
			return s0;
		}
		function peg$parseValueStringEscapes() {
			var s0 = peg$currPos, s1, s2, s3;
			if (input.charCodeAt(peg$currPos) === 92) {
				s1 = peg$c17;
				peg$currPos++;
			} else s1 = peg$FAILED;
			if (s1 !== peg$FAILED) {
				if (input.charCodeAt(peg$currPos) === 34) {
					s2 = peg$c16;
					peg$currPos++;
				} else s2 = peg$FAILED;
				if (s2 === peg$FAILED) {
					if (input.charCodeAt(peg$currPos) === 92) {
						s2 = peg$c17;
						peg$currPos++;
					} else s2 = peg$FAILED;
					if (s2 === peg$FAILED) {
						s2 = peg$currPos;
						if (input.charCodeAt(peg$currPos) === 110) {
							s3 = peg$c18;
							peg$currPos++;
						} else s3 = peg$FAILED;
						if (s3 !== peg$FAILED) {
							peg$savedPos = s2;
							s3 = peg$f29();
						}
						s2 = s3;
						if (s2 === peg$FAILED) {
							s2 = peg$currPos;
							if (input.charCodeAt(peg$currPos) === 114) {
								s3 = peg$c19;
								peg$currPos++;
							} else s3 = peg$FAILED;
							if (s3 !== peg$FAILED) {
								peg$savedPos = s2;
								s3 = peg$f30();
							}
							s2 = s3;
							if (s2 === peg$FAILED) {
								s2 = peg$currPos;
								if (input.charCodeAt(peg$currPos) === 116) {
									s3 = peg$c20;
									peg$currPos++;
								} else s3 = peg$FAILED;
								if (s3 !== peg$FAILED) {
									peg$savedPos = s2;
									s3 = peg$f31();
								}
								s2 = s3;
							}
						}
					}
				}
				if (s2 !== peg$FAILED) {
					peg$savedPos = s0;
					s0 = peg$f32(s2);
				} else {
					peg$currPos = s0;
					s0 = peg$FAILED;
				}
			} else {
				peg$currPos = s0;
				s0 = peg$FAILED;
			}
			return s0;
		}
		function peg$parseIdentifier() {
			var s0, s1, s2;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			rule$expects(peg$e18);
			peg$silentFails++;
			s0 = peg$currPos;
			s1 = [];
			if (peg$r3.test(input.charAt(peg$currPos))) {
				s2 = input.charAt(peg$currPos);
				peg$currPos++;
			} else s2 = peg$FAILED;
			if (s2 !== peg$FAILED) while (s2 !== peg$FAILED) {
				s1.push(s2);
				if (peg$r3.test(input.charAt(peg$currPos))) {
					s2 = input.charAt(peg$currPos);
					peg$currPos++;
				} else s2 = peg$FAILED;
			}
			else s1 = peg$FAILED;
			if (s1 !== peg$FAILED) s0 = input.substring(s0, peg$currPos);
			else s0 = s1;
			peg$silentFails--;
			return s0;
		}
		function peg$parse_() {
			var s0;
			var rule$expects = function(expected2) {
				if (peg$silentFails === 0) peg$expect(expected2);
			};
			rule$expects(peg$e19);
			peg$silentFails++;
			if (peg$r4.test(input.charAt(peg$currPos))) {
				s0 = input.charAt(peg$currPos);
				peg$currPos++;
			} else s0 = peg$FAILED;
			peg$silentFails--;
			return s0;
		}
		const { Variable: Variable2, Function: Function3 } = options;
		peg$begin();
		peg$result = peg$startRuleFunction();
		if (peg$result !== peg$FAILED && peg$currPos === input.length) return peg$result;
		else {
			if (peg$result !== peg$FAILED && peg$currPos < input.length) peg$expect(peg$endExpectation());
			throw peg$buildError();
		}
	}
	module.exports = {
		SyntaxError: peg$SyntaxError,
		parse: peg$parse
	};
} });
var require_entities = __commonJS({ "node_modules/entities/lib/maps/entities.json"(exports, module) {
	module.exports = {
		Aacute: "Á",
		aacute: "á",
		Abreve: "Ă",
		abreve: "ă",
		ac: "∾",
		acd: "∿",
		acE: "∾̳",
		Acirc: "Â",
		acirc: "â",
		acute: "´",
		Acy: "А",
		acy: "а",
		AElig: "Æ",
		aelig: "æ",
		af: "⁡",
		Afr: "𝔄",
		afr: "𝔞",
		Agrave: "À",
		agrave: "à",
		alefsym: "ℵ",
		aleph: "ℵ",
		Alpha: "Α",
		alpha: "α",
		Amacr: "Ā",
		amacr: "ā",
		amalg: "⨿",
		amp: "&",
		AMP: "&",
		andand: "⩕",
		And: "⩓",
		and: "∧",
		andd: "⩜",
		andslope: "⩘",
		andv: "⩚",
		ang: "∠",
		ange: "⦤",
		angle: "∠",
		angmsdaa: "⦨",
		angmsdab: "⦩",
		angmsdac: "⦪",
		angmsdad: "⦫",
		angmsdae: "⦬",
		angmsdaf: "⦭",
		angmsdag: "⦮",
		angmsdah: "⦯",
		angmsd: "∡",
		angrt: "∟",
		angrtvb: "⊾",
		angrtvbd: "⦝",
		angsph: "∢",
		angst: "Å",
		angzarr: "⍼",
		Aogon: "Ą",
		aogon: "ą",
		Aopf: "𝔸",
		aopf: "𝕒",
		apacir: "⩯",
		ap: "≈",
		apE: "⩰",
		ape: "≊",
		apid: "≋",
		apos: "'",
		ApplyFunction: "⁡",
		approx: "≈",
		approxeq: "≊",
		Aring: "Å",
		aring: "å",
		Ascr: "𝒜",
		ascr: "𝒶",
		Assign: "≔",
		ast: "*",
		asymp: "≈",
		asympeq: "≍",
		Atilde: "Ã",
		atilde: "ã",
		Auml: "Ä",
		auml: "ä",
		awconint: "∳",
		awint: "⨑",
		backcong: "≌",
		backepsilon: "϶",
		backprime: "‵",
		backsim: "∽",
		backsimeq: "⋍",
		Backslash: "∖",
		Barv: "⫧",
		barvee: "⊽",
		barwed: "⌅",
		Barwed: "⌆",
		barwedge: "⌅",
		bbrk: "⎵",
		bbrktbrk: "⎶",
		bcong: "≌",
		Bcy: "Б",
		bcy: "б",
		bdquo: "„",
		becaus: "∵",
		because: "∵",
		Because: "∵",
		bemptyv: "⦰",
		bepsi: "϶",
		bernou: "ℬ",
		Bernoullis: "ℬ",
		Beta: "Β",
		beta: "β",
		beth: "ℶ",
		between: "≬",
		Bfr: "𝔅",
		bfr: "𝔟",
		bigcap: "⋂",
		bigcirc: "◯",
		bigcup: "⋃",
		bigodot: "⨀",
		bigoplus: "⨁",
		bigotimes: "⨂",
		bigsqcup: "⨆",
		bigstar: "★",
		bigtriangledown: "▽",
		bigtriangleup: "△",
		biguplus: "⨄",
		bigvee: "⋁",
		bigwedge: "⋀",
		bkarow: "⤍",
		blacklozenge: "⧫",
		blacksquare: "▪",
		blacktriangle: "▴",
		blacktriangledown: "▾",
		blacktriangleleft: "◂",
		blacktriangleright: "▸",
		blank: "␣",
		blk12: "▒",
		blk14: "░",
		blk34: "▓",
		block: "█",
		bne: "=⃥",
		bnequiv: "≡⃥",
		bNot: "⫭",
		bnot: "⌐",
		Bopf: "𝔹",
		bopf: "𝕓",
		bot: "⊥",
		bottom: "⊥",
		bowtie: "⋈",
		boxbox: "⧉",
		boxdl: "┐",
		boxdL: "╕",
		boxDl: "╖",
		boxDL: "╗",
		boxdr: "┌",
		boxdR: "╒",
		boxDr: "╓",
		boxDR: "╔",
		boxh: "─",
		boxH: "═",
		boxhd: "┬",
		boxHd: "╤",
		boxhD: "╥",
		boxHD: "╦",
		boxhu: "┴",
		boxHu: "╧",
		boxhU: "╨",
		boxHU: "╩",
		boxminus: "⊟",
		boxplus: "⊞",
		boxtimes: "⊠",
		boxul: "┘",
		boxuL: "╛",
		boxUl: "╜",
		boxUL: "╝",
		boxur: "└",
		boxuR: "╘",
		boxUr: "╙",
		boxUR: "╚",
		boxv: "│",
		boxV: "║",
		boxvh: "┼",
		boxvH: "╪",
		boxVh: "╫",
		boxVH: "╬",
		boxvl: "┤",
		boxvL: "╡",
		boxVl: "╢",
		boxVL: "╣",
		boxvr: "├",
		boxvR: "╞",
		boxVr: "╟",
		boxVR: "╠",
		bprime: "‵",
		breve: "˘",
		Breve: "˘",
		brvbar: "¦",
		bscr: "𝒷",
		Bscr: "ℬ",
		bsemi: "⁏",
		bsim: "∽",
		bsime: "⋍",
		bsolb: "⧅",
		bsol: "\\",
		bsolhsub: "⟈",
		bull: "•",
		bullet: "•",
		bump: "≎",
		bumpE: "⪮",
		bumpe: "≏",
		Bumpeq: "≎",
		bumpeq: "≏",
		Cacute: "Ć",
		cacute: "ć",
		capand: "⩄",
		capbrcup: "⩉",
		capcap: "⩋",
		cap: "∩",
		Cap: "⋒",
		capcup: "⩇",
		capdot: "⩀",
		CapitalDifferentialD: "ⅅ",
		caps: "∩︀",
		caret: "⁁",
		caron: "ˇ",
		Cayleys: "ℭ",
		ccaps: "⩍",
		Ccaron: "Č",
		ccaron: "č",
		Ccedil: "Ç",
		ccedil: "ç",
		Ccirc: "Ĉ",
		ccirc: "ĉ",
		Cconint: "∰",
		ccups: "⩌",
		ccupssm: "⩐",
		Cdot: "Ċ",
		cdot: "ċ",
		cedil: "¸",
		Cedilla: "¸",
		cemptyv: "⦲",
		cent: "¢",
		centerdot: "·",
		CenterDot: "·",
		cfr: "𝔠",
		Cfr: "ℭ",
		CHcy: "Ч",
		chcy: "ч",
		check: "✓",
		checkmark: "✓",
		Chi: "Χ",
		chi: "χ",
		circ: "ˆ",
		circeq: "≗",
		circlearrowleft: "↺",
		circlearrowright: "↻",
		circledast: "⊛",
		circledcirc: "⊚",
		circleddash: "⊝",
		CircleDot: "⊙",
		circledR: "®",
		circledS: "Ⓢ",
		CircleMinus: "⊖",
		CirclePlus: "⊕",
		CircleTimes: "⊗",
		cir: "○",
		cirE: "⧃",
		cire: "≗",
		cirfnint: "⨐",
		cirmid: "⫯",
		cirscir: "⧂",
		ClockwiseContourIntegral: "∲",
		CloseCurlyDoubleQuote: "”",
		CloseCurlyQuote: "’",
		clubs: "♣",
		clubsuit: "♣",
		colon: ":",
		Colon: "∷",
		Colone: "⩴",
		colone: "≔",
		coloneq: "≔",
		comma: ",",
		commat: "@",
		comp: "∁",
		compfn: "∘",
		complement: "∁",
		complexes: "ℂ",
		cong: "≅",
		congdot: "⩭",
		Congruent: "≡",
		conint: "∮",
		Conint: "∯",
		ContourIntegral: "∮",
		copf: "𝕔",
		Copf: "ℂ",
		coprod: "∐",
		Coproduct: "∐",
		copy: "©",
		COPY: "©",
		copysr: "℗",
		CounterClockwiseContourIntegral: "∳",
		crarr: "↵",
		cross: "✗",
		Cross: "⨯",
		Cscr: "𝒞",
		cscr: "𝒸",
		csub: "⫏",
		csube: "⫑",
		csup: "⫐",
		csupe: "⫒",
		ctdot: "⋯",
		cudarrl: "⤸",
		cudarrr: "⤵",
		cuepr: "⋞",
		cuesc: "⋟",
		cularr: "↶",
		cularrp: "⤽",
		cupbrcap: "⩈",
		cupcap: "⩆",
		CupCap: "≍",
		cup: "∪",
		Cup: "⋓",
		cupcup: "⩊",
		cupdot: "⊍",
		cupor: "⩅",
		cups: "∪︀",
		curarr: "↷",
		curarrm: "⤼",
		curlyeqprec: "⋞",
		curlyeqsucc: "⋟",
		curlyvee: "⋎",
		curlywedge: "⋏",
		curren: "¤",
		curvearrowleft: "↶",
		curvearrowright: "↷",
		cuvee: "⋎",
		cuwed: "⋏",
		cwconint: "∲",
		cwint: "∱",
		cylcty: "⌭",
		dagger: "†",
		Dagger: "‡",
		daleth: "ℸ",
		darr: "↓",
		Darr: "↡",
		dArr: "⇓",
		dash: "‐",
		Dashv: "⫤",
		dashv: "⊣",
		dbkarow: "⤏",
		dblac: "˝",
		Dcaron: "Ď",
		dcaron: "ď",
		Dcy: "Д",
		dcy: "д",
		ddagger: "‡",
		ddarr: "⇊",
		DD: "ⅅ",
		dd: "ⅆ",
		DDotrahd: "⤑",
		ddotseq: "⩷",
		deg: "°",
		Del: "∇",
		Delta: "Δ",
		delta: "δ",
		demptyv: "⦱",
		dfisht: "⥿",
		Dfr: "𝔇",
		dfr: "𝔡",
		dHar: "⥥",
		dharl: "⇃",
		dharr: "⇂",
		DiacriticalAcute: "´",
		DiacriticalDot: "˙",
		DiacriticalDoubleAcute: "˝",
		DiacriticalGrave: "`",
		DiacriticalTilde: "˜",
		diam: "⋄",
		diamond: "⋄",
		Diamond: "⋄",
		diamondsuit: "♦",
		diams: "♦",
		die: "¨",
		DifferentialD: "ⅆ",
		digamma: "ϝ",
		disin: "⋲",
		div: "÷",
		divide: "÷",
		divideontimes: "⋇",
		divonx: "⋇",
		DJcy: "Ђ",
		djcy: "ђ",
		dlcorn: "⌞",
		dlcrop: "⌍",
		dollar: "$",
		Dopf: "𝔻",
		dopf: "𝕕",
		Dot: "¨",
		dot: "˙",
		DotDot: "⃜",
		doteq: "≐",
		doteqdot: "≑",
		DotEqual: "≐",
		dotminus: "∸",
		dotplus: "∔",
		dotsquare: "⊡",
		doublebarwedge: "⌆",
		DoubleContourIntegral: "∯",
		DoubleDot: "¨",
		DoubleDownArrow: "⇓",
		DoubleLeftArrow: "⇐",
		DoubleLeftRightArrow: "⇔",
		DoubleLeftTee: "⫤",
		DoubleLongLeftArrow: "⟸",
		DoubleLongLeftRightArrow: "⟺",
		DoubleLongRightArrow: "⟹",
		DoubleRightArrow: "⇒",
		DoubleRightTee: "⊨",
		DoubleUpArrow: "⇑",
		DoubleUpDownArrow: "⇕",
		DoubleVerticalBar: "∥",
		DownArrowBar: "⤓",
		downarrow: "↓",
		DownArrow: "↓",
		Downarrow: "⇓",
		DownArrowUpArrow: "⇵",
		DownBreve: "̑",
		downdownarrows: "⇊",
		downharpoonleft: "⇃",
		downharpoonright: "⇂",
		DownLeftRightVector: "⥐",
		DownLeftTeeVector: "⥞",
		DownLeftVectorBar: "⥖",
		DownLeftVector: "↽",
		DownRightTeeVector: "⥟",
		DownRightVectorBar: "⥗",
		DownRightVector: "⇁",
		DownTeeArrow: "↧",
		DownTee: "⊤",
		drbkarow: "⤐",
		drcorn: "⌟",
		drcrop: "⌌",
		Dscr: "𝒟",
		dscr: "𝒹",
		DScy: "Ѕ",
		dscy: "ѕ",
		dsol: "⧶",
		Dstrok: "Đ",
		dstrok: "đ",
		dtdot: "⋱",
		dtri: "▿",
		dtrif: "▾",
		duarr: "⇵",
		duhar: "⥯",
		dwangle: "⦦",
		DZcy: "Џ",
		dzcy: "џ",
		dzigrarr: "⟿",
		Eacute: "É",
		eacute: "é",
		easter: "⩮",
		Ecaron: "Ě",
		ecaron: "ě",
		Ecirc: "Ê",
		ecirc: "ê",
		ecir: "≖",
		ecolon: "≕",
		Ecy: "Э",
		ecy: "э",
		eDDot: "⩷",
		Edot: "Ė",
		edot: "ė",
		eDot: "≑",
		ee: "ⅇ",
		efDot: "≒",
		Efr: "𝔈",
		efr: "𝔢",
		eg: "⪚",
		Egrave: "È",
		egrave: "è",
		egs: "⪖",
		egsdot: "⪘",
		el: "⪙",
		Element: "∈",
		elinters: "⏧",
		ell: "ℓ",
		els: "⪕",
		elsdot: "⪗",
		Emacr: "Ē",
		emacr: "ē",
		empty: "∅",
		emptyset: "∅",
		EmptySmallSquare: "◻",
		emptyv: "∅",
		EmptyVerySmallSquare: "▫",
		emsp13: " ",
		emsp14: " ",
		emsp: " ",
		ENG: "Ŋ",
		eng: "ŋ",
		ensp: " ",
		Eogon: "Ę",
		eogon: "ę",
		Eopf: "𝔼",
		eopf: "𝕖",
		epar: "⋕",
		eparsl: "⧣",
		eplus: "⩱",
		epsi: "ε",
		Epsilon: "Ε",
		epsilon: "ε",
		epsiv: "ϵ",
		eqcirc: "≖",
		eqcolon: "≕",
		eqsim: "≂",
		eqslantgtr: "⪖",
		eqslantless: "⪕",
		Equal: "⩵",
		equals: "=",
		EqualTilde: "≂",
		equest: "≟",
		Equilibrium: "⇌",
		equiv: "≡",
		equivDD: "⩸",
		eqvparsl: "⧥",
		erarr: "⥱",
		erDot: "≓",
		escr: "ℯ",
		Escr: "ℰ",
		esdot: "≐",
		Esim: "⩳",
		esim: "≂",
		Eta: "Η",
		eta: "η",
		ETH: "Ð",
		eth: "ð",
		Euml: "Ë",
		euml: "ë",
		euro: "€",
		excl: "!",
		exist: "∃",
		Exists: "∃",
		expectation: "ℰ",
		exponentiale: "ⅇ",
		ExponentialE: "ⅇ",
		fallingdotseq: "≒",
		Fcy: "Ф",
		fcy: "ф",
		female: "♀",
		ffilig: "ﬃ",
		fflig: "ﬀ",
		ffllig: "ﬄ",
		Ffr: "𝔉",
		ffr: "𝔣",
		filig: "ﬁ",
		FilledSmallSquare: "◼",
		FilledVerySmallSquare: "▪",
		fjlig: "fj",
		flat: "♭",
		fllig: "ﬂ",
		fltns: "▱",
		fnof: "ƒ",
		Fopf: "𝔽",
		fopf: "𝕗",
		forall: "∀",
		ForAll: "∀",
		fork: "⋔",
		forkv: "⫙",
		Fouriertrf: "ℱ",
		fpartint: "⨍",
		frac12: "½",
		frac13: "⅓",
		frac14: "¼",
		frac15: "⅕",
		frac16: "⅙",
		frac18: "⅛",
		frac23: "⅔",
		frac25: "⅖",
		frac34: "¾",
		frac35: "⅗",
		frac38: "⅜",
		frac45: "⅘",
		frac56: "⅚",
		frac58: "⅝",
		frac78: "⅞",
		frasl: "⁄",
		frown: "⌢",
		fscr: "𝒻",
		Fscr: "ℱ",
		gacute: "ǵ",
		Gamma: "Γ",
		gamma: "γ",
		Gammad: "Ϝ",
		gammad: "ϝ",
		gap: "⪆",
		Gbreve: "Ğ",
		gbreve: "ğ",
		Gcedil: "Ģ",
		Gcirc: "Ĝ",
		gcirc: "ĝ",
		Gcy: "Г",
		gcy: "г",
		Gdot: "Ġ",
		gdot: "ġ",
		ge: "≥",
		gE: "≧",
		gEl: "⪌",
		gel: "⋛",
		geq: "≥",
		geqq: "≧",
		geqslant: "⩾",
		gescc: "⪩",
		ges: "⩾",
		gesdot: "⪀",
		gesdoto: "⪂",
		gesdotol: "⪄",
		gesl: "⋛︀",
		gesles: "⪔",
		Gfr: "𝔊",
		gfr: "𝔤",
		gg: "≫",
		Gg: "⋙",
		ggg: "⋙",
		gimel: "ℷ",
		GJcy: "Ѓ",
		gjcy: "ѓ",
		gla: "⪥",
		gl: "≷",
		glE: "⪒",
		glj: "⪤",
		gnap: "⪊",
		gnapprox: "⪊",
		gne: "⪈",
		gnE: "≩",
		gneq: "⪈",
		gneqq: "≩",
		gnsim: "⋧",
		Gopf: "𝔾",
		gopf: "𝕘",
		grave: "`",
		GreaterEqual: "≥",
		GreaterEqualLess: "⋛",
		GreaterFullEqual: "≧",
		GreaterGreater: "⪢",
		GreaterLess: "≷",
		GreaterSlantEqual: "⩾",
		GreaterTilde: "≳",
		Gscr: "𝒢",
		gscr: "ℊ",
		gsim: "≳",
		gsime: "⪎",
		gsiml: "⪐",
		gtcc: "⪧",
		gtcir: "⩺",
		gt: ">",
		GT: ">",
		Gt: "≫",
		gtdot: "⋗",
		gtlPar: "⦕",
		gtquest: "⩼",
		gtrapprox: "⪆",
		gtrarr: "⥸",
		gtrdot: "⋗",
		gtreqless: "⋛",
		gtreqqless: "⪌",
		gtrless: "≷",
		gtrsim: "≳",
		gvertneqq: "≩︀",
		gvnE: "≩︀",
		Hacek: "ˇ",
		hairsp: " ",
		half: "½",
		hamilt: "ℋ",
		HARDcy: "Ъ",
		hardcy: "ъ",
		harrcir: "⥈",
		harr: "↔",
		hArr: "⇔",
		harrw: "↭",
		Hat: "^",
		hbar: "ℏ",
		Hcirc: "Ĥ",
		hcirc: "ĥ",
		hearts: "♥",
		heartsuit: "♥",
		hellip: "…",
		hercon: "⊹",
		hfr: "𝔥",
		Hfr: "ℌ",
		HilbertSpace: "ℋ",
		hksearow: "⤥",
		hkswarow: "⤦",
		hoarr: "⇿",
		homtht: "∻",
		hookleftarrow: "↩",
		hookrightarrow: "↪",
		hopf: "𝕙",
		Hopf: "ℍ",
		horbar: "―",
		HorizontalLine: "─",
		hscr: "𝒽",
		Hscr: "ℋ",
		hslash: "ℏ",
		Hstrok: "Ħ",
		hstrok: "ħ",
		HumpDownHump: "≎",
		HumpEqual: "≏",
		hybull: "⁃",
		hyphen: "‐",
		Iacute: "Í",
		iacute: "í",
		ic: "⁣",
		Icirc: "Î",
		icirc: "î",
		Icy: "И",
		icy: "и",
		Idot: "İ",
		IEcy: "Е",
		iecy: "е",
		iexcl: "¡",
		iff: "⇔",
		ifr: "𝔦",
		Ifr: "ℑ",
		Igrave: "Ì",
		igrave: "ì",
		ii: "ⅈ",
		iiiint: "⨌",
		iiint: "∭",
		iinfin: "⧜",
		iiota: "℩",
		IJlig: "Ĳ",
		ijlig: "ĳ",
		Imacr: "Ī",
		imacr: "ī",
		image: "ℑ",
		ImaginaryI: "ⅈ",
		imagline: "ℐ",
		imagpart: "ℑ",
		imath: "ı",
		Im: "ℑ",
		imof: "⊷",
		imped: "Ƶ",
		Implies: "⇒",
		incare: "℅",
		in: "∈",
		infin: "∞",
		infintie: "⧝",
		inodot: "ı",
		intcal: "⊺",
		int: "∫",
		Int: "∬",
		integers: "ℤ",
		Integral: "∫",
		intercal: "⊺",
		Intersection: "⋂",
		intlarhk: "⨗",
		intprod: "⨼",
		InvisibleComma: "⁣",
		InvisibleTimes: "⁢",
		IOcy: "Ё",
		iocy: "ё",
		Iogon: "Į",
		iogon: "į",
		Iopf: "𝕀",
		iopf: "𝕚",
		Iota: "Ι",
		iota: "ι",
		iprod: "⨼",
		iquest: "¿",
		iscr: "𝒾",
		Iscr: "ℐ",
		isin: "∈",
		isindot: "⋵",
		isinE: "⋹",
		isins: "⋴",
		isinsv: "⋳",
		isinv: "∈",
		it: "⁢",
		Itilde: "Ĩ",
		itilde: "ĩ",
		Iukcy: "І",
		iukcy: "і",
		Iuml: "Ï",
		iuml: "ï",
		Jcirc: "Ĵ",
		jcirc: "ĵ",
		Jcy: "Й",
		jcy: "й",
		Jfr: "𝔍",
		jfr: "𝔧",
		jmath: "ȷ",
		Jopf: "𝕁",
		jopf: "𝕛",
		Jscr: "𝒥",
		jscr: "𝒿",
		Jsercy: "Ј",
		jsercy: "ј",
		Jukcy: "Є",
		jukcy: "є",
		Kappa: "Κ",
		kappa: "κ",
		kappav: "ϰ",
		Kcedil: "Ķ",
		kcedil: "ķ",
		Kcy: "К",
		kcy: "к",
		Kfr: "𝔎",
		kfr: "𝔨",
		kgreen: "ĸ",
		KHcy: "Х",
		khcy: "х",
		KJcy: "Ќ",
		kjcy: "ќ",
		Kopf: "𝕂",
		kopf: "𝕜",
		Kscr: "𝒦",
		kscr: "𝓀",
		lAarr: "⇚",
		Lacute: "Ĺ",
		lacute: "ĺ",
		laemptyv: "⦴",
		lagran: "ℒ",
		Lambda: "Λ",
		lambda: "λ",
		lang: "⟨",
		Lang: "⟪",
		langd: "⦑",
		langle: "⟨",
		lap: "⪅",
		Laplacetrf: "ℒ",
		laquo: "«",
		larrb: "⇤",
		larrbfs: "⤟",
		larr: "←",
		Larr: "↞",
		lArr: "⇐",
		larrfs: "⤝",
		larrhk: "↩",
		larrlp: "↫",
		larrpl: "⤹",
		larrsim: "⥳",
		larrtl: "↢",
		latail: "⤙",
		lAtail: "⤛",
		lat: "⪫",
		late: "⪭",
		lates: "⪭︀",
		lbarr: "⤌",
		lBarr: "⤎",
		lbbrk: "❲",
		lbrace: "{",
		lbrack: "[",
		lbrke: "⦋",
		lbrksld: "⦏",
		lbrkslu: "⦍",
		Lcaron: "Ľ",
		lcaron: "ľ",
		Lcedil: "Ļ",
		lcedil: "ļ",
		lceil: "⌈",
		lcub: "{",
		Lcy: "Л",
		lcy: "л",
		ldca: "⤶",
		ldquo: "“",
		ldquor: "„",
		ldrdhar: "⥧",
		ldrushar: "⥋",
		ldsh: "↲",
		le: "≤",
		lE: "≦",
		LeftAngleBracket: "⟨",
		LeftArrowBar: "⇤",
		leftarrow: "←",
		LeftArrow: "←",
		Leftarrow: "⇐",
		LeftArrowRightArrow: "⇆",
		leftarrowtail: "↢",
		LeftCeiling: "⌈",
		LeftDoubleBracket: "⟦",
		LeftDownTeeVector: "⥡",
		LeftDownVectorBar: "⥙",
		LeftDownVector: "⇃",
		LeftFloor: "⌊",
		leftharpoondown: "↽",
		leftharpoonup: "↼",
		leftleftarrows: "⇇",
		leftrightarrow: "↔",
		LeftRightArrow: "↔",
		Leftrightarrow: "⇔",
		leftrightarrows: "⇆",
		leftrightharpoons: "⇋",
		leftrightsquigarrow: "↭",
		LeftRightVector: "⥎",
		LeftTeeArrow: "↤",
		LeftTee: "⊣",
		LeftTeeVector: "⥚",
		leftthreetimes: "⋋",
		LeftTriangleBar: "⧏",
		LeftTriangle: "⊲",
		LeftTriangleEqual: "⊴",
		LeftUpDownVector: "⥑",
		LeftUpTeeVector: "⥠",
		LeftUpVectorBar: "⥘",
		LeftUpVector: "↿",
		LeftVectorBar: "⥒",
		LeftVector: "↼",
		lEg: "⪋",
		leg: "⋚",
		leq: "≤",
		leqq: "≦",
		leqslant: "⩽",
		lescc: "⪨",
		les: "⩽",
		lesdot: "⩿",
		lesdoto: "⪁",
		lesdotor: "⪃",
		lesg: "⋚︀",
		lesges: "⪓",
		lessapprox: "⪅",
		lessdot: "⋖",
		lesseqgtr: "⋚",
		lesseqqgtr: "⪋",
		LessEqualGreater: "⋚",
		LessFullEqual: "≦",
		LessGreater: "≶",
		lessgtr: "≶",
		LessLess: "⪡",
		lesssim: "≲",
		LessSlantEqual: "⩽",
		LessTilde: "≲",
		lfisht: "⥼",
		lfloor: "⌊",
		Lfr: "𝔏",
		lfr: "𝔩",
		lg: "≶",
		lgE: "⪑",
		lHar: "⥢",
		lhard: "↽",
		lharu: "↼",
		lharul: "⥪",
		lhblk: "▄",
		LJcy: "Љ",
		ljcy: "љ",
		llarr: "⇇",
		ll: "≪",
		Ll: "⋘",
		llcorner: "⌞",
		Lleftarrow: "⇚",
		llhard: "⥫",
		lltri: "◺",
		Lmidot: "Ŀ",
		lmidot: "ŀ",
		lmoustache: "⎰",
		lmoust: "⎰",
		lnap: "⪉",
		lnapprox: "⪉",
		lne: "⪇",
		lnE: "≨",
		lneq: "⪇",
		lneqq: "≨",
		lnsim: "⋦",
		loang: "⟬",
		loarr: "⇽",
		lobrk: "⟦",
		longleftarrow: "⟵",
		LongLeftArrow: "⟵",
		Longleftarrow: "⟸",
		longleftrightarrow: "⟷",
		LongLeftRightArrow: "⟷",
		Longleftrightarrow: "⟺",
		longmapsto: "⟼",
		longrightarrow: "⟶",
		LongRightArrow: "⟶",
		Longrightarrow: "⟹",
		looparrowleft: "↫",
		looparrowright: "↬",
		lopar: "⦅",
		Lopf: "𝕃",
		lopf: "𝕝",
		loplus: "⨭",
		lotimes: "⨴",
		lowast: "∗",
		lowbar: "_",
		LowerLeftArrow: "↙",
		LowerRightArrow: "↘",
		loz: "◊",
		lozenge: "◊",
		lozf: "⧫",
		lpar: "(",
		lparlt: "⦓",
		lrarr: "⇆",
		lrcorner: "⌟",
		lrhar: "⇋",
		lrhard: "⥭",
		lrm: "‎",
		lrtri: "⊿",
		lsaquo: "‹",
		lscr: "𝓁",
		Lscr: "ℒ",
		lsh: "↰",
		Lsh: "↰",
		lsim: "≲",
		lsime: "⪍",
		lsimg: "⪏",
		lsqb: "[",
		lsquo: "‘",
		lsquor: "‚",
		Lstrok: "Ł",
		lstrok: "ł",
		ltcc: "⪦",
		ltcir: "⩹",
		lt: "<",
		LT: "<",
		Lt: "≪",
		ltdot: "⋖",
		lthree: "⋋",
		ltimes: "⋉",
		ltlarr: "⥶",
		ltquest: "⩻",
		ltri: "◃",
		ltrie: "⊴",
		ltrif: "◂",
		ltrPar: "⦖",
		lurdshar: "⥊",
		luruhar: "⥦",
		lvertneqq: "≨︀",
		lvnE: "≨︀",
		macr: "¯",
		male: "♂",
		malt: "✠",
		maltese: "✠",
		Map: "⤅",
		map: "↦",
		mapsto: "↦",
		mapstodown: "↧",
		mapstoleft: "↤",
		mapstoup: "↥",
		marker: "▮",
		mcomma: "⨩",
		Mcy: "М",
		mcy: "м",
		mdash: "—",
		mDDot: "∺",
		measuredangle: "∡",
		MediumSpace: " ",
		Mellintrf: "ℳ",
		Mfr: "𝔐",
		mfr: "𝔪",
		mho: "℧",
		micro: "µ",
		midast: "*",
		midcir: "⫰",
		mid: "∣",
		middot: "·",
		minusb: "⊟",
		minus: "−",
		minusd: "∸",
		minusdu: "⨪",
		MinusPlus: "∓",
		mlcp: "⫛",
		mldr: "…",
		mnplus: "∓",
		models: "⊧",
		Mopf: "𝕄",
		mopf: "𝕞",
		mp: "∓",
		mscr: "𝓂",
		Mscr: "ℳ",
		mstpos: "∾",
		Mu: "Μ",
		mu: "μ",
		multimap: "⊸",
		mumap: "⊸",
		nabla: "∇",
		Nacute: "Ń",
		nacute: "ń",
		nang: "∠⃒",
		nap: "≉",
		napE: "⩰̸",
		napid: "≋̸",
		napos: "ŉ",
		napprox: "≉",
		natural: "♮",
		naturals: "ℕ",
		natur: "♮",
		nbsp: "\xA0",
		nbump: "≎̸",
		nbumpe: "≏̸",
		ncap: "⩃",
		Ncaron: "Ň",
		ncaron: "ň",
		Ncedil: "Ņ",
		ncedil: "ņ",
		ncong: "≇",
		ncongdot: "⩭̸",
		ncup: "⩂",
		Ncy: "Н",
		ncy: "н",
		ndash: "–",
		nearhk: "⤤",
		nearr: "↗",
		neArr: "⇗",
		nearrow: "↗",
		ne: "≠",
		nedot: "≐̸",
		NegativeMediumSpace: "​",
		NegativeThickSpace: "​",
		NegativeThinSpace: "​",
		NegativeVeryThinSpace: "​",
		nequiv: "≢",
		nesear: "⤨",
		nesim: "≂̸",
		NestedGreaterGreater: "≫",
		NestedLessLess: "≪",
		NewLine: "\n",
		nexist: "∄",
		nexists: "∄",
		Nfr: "𝔑",
		nfr: "𝔫",
		ngE: "≧̸",
		nge: "≱",
		ngeq: "≱",
		ngeqq: "≧̸",
		ngeqslant: "⩾̸",
		nges: "⩾̸",
		nGg: "⋙̸",
		ngsim: "≵",
		nGt: "≫⃒",
		ngt: "≯",
		ngtr: "≯",
		nGtv: "≫̸",
		nharr: "↮",
		nhArr: "⇎",
		nhpar: "⫲",
		ni: "∋",
		nis: "⋼",
		nisd: "⋺",
		niv: "∋",
		NJcy: "Њ",
		njcy: "њ",
		nlarr: "↚",
		nlArr: "⇍",
		nldr: "‥",
		nlE: "≦̸",
		nle: "≰",
		nleftarrow: "↚",
		nLeftarrow: "⇍",
		nleftrightarrow: "↮",
		nLeftrightarrow: "⇎",
		nleq: "≰",
		nleqq: "≦̸",
		nleqslant: "⩽̸",
		nles: "⩽̸",
		nless: "≮",
		nLl: "⋘̸",
		nlsim: "≴",
		nLt: "≪⃒",
		nlt: "≮",
		nltri: "⋪",
		nltrie: "⋬",
		nLtv: "≪̸",
		nmid: "∤",
		NoBreak: "⁠",
		NonBreakingSpace: "\xA0",
		nopf: "𝕟",
		Nopf: "ℕ",
		Not: "⫬",
		not: "¬",
		NotCongruent: "≢",
		NotCupCap: "≭",
		NotDoubleVerticalBar: "∦",
		NotElement: "∉",
		NotEqual: "≠",
		NotEqualTilde: "≂̸",
		NotExists: "∄",
		NotGreater: "≯",
		NotGreaterEqual: "≱",
		NotGreaterFullEqual: "≧̸",
		NotGreaterGreater: "≫̸",
		NotGreaterLess: "≹",
		NotGreaterSlantEqual: "⩾̸",
		NotGreaterTilde: "≵",
		NotHumpDownHump: "≎̸",
		NotHumpEqual: "≏̸",
		notin: "∉",
		notindot: "⋵̸",
		notinE: "⋹̸",
		notinva: "∉",
		notinvb: "⋷",
		notinvc: "⋶",
		NotLeftTriangleBar: "⧏̸",
		NotLeftTriangle: "⋪",
		NotLeftTriangleEqual: "⋬",
		NotLess: "≮",
		NotLessEqual: "≰",
		NotLessGreater: "≸",
		NotLessLess: "≪̸",
		NotLessSlantEqual: "⩽̸",
		NotLessTilde: "≴",
		NotNestedGreaterGreater: "⪢̸",
		NotNestedLessLess: "⪡̸",
		notni: "∌",
		notniva: "∌",
		notnivb: "⋾",
		notnivc: "⋽",
		NotPrecedes: "⊀",
		NotPrecedesEqual: "⪯̸",
		NotPrecedesSlantEqual: "⋠",
		NotReverseElement: "∌",
		NotRightTriangleBar: "⧐̸",
		NotRightTriangle: "⋫",
		NotRightTriangleEqual: "⋭",
		NotSquareSubset: "⊏̸",
		NotSquareSubsetEqual: "⋢",
		NotSquareSuperset: "⊐̸",
		NotSquareSupersetEqual: "⋣",
		NotSubset: "⊂⃒",
		NotSubsetEqual: "⊈",
		NotSucceeds: "⊁",
		NotSucceedsEqual: "⪰̸",
		NotSucceedsSlantEqual: "⋡",
		NotSucceedsTilde: "≿̸",
		NotSuperset: "⊃⃒",
		NotSupersetEqual: "⊉",
		NotTilde: "≁",
		NotTildeEqual: "≄",
		NotTildeFullEqual: "≇",
		NotTildeTilde: "≉",
		NotVerticalBar: "∤",
		nparallel: "∦",
		npar: "∦",
		nparsl: "⫽⃥",
		npart: "∂̸",
		npolint: "⨔",
		npr: "⊀",
		nprcue: "⋠",
		nprec: "⊀",
		npreceq: "⪯̸",
		npre: "⪯̸",
		nrarrc: "⤳̸",
		nrarr: "↛",
		nrArr: "⇏",
		nrarrw: "↝̸",
		nrightarrow: "↛",
		nRightarrow: "⇏",
		nrtri: "⋫",
		nrtrie: "⋭",
		nsc: "⊁",
		nsccue: "⋡",
		nsce: "⪰̸",
		Nscr: "𝒩",
		nscr: "𝓃",
		nshortmid: "∤",
		nshortparallel: "∦",
		nsim: "≁",
		nsime: "≄",
		nsimeq: "≄",
		nsmid: "∤",
		nspar: "∦",
		nsqsube: "⋢",
		nsqsupe: "⋣",
		nsub: "⊄",
		nsubE: "⫅̸",
		nsube: "⊈",
		nsubset: "⊂⃒",
		nsubseteq: "⊈",
		nsubseteqq: "⫅̸",
		nsucc: "⊁",
		nsucceq: "⪰̸",
		nsup: "⊅",
		nsupE: "⫆̸",
		nsupe: "⊉",
		nsupset: "⊃⃒",
		nsupseteq: "⊉",
		nsupseteqq: "⫆̸",
		ntgl: "≹",
		Ntilde: "Ñ",
		ntilde: "ñ",
		ntlg: "≸",
		ntriangleleft: "⋪",
		ntrianglelefteq: "⋬",
		ntriangleright: "⋫",
		ntrianglerighteq: "⋭",
		Nu: "Ν",
		nu: "ν",
		num: "#",
		numero: "№",
		numsp: " ",
		nvap: "≍⃒",
		nvdash: "⊬",
		nvDash: "⊭",
		nVdash: "⊮",
		nVDash: "⊯",
		nvge: "≥⃒",
		nvgt: ">⃒",
		nvHarr: "⤄",
		nvinfin: "⧞",
		nvlArr: "⤂",
		nvle: "≤⃒",
		nvlt: "<⃒",
		nvltrie: "⊴⃒",
		nvrArr: "⤃",
		nvrtrie: "⊵⃒",
		nvsim: "∼⃒",
		nwarhk: "⤣",
		nwarr: "↖",
		nwArr: "⇖",
		nwarrow: "↖",
		nwnear: "⤧",
		Oacute: "Ó",
		oacute: "ó",
		oast: "⊛",
		Ocirc: "Ô",
		ocirc: "ô",
		ocir: "⊚",
		Ocy: "О",
		ocy: "о",
		odash: "⊝",
		Odblac: "Ő",
		odblac: "ő",
		odiv: "⨸",
		odot: "⊙",
		odsold: "⦼",
		OElig: "Œ",
		oelig: "œ",
		ofcir: "⦿",
		Ofr: "𝔒",
		ofr: "𝔬",
		ogon: "˛",
		Ograve: "Ò",
		ograve: "ò",
		ogt: "⧁",
		ohbar: "⦵",
		ohm: "Ω",
		oint: "∮",
		olarr: "↺",
		olcir: "⦾",
		olcross: "⦻",
		oline: "‾",
		olt: "⧀",
		Omacr: "Ō",
		omacr: "ō",
		Omega: "Ω",
		omega: "ω",
		Omicron: "Ο",
		omicron: "ο",
		omid: "⦶",
		ominus: "⊖",
		Oopf: "𝕆",
		oopf: "𝕠",
		opar: "⦷",
		OpenCurlyDoubleQuote: "“",
		OpenCurlyQuote: "‘",
		operp: "⦹",
		oplus: "⊕",
		orarr: "↻",
		Or: "⩔",
		or: "∨",
		ord: "⩝",
		order: "ℴ",
		orderof: "ℴ",
		ordf: "ª",
		ordm: "º",
		origof: "⊶",
		oror: "⩖",
		orslope: "⩗",
		orv: "⩛",
		oS: "Ⓢ",
		Oscr: "𝒪",
		oscr: "ℴ",
		Oslash: "Ø",
		oslash: "ø",
		osol: "⊘",
		Otilde: "Õ",
		otilde: "õ",
		otimesas: "⨶",
		Otimes: "⨷",
		otimes: "⊗",
		Ouml: "Ö",
		ouml: "ö",
		ovbar: "⌽",
		OverBar: "‾",
		OverBrace: "⏞",
		OverBracket: "⎴",
		OverParenthesis: "⏜",
		para: "¶",
		parallel: "∥",
		par: "∥",
		parsim: "⫳",
		parsl: "⫽",
		part: "∂",
		PartialD: "∂",
		Pcy: "П",
		pcy: "п",
		percnt: "%",
		period: ".",
		permil: "‰",
		perp: "⊥",
		pertenk: "‱",
		Pfr: "𝔓",
		pfr: "𝔭",
		Phi: "Φ",
		phi: "φ",
		phiv: "ϕ",
		phmmat: "ℳ",
		phone: "☎",
		Pi: "Π",
		pi: "π",
		pitchfork: "⋔",
		piv: "ϖ",
		planck: "ℏ",
		planckh: "ℎ",
		plankv: "ℏ",
		plusacir: "⨣",
		plusb: "⊞",
		pluscir: "⨢",
		plus: "+",
		plusdo: "∔",
		plusdu: "⨥",
		pluse: "⩲",
		PlusMinus: "±",
		plusmn: "±",
		plussim: "⨦",
		plustwo: "⨧",
		pm: "±",
		Poincareplane: "ℌ",
		pointint: "⨕",
		popf: "𝕡",
		Popf: "ℙ",
		pound: "£",
		prap: "⪷",
		Pr: "⪻",
		pr: "≺",
		prcue: "≼",
		precapprox: "⪷",
		prec: "≺",
		preccurlyeq: "≼",
		Precedes: "≺",
		PrecedesEqual: "⪯",
		PrecedesSlantEqual: "≼",
		PrecedesTilde: "≾",
		preceq: "⪯",
		precnapprox: "⪹",
		precneqq: "⪵",
		precnsim: "⋨",
		pre: "⪯",
		prE: "⪳",
		precsim: "≾",
		prime: "′",
		Prime: "″",
		primes: "ℙ",
		prnap: "⪹",
		prnE: "⪵",
		prnsim: "⋨",
		prod: "∏",
		Product: "∏",
		profalar: "⌮",
		profline: "⌒",
		profsurf: "⌓",
		prop: "∝",
		Proportional: "∝",
		Proportion: "∷",
		propto: "∝",
		prsim: "≾",
		prurel: "⊰",
		Pscr: "𝒫",
		pscr: "𝓅",
		Psi: "Ψ",
		psi: "ψ",
		puncsp: " ",
		Qfr: "𝔔",
		qfr: "𝔮",
		qint: "⨌",
		qopf: "𝕢",
		Qopf: "ℚ",
		qprime: "⁗",
		Qscr: "𝒬",
		qscr: "𝓆",
		quaternions: "ℍ",
		quatint: "⨖",
		quest: "?",
		questeq: "≟",
		quot: "\"",
		QUOT: "\"",
		rAarr: "⇛",
		race: "∽̱",
		Racute: "Ŕ",
		racute: "ŕ",
		radic: "√",
		raemptyv: "⦳",
		rang: "⟩",
		Rang: "⟫",
		rangd: "⦒",
		range: "⦥",
		rangle: "⟩",
		raquo: "»",
		rarrap: "⥵",
		rarrb: "⇥",
		rarrbfs: "⤠",
		rarrc: "⤳",
		rarr: "→",
		Rarr: "↠",
		rArr: "⇒",
		rarrfs: "⤞",
		rarrhk: "↪",
		rarrlp: "↬",
		rarrpl: "⥅",
		rarrsim: "⥴",
		Rarrtl: "⤖",
		rarrtl: "↣",
		rarrw: "↝",
		ratail: "⤚",
		rAtail: "⤜",
		ratio: "∶",
		rationals: "ℚ",
		rbarr: "⤍",
		rBarr: "⤏",
		RBarr: "⤐",
		rbbrk: "❳",
		rbrace: "}",
		rbrack: "]",
		rbrke: "⦌",
		rbrksld: "⦎",
		rbrkslu: "⦐",
		Rcaron: "Ř",
		rcaron: "ř",
		Rcedil: "Ŗ",
		rcedil: "ŗ",
		rceil: "⌉",
		rcub: "}",
		Rcy: "Р",
		rcy: "р",
		rdca: "⤷",
		rdldhar: "⥩",
		rdquo: "”",
		rdquor: "”",
		rdsh: "↳",
		real: "ℜ",
		realine: "ℛ",
		realpart: "ℜ",
		reals: "ℝ",
		Re: "ℜ",
		rect: "▭",
		reg: "®",
		REG: "®",
		ReverseElement: "∋",
		ReverseEquilibrium: "⇋",
		ReverseUpEquilibrium: "⥯",
		rfisht: "⥽",
		rfloor: "⌋",
		rfr: "𝔯",
		Rfr: "ℜ",
		rHar: "⥤",
		rhard: "⇁",
		rharu: "⇀",
		rharul: "⥬",
		Rho: "Ρ",
		rho: "ρ",
		rhov: "ϱ",
		RightAngleBracket: "⟩",
		RightArrowBar: "⇥",
		rightarrow: "→",
		RightArrow: "→",
		Rightarrow: "⇒",
		RightArrowLeftArrow: "⇄",
		rightarrowtail: "↣",
		RightCeiling: "⌉",
		RightDoubleBracket: "⟧",
		RightDownTeeVector: "⥝",
		RightDownVectorBar: "⥕",
		RightDownVector: "⇂",
		RightFloor: "⌋",
		rightharpoondown: "⇁",
		rightharpoonup: "⇀",
		rightleftarrows: "⇄",
		rightleftharpoons: "⇌",
		rightrightarrows: "⇉",
		rightsquigarrow: "↝",
		RightTeeArrow: "↦",
		RightTee: "⊢",
		RightTeeVector: "⥛",
		rightthreetimes: "⋌",
		RightTriangleBar: "⧐",
		RightTriangle: "⊳",
		RightTriangleEqual: "⊵",
		RightUpDownVector: "⥏",
		RightUpTeeVector: "⥜",
		RightUpVectorBar: "⥔",
		RightUpVector: "↾",
		RightVectorBar: "⥓",
		RightVector: "⇀",
		ring: "˚",
		risingdotseq: "≓",
		rlarr: "⇄",
		rlhar: "⇌",
		rlm: "‏",
		rmoustache: "⎱",
		rmoust: "⎱",
		rnmid: "⫮",
		roang: "⟭",
		roarr: "⇾",
		robrk: "⟧",
		ropar: "⦆",
		ropf: "𝕣",
		Ropf: "ℝ",
		roplus: "⨮",
		rotimes: "⨵",
		RoundImplies: "⥰",
		rpar: ")",
		rpargt: "⦔",
		rppolint: "⨒",
		rrarr: "⇉",
		Rrightarrow: "⇛",
		rsaquo: "›",
		rscr: "𝓇",
		Rscr: "ℛ",
		rsh: "↱",
		Rsh: "↱",
		rsqb: "]",
		rsquo: "’",
		rsquor: "’",
		rthree: "⋌",
		rtimes: "⋊",
		rtri: "▹",
		rtrie: "⊵",
		rtrif: "▸",
		rtriltri: "⧎",
		RuleDelayed: "⧴",
		ruluhar: "⥨",
		rx: "℞",
		Sacute: "Ś",
		sacute: "ś",
		sbquo: "‚",
		scap: "⪸",
		Scaron: "Š",
		scaron: "š",
		Sc: "⪼",
		sc: "≻",
		sccue: "≽",
		sce: "⪰",
		scE: "⪴",
		Scedil: "Ş",
		scedil: "ş",
		Scirc: "Ŝ",
		scirc: "ŝ",
		scnap: "⪺",
		scnE: "⪶",
		scnsim: "⋩",
		scpolint: "⨓",
		scsim: "≿",
		Scy: "С",
		scy: "с",
		sdotb: "⊡",
		sdot: "⋅",
		sdote: "⩦",
		searhk: "⤥",
		searr: "↘",
		seArr: "⇘",
		searrow: "↘",
		sect: "§",
		semi: ";",
		seswar: "⤩",
		setminus: "∖",
		setmn: "∖",
		sext: "✶",
		Sfr: "𝔖",
		sfr: "𝔰",
		sfrown: "⌢",
		sharp: "♯",
		SHCHcy: "Щ",
		shchcy: "щ",
		SHcy: "Ш",
		shcy: "ш",
		ShortDownArrow: "↓",
		ShortLeftArrow: "←",
		shortmid: "∣",
		shortparallel: "∥",
		ShortRightArrow: "→",
		ShortUpArrow: "↑",
		shy: "­",
		Sigma: "Σ",
		sigma: "σ",
		sigmaf: "ς",
		sigmav: "ς",
		sim: "∼",
		simdot: "⩪",
		sime: "≃",
		simeq: "≃",
		simg: "⪞",
		simgE: "⪠",
		siml: "⪝",
		simlE: "⪟",
		simne: "≆",
		simplus: "⨤",
		simrarr: "⥲",
		slarr: "←",
		SmallCircle: "∘",
		smallsetminus: "∖",
		smashp: "⨳",
		smeparsl: "⧤",
		smid: "∣",
		smile: "⌣",
		smt: "⪪",
		smte: "⪬",
		smtes: "⪬︀",
		SOFTcy: "Ь",
		softcy: "ь",
		solbar: "⌿",
		solb: "⧄",
		sol: "/",
		Sopf: "𝕊",
		sopf: "𝕤",
		spades: "♠",
		spadesuit: "♠",
		spar: "∥",
		sqcap: "⊓",
		sqcaps: "⊓︀",
		sqcup: "⊔",
		sqcups: "⊔︀",
		Sqrt: "√",
		sqsub: "⊏",
		sqsube: "⊑",
		sqsubset: "⊏",
		sqsubseteq: "⊑",
		sqsup: "⊐",
		sqsupe: "⊒",
		sqsupset: "⊐",
		sqsupseteq: "⊒",
		square: "□",
		Square: "□",
		SquareIntersection: "⊓",
		SquareSubset: "⊏",
		SquareSubsetEqual: "⊑",
		SquareSuperset: "⊐",
		SquareSupersetEqual: "⊒",
		SquareUnion: "⊔",
		squarf: "▪",
		squ: "□",
		squf: "▪",
		srarr: "→",
		Sscr: "𝒮",
		sscr: "𝓈",
		ssetmn: "∖",
		ssmile: "⌣",
		sstarf: "⋆",
		Star: "⋆",
		star: "☆",
		starf: "★",
		straightepsilon: "ϵ",
		straightphi: "ϕ",
		strns: "¯",
		sub: "⊂",
		Sub: "⋐",
		subdot: "⪽",
		subE: "⫅",
		sube: "⊆",
		subedot: "⫃",
		submult: "⫁",
		subnE: "⫋",
		subne: "⊊",
		subplus: "⪿",
		subrarr: "⥹",
		subset: "⊂",
		Subset: "⋐",
		subseteq: "⊆",
		subseteqq: "⫅",
		SubsetEqual: "⊆",
		subsetneq: "⊊",
		subsetneqq: "⫋",
		subsim: "⫇",
		subsub: "⫕",
		subsup: "⫓",
		succapprox: "⪸",
		succ: "≻",
		succcurlyeq: "≽",
		Succeeds: "≻",
		SucceedsEqual: "⪰",
		SucceedsSlantEqual: "≽",
		SucceedsTilde: "≿",
		succeq: "⪰",
		succnapprox: "⪺",
		succneqq: "⪶",
		succnsim: "⋩",
		succsim: "≿",
		SuchThat: "∋",
		sum: "∑",
		Sum: "∑",
		sung: "♪",
		sup1: "¹",
		sup2: "²",
		sup3: "³",
		sup: "⊃",
		Sup: "⋑",
		supdot: "⪾",
		supdsub: "⫘",
		supE: "⫆",
		supe: "⊇",
		supedot: "⫄",
		Superset: "⊃",
		SupersetEqual: "⊇",
		suphsol: "⟉",
		suphsub: "⫗",
		suplarr: "⥻",
		supmult: "⫂",
		supnE: "⫌",
		supne: "⊋",
		supplus: "⫀",
		supset: "⊃",
		Supset: "⋑",
		supseteq: "⊇",
		supseteqq: "⫆",
		supsetneq: "⊋",
		supsetneqq: "⫌",
		supsim: "⫈",
		supsub: "⫔",
		supsup: "⫖",
		swarhk: "⤦",
		swarr: "↙",
		swArr: "⇙",
		swarrow: "↙",
		swnwar: "⤪",
		szlig: "ß",
		Tab: "	",
		target: "⌖",
		Tau: "Τ",
		tau: "τ",
		tbrk: "⎴",
		Tcaron: "Ť",
		tcaron: "ť",
		Tcedil: "Ţ",
		tcedil: "ţ",
		Tcy: "Т",
		tcy: "т",
		tdot: "⃛",
		telrec: "⌕",
		Tfr: "𝔗",
		tfr: "𝔱",
		there4: "∴",
		therefore: "∴",
		Therefore: "∴",
		Theta: "Θ",
		theta: "θ",
		thetasym: "ϑ",
		thetav: "ϑ",
		thickapprox: "≈",
		thicksim: "∼",
		ThickSpace: "  ",
		ThinSpace: " ",
		thinsp: " ",
		thkap: "≈",
		thksim: "∼",
		THORN: "Þ",
		thorn: "þ",
		tilde: "˜",
		Tilde: "∼",
		TildeEqual: "≃",
		TildeFullEqual: "≅",
		TildeTilde: "≈",
		timesbar: "⨱",
		timesb: "⊠",
		times: "×",
		timesd: "⨰",
		tint: "∭",
		toea: "⤨",
		topbot: "⌶",
		topcir: "⫱",
		top: "⊤",
		Topf: "𝕋",
		topf: "𝕥",
		topfork: "⫚",
		tosa: "⤩",
		tprime: "‴",
		trade: "™",
		TRADE: "™",
		triangle: "▵",
		triangledown: "▿",
		triangleleft: "◃",
		trianglelefteq: "⊴",
		triangleq: "≜",
		triangleright: "▹",
		trianglerighteq: "⊵",
		tridot: "◬",
		trie: "≜",
		triminus: "⨺",
		TripleDot: "⃛",
		triplus: "⨹",
		trisb: "⧍",
		tritime: "⨻",
		trpezium: "⏢",
		Tscr: "𝒯",
		tscr: "𝓉",
		TScy: "Ц",
		tscy: "ц",
		TSHcy: "Ћ",
		tshcy: "ћ",
		Tstrok: "Ŧ",
		tstrok: "ŧ",
		twixt: "≬",
		twoheadleftarrow: "↞",
		twoheadrightarrow: "↠",
		Uacute: "Ú",
		uacute: "ú",
		uarr: "↑",
		Uarr: "↟",
		uArr: "⇑",
		Uarrocir: "⥉",
		Ubrcy: "Ў",
		ubrcy: "ў",
		Ubreve: "Ŭ",
		ubreve: "ŭ",
		Ucirc: "Û",
		ucirc: "û",
		Ucy: "У",
		ucy: "у",
		udarr: "⇅",
		Udblac: "Ű",
		udblac: "ű",
		udhar: "⥮",
		ufisht: "⥾",
		Ufr: "𝔘",
		ufr: "𝔲",
		Ugrave: "Ù",
		ugrave: "ù",
		uHar: "⥣",
		uharl: "↿",
		uharr: "↾",
		uhblk: "▀",
		ulcorn: "⌜",
		ulcorner: "⌜",
		ulcrop: "⌏",
		ultri: "◸",
		Umacr: "Ū",
		umacr: "ū",
		uml: "¨",
		UnderBar: "_",
		UnderBrace: "⏟",
		UnderBracket: "⎵",
		UnderParenthesis: "⏝",
		Union: "⋃",
		UnionPlus: "⊎",
		Uogon: "Ų",
		uogon: "ų",
		Uopf: "𝕌",
		uopf: "𝕦",
		UpArrowBar: "⤒",
		uparrow: "↑",
		UpArrow: "↑",
		Uparrow: "⇑",
		UpArrowDownArrow: "⇅",
		updownarrow: "↕",
		UpDownArrow: "↕",
		Updownarrow: "⇕",
		UpEquilibrium: "⥮",
		upharpoonleft: "↿",
		upharpoonright: "↾",
		uplus: "⊎",
		UpperLeftArrow: "↖",
		UpperRightArrow: "↗",
		upsi: "υ",
		Upsi: "ϒ",
		upsih: "ϒ",
		Upsilon: "Υ",
		upsilon: "υ",
		UpTeeArrow: "↥",
		UpTee: "⊥",
		upuparrows: "⇈",
		urcorn: "⌝",
		urcorner: "⌝",
		urcrop: "⌎",
		Uring: "Ů",
		uring: "ů",
		urtri: "◹",
		Uscr: "𝒰",
		uscr: "𝓊",
		utdot: "⋰",
		Utilde: "Ũ",
		utilde: "ũ",
		utri: "▵",
		utrif: "▴",
		uuarr: "⇈",
		Uuml: "Ü",
		uuml: "ü",
		uwangle: "⦧",
		vangrt: "⦜",
		varepsilon: "ϵ",
		varkappa: "ϰ",
		varnothing: "∅",
		varphi: "ϕ",
		varpi: "ϖ",
		varpropto: "∝",
		varr: "↕",
		vArr: "⇕",
		varrho: "ϱ",
		varsigma: "ς",
		varsubsetneq: "⊊︀",
		varsubsetneqq: "⫋︀",
		varsupsetneq: "⊋︀",
		varsupsetneqq: "⫌︀",
		vartheta: "ϑ",
		vartriangleleft: "⊲",
		vartriangleright: "⊳",
		vBar: "⫨",
		Vbar: "⫫",
		vBarv: "⫩",
		Vcy: "В",
		vcy: "в",
		vdash: "⊢",
		vDash: "⊨",
		Vdash: "⊩",
		VDash: "⊫",
		Vdashl: "⫦",
		veebar: "⊻",
		vee: "∨",
		Vee: "⋁",
		veeeq: "≚",
		vellip: "⋮",
		verbar: "|",
		Verbar: "‖",
		vert: "|",
		Vert: "‖",
		VerticalBar: "∣",
		VerticalLine: "|",
		VerticalSeparator: "❘",
		VerticalTilde: "≀",
		VeryThinSpace: " ",
		Vfr: "𝔙",
		vfr: "𝔳",
		vltri: "⊲",
		vnsub: "⊂⃒",
		vnsup: "⊃⃒",
		Vopf: "𝕍",
		vopf: "𝕧",
		vprop: "∝",
		vrtri: "⊳",
		Vscr: "𝒱",
		vscr: "𝓋",
		vsubnE: "⫋︀",
		vsubne: "⊊︀",
		vsupnE: "⫌︀",
		vsupne: "⊋︀",
		Vvdash: "⊪",
		vzigzag: "⦚",
		Wcirc: "Ŵ",
		wcirc: "ŵ",
		wedbar: "⩟",
		wedge: "∧",
		Wedge: "⋀",
		wedgeq: "≙",
		weierp: "℘",
		Wfr: "𝔚",
		wfr: "𝔴",
		Wopf: "𝕎",
		wopf: "𝕨",
		wp: "℘",
		wr: "≀",
		wreath: "≀",
		Wscr: "𝒲",
		wscr: "𝓌",
		xcap: "⋂",
		xcirc: "◯",
		xcup: "⋃",
		xdtri: "▽",
		Xfr: "𝔛",
		xfr: "𝔵",
		xharr: "⟷",
		xhArr: "⟺",
		Xi: "Ξ",
		xi: "ξ",
		xlarr: "⟵",
		xlArr: "⟸",
		xmap: "⟼",
		xnis: "⋻",
		xodot: "⨀",
		Xopf: "𝕏",
		xopf: "𝕩",
		xoplus: "⨁",
		xotime: "⨂",
		xrarr: "⟶",
		xrArr: "⟹",
		Xscr: "𝒳",
		xscr: "𝓍",
		xsqcup: "⨆",
		xuplus: "⨄",
		xutri: "△",
		xvee: "⋁",
		xwedge: "⋀",
		Yacute: "Ý",
		yacute: "ý",
		YAcy: "Я",
		yacy: "я",
		Ycirc: "Ŷ",
		ycirc: "ŷ",
		Ycy: "Ы",
		ycy: "ы",
		yen: "¥",
		Yfr: "𝔜",
		yfr: "𝔶",
		YIcy: "Ї",
		yicy: "ї",
		Yopf: "𝕐",
		yopf: "𝕪",
		Yscr: "𝒴",
		yscr: "𝓎",
		YUcy: "Ю",
		yucy: "ю",
		yuml: "ÿ",
		Yuml: "Ÿ",
		Zacute: "Ź",
		zacute: "ź",
		Zcaron: "Ž",
		zcaron: "ž",
		Zcy: "З",
		zcy: "з",
		Zdot: "Ż",
		zdot: "ż",
		zeetrf: "ℨ",
		ZeroWidthSpace: "​",
		Zeta: "Ζ",
		zeta: "ζ",
		zfr: "𝔷",
		Zfr: "ℨ",
		ZHcy: "Ж",
		zhcy: "ж",
		zigrarr: "⇝",
		zopf: "𝕫",
		Zopf: "ℤ",
		Zscr: "𝒵",
		zscr: "𝓏",
		zwj: "‍",
		zwnj: "‌"
	};
} });
var require_entities2 = __commonJS({ "node_modules/markdown-it/lib/common/entities.js"(exports, module) {
	"use strict";
	module.exports = require_entities();
} });
var require_regex = __commonJS({ "node_modules/uc.micro/categories/P/regex.js"(exports, module) {
	module.exports = /[!-#%-\*,-\/:;\?@\[-\]_\{\}\xA1\xA7\xAB\xB6\xB7\xBB\xBF\u037E\u0387\u055A-\u055F\u0589\u058A\u05BE\u05C0\u05C3\u05C6\u05F3\u05F4\u0609\u060A\u060C\u060D\u061B\u061E\u061F\u066A-\u066D\u06D4\u0700-\u070D\u07F7-\u07F9\u0830-\u083E\u085E\u0964\u0965\u0970\u09FD\u0A76\u0AF0\u0C84\u0DF4\u0E4F\u0E5A\u0E5B\u0F04-\u0F12\u0F14\u0F3A-\u0F3D\u0F85\u0FD0-\u0FD4\u0FD9\u0FDA\u104A-\u104F\u10FB\u1360-\u1368\u1400\u166D\u166E\u169B\u169C\u16EB-\u16ED\u1735\u1736\u17D4-\u17D6\u17D8-\u17DA\u1800-\u180A\u1944\u1945\u1A1E\u1A1F\u1AA0-\u1AA6\u1AA8-\u1AAD\u1B5A-\u1B60\u1BFC-\u1BFF\u1C3B-\u1C3F\u1C7E\u1C7F\u1CC0-\u1CC7\u1CD3\u2010-\u2027\u2030-\u2043\u2045-\u2051\u2053-\u205E\u207D\u207E\u208D\u208E\u2308-\u230B\u2329\u232A\u2768-\u2775\u27C5\u27C6\u27E6-\u27EF\u2983-\u2998\u29D8-\u29DB\u29FC\u29FD\u2CF9-\u2CFC\u2CFE\u2CFF\u2D70\u2E00-\u2E2E\u2E30-\u2E4E\u3001-\u3003\u3008-\u3011\u3014-\u301F\u3030\u303D\u30A0\u30FB\uA4FE\uA4FF\uA60D-\uA60F\uA673\uA67E\uA6F2-\uA6F7\uA874-\uA877\uA8CE\uA8CF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA95F\uA9C1-\uA9CD\uA9DE\uA9DF\uAA5C-\uAA5F\uAADE\uAADF\uAAF0\uAAF1\uABEB\uFD3E\uFD3F\uFE10-\uFE19\uFE30-\uFE52\uFE54-\uFE61\uFE63\uFE68\uFE6A\uFE6B\uFF01-\uFF03\uFF05-\uFF0A\uFF0C-\uFF0F\uFF1A\uFF1B\uFF1F\uFF20\uFF3B-\uFF3D\uFF3F\uFF5B\uFF5D\uFF5F-\uFF65]|\uD800[\uDD00-\uDD02\uDF9F\uDFD0]|\uD801\uDD6F|\uD802[\uDC57\uDD1F\uDD3F\uDE50-\uDE58\uDE7F\uDEF0-\uDEF6\uDF39-\uDF3F\uDF99-\uDF9C]|\uD803[\uDF55-\uDF59]|\uD804[\uDC47-\uDC4D\uDCBB\uDCBC\uDCBE-\uDCC1\uDD40-\uDD43\uDD74\uDD75\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDDF\uDE38-\uDE3D\uDEA9]|\uD805[\uDC4B-\uDC4F\uDC5B\uDC5D\uDCC6\uDDC1-\uDDD7\uDE41-\uDE43\uDE60-\uDE6C\uDF3C-\uDF3E]|\uD806[\uDC3B\uDE3F-\uDE46\uDE9A-\uDE9C\uDE9E-\uDEA2]|\uD807[\uDC41-\uDC45\uDC70\uDC71\uDEF7\uDEF8]|\uD809[\uDC70-\uDC74]|\uD81A[\uDE6E\uDE6F\uDEF5\uDF37-\uDF3B\uDF44]|\uD81B[\uDE97-\uDE9A]|\uD82F\uDC9F|\uD836[\uDE87-\uDE8B]|\uD83A[\uDD5E\uDD5F]/;
} });
var require_encode = __commonJS({ "node_modules/mdurl/encode.js"(exports, module) {
	"use strict";
	var encodeCache = {};
	function getEncodeCache(exclude) {
		var i, ch, cache = encodeCache[exclude];
		if (cache) return cache;
		cache = encodeCache[exclude] = [];
		for (i = 0; i < 128; i++) {
			ch = String.fromCharCode(i);
			if (/^[0-9a-z]$/i.test(ch)) cache.push(ch);
			else cache.push("%" + ("0" + i.toString(16).toUpperCase()).slice(-2));
		}
		for (i = 0; i < exclude.length; i++) cache[exclude.charCodeAt(i)] = exclude[i];
		return cache;
	}
	function encode(string, exclude, keepEscaped) {
		var i, l, code2, nextCode, cache, result = "";
		if (typeof exclude !== "string") {
			keepEscaped = exclude;
			exclude = encode.defaultChars;
		}
		if (typeof keepEscaped === "undefined") keepEscaped = true;
		cache = getEncodeCache(exclude);
		for (i = 0, l = string.length; i < l; i++) {
			code2 = string.charCodeAt(i);
			if (keepEscaped && code2 === 37 && i + 2 < l) {
				if (/^[0-9a-f]{2}$/i.test(string.slice(i + 1, i + 3))) {
					result += string.slice(i, i + 3);
					i += 2;
					continue;
				}
			}
			if (code2 < 128) {
				result += cache[code2];
				continue;
			}
			if (code2 >= 55296 && code2 <= 57343) {
				if (code2 >= 55296 && code2 <= 56319 && i + 1 < l) {
					nextCode = string.charCodeAt(i + 1);
					if (nextCode >= 56320 && nextCode <= 57343) {
						result += encodeURIComponent(string[i] + string[i + 1]);
						i++;
						continue;
					}
				}
				result += "%EF%BF%BD";
				continue;
			}
			result += encodeURIComponent(string[i]);
		}
		return result;
	}
	encode.defaultChars = ";/?:@&=+$,-_.!~*'()#";
	encode.componentChars = "-_.!~*'()";
	module.exports = encode;
} });
var require_decode = __commonJS({ "node_modules/mdurl/decode.js"(exports, module) {
	"use strict";
	var decodeCache = {};
	function getDecodeCache(exclude) {
		var i, ch, cache = decodeCache[exclude];
		if (cache) return cache;
		cache = decodeCache[exclude] = [];
		for (i = 0; i < 128; i++) {
			ch = String.fromCharCode(i);
			cache.push(ch);
		}
		for (i = 0; i < exclude.length; i++) {
			ch = exclude.charCodeAt(i);
			cache[ch] = "%" + ("0" + ch.toString(16).toUpperCase()).slice(-2);
		}
		return cache;
	}
	function decode(string, exclude) {
		var cache;
		if (typeof exclude !== "string") exclude = decode.defaultChars;
		cache = getDecodeCache(exclude);
		return string.replace(/(%[a-f0-9]{2})+/gi, function(seq) {
			var i, l, b1, b2, b3, b4, chr, result = "";
			for (i = 0, l = seq.length; i < l; i += 3) {
				b1 = parseInt(seq.slice(i + 1, i + 3), 16);
				if (b1 < 128) {
					result += cache[b1];
					continue;
				}
				if ((b1 & 224) === 192 && i + 3 < l) {
					b2 = parseInt(seq.slice(i + 4, i + 6), 16);
					if ((b2 & 192) === 128) {
						chr = b1 << 6 & 1984 | b2 & 63;
						if (chr < 128) result += "��";
						else result += String.fromCharCode(chr);
						i += 3;
						continue;
					}
				}
				if ((b1 & 240) === 224 && i + 6 < l) {
					b2 = parseInt(seq.slice(i + 4, i + 6), 16);
					b3 = parseInt(seq.slice(i + 7, i + 9), 16);
					if ((b2 & 192) === 128 && (b3 & 192) === 128) {
						chr = b1 << 12 & 61440 | b2 << 6 & 4032 | b3 & 63;
						if (chr < 2048 || chr >= 55296 && chr <= 57343) result += "���";
						else result += String.fromCharCode(chr);
						i += 6;
						continue;
					}
				}
				if ((b1 & 248) === 240 && i + 9 < l) {
					b2 = parseInt(seq.slice(i + 4, i + 6), 16);
					b3 = parseInt(seq.slice(i + 7, i + 9), 16);
					b4 = parseInt(seq.slice(i + 10, i + 12), 16);
					if ((b2 & 192) === 128 && (b3 & 192) === 128 && (b4 & 192) === 128) {
						chr = b1 << 18 & 1835008 | b2 << 12 & 258048 | b3 << 6 & 4032 | b4 & 63;
						if (chr < 65536 || chr > 1114111) result += "����";
						else {
							chr -= 65536;
							result += String.fromCharCode(55296 + (chr >> 10), 56320 + (chr & 1023));
						}
						i += 9;
						continue;
					}
				}
				result += "�";
			}
			return result;
		});
	}
	decode.defaultChars = ";/?:@&=+$,#";
	decode.componentChars = "";
	module.exports = decode;
} });
var require_format = __commonJS({ "node_modules/mdurl/format.js"(exports, module) {
	"use strict";
	module.exports = function format2(url) {
		var result = "";
		result += url.protocol || "";
		result += url.slashes ? "//" : "";
		result += url.auth ? url.auth + "@" : "";
		if (url.hostname && url.hostname.indexOf(":") !== -1) result += "[" + url.hostname + "]";
		else result += url.hostname || "";
		result += url.port ? ":" + url.port : "";
		result += url.pathname || "";
		result += url.search || "";
		result += url.hash || "";
		return result;
	};
} });
var require_parse = __commonJS({ "node_modules/mdurl/parse.js"(exports, module) {
	"use strict";
	function Url() {
		this.protocol = null;
		this.slashes = null;
		this.auth = null;
		this.port = null;
		this.hostname = null;
		this.hash = null;
		this.search = null;
		this.pathname = null;
	}
	var protocolPattern = /^([a-z0-9.+-]+:)/i;
	var portPattern = /:[0-9]*$/;
	var simplePathPattern = /^(\/\/?(?!\/)[^\?\s]*)(\?[^\s]*)?$/;
	var unwise = [
		"{",
		"}",
		"|",
		"\\",
		"^",
		"`"
	].concat([
		"<",
		">",
		"\"",
		"`",
		" ",
		"\r",
		"\n",
		"	"
	]);
	var autoEscape = ["'"].concat(unwise);
	var nonHostChars = [
		"%",
		"/",
		"?",
		";",
		"#"
	].concat(autoEscape);
	var hostEndingChars = [
		"/",
		"?",
		"#"
	];
	var hostnameMaxLen = 255;
	var hostnamePartPattern = /^[+a-z0-9A-Z_-]{0,63}$/;
	var hostnamePartStart = /^([+a-z0-9A-Z_-]{0,63})(.*)$/;
	var hostlessProtocol = {
		"javascript": true,
		"javascript:": true
	};
	var slashedProtocol = {
		"http": true,
		"https": true,
		"ftp": true,
		"gopher": true,
		"file": true,
		"http:": true,
		"https:": true,
		"ftp:": true,
		"gopher:": true,
		"file:": true
	};
	function urlParse(url, slashesDenoteHost) {
		if (url && url instanceof Url) return url;
		var u = new Url();
		u.parse(url, slashesDenoteHost);
		return u;
	}
	Url.prototype.parse = function(url, slashesDenoteHost) {
		var i, l, lowerProto, hec, slashes, rest = url;
		rest = rest.trim();
		if (!slashesDenoteHost && url.split("#").length === 1) {
			var simplePath = simplePathPattern.exec(rest);
			if (simplePath) {
				this.pathname = simplePath[1];
				if (simplePath[2]) this.search = simplePath[2];
				return this;
			}
		}
		var proto = protocolPattern.exec(rest);
		if (proto) {
			proto = proto[0];
			lowerProto = proto.toLowerCase();
			this.protocol = proto;
			rest = rest.substr(proto.length);
		}
		if (slashesDenoteHost || proto || rest.match(/^\/\/[^@\/]+@[^@\/]+/)) {
			slashes = rest.substr(0, 2) === "//";
			if (slashes && !(proto && hostlessProtocol[proto])) {
				rest = rest.substr(2);
				this.slashes = true;
			}
		}
		if (!hostlessProtocol[proto] && (slashes || proto && !slashedProtocol[proto])) {
			var hostEnd = -1;
			for (i = 0; i < hostEndingChars.length; i++) {
				hec = rest.indexOf(hostEndingChars[i]);
				if (hec !== -1 && (hostEnd === -1 || hec < hostEnd)) hostEnd = hec;
			}
			var auth, atSign;
			if (hostEnd === -1) atSign = rest.lastIndexOf("@");
			else atSign = rest.lastIndexOf("@", hostEnd);
			if (atSign !== -1) {
				auth = rest.slice(0, atSign);
				rest = rest.slice(atSign + 1);
				this.auth = auth;
			}
			hostEnd = -1;
			for (i = 0; i < nonHostChars.length; i++) {
				hec = rest.indexOf(nonHostChars[i]);
				if (hec !== -1 && (hostEnd === -1 || hec < hostEnd)) hostEnd = hec;
			}
			if (hostEnd === -1) hostEnd = rest.length;
			if (rest[hostEnd - 1] === ":") hostEnd--;
			var host = rest.slice(0, hostEnd);
			rest = rest.slice(hostEnd);
			this.parseHost(host);
			this.hostname = this.hostname || "";
			var ipv6Hostname = this.hostname[0] === "[" && this.hostname[this.hostname.length - 1] === "]";
			if (!ipv6Hostname) {
				var hostparts = this.hostname.split(/\./);
				for (i = 0, l = hostparts.length; i < l; i++) {
					var part = hostparts[i];
					if (!part) continue;
					if (!part.match(hostnamePartPattern)) {
						var newpart = "";
						for (var j = 0, k = part.length; j < k; j++) if (part.charCodeAt(j) > 127) newpart += "x";
						else newpart += part[j];
						if (!newpart.match(hostnamePartPattern)) {
							var validParts = hostparts.slice(0, i);
							var notHost = hostparts.slice(i + 1);
							var bit = part.match(hostnamePartStart);
							if (bit) {
								validParts.push(bit[1]);
								notHost.unshift(bit[2]);
							}
							if (notHost.length) rest = notHost.join(".") + rest;
							this.hostname = validParts.join(".");
							break;
						}
					}
				}
			}
			if (this.hostname.length > hostnameMaxLen) this.hostname = "";
			if (ipv6Hostname) this.hostname = this.hostname.substr(1, this.hostname.length - 2);
		}
		var hash = rest.indexOf("#");
		if (hash !== -1) {
			this.hash = rest.substr(hash);
			rest = rest.slice(0, hash);
		}
		var qm = rest.indexOf("?");
		if (qm !== -1) {
			this.search = rest.substr(qm);
			rest = rest.slice(0, qm);
		}
		if (rest) this.pathname = rest;
		if (slashedProtocol[lowerProto] && this.hostname && !this.pathname) this.pathname = "";
		return this;
	};
	Url.prototype.parseHost = function(host) {
		var port = portPattern.exec(host);
		if (port) {
			port = port[0];
			if (port !== ":") this.port = port.substr(1);
			host = host.substr(0, host.length - port.length);
		}
		if (host) this.hostname = host;
	};
	module.exports = urlParse;
} });
var require_mdurl = __commonJS({ "node_modules/mdurl/index.js"(exports, module) {
	"use strict";
	module.exports.encode = require_encode();
	module.exports.decode = require_decode();
	module.exports.format = require_format();
	module.exports.parse = require_parse();
} });
var require_regex2 = __commonJS({ "node_modules/uc.micro/properties/Any/regex.js"(exports, module) {
	module.exports = /[\0-\uD7FF\uE000-\uFFFF]|[\uD800-\uDBFF][\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/;
} });
var require_regex3 = __commonJS({ "node_modules/uc.micro/categories/Cc/regex.js"(exports, module) {
	module.exports = /[\0-\x1F\x7F-\x9F]/;
} });
var require_regex4 = __commonJS({ "node_modules/uc.micro/categories/Cf/regex.js"(exports, module) {
	module.exports = /[\xAD\u0600-\u0605\u061C\u06DD\u070F\u08E2\u180E\u200B-\u200F\u202A-\u202E\u2060-\u2064\u2066-\u206F\uFEFF\uFFF9-\uFFFB]|\uD804[\uDCBD\uDCCD]|\uD82F[\uDCA0-\uDCA3]|\uD834[\uDD73-\uDD7A]|\uDB40[\uDC01\uDC20-\uDC7F]/;
} });
var require_regex5 = __commonJS({ "node_modules/uc.micro/categories/Z/regex.js"(exports, module) {
	module.exports = /[ \xA0\u1680\u2000-\u200A\u2028\u2029\u202F\u205F\u3000]/;
} });
var require_uc = __commonJS({ "node_modules/uc.micro/index.js"(exports) {
	"use strict";
	exports.Any = require_regex2();
	exports.Cc = require_regex3();
	exports.Cf = require_regex4();
	exports.P = require_regex();
	exports.Z = require_regex5();
} });
var require_utils = __commonJS({ "node_modules/markdown-it/lib/common/utils.js"(exports) {
	"use strict";
	function _class(obj) {
		return Object.prototype.toString.call(obj);
	}
	function isString(obj) {
		return _class(obj) === "[object String]";
	}
	var _hasOwnProperty = Object.prototype.hasOwnProperty;
	function has(object, key) {
		return _hasOwnProperty.call(object, key);
	}
	function assign(obj) {
		Array.prototype.slice.call(arguments, 1).forEach(function(source) {
			if (!source) return;
			if (typeof source !== "object") throw new TypeError(source + "must be object");
			Object.keys(source).forEach(function(key) {
				obj[key] = source[key];
			});
		});
		return obj;
	}
	function arrayReplaceAt(src, pos, newElements) {
		return [].concat(src.slice(0, pos), newElements, src.slice(pos + 1));
	}
	function isValidEntityCode(c) {
		if (c >= 55296 && c <= 57343) return false;
		if (c >= 64976 && c <= 65007) return false;
		if ((c & 65535) === 65535 || (c & 65535) === 65534) return false;
		if (c >= 0 && c <= 8) return false;
		if (c === 11) return false;
		if (c >= 14 && c <= 31) return false;
		if (c >= 127 && c <= 159) return false;
		if (c > 1114111) return false;
		return true;
	}
	function fromCodePoint(c) {
		if (c > 65535) {
			c -= 65536;
			var surrogate1 = 55296 + (c >> 10), surrogate2 = 56320 + (c & 1023);
			return String.fromCharCode(surrogate1, surrogate2);
		}
		return String.fromCharCode(c);
	}
	var UNESCAPE_MD_RE = /\\([!"#$%&'()*+,\-.\/:;<=>?@[\\\]^_`{|}~])/g;
	var UNESCAPE_ALL_RE = new RegExp(UNESCAPE_MD_RE.source + "|" + /&([a-z#][a-z0-9]{1,31});/gi.source, "gi");
	var DIGITAL_ENTITY_TEST_RE = /^#((?:x[a-f0-9]{1,8}|[0-9]{1,8}))/i;
	var entities = require_entities2();
	function replaceEntityPattern(match, name) {
		var code2 = 0;
		if (has(entities, name)) return entities[name];
		if (name.charCodeAt(0) === 35 && DIGITAL_ENTITY_TEST_RE.test(name)) {
			code2 = name[1].toLowerCase() === "x" ? parseInt(name.slice(2), 16) : parseInt(name.slice(1), 10);
			if (isValidEntityCode(code2)) return fromCodePoint(code2);
		}
		return match;
	}
	function unescapeMd(str) {
		if (str.indexOf("\\") < 0) return str;
		return str.replace(UNESCAPE_MD_RE, "$1");
	}
	function unescapeAll(str) {
		if (str.indexOf("\\") < 0 && str.indexOf("&") < 0) return str;
		return str.replace(UNESCAPE_ALL_RE, function(match, escaped, entity) {
			if (escaped) return escaped;
			return replaceEntityPattern(match, entity);
		});
	}
	var HTML_ESCAPE_TEST_RE = /[&<>"]/;
	var HTML_ESCAPE_REPLACE_RE = /[&<>"]/g;
	var HTML_REPLACEMENTS = {
		"&": "&amp;",
		"<": "&lt;",
		">": "&gt;",
		"\"": "&quot;"
	};
	function replaceUnsafeChar(ch) {
		return HTML_REPLACEMENTS[ch];
	}
	function escapeHtml2(str) {
		if (HTML_ESCAPE_TEST_RE.test(str)) return str.replace(HTML_ESCAPE_REPLACE_RE, replaceUnsafeChar);
		return str;
	}
	var REGEXP_ESCAPE_RE = /[.?*+^$[\]\\(){}|-]/g;
	function escapeRE(str) {
		return str.replace(REGEXP_ESCAPE_RE, "\\$&");
	}
	function isSpace(code2) {
		switch (code2) {
			case 9:
			case 32: return true;
		}
		return false;
	}
	function isWhiteSpace(code2) {
		if (code2 >= 8192 && code2 <= 8202) return true;
		switch (code2) {
			case 9:
			case 10:
			case 11:
			case 12:
			case 13:
			case 32:
			case 160:
			case 5760:
			case 8239:
			case 8287:
			case 12288: return true;
		}
		return false;
	}
	var UNICODE_PUNCT_RE = require_regex();
	function isPunctChar(ch) {
		return UNICODE_PUNCT_RE.test(ch);
	}
	function isMdAsciiPunct(ch) {
		switch (ch) {
			case 33:
			case 34:
			case 35:
			case 36:
			case 37:
			case 38:
			case 39:
			case 40:
			case 41:
			case 42:
			case 43:
			case 44:
			case 45:
			case 46:
			case 47:
			case 58:
			case 59:
			case 60:
			case 61:
			case 62:
			case 63:
			case 64:
			case 91:
			case 92:
			case 93:
			case 94:
			case 95:
			case 96:
			case 123:
			case 124:
			case 125:
			case 126: return true;
			default: return false;
		}
	}
	function normalizeReference(str) {
		str = str.trim().replace(/\s+/g, " ");
		if ("ẞ".toLowerCase() === "Ṿ") str = str.replace(/ẞ/g, "ß");
		return str.toLowerCase().toUpperCase();
	}
	exports.lib = {};
	exports.lib.mdurl = require_mdurl();
	exports.lib.ucmicro = require_uc();
	exports.assign = assign;
	exports.isString = isString;
	exports.has = has;
	exports.unescapeMd = unescapeMd;
	exports.unescapeAll = unescapeAll;
	exports.isValidEntityCode = isValidEntityCode;
	exports.fromCodePoint = fromCodePoint;
	exports.escapeHtml = escapeHtml2;
	exports.arrayReplaceAt = arrayReplaceAt;
	exports.isSpace = isSpace;
	exports.isWhiteSpace = isWhiteSpace;
	exports.isMdAsciiPunct = isMdAsciiPunct;
	exports.isPunctChar = isPunctChar;
	exports.escapeRE = escapeRE;
	exports.normalizeReference = normalizeReference;
} });
var require_parse_link_label = __commonJS({ "node_modules/markdown-it/lib/helpers/parse_link_label.js"(exports, module) {
	"use strict";
	module.exports = function parseLinkLabel(state, start, disableNested) {
		var level, found, marker, prevPos, labelEnd = -1, max2 = state.posMax, oldPos = state.pos;
		state.pos = start + 1;
		level = 1;
		while (state.pos < max2) {
			marker = state.src.charCodeAt(state.pos);
			if (marker === 93) {
				level--;
				if (level === 0) {
					found = true;
					break;
				}
			}
			prevPos = state.pos;
			state.md.inline.skipToken(state);
			if (marker === 91) {
				if (prevPos === state.pos - 1) level++;
				else if (disableNested) {
					state.pos = oldPos;
					return -1;
				}
			}
		}
		if (found) labelEnd = state.pos;
		state.pos = oldPos;
		return labelEnd;
	};
} });
var require_parse_link_destination = __commonJS({ "node_modules/markdown-it/lib/helpers/parse_link_destination.js"(exports, module) {
	"use strict";
	var unescapeAll = require_utils().unescapeAll;
	module.exports = function parseLinkDestination(str, pos, max2) {
		var code2, level, lines = 0, start = pos, result = {
			ok: false,
			pos: 0,
			lines: 0,
			str: ""
		};
		if (str.charCodeAt(pos) === 60) {
			pos++;
			while (pos < max2) {
				code2 = str.charCodeAt(pos);
				if (code2 === 10) return result;
				if (code2 === 60) return result;
				if (code2 === 62) {
					result.pos = pos + 1;
					result.str = unescapeAll(str.slice(start + 1, pos));
					result.ok = true;
					return result;
				}
				if (code2 === 92 && pos + 1 < max2) {
					pos += 2;
					continue;
				}
				pos++;
			}
			return result;
		}
		level = 0;
		while (pos < max2) {
			code2 = str.charCodeAt(pos);
			if (code2 === 32) break;
			if (code2 < 32 || code2 === 127) break;
			if (code2 === 92 && pos + 1 < max2) {
				if (str.charCodeAt(pos + 1) === 32) break;
				pos += 2;
				continue;
			}
			if (code2 === 40) {
				level++;
				if (level > 32) return result;
			}
			if (code2 === 41) {
				if (level === 0) break;
				level--;
			}
			pos++;
		}
		if (start === pos) return result;
		if (level !== 0) return result;
		result.str = unescapeAll(str.slice(start, pos));
		result.lines = lines;
		result.pos = pos;
		result.ok = true;
		return result;
	};
} });
var require_parse_link_title = __commonJS({ "node_modules/markdown-it/lib/helpers/parse_link_title.js"(exports, module) {
	"use strict";
	var unescapeAll = require_utils().unescapeAll;
	module.exports = function parseLinkTitle(str, pos, max2) {
		var code2, marker, lines = 0, start = pos, result = {
			ok: false,
			pos: 0,
			lines: 0,
			str: ""
		};
		if (pos >= max2) return result;
		marker = str.charCodeAt(pos);
		if (marker !== 34 && marker !== 39 && marker !== 40) return result;
		pos++;
		if (marker === 40) marker = 41;
		while (pos < max2) {
			code2 = str.charCodeAt(pos);
			if (code2 === marker) {
				result.pos = pos + 1;
				result.lines = lines;
				result.str = unescapeAll(str.slice(start + 1, pos));
				result.ok = true;
				return result;
			} else if (code2 === 40 && marker === 41) return result;
			else if (code2 === 10) lines++;
			else if (code2 === 92 && pos + 1 < max2) {
				pos++;
				if (str.charCodeAt(pos) === 10) lines++;
			}
			pos++;
		}
		return result;
	};
} });
var require_helpers = __commonJS({ "node_modules/markdown-it/lib/helpers/index.js"(exports) {
	"use strict";
	exports.parseLinkLabel = require_parse_link_label();
	exports.parseLinkDestination = require_parse_link_destination();
	exports.parseLinkTitle = require_parse_link_title();
} });
var require_renderer = __commonJS({ "node_modules/markdown-it/lib/renderer.js"(exports, module) {
	"use strict";
	var assign = require_utils().assign;
	var unescapeAll = require_utils().unescapeAll;
	var escapeHtml2 = require_utils().escapeHtml;
	var default_rules = {};
	default_rules.code_inline = function(tokens, idx, options, env, slf) {
		var token = tokens[idx];
		return "<code" + slf.renderAttrs(token) + ">" + escapeHtml2(tokens[idx].content) + "</code>";
	};
	default_rules.code_block = function(tokens, idx, options, env, slf) {
		var token = tokens[idx];
		return "<pre" + slf.renderAttrs(token) + "><code>" + escapeHtml2(tokens[idx].content) + "</code></pre>\n";
	};
	default_rules.fence = function(tokens, idx, options, env, slf) {
		var token = tokens[idx], info = token.info ? unescapeAll(token.info).trim() : "", langName = "", langAttrs = "", highlighted, i, arr, tmpAttrs, tmpToken;
		if (info) {
			arr = info.split(/(\s+)/g);
			langName = arr[0];
			langAttrs = arr.slice(2).join("");
		}
		if (options.highlight) highlighted = options.highlight(token.content, langName, langAttrs) || escapeHtml2(token.content);
		else highlighted = escapeHtml2(token.content);
		if (highlighted.indexOf("<pre") === 0) return highlighted + "\n";
		if (info) {
			i = token.attrIndex("class");
			tmpAttrs = token.attrs ? token.attrs.slice() : [];
			if (i < 0) tmpAttrs.push(["class", options.langPrefix + langName]);
			else {
				tmpAttrs[i] = tmpAttrs[i].slice();
				tmpAttrs[i][1] += " " + options.langPrefix + langName;
			}
			tmpToken = { attrs: tmpAttrs };
			return "<pre><code" + slf.renderAttrs(tmpToken) + ">" + highlighted + "</code></pre>\n";
		}
		return "<pre><code" + slf.renderAttrs(token) + ">" + highlighted + "</code></pre>\n";
	};
	default_rules.image = function(tokens, idx, options, env, slf) {
		var token = tokens[idx];
		token.attrs[token.attrIndex("alt")][1] = slf.renderInlineAsText(token.children, options, env);
		return slf.renderToken(tokens, idx, options);
	};
	default_rules.hardbreak = function(tokens, idx, options) {
		return options.xhtmlOut ? "<br />\n" : "<br>\n";
	};
	default_rules.softbreak = function(tokens, idx, options) {
		return options.breaks ? options.xhtmlOut ? "<br />\n" : "<br>\n" : "\n";
	};
	default_rules.text = function(tokens, idx) {
		return escapeHtml2(tokens[idx].content);
	};
	default_rules.html_block = function(tokens, idx) {
		return tokens[idx].content;
	};
	default_rules.html_inline = function(tokens, idx) {
		return tokens[idx].content;
	};
	function Renderer() {
		this.rules = assign({}, default_rules);
	}
	Renderer.prototype.renderAttrs = function renderAttrs(token) {
		var i, l, result;
		if (!token.attrs) return "";
		result = "";
		for (i = 0, l = token.attrs.length; i < l; i++) result += " " + escapeHtml2(token.attrs[i][0]) + "=\"" + escapeHtml2(token.attrs[i][1]) + "\"";
		return result;
	};
	Renderer.prototype.renderToken = function renderToken(tokens, idx, options) {
		var nextToken, result = "", needLf = false, token = tokens[idx];
		if (token.hidden) return "";
		if (token.block && token.nesting !== -1 && idx && tokens[idx - 1].hidden) result += "\n";
		result += (token.nesting === -1 ? "</" : "<") + token.tag;
		result += this.renderAttrs(token);
		if (token.nesting === 0 && options.xhtmlOut) result += " /";
		if (token.block) {
			needLf = true;
			if (token.nesting === 1) {
				if (idx + 1 < tokens.length) {
					nextToken = tokens[idx + 1];
					if (nextToken.type === "inline" || nextToken.hidden) needLf = false;
					else if (nextToken.nesting === -1 && nextToken.tag === token.tag) needLf = false;
				}
			}
		}
		result += needLf ? ">\n" : ">";
		return result;
	};
	Renderer.prototype.renderInline = function(tokens, options, env) {
		var type, result = "", rules = this.rules;
		for (var i = 0, len = tokens.length; i < len; i++) {
			type = tokens[i].type;
			if (typeof rules[type] !== "undefined") result += rules[type](tokens, i, options, env, this);
			else result += this.renderToken(tokens, i, options);
		}
		return result;
	};
	Renderer.prototype.renderInlineAsText = function(tokens, options, env) {
		var result = "";
		for (var i = 0, len = tokens.length; i < len; i++) if (tokens[i].type === "text") result += tokens[i].content;
		else if (tokens[i].type === "image") result += this.renderInlineAsText(tokens[i].children, options, env);
		else if (tokens[i].type === "softbreak") result += "\n";
		return result;
	};
	Renderer.prototype.render = function(tokens, options, env) {
		var i, len, type, result = "", rules = this.rules;
		for (i = 0, len = tokens.length; i < len; i++) {
			type = tokens[i].type;
			if (type === "inline") result += this.renderInline(tokens[i].children, options, env);
			else if (typeof rules[type] !== "undefined") result += rules[tokens[i].type](tokens, i, options, env, this);
			else result += this.renderToken(tokens, i, options, env);
		}
		return result;
	};
	module.exports = Renderer;
} });
var require_ruler = __commonJS({ "node_modules/markdown-it/lib/ruler.js"(exports, module) {
	"use strict";
	function Ruler() {
		this.__rules__ = [];
		this.__cache__ = null;
	}
	Ruler.prototype.__find__ = function(name) {
		for (var i = 0; i < this.__rules__.length; i++) if (this.__rules__[i].name === name) return i;
		return -1;
	};
	Ruler.prototype.__compile__ = function() {
		var self = this;
		var chains = [""];
		self.__rules__.forEach(function(rule) {
			if (!rule.enabled) return;
			rule.alt.forEach(function(altName) {
				if (chains.indexOf(altName) < 0) chains.push(altName);
			});
		});
		self.__cache__ = {};
		chains.forEach(function(chain) {
			self.__cache__[chain] = [];
			self.__rules__.forEach(function(rule) {
				if (!rule.enabled) return;
				if (chain && rule.alt.indexOf(chain) < 0) return;
				self.__cache__[chain].push(rule.fn);
			});
		});
	};
	Ruler.prototype.at = function(name, fn, options) {
		var index = this.__find__(name);
		var opt = options || {};
		if (index === -1) throw new Error("Parser rule not found: " + name);
		this.__rules__[index].fn = fn;
		this.__rules__[index].alt = opt.alt || [];
		this.__cache__ = null;
	};
	Ruler.prototype.before = function(beforeName, ruleName, fn, options) {
		var index = this.__find__(beforeName);
		var opt = options || {};
		if (index === -1) throw new Error("Parser rule not found: " + beforeName);
		this.__rules__.splice(index, 0, {
			name: ruleName,
			enabled: true,
			fn,
			alt: opt.alt || []
		});
		this.__cache__ = null;
	};
	Ruler.prototype.after = function(afterName, ruleName, fn, options) {
		var index = this.__find__(afterName);
		var opt = options || {};
		if (index === -1) throw new Error("Parser rule not found: " + afterName);
		this.__rules__.splice(index + 1, 0, {
			name: ruleName,
			enabled: true,
			fn,
			alt: opt.alt || []
		});
		this.__cache__ = null;
	};
	Ruler.prototype.push = function(ruleName, fn, options) {
		var opt = options || {};
		this.__rules__.push({
			name: ruleName,
			enabled: true,
			fn,
			alt: opt.alt || []
		});
		this.__cache__ = null;
	};
	Ruler.prototype.enable = function(list2, ignoreInvalid) {
		if (!Array.isArray(list2)) list2 = [list2];
		var result = [];
		list2.forEach(function(name) {
			var idx = this.__find__(name);
			if (idx < 0) {
				if (ignoreInvalid) return;
				throw new Error("Rules manager: invalid rule name " + name);
			}
			this.__rules__[idx].enabled = true;
			result.push(name);
		}, this);
		this.__cache__ = null;
		return result;
	};
	Ruler.prototype.enableOnly = function(list2, ignoreInvalid) {
		if (!Array.isArray(list2)) list2 = [list2];
		this.__rules__.forEach(function(rule) {
			rule.enabled = false;
		});
		this.enable(list2, ignoreInvalid);
	};
	Ruler.prototype.disable = function(list2, ignoreInvalid) {
		if (!Array.isArray(list2)) list2 = [list2];
		var result = [];
		list2.forEach(function(name) {
			var idx = this.__find__(name);
			if (idx < 0) {
				if (ignoreInvalid) return;
				throw new Error("Rules manager: invalid rule name " + name);
			}
			this.__rules__[idx].enabled = false;
			result.push(name);
		}, this);
		this.__cache__ = null;
		return result;
	};
	Ruler.prototype.getRules = function(chainName) {
		if (this.__cache__ === null) this.__compile__();
		return this.__cache__[chainName] || [];
	};
	module.exports = Ruler;
} });
var require_normalize = __commonJS({ "node_modules/markdown-it/lib/rules_core/normalize.js"(exports, module) {
	"use strict";
	var NEWLINES_RE = /\r\n?|\n/g;
	var NULL_RE = /\0/g;
	module.exports = function normalize(state) {
		var str = state.src.replace(NEWLINES_RE, "\n");
		str = str.replace(NULL_RE, "�");
		state.src = str;
	};
} });
var require_block = __commonJS({ "node_modules/markdown-it/lib/rules_core/block.js"(exports, module) {
	"use strict";
	module.exports = function block4(state) {
		var token;
		if (state.inlineMode) {
			token = new state.Token("inline", "", 0);
			token.content = state.src;
			token.map = [0, 1];
			token.children = [];
			state.tokens.push(token);
		} else state.md.block.parse(state.src, state.md, state.env, state.tokens);
	};
} });
var require_inline = __commonJS({ "node_modules/markdown-it/lib/rules_core/inline.js"(exports, module) {
	"use strict";
	module.exports = function inline4(state) {
		var tokens = state.tokens, tok, i, l;
		for (i = 0, l = tokens.length; i < l; i++) {
			tok = tokens[i];
			if (tok.type === "inline") state.md.inline.parse(tok.content, state.md, state.env, tok.children);
		}
	};
} });
var require_linkify = __commonJS({ "node_modules/markdown-it/lib/rules_core/linkify.js"(exports, module) {
	"use strict";
	var arrayReplaceAt = require_utils().arrayReplaceAt;
	function isLinkOpen(str) {
		return /^<a[>\s]/i.test(str);
	}
	function isLinkClose(str) {
		return /^<\/a\s*>/i.test(str);
	}
	module.exports = function linkify(state) {
		var i, j, l, tokens, token, currentToken, nodes, ln, text2, pos, lastPos, level, htmlLinkLevel, url, fullUrl, urlText, blockTokens = state.tokens, links;
		if (!state.md.options.linkify) return;
		for (j = 0, l = blockTokens.length; j < l; j++) {
			if (blockTokens[j].type !== "inline" || !state.md.linkify.pretest(blockTokens[j].content)) continue;
			tokens = blockTokens[j].children;
			htmlLinkLevel = 0;
			for (i = tokens.length - 1; i >= 0; i--) {
				currentToken = tokens[i];
				if (currentToken.type === "link_close") {
					i--;
					while (tokens[i].level !== currentToken.level && tokens[i].type !== "link_open") i--;
					continue;
				}
				if (currentToken.type === "html_inline") {
					if (isLinkOpen(currentToken.content) && htmlLinkLevel > 0) htmlLinkLevel--;
					if (isLinkClose(currentToken.content)) htmlLinkLevel++;
				}
				if (htmlLinkLevel > 0) continue;
				if (currentToken.type === "text" && state.md.linkify.test(currentToken.content)) {
					text2 = currentToken.content;
					links = state.md.linkify.match(text2);
					nodes = [];
					level = currentToken.level;
					lastPos = 0;
					for (ln = 0; ln < links.length; ln++) {
						url = links[ln].url;
						fullUrl = state.md.normalizeLink(url);
						if (!state.md.validateLink(fullUrl)) continue;
						urlText = links[ln].text;
						if (!links[ln].schema) urlText = state.md.normalizeLinkText("http://" + urlText).replace(/^http:\/\//, "");
						else if (links[ln].schema === "mailto:" && !/^mailto:/i.test(urlText)) urlText = state.md.normalizeLinkText("mailto:" + urlText).replace(/^mailto:/, "");
						else urlText = state.md.normalizeLinkText(urlText);
						pos = links[ln].index;
						if (pos > lastPos) {
							token = new state.Token("text", "", 0);
							token.content = text2.slice(lastPos, pos);
							token.level = level;
							nodes.push(token);
						}
						token = new state.Token("link_open", "a", 1);
						token.attrs = [["href", fullUrl]];
						token.level = level++;
						token.markup = "linkify";
						token.info = "auto";
						nodes.push(token);
						token = new state.Token("text", "", 0);
						token.content = urlText;
						token.level = level;
						nodes.push(token);
						token = new state.Token("link_close", "a", -1);
						token.level = --level;
						token.markup = "linkify";
						token.info = "auto";
						nodes.push(token);
						lastPos = links[ln].lastIndex;
					}
					if (lastPos < text2.length) {
						token = new state.Token("text", "", 0);
						token.content = text2.slice(lastPos);
						token.level = level;
						nodes.push(token);
					}
					blockTokens[j].children = tokens = arrayReplaceAt(tokens, i, nodes);
				}
			}
		}
	};
} });
var require_replacements = __commonJS({ "node_modules/markdown-it/lib/rules_core/replacements.js"(exports, module) {
	"use strict";
	var RARE_RE = /\+-|\.\.|\?\?\?\?|!!!!|,,|--/;
	var SCOPED_ABBR_TEST_RE = /\((c|tm|r|p)\)/i;
	var SCOPED_ABBR_RE = /\((c|tm|r|p)\)/gi;
	var SCOPED_ABBR = {
		c: "©",
		r: "®",
		p: "§",
		tm: "™"
	};
	function replaceFn(match, name) {
		return SCOPED_ABBR[name.toLowerCase()];
	}
	function replace_scoped(inlineTokens) {
		var i, token, inside_autolink = 0;
		for (i = inlineTokens.length - 1; i >= 0; i--) {
			token = inlineTokens[i];
			if (token.type === "text" && !inside_autolink) token.content = token.content.replace(SCOPED_ABBR_RE, replaceFn);
			if (token.type === "link_open" && token.info === "auto") inside_autolink--;
			if (token.type === "link_close" && token.info === "auto") inside_autolink++;
		}
	}
	function replace_rare(inlineTokens) {
		var i, token, inside_autolink = 0;
		for (i = inlineTokens.length - 1; i >= 0; i--) {
			token = inlineTokens[i];
			if (token.type === "text" && !inside_autolink) {
				if (RARE_RE.test(token.content)) token.content = token.content.replace(/\+-/g, "±").replace(/\.{2,}/g, "…").replace(/([?!])…/g, "$1..").replace(/([?!]){4,}/g, "$1$1$1").replace(/,{2,}/g, ",").replace(/(^|[^-])---(?=[^-]|$)/gm, "$1—").replace(/(^|\s)--(?=\s|$)/gm, "$1–").replace(/(^|[^-\s])--(?=[^-\s]|$)/gm, "$1–");
			}
			if (token.type === "link_open" && token.info === "auto") inside_autolink--;
			if (token.type === "link_close" && token.info === "auto") inside_autolink++;
		}
	}
	module.exports = function replace(state) {
		var blkIdx;
		if (!state.md.options.typographer) return;
		for (blkIdx = state.tokens.length - 1; blkIdx >= 0; blkIdx--) {
			if (state.tokens[blkIdx].type !== "inline") continue;
			if (SCOPED_ABBR_TEST_RE.test(state.tokens[blkIdx].content)) replace_scoped(state.tokens[blkIdx].children);
			if (RARE_RE.test(state.tokens[blkIdx].content)) replace_rare(state.tokens[blkIdx].children);
		}
	};
} });
var require_smartquotes = __commonJS({ "node_modules/markdown-it/lib/rules_core/smartquotes.js"(exports, module) {
	"use strict";
	var isWhiteSpace = require_utils().isWhiteSpace;
	var isPunctChar = require_utils().isPunctChar;
	var isMdAsciiPunct = require_utils().isMdAsciiPunct;
	var QUOTE_TEST_RE = /['"]/;
	var QUOTE_RE = /['"]/g;
	var APOSTROPHE = "’";
	function replaceAt(str, index, ch) {
		return str.substr(0, index) + ch + str.substr(index + 1);
	}
	function process_inlines(tokens, state) {
		var i, token, text2, t, pos, max2, thisLevel, item2, lastChar, nextChar, isLastPunctChar, isNextPunctChar, isLastWhiteSpace, isNextWhiteSpace, canOpen, canClose, j, isSingle, stack = [], openQuote, closeQuote;
		for (i = 0; i < tokens.length; i++) {
			token = tokens[i];
			thisLevel = tokens[i].level;
			for (j = stack.length - 1; j >= 0; j--) if (stack[j].level <= thisLevel) break;
			stack.length = j + 1;
			if (token.type !== "text") continue;
			text2 = token.content;
			pos = 0;
			max2 = text2.length;
			OUTER: while (pos < max2) {
				QUOTE_RE.lastIndex = pos;
				t = QUOTE_RE.exec(text2);
				if (!t) break;
				canOpen = canClose = true;
				pos = t.index + 1;
				isSingle = t[0] === "'";
				lastChar = 32;
				if (t.index - 1 >= 0) lastChar = text2.charCodeAt(t.index - 1);
				else for (j = i - 1; j >= 0; j--) {
					if (tokens[j].type === "softbreak" || tokens[j].type === "hardbreak") break;
					if (!tokens[j].content) continue;
					lastChar = tokens[j].content.charCodeAt(tokens[j].content.length - 1);
					break;
				}
				nextChar = 32;
				if (pos < max2) nextChar = text2.charCodeAt(pos);
				else for (j = i + 1; j < tokens.length; j++) {
					if (tokens[j].type === "softbreak" || tokens[j].type === "hardbreak") break;
					if (!tokens[j].content) continue;
					nextChar = tokens[j].content.charCodeAt(0);
					break;
				}
				isLastPunctChar = isMdAsciiPunct(lastChar) || isPunctChar(String.fromCharCode(lastChar));
				isNextPunctChar = isMdAsciiPunct(nextChar) || isPunctChar(String.fromCharCode(nextChar));
				isLastWhiteSpace = isWhiteSpace(lastChar);
				isNextWhiteSpace = isWhiteSpace(nextChar);
				if (isNextWhiteSpace) canOpen = false;
				else if (isNextPunctChar) {
					if (!(isLastWhiteSpace || isLastPunctChar)) canOpen = false;
				}
				if (isLastWhiteSpace) canClose = false;
				else if (isLastPunctChar) {
					if (!(isNextWhiteSpace || isNextPunctChar)) canClose = false;
				}
				if (nextChar === 34 && t[0] === "\"") {
					if (lastChar >= 48 && lastChar <= 57) canClose = canOpen = false;
				}
				if (canOpen && canClose) {
					canOpen = isLastPunctChar;
					canClose = isNextPunctChar;
				}
				if (!canOpen && !canClose) {
					if (isSingle) token.content = replaceAt(token.content, t.index, APOSTROPHE);
					continue;
				}
				if (canClose) for (j = stack.length - 1; j >= 0; j--) {
					item2 = stack[j];
					if (stack[j].level < thisLevel) break;
					if (item2.single === isSingle && stack[j].level === thisLevel) {
						item2 = stack[j];
						if (isSingle) {
							openQuote = state.md.options.quotes[2];
							closeQuote = state.md.options.quotes[3];
						} else {
							openQuote = state.md.options.quotes[0];
							closeQuote = state.md.options.quotes[1];
						}
						token.content = replaceAt(token.content, t.index, closeQuote);
						tokens[item2.token].content = replaceAt(tokens[item2.token].content, item2.pos, openQuote);
						pos += closeQuote.length - 1;
						if (item2.token === i) pos += openQuote.length - 1;
						text2 = token.content;
						max2 = text2.length;
						stack.length = j;
						continue OUTER;
					}
				}
				if (canOpen) stack.push({
					token: i,
					pos: t.index,
					single: isSingle,
					level: thisLevel
				});
				else if (canClose && isSingle) token.content = replaceAt(token.content, t.index, APOSTROPHE);
			}
		}
	}
	module.exports = function smartquotes(state) {
		var blkIdx;
		if (!state.md.options.typographer) return;
		for (blkIdx = state.tokens.length - 1; blkIdx >= 0; blkIdx--) {
			if (state.tokens[blkIdx].type !== "inline" || !QUOTE_TEST_RE.test(state.tokens[blkIdx].content)) continue;
			process_inlines(state.tokens[blkIdx].children, state);
		}
	};
} });
var require_token = __commonJS({ "node_modules/markdown-it/lib/token.js"(exports, module) {
	"use strict";
	function Token(type, tag, nesting) {
		this.type = type;
		this.tag = tag;
		this.attrs = null;
		this.map = null;
		this.nesting = nesting;
		this.level = 0;
		this.children = null;
		this.content = "";
		this.markup = "";
		this.info = "";
		this.meta = null;
		this.block = false;
		this.hidden = false;
	}
	Token.prototype.attrIndex = function attrIndex(name) {
		var attrs, i, len;
		if (!this.attrs) return -1;
		attrs = this.attrs;
		for (i = 0, len = attrs.length; i < len; i++) if (attrs[i][0] === name) return i;
		return -1;
	};
	Token.prototype.attrPush = function attrPush(attrData) {
		if (this.attrs) this.attrs.push(attrData);
		else this.attrs = [attrData];
	};
	Token.prototype.attrSet = function attrSet(name, value) {
		var idx = this.attrIndex(name), attrData = [name, value];
		if (idx < 0) this.attrPush(attrData);
		else this.attrs[idx] = attrData;
	};
	Token.prototype.attrGet = function attrGet(name) {
		var idx = this.attrIndex(name), value = null;
		if (idx >= 0) value = this.attrs[idx][1];
		return value;
	};
	Token.prototype.attrJoin = function attrJoin(name, value) {
		var idx = this.attrIndex(name);
		if (idx < 0) this.attrPush([name, value]);
		else this.attrs[idx][1] = this.attrs[idx][1] + " " + value;
	};
	module.exports = Token;
} });
var require_state_core = __commonJS({ "node_modules/markdown-it/lib/rules_core/state_core.js"(exports, module) {
	"use strict";
	var Token = require_token();
	function StateCore(src, md, env) {
		this.src = src;
		this.env = env;
		this.tokens = [];
		this.inlineMode = false;
		this.md = md;
	}
	StateCore.prototype.Token = Token;
	module.exports = StateCore;
} });
var require_parser_core = __commonJS({ "node_modules/markdown-it/lib/parser_core.js"(exports, module) {
	"use strict";
	var Ruler = require_ruler();
	var _rules = [
		["normalize", require_normalize()],
		["block", require_block()],
		["inline", require_inline()],
		["linkify", require_linkify()],
		["replacements", require_replacements()],
		["smartquotes", require_smartquotes()]
	];
	function Core() {
		this.ruler = new Ruler();
		for (var i = 0; i < _rules.length; i++) this.ruler.push(_rules[i][0], _rules[i][1]);
	}
	Core.prototype.process = function(state) {
		var i, l, rules = this.ruler.getRules("");
		for (i = 0, l = rules.length; i < l; i++) rules[i](state);
	};
	Core.prototype.State = require_state_core();
	module.exports = Core;
} });
var require_table = __commonJS({ "node_modules/markdown-it/lib/rules_block/table.js"(exports, module) {
	"use strict";
	var isSpace = require_utils().isSpace;
	function getLine2(state, line) {
		var pos = state.bMarks[line] + state.tShift[line], max2 = state.eMarks[line];
		return state.src.substr(pos, max2 - pos);
	}
	function escapedSplit(str) {
		var result = [], pos = 0, max2 = str.length, ch, isEscaped = false, lastPos = 0, current = "";
		ch = str.charCodeAt(pos);
		while (pos < max2) {
			if (ch === 124) if (!isEscaped) {
				result.push(current + str.substring(lastPos, pos));
				current = "";
				lastPos = pos + 1;
			} else {
				current += str.substring(lastPos, pos - 1);
				lastPos = pos;
			}
			isEscaped = ch === 92;
			pos++;
			ch = str.charCodeAt(pos);
		}
		result.push(current + str.substring(lastPos));
		return result;
	}
	module.exports = function table3(state, startLine, endLine, silent) {
		var ch, lineText, pos, i, l, nextLine, columns, columnCount, token, aligns, t, tableLines, tbodyLines, oldParentType, terminate, terminatorRules, firstCh, secondCh;
		if (startLine + 2 > endLine) return false;
		nextLine = startLine + 1;
		if (state.sCount[nextLine] < state.blkIndent) return false;
		if (!state.md.options.allowIndentation && state.sCount[nextLine] - state.blkIndent >= 4) return false;
		pos = state.bMarks[nextLine] + state.tShift[nextLine];
		if (pos >= state.eMarks[nextLine]) return false;
		firstCh = state.src.charCodeAt(pos++);
		if (firstCh !== 124 && firstCh !== 45 && firstCh !== 58) return false;
		if (pos >= state.eMarks[nextLine]) return false;
		secondCh = state.src.charCodeAt(pos++);
		if (secondCh !== 124 && secondCh !== 45 && secondCh !== 58 && !isSpace(secondCh)) return false;
		if (firstCh === 45 && isSpace(secondCh)) return false;
		while (pos < state.eMarks[nextLine]) {
			ch = state.src.charCodeAt(pos);
			if (ch !== 124 && ch !== 45 && ch !== 58 && !isSpace(ch)) return false;
			pos++;
		}
		lineText = getLine2(state, startLine + 1);
		columns = lineText.split("|");
		aligns = [];
		for (i = 0; i < columns.length; i++) {
			t = columns[i].trim();
			if (!t) if (i === 0 || i === columns.length - 1) continue;
			else return false;
			if (!/^:?-+:?$/.test(t)) return false;
			if (t.charCodeAt(t.length - 1) === 58) aligns.push(t.charCodeAt(0) === 58 ? "center" : "right");
			else if (t.charCodeAt(0) === 58) aligns.push("left");
			else aligns.push("");
		}
		lineText = getLine2(state, startLine).trim();
		if (lineText.indexOf("|") === -1) return false;
		if (!state.md.options.allowIndentation && state.sCount[startLine] - state.blkIndent >= 4) return false;
		columns = escapedSplit(lineText);
		if (columns.length && columns[0] === "") columns.shift();
		if (columns.length && columns[columns.length - 1] === "") columns.pop();
		columnCount = columns.length;
		if (columnCount === 0 || columnCount !== aligns.length) return false;
		if (silent) return true;
		oldParentType = state.parentType;
		state.parentType = "table";
		terminatorRules = state.md.block.ruler.getRules("blockquote");
		token = state.push("table_open", "table", 1);
		token.map = tableLines = [startLine, 0];
		token = state.push("thead_open", "thead", 1);
		token.map = [startLine, startLine + 1];
		token = state.push("tr_open", "tr", 1);
		token.map = [startLine, startLine + 1];
		for (i = 0; i < columns.length; i++) {
			token = state.push("th_open", "th", 1);
			if (aligns[i]) token.attrs = [["style", "text-align:" + aligns[i]]];
			token = state.push("inline", "", 0);
			token.content = columns[i].trim();
			token.children = [];
			token = state.push("th_close", "th", -1);
		}
		token = state.push("tr_close", "tr", -1);
		token = state.push("thead_close", "thead", -1);
		for (nextLine = startLine + 2; nextLine < endLine; nextLine++) {
			if (state.sCount[nextLine] < state.blkIndent) break;
			terminate = false;
			for (i = 0, l = terminatorRules.length; i < l; i++) if (terminatorRules[i](state, nextLine, endLine, true)) {
				terminate = true;
				break;
			}
			if (terminate) break;
			lineText = getLine2(state, nextLine).trim();
			if (!lineText) break;
			if (!state.md.options.allowIndentation && state.sCount[nextLine] - state.blkIndent >= 4) break;
			columns = escapedSplit(lineText);
			if (columns.length && columns[0] === "") columns.shift();
			if (columns.length && columns[columns.length - 1] === "") columns.pop();
			if (nextLine === startLine + 2) {
				token = state.push("tbody_open", "tbody", 1);
				token.map = tbodyLines = [startLine + 2, 0];
			}
			token = state.push("tr_open", "tr", 1);
			token.map = [nextLine, nextLine + 1];
			for (i = 0; i < columnCount; i++) {
				token = state.push("td_open", "td", 1);
				if (aligns[i]) token.attrs = [["style", "text-align:" + aligns[i]]];
				token = state.push("inline", "", 0);
				token.content = columns[i] ? columns[i].trim() : "";
				token.children = [];
				token = state.push("td_close", "td", -1);
			}
			token = state.push("tr_close", "tr", -1);
		}
		if (tbodyLines) {
			token = state.push("tbody_close", "tbody", -1);
			tbodyLines[1] = nextLine;
		}
		token = state.push("table_close", "table", -1);
		tableLines[1] = nextLine;
		state.parentType = oldParentType;
		state.line = nextLine;
		return true;
	};
} });
var require_code = __commonJS({ "node_modules/markdown-it/lib/rules_block/code.js"(exports, module) {
	"use strict";
	module.exports = function code2(state, startLine, endLine) {
		if (state.md.options.allowIndentation) return false;
		var nextLine, last, token;
		if (state.sCount[startLine] - state.blkIndent < 4) return false;
		last = nextLine = startLine + 1;
		while (nextLine < endLine) {
			if (state.isEmpty(nextLine)) {
				nextLine++;
				continue;
			}
			if (state.sCount[nextLine] - state.blkIndent >= 4) {
				nextLine++;
				last = nextLine;
				continue;
			}
			break;
		}
		state.line = last;
		token = state.push("code_block", "code", 0);
		token.content = state.getLines(startLine, last, 4 + state.blkIndent, false) + "\n";
		token.map = [startLine, state.line];
		return true;
	};
} });
var require_fence = __commonJS({ "node_modules/markdown-it/lib/rules_block/fence.js"(exports, module) {
	"use strict";
	module.exports = function fence3(state, startLine, endLine, silent) {
		var marker, len, params, nextLine, mem, token, markup, haveEndMarker = false, pos = state.bMarks[startLine] + state.tShift[startLine], max2 = state.eMarks[startLine];
		if (!state.md.options.allowIndentation && state.sCount[startLine] - state.blkIndent >= 4) return false;
		if (pos + 3 > max2) return false;
		marker = state.src.charCodeAt(pos);
		if (marker !== 126 && marker !== 96) return false;
		mem = pos;
		pos = state.skipChars(pos, marker);
		len = pos - mem;
		if (len < 3) return false;
		markup = state.src.slice(mem, pos);
		params = state.src.slice(pos, max2);
		if (marker === 96) {
			if (params.indexOf(String.fromCharCode(marker)) >= 0) return false;
		}
		if (silent) return true;
		nextLine = startLine;
		for (;;) {
			nextLine++;
			if (nextLine >= endLine) break;
			pos = mem = state.bMarks[nextLine] + state.tShift[nextLine];
			max2 = state.eMarks[nextLine];
			if (pos < max2 && state.sCount[nextLine] < state.blkIndent) break;
			if (state.src.charCodeAt(pos) !== marker) continue;
			if (!state.md.options.allowIndentation && state.sCount[nextLine] - state.blkIndent >= 4) continue;
			pos = state.skipChars(pos, marker);
			if (pos - mem < len) continue;
			pos = state.skipSpaces(pos);
			if (pos < max2) continue;
			haveEndMarker = true;
			break;
		}
		len = state.sCount[startLine];
		state.line = nextLine + (haveEndMarker ? 1 : 0);
		token = state.push("fence", "code", 0);
		token.info = params;
		token.content = state.getLines(startLine + 1, nextLine, len, true);
		token.markup = markup;
		token.map = [startLine, state.line];
		return true;
	};
} });
var require_blockquote = __commonJS({ "node_modules/markdown-it/lib/rules_block/blockquote.js"(exports, module) {
	"use strict";
	var isSpace = require_utils().isSpace;
	module.exports = function blockquote2(state, startLine, endLine, silent) {
		var adjustTab, ch, i, initial, l, lastLineEmpty, lines, nextLine, offset, oldBMarks, oldBSCount, oldIndent, oldParentType, oldSCount, oldTShift, spaceAfterMarker, terminate, terminatorRules, token, isOutdented, oldLineMax = state.lineMax, pos = state.bMarks[startLine] + state.tShift[startLine], max2 = state.eMarks[startLine];
		if (!state.md.options.allowIndentation && state.sCount[startLine] - state.blkIndent >= 4) return false;
		if (state.src.charCodeAt(pos++) !== 62) return false;
		if (silent) return true;
		initial = offset = state.sCount[startLine] + 1;
		if (state.src.charCodeAt(pos) === 32) {
			pos++;
			initial++;
			offset++;
			adjustTab = false;
			spaceAfterMarker = true;
		} else if (state.src.charCodeAt(pos) === 9) {
			spaceAfterMarker = true;
			if ((state.bsCount[startLine] + offset) % 4 === 3) {
				pos++;
				initial++;
				offset++;
				adjustTab = false;
			} else adjustTab = true;
		} else spaceAfterMarker = false;
		oldBMarks = [state.bMarks[startLine]];
		state.bMarks[startLine] = pos;
		while (pos < max2) {
			ch = state.src.charCodeAt(pos);
			if (isSpace(ch)) if (ch === 9) offset += 4 - (offset + state.bsCount[startLine] + (adjustTab ? 1 : 0)) % 4;
			else offset++;
			else break;
			pos++;
		}
		oldBSCount = [state.bsCount[startLine]];
		state.bsCount[startLine] = state.sCount[startLine] + 1 + (spaceAfterMarker ? 1 : 0);
		lastLineEmpty = pos >= max2;
		oldSCount = [state.sCount[startLine]];
		state.sCount[startLine] = offset - initial;
		oldTShift = [state.tShift[startLine]];
		state.tShift[startLine] = pos - state.bMarks[startLine];
		terminatorRules = state.md.block.ruler.getRules("blockquote");
		oldParentType = state.parentType;
		state.parentType = "blockquote";
		for (nextLine = startLine + 1; nextLine < endLine; nextLine++) {
			isOutdented = state.sCount[nextLine] < state.blkIndent;
			pos = state.bMarks[nextLine] + state.tShift[nextLine];
			max2 = state.eMarks[nextLine];
			if (pos >= max2) break;
			if (state.src.charCodeAt(pos++) === 62 && !isOutdented) {
				initial = offset = state.sCount[nextLine] + 1;
				if (state.src.charCodeAt(pos) === 32) {
					pos++;
					initial++;
					offset++;
					adjustTab = false;
					spaceAfterMarker = true;
				} else if (state.src.charCodeAt(pos) === 9) {
					spaceAfterMarker = true;
					if ((state.bsCount[nextLine] + offset) % 4 === 3) {
						pos++;
						initial++;
						offset++;
						adjustTab = false;
					} else adjustTab = true;
				} else spaceAfterMarker = false;
				oldBMarks.push(state.bMarks[nextLine]);
				state.bMarks[nextLine] = pos;
				while (pos < max2) {
					ch = state.src.charCodeAt(pos);
					if (isSpace(ch)) if (ch === 9) offset += 4 - (offset + state.bsCount[nextLine] + (adjustTab ? 1 : 0)) % 4;
					else offset++;
					else break;
					pos++;
				}
				lastLineEmpty = pos >= max2;
				oldBSCount.push(state.bsCount[nextLine]);
				state.bsCount[nextLine] = state.sCount[nextLine] + 1 + (spaceAfterMarker ? 1 : 0);
				oldSCount.push(state.sCount[nextLine]);
				state.sCount[nextLine] = offset - initial;
				oldTShift.push(state.tShift[nextLine]);
				state.tShift[nextLine] = pos - state.bMarks[nextLine];
				continue;
			}
			if (lastLineEmpty) break;
			terminate = false;
			for (i = 0, l = terminatorRules.length; i < l; i++) if (terminatorRules[i](state, nextLine, endLine, true)) {
				terminate = true;
				break;
			}
			if (terminate) {
				state.lineMax = nextLine;
				if (state.blkIndent !== 0) {
					oldBMarks.push(state.bMarks[nextLine]);
					oldBSCount.push(state.bsCount[nextLine]);
					oldTShift.push(state.tShift[nextLine]);
					oldSCount.push(state.sCount[nextLine]);
					state.sCount[nextLine] -= state.blkIndent;
				}
				break;
			}
			oldBMarks.push(state.bMarks[nextLine]);
			oldBSCount.push(state.bsCount[nextLine]);
			oldTShift.push(state.tShift[nextLine]);
			oldSCount.push(state.sCount[nextLine]);
			state.sCount[nextLine] = -1;
		}
		oldIndent = state.blkIndent;
		state.blkIndent = 0;
		token = state.push("blockquote_open", "blockquote", 1);
		token.markup = ">";
		token.map = lines = [startLine, 0];
		state.md.block.tokenize(state, startLine, nextLine);
		token = state.push("blockquote_close", "blockquote", -1);
		token.markup = ">";
		state.lineMax = oldLineMax;
		state.parentType = oldParentType;
		lines[1] = state.line;
		for (i = 0; i < oldTShift.length; i++) {
			state.bMarks[i + startLine] = oldBMarks[i];
			state.tShift[i + startLine] = oldTShift[i];
			state.sCount[i + startLine] = oldSCount[i];
			state.bsCount[i + startLine] = oldBSCount[i];
		}
		state.blkIndent = oldIndent;
		return true;
	};
} });
var require_hr = __commonJS({ "node_modules/markdown-it/lib/rules_block/hr.js"(exports, module) {
	"use strict";
	var isSpace = require_utils().isSpace;
	module.exports = function hr2(state, startLine, endLine, silent) {
		var marker, cnt, ch, token, pos = state.bMarks[startLine] + state.tShift[startLine], max2 = state.eMarks[startLine];
		if (!state.md.options.allowIndentation && state.sCount[startLine] - state.blkIndent >= 4) return false;
		marker = state.src.charCodeAt(pos++);
		if (marker !== 42 && marker !== 45 && marker !== 95) return false;
		cnt = 1;
		while (pos < max2) {
			ch = state.src.charCodeAt(pos++);
			if (ch !== marker && !isSpace(ch)) return false;
			if (ch === marker) cnt++;
		}
		if (cnt < 3) return false;
		if (silent) return true;
		state.line = startLine + 1;
		token = state.push("hr", "hr", 0);
		token.map = [startLine, state.line];
		token.markup = Array(cnt + 1).join(String.fromCharCode(marker));
		return true;
	};
} });
var require_list = __commonJS({ "node_modules/markdown-it/lib/rules_block/list.js"(exports, module) {
	"use strict";
	var isSpace = require_utils().isSpace;
	function skipBulletListMarker(state, startLine) {
		var marker, pos = state.bMarks[startLine] + state.tShift[startLine], max2 = state.eMarks[startLine], ch;
		marker = state.src.charCodeAt(pos++);
		if (marker !== 42 && marker !== 45 && marker !== 43) return -1;
		if (pos < max2) {
			ch = state.src.charCodeAt(pos);
			if (!isSpace(ch)) return -1;
		}
		return pos;
	}
	function skipOrderedListMarker(state, startLine) {
		var ch, start = state.bMarks[startLine] + state.tShift[startLine], pos = start, max2 = state.eMarks[startLine];
		if (pos + 1 >= max2) return -1;
		ch = state.src.charCodeAt(pos++);
		if (ch < 48 || ch > 57) return -1;
		for (;;) {
			if (pos >= max2) return -1;
			ch = state.src.charCodeAt(pos++);
			if (ch >= 48 && ch <= 57) {
				if (pos - start >= 10) return -1;
				continue;
			}
			if (ch === 41 || ch === 46) break;
			return -1;
		}
		if (pos < max2) {
			ch = state.src.charCodeAt(pos);
			if (!isSpace(ch)) return -1;
		}
		return pos;
	}
	function markTightParagraphs(state, idx) {
		var i, l, level = state.level + 2;
		for (i = idx + 2, l = state.tokens.length - 2; i < l; i++) if (state.tokens[i].level === level && state.tokens[i].type === "paragraph_open") {
			state.tokens[i + 2].hidden = true;
			state.tokens[i].hidden = true;
			i += 2;
		}
	}
	module.exports = function list2(state, startLine, endLine, silent) {
		var ch, contentStart, i, indent, indentAfterMarker, initial, isOrdered, itemLines, l, listLines, listTokIdx, markerCharCode, markerValue, max2, nextLine, offset, oldListIndent, oldParentType, oldSCount, oldTShift, oldTight, pos, posAfterMarker, prevEmptyEnd, start, terminate, terminatorRules, token, isTerminatingParagraph = false, tight = true;
		if (!state.md.options.allowIndentation && state.sCount[startLine] - state.blkIndent >= 4) return false;
		if (!state.md.options.allowIndentation && state.listIndent >= 0 && state.sCount[startLine] - state.listIndent >= 4 && state.sCount[startLine] < state.blkIndent) return false;
		if (silent && state.parentType === "paragraph") {
			if (state.sCount[startLine] >= state.blkIndent) isTerminatingParagraph = true;
		}
		if ((posAfterMarker = skipOrderedListMarker(state, startLine)) >= 0) {
			isOrdered = true;
			start = state.bMarks[startLine] + state.tShift[startLine];
			markerValue = Number(state.src.slice(start, posAfterMarker - 1));
			if (isTerminatingParagraph && markerValue !== 1) return false;
		} else if ((posAfterMarker = skipBulletListMarker(state, startLine)) >= 0) isOrdered = false;
		else return false;
		if (isTerminatingParagraph) {
			if (state.skipSpaces(posAfterMarker) >= state.eMarks[startLine]) return false;
		}
		markerCharCode = state.src.charCodeAt(posAfterMarker - 1);
		if (silent) return true;
		listTokIdx = state.tokens.length;
		if (isOrdered) {
			token = state.push("ordered_list_open", "ol", 1);
			if (markerValue !== 1) token.attrs = [["start", markerValue]];
		} else token = state.push("bullet_list_open", "ul", 1);
		token.map = listLines = [startLine, 0];
		token.markup = String.fromCharCode(markerCharCode);
		nextLine = startLine;
		prevEmptyEnd = false;
		terminatorRules = state.md.block.ruler.getRules("list");
		oldParentType = state.parentType;
		state.parentType = "list";
		while (nextLine < endLine) {
			pos = posAfterMarker;
			max2 = state.eMarks[nextLine];
			initial = offset = state.sCount[nextLine] + posAfterMarker - (state.bMarks[startLine] + state.tShift[startLine]);
			while (pos < max2) {
				ch = state.src.charCodeAt(pos);
				if (ch === 9) offset += 4 - (offset + state.bsCount[nextLine]) % 4;
				else if (ch === 32) offset++;
				else break;
				pos++;
			}
			contentStart = pos;
			if (contentStart >= max2) indentAfterMarker = 1;
			else indentAfterMarker = offset - initial;
			if (!state.md.options.allowIndentation && indentAfterMarker > 4) indentAfterMarker = 1;
			indent = initial + indentAfterMarker;
			token = state.push("list_item_open", "li", 1);
			token.markup = String.fromCharCode(markerCharCode);
			token.map = itemLines = [startLine, 0];
			if (isOrdered) token.info = state.src.slice(start, posAfterMarker - 1);
			oldTight = state.tight;
			oldTShift = state.tShift[startLine];
			oldSCount = state.sCount[startLine];
			oldListIndent = state.listIndent;
			state.listIndent = state.blkIndent;
			state.blkIndent = indent;
			state.tight = true;
			state.tShift[startLine] = contentStart - state.bMarks[startLine];
			state.sCount[startLine] = offset;
			if (contentStart >= max2 && state.isEmpty(startLine + 1)) state.line = Math.min(state.line + 2, endLine);
			else state.md.block.tokenize(state, startLine, endLine, true);
			if (!state.tight || prevEmptyEnd) tight = false;
			prevEmptyEnd = state.line - startLine > 1 && state.isEmpty(state.line - 1);
			state.blkIndent = state.listIndent;
			state.listIndent = oldListIndent;
			state.tShift[startLine] = oldTShift;
			state.sCount[startLine] = oldSCount;
			state.tight = oldTight;
			token = state.push("list_item_close", "li", -1);
			token.markup = String.fromCharCode(markerCharCode);
			nextLine = startLine = state.line;
			itemLines[1] = nextLine;
			contentStart = state.bMarks[startLine];
			if (nextLine >= endLine) break;
			if (state.sCount[nextLine] < state.blkIndent) break;
			if (!state.md.options.allowIndentation && state.sCount[startLine] - state.blkIndent >= 4) break;
			terminate = false;
			for (i = 0, l = terminatorRules.length; i < l; i++) if (terminatorRules[i](state, nextLine, endLine, true)) {
				terminate = true;
				break;
			}
			if (terminate) break;
			if (isOrdered) {
				posAfterMarker = skipOrderedListMarker(state, nextLine);
				if (posAfterMarker < 0) break;
				start = state.bMarks[nextLine] + state.tShift[nextLine];
			} else {
				posAfterMarker = skipBulletListMarker(state, nextLine);
				if (posAfterMarker < 0) break;
			}
			if (markerCharCode !== state.src.charCodeAt(posAfterMarker - 1)) break;
		}
		if (isOrdered) token = state.push("ordered_list_close", "ol", -1);
		else token = state.push("bullet_list_close", "ul", -1);
		token.markup = String.fromCharCode(markerCharCode);
		listLines[1] = nextLine;
		state.line = nextLine;
		state.parentType = oldParentType;
		if (tight) markTightParagraphs(state, listTokIdx);
		return true;
	};
} });
var require_reference = __commonJS({ "node_modules/markdown-it/lib/rules_block/reference.js"(exports, module) {
	"use strict";
	var normalizeReference = require_utils().normalizeReference;
	var isSpace = require_utils().isSpace;
	module.exports = function reference(state, startLine, _endLine, silent) {
		var ch, destEndPos, destEndLineNo, endLine, href, i, l, label, labelEnd, oldParentType, res, start, str, terminate, terminatorRules, title, lines = 0, pos = state.bMarks[startLine] + state.tShift[startLine], max2 = state.eMarks[startLine], nextLine = startLine + 1;
		if (!state.md.options.allowIndentation && state.sCount[startLine] - state.blkIndent >= 4) return false;
		if (state.src.charCodeAt(pos) !== 91) return false;
		while (++pos < max2) if (state.src.charCodeAt(pos) === 93 && state.src.charCodeAt(pos - 1) !== 92) {
			if (pos + 1 === max2) return false;
			if (state.src.charCodeAt(pos + 1) !== 58) return false;
			break;
		}
		endLine = state.lineMax;
		terminatorRules = state.md.block.ruler.getRules("reference");
		oldParentType = state.parentType;
		state.parentType = "reference";
		for (; nextLine < endLine && !state.isEmpty(nextLine); nextLine++) {
			if (!state.md.options.allowIndentation && state.sCount[nextLine] - state.blkIndent > 3) continue;
			if (state.sCount[nextLine] < 0) continue;
			terminate = false;
			for (i = 0, l = terminatorRules.length; i < l; i++) if (terminatorRules[i](state, nextLine, endLine, true)) {
				terminate = true;
				break;
			}
			if (terminate) break;
		}
		str = state.getLines(startLine, nextLine, state.blkIndent, false).trim();
		max2 = str.length;
		for (pos = 1; pos < max2; pos++) {
			ch = str.charCodeAt(pos);
			if (ch === 91) return false;
			else if (ch === 93) {
				labelEnd = pos;
				break;
			} else if (ch === 10) lines++;
			else if (ch === 92) {
				pos++;
				if (pos < max2 && str.charCodeAt(pos) === 10) lines++;
			}
		}
		if (labelEnd < 0 || str.charCodeAt(labelEnd + 1) !== 58) return false;
		for (pos = labelEnd + 2; pos < max2; pos++) {
			ch = str.charCodeAt(pos);
			if (ch === 10) lines++;
			else if (isSpace(ch)) {} else break;
		}
		res = state.md.helpers.parseLinkDestination(str, pos, max2);
		if (!res.ok) return false;
		href = state.md.normalizeLink(res.str);
		if (!state.md.validateLink(href)) return false;
		pos = res.pos;
		lines += res.lines;
		destEndPos = pos;
		destEndLineNo = lines;
		start = pos;
		for (; pos < max2; pos++) {
			ch = str.charCodeAt(pos);
			if (ch === 10) lines++;
			else if (isSpace(ch)) {} else break;
		}
		res = state.md.helpers.parseLinkTitle(str, pos, max2);
		if (pos < max2 && start !== pos && res.ok) {
			title = res.str;
			pos = res.pos;
			lines += res.lines;
		} else {
			title = "";
			pos = destEndPos;
			lines = destEndLineNo;
		}
		while (pos < max2) {
			ch = str.charCodeAt(pos);
			if (!isSpace(ch)) break;
			pos++;
		}
		if (pos < max2 && str.charCodeAt(pos) !== 10) {
			if (title) {
				title = "";
				pos = destEndPos;
				lines = destEndLineNo;
				while (pos < max2) {
					ch = str.charCodeAt(pos);
					if (!isSpace(ch)) break;
					pos++;
				}
			}
		}
		if (pos < max2 && str.charCodeAt(pos) !== 10) return false;
		label = normalizeReference(str.slice(1, labelEnd));
		if (!label) return false;
		if (silent) return true;
		if (typeof state.env.references === "undefined") state.env.references = {};
		if (typeof state.env.references[label] === "undefined") state.env.references[label] = {
			title,
			href
		};
		state.parentType = oldParentType;
		state.line = startLine + lines + 1;
		return true;
	};
} });
var require_html_blocks = __commonJS({ "node_modules/markdown-it/lib/common/html_blocks.js"(exports, module) {
	"use strict";
	module.exports = [
		"address",
		"article",
		"aside",
		"base",
		"basefont",
		"blockquote",
		"body",
		"caption",
		"center",
		"col",
		"colgroup",
		"dd",
		"details",
		"dialog",
		"dir",
		"div",
		"dl",
		"dt",
		"fieldset",
		"figcaption",
		"figure",
		"footer",
		"form",
		"frame",
		"frameset",
		"h1",
		"h2",
		"h3",
		"h4",
		"h5",
		"h6",
		"head",
		"header",
		"hr",
		"html",
		"iframe",
		"legend",
		"li",
		"link",
		"main",
		"menu",
		"menuitem",
		"nav",
		"noframes",
		"ol",
		"optgroup",
		"option",
		"p",
		"param",
		"section",
		"source",
		"summary",
		"table",
		"tbody",
		"td",
		"tfoot",
		"th",
		"thead",
		"title",
		"tr",
		"track",
		"ul"
	];
} });
var require_html_re = __commonJS({ "node_modules/markdown-it/lib/common/html_re.js"(exports, module) {
	"use strict";
	var open_tag = "<[A-Za-z][A-Za-z0-9\\-]*(?:\\s+[a-zA-Z_:][a-zA-Z0-9:._-]*(?:\\s*=\\s*(?:[^\"'=<>`\\x00-\\x20]+|'[^']*'|\"[^\"]*\"))?)*\\s*\\/?>";
	var close_tag = "<\\/[A-Za-z][A-Za-z0-9\\-]*\\s*>";
	var HTML_TAG_RE = new RegExp("^(?:" + open_tag + "|" + close_tag + "|<!---->|<!--(?:-?[^>-])(?:-?[^-])*-->|<[?][\\s\\S]*?[?]>|<![A-Z]+\\s+[^>]*>|<!\\[CDATA\\[[\\s\\S]*?\\]\\]>)");
	var HTML_OPEN_CLOSE_TAG_RE = new RegExp("^(?:" + open_tag + "|" + close_tag + ")");
	module.exports.HTML_TAG_RE = HTML_TAG_RE;
	module.exports.HTML_OPEN_CLOSE_TAG_RE = HTML_OPEN_CLOSE_TAG_RE;
} });
var require_html_block = __commonJS({ "node_modules/markdown-it/lib/rules_block/html_block.js"(exports, module) {
	"use strict";
	var block_names = require_html_blocks();
	var HTML_OPEN_CLOSE_TAG_RE = require_html_re().HTML_OPEN_CLOSE_TAG_RE;
	var HTML_SEQUENCES = [
		[
			/^<(script|pre|style|textarea)(?=(\s|>|$))/i,
			/<\/(script|pre|style|textarea)>/i,
			true
		],
		[
			/^<!--/,
			/-->/,
			true
		],
		[
			/^<\?/,
			/\?>/,
			true
		],
		[
			/^<![A-Z]/,
			/>/,
			true
		],
		[
			/^<!\[CDATA\[/,
			/\]\]>/,
			true
		],
		[
			new RegExp("^</?(" + block_names.join("|") + ")(?=(\\s|/?>|$))", "i"),
			/^$/,
			true
		],
		[
			new RegExp(HTML_OPEN_CLOSE_TAG_RE.source + "\\s*$"),
			/^$/,
			false
		]
	];
	module.exports = function html_block(state, startLine, endLine, silent) {
		var i, nextLine, token, lineText, pos = state.bMarks[startLine] + state.tShift[startLine], max2 = state.eMarks[startLine];
		if (!state.md.options.allowIndentation && state.sCount[startLine] - state.blkIndent >= 4) return false;
		if (!state.md.options.html) return false;
		if (state.src.charCodeAt(pos) !== 60) return false;
		lineText = state.src.slice(pos, max2);
		for (i = 0; i < HTML_SEQUENCES.length; i++) if (HTML_SEQUENCES[i][0].test(lineText)) break;
		if (i === HTML_SEQUENCES.length) return false;
		if (silent) return HTML_SEQUENCES[i][2];
		nextLine = startLine + 1;
		if (!HTML_SEQUENCES[i][1].test(lineText)) for (; nextLine < endLine; nextLine++) {
			if (state.sCount[nextLine] < state.blkIndent) break;
			pos = state.bMarks[nextLine] + state.tShift[nextLine];
			max2 = state.eMarks[nextLine];
			lineText = state.src.slice(pos, max2);
			if (HTML_SEQUENCES[i][1].test(lineText)) {
				if (lineText.length !== 0) nextLine++;
				break;
			}
		}
		state.line = nextLine;
		token = state.push("html_block", "", 0);
		token.map = [startLine, nextLine];
		token.content = state.getLines(startLine, nextLine, state.blkIndent, true);
		return true;
	};
} });
var require_heading = __commonJS({ "node_modules/markdown-it/lib/rules_block/heading.js"(exports, module) {
	"use strict";
	var isSpace = require_utils().isSpace;
	module.exports = function heading2(state, startLine, endLine, silent) {
		var ch, level, tmp, token, pos = state.bMarks[startLine] + state.tShift[startLine], max2 = state.eMarks[startLine];
		if (!state.md.options.allowIndentation && state.sCount[startLine] - state.blkIndent >= 4) return false;
		ch = state.src.charCodeAt(pos);
		if (ch !== 35 || pos >= max2) return false;
		level = 1;
		ch = state.src.charCodeAt(++pos);
		while (ch === 35 && pos < max2 && level <= 6) {
			level++;
			ch = state.src.charCodeAt(++pos);
		}
		if (level > 6 || pos < max2 && !isSpace(ch)) return false;
		if (silent) return true;
		max2 = state.skipSpacesBack(max2, pos);
		tmp = state.skipCharsBack(max2, 35, pos);
		if (tmp > pos && isSpace(state.src.charCodeAt(tmp - 1))) max2 = tmp;
		state.line = startLine + 1;
		token = state.push("heading_open", "h" + String(level), 1);
		token.markup = "########".slice(0, level);
		token.map = [startLine, state.line];
		token = state.push("inline", "", 0);
		token.content = state.src.slice(pos, max2).trim();
		token.map = [startLine, state.line];
		token.children = [];
		token = state.push("heading_close", "h" + String(level), -1);
		token.markup = "########".slice(0, level);
		return true;
	};
} });
var require_lheading = __commonJS({ "node_modules/markdown-it/lib/rules_block/lheading.js"(exports, module) {
	"use strict";
	module.exports = function lheading(state, startLine, endLine) {
		var content, terminate, i, l, token, pos, max2, level, marker, nextLine = startLine + 1, oldParentType, terminatorRules = state.md.block.ruler.getRules("paragraph");
		if (!state.md.options.allowIndentation && state.sCount[startLine] - state.blkIndent >= 4) return false;
		oldParentType = state.parentType;
		state.parentType = "paragraph";
		for (; nextLine < endLine && !state.isEmpty(nextLine); nextLine++) {
			if (!state.md.options.allowIndentation && state.sCount[nextLine] - state.blkIndent > 3) continue;
			if (state.sCount[nextLine] >= state.blkIndent) {
				pos = state.bMarks[nextLine] + state.tShift[nextLine];
				max2 = state.eMarks[nextLine];
				if (pos < max2) {
					marker = state.src.charCodeAt(pos);
					if (marker === 45 || marker === 61) {
						pos = state.skipChars(pos, marker);
						pos = state.skipSpaces(pos);
						if (pos >= max2) {
							level = marker === 61 ? 1 : 2;
							break;
						}
					}
				}
			}
			if (state.sCount[nextLine] < 0) continue;
			terminate = false;
			for (i = 0, l = terminatorRules.length; i < l; i++) if (terminatorRules[i](state, nextLine, endLine, true)) {
				terminate = true;
				break;
			}
			if (terminate) break;
		}
		if (!level) return false;
		content = state.getLines(startLine, nextLine, state.blkIndent, false).trim();
		state.line = nextLine + 1;
		token = state.push("heading_open", "h" + String(level), 1);
		token.markup = String.fromCharCode(marker);
		token.map = [startLine, state.line];
		token = state.push("inline", "", 0);
		token.content = content;
		token.map = [startLine, state.line - 1];
		token.children = [];
		token = state.push("heading_close", "h" + String(level), -1);
		token.markup = String.fromCharCode(marker);
		state.parentType = oldParentType;
		return true;
	};
} });
var require_paragraph = __commonJS({ "node_modules/markdown-it/lib/rules_block/paragraph.js"(exports, module) {
	"use strict";
	module.exports = function paragraph2(state, startLine) {
		var content, terminate, i, l, token, oldParentType, nextLine = startLine + 1, terminatorRules = state.md.block.ruler.getRules("paragraph"), endLine = state.lineMax;
		oldParentType = state.parentType;
		state.parentType = "paragraph";
		for (; nextLine < endLine && !state.isEmpty(nextLine); nextLine++) {
			if (!state.md.options.allowIndentation && state.sCount[nextLine] - state.blkIndent > 3) continue;
			if (state.sCount[nextLine] < 0) continue;
			terminate = false;
			for (i = 0, l = terminatorRules.length; i < l; i++) if (terminatorRules[i](state, nextLine, endLine, true)) {
				terminate = true;
				break;
			}
			if (terminate) break;
		}
		content = state.getLines(startLine, nextLine, state.blkIndent, false).trim();
		state.line = nextLine;
		token = state.push("paragraph_open", "p", 1);
		token.map = [startLine, state.line];
		token = state.push("inline", "", 0);
		token.content = content;
		token.map = [startLine, state.line];
		token.children = [];
		token = state.push("paragraph_close", "p", -1);
		state.parentType = oldParentType;
		return true;
	};
} });
var require_state_block = __commonJS({ "node_modules/markdown-it/lib/rules_block/state_block.js"(exports, module) {
	"use strict";
	var Token = require_token();
	var isSpace = require_utils().isSpace;
	function StateBlock(src, md, env, tokens) {
		var ch, s2, start, pos, len, indent, offset, indent_found;
		this.src = src;
		this.md = md;
		this.env = env;
		this.tokens = tokens;
		this.bMarks = [];
		this.eMarks = [];
		this.tShift = [];
		this.sCount = [];
		this.bsCount = [];
		this.blkIndent = 0;
		this.line = 0;
		this.lineMax = 0;
		this.tight = false;
		this.ddIndent = -1;
		this.listIndent = -1;
		this.parentType = "root";
		this.level = 0;
		this.result = "";
		s2 = this.src;
		indent_found = false;
		for (start = pos = indent = offset = 0, len = s2.length; pos < len; pos++) {
			ch = s2.charCodeAt(pos);
			if (!indent_found) if (isSpace(ch)) {
				indent++;
				if (ch === 9) offset += 4 - offset % 4;
				else offset++;
				continue;
			} else indent_found = true;
			if (ch === 10 || pos === len - 1) {
				if (ch !== 10) pos++;
				this.bMarks.push(start);
				this.eMarks.push(pos);
				this.tShift.push(indent);
				this.sCount.push(offset);
				this.bsCount.push(0);
				indent_found = false;
				indent = 0;
				offset = 0;
				start = pos + 1;
			}
		}
		this.bMarks.push(s2.length);
		this.eMarks.push(s2.length);
		this.tShift.push(0);
		this.sCount.push(0);
		this.bsCount.push(0);
		this.lineMax = this.bMarks.length - 1;
	}
	StateBlock.prototype.push = function(type, tag, nesting) {
		var token = new Token(type, tag, nesting);
		token.block = true;
		if (nesting < 0) this.level--;
		token.level = this.level;
		if (nesting > 0) this.level++;
		this.tokens.push(token);
		return token;
	};
	StateBlock.prototype.isEmpty = function isEmpty(line) {
		return this.bMarks[line] + this.tShift[line] >= this.eMarks[line];
	};
	StateBlock.prototype.skipEmptyLines = function skipEmptyLines(from) {
		for (var max2 = this.lineMax; from < max2; from++) if (this.bMarks[from] + this.tShift[from] < this.eMarks[from]) break;
		return from;
	};
	StateBlock.prototype.skipSpaces = function skipSpaces(pos) {
		var ch;
		for (var max2 = this.src.length; pos < max2; pos++) {
			ch = this.src.charCodeAt(pos);
			if (!isSpace(ch)) break;
		}
		return pos;
	};
	StateBlock.prototype.skipSpacesBack = function skipSpacesBack(pos, min) {
		if (pos <= min) return pos;
		while (pos > min) if (!isSpace(this.src.charCodeAt(--pos))) return pos + 1;
		return pos;
	};
	StateBlock.prototype.skipChars = function skipChars(pos, code2) {
		for (var max2 = this.src.length; pos < max2; pos++) if (this.src.charCodeAt(pos) !== code2) break;
		return pos;
	};
	StateBlock.prototype.skipCharsBack = function skipCharsBack(pos, code2, min) {
		if (pos <= min) return pos;
		while (pos > min) if (code2 !== this.src.charCodeAt(--pos)) return pos + 1;
		return pos;
	};
	StateBlock.prototype.getLines = function getLines(begin, end, indent, keepLastLF) {
		var i, lineIndent, ch, first, last, queue, lineStart, line = begin;
		if (begin >= end) return "";
		queue = new Array(end - begin);
		for (i = 0; line < end; line++, i++) {
			lineIndent = 0;
			lineStart = first = this.bMarks[line];
			if (line + 1 < end || keepLastLF) last = this.eMarks[line] + 1;
			else last = this.eMarks[line];
			while (first < last && lineIndent < indent) {
				ch = this.src.charCodeAt(first);
				if (isSpace(ch)) if (ch === 9) lineIndent += 4 - (lineIndent + this.bsCount[line]) % 4;
				else lineIndent++;
				else if (first - lineStart < this.tShift[line]) lineIndent++;
				else break;
				first++;
			}
			if (lineIndent > indent) queue[i] = new Array(lineIndent - indent + 1).join(" ") + this.src.slice(first, last);
			else queue[i] = this.src.slice(first, last);
		}
		return queue.join("");
	};
	StateBlock.prototype.Token = Token;
	module.exports = StateBlock;
} });
var require_parser_block = __commonJS({ "node_modules/markdown-it/lib/parser_block.js"(exports, module) {
	"use strict";
	var Ruler = require_ruler();
	var _rules = [
		[
			"table",
			require_table(),
			["paragraph", "reference"]
		],
		["code", require_code()],
		[
			"fence",
			require_fence(),
			[
				"paragraph",
				"reference",
				"blockquote",
				"list"
			]
		],
		[
			"blockquote",
			require_blockquote(),
			[
				"paragraph",
				"reference",
				"blockquote",
				"list"
			]
		],
		[
			"hr",
			require_hr(),
			[
				"paragraph",
				"reference",
				"blockquote",
				"list"
			]
		],
		[
			"list",
			require_list(),
			[
				"paragraph",
				"reference",
				"blockquote"
			]
		],
		["reference", require_reference()],
		[
			"html_block",
			require_html_block(),
			[
				"paragraph",
				"reference",
				"blockquote"
			]
		],
		[
			"heading",
			require_heading(),
			[
				"paragraph",
				"reference",
				"blockquote"
			]
		],
		["lheading", require_lheading()],
		["paragraph", require_paragraph()]
	];
	function ParserBlock() {
		this.ruler = new Ruler();
		for (var i = 0; i < _rules.length; i++) this.ruler.push(_rules[i][0], _rules[i][1], { alt: (_rules[i][2] || []).slice() });
	}
	ParserBlock.prototype.tokenize = function(state, startLine, endLine) {
		var ok, i, rules = this.ruler.getRules(""), len = rules.length, line = startLine, hasEmptyLines = false, maxNesting = state.md.options.maxNesting;
		while (line < endLine) {
			state.line = line = state.skipEmptyLines(line);
			if (line >= endLine) break;
			if (state.sCount[line] < state.blkIndent) break;
			if (state.level >= maxNesting) {
				state.line = endLine;
				break;
			}
			for (i = 0; i < len; i++) {
				ok = rules[i](state, line, endLine, false);
				if (ok) break;
			}
			state.tight = !hasEmptyLines;
			if (state.isEmpty(state.line - 1)) hasEmptyLines = true;
			line = state.line;
			if (line < endLine && state.isEmpty(line)) {
				hasEmptyLines = true;
				line++;
				state.line = line;
			}
		}
	};
	ParserBlock.prototype.parse = function(src, md, env, outTokens) {
		var state;
		if (!src) return;
		state = new this.State(src, md, env, outTokens);
		this.tokenize(state, state.line, state.lineMax);
	};
	ParserBlock.prototype.State = require_state_block();
	module.exports = ParserBlock;
} });
var require_text = __commonJS({ "node_modules/markdown-it/lib/rules_inline/text.js"(exports, module) {
	"use strict";
	function isTerminatorChar(ch) {
		switch (ch) {
			case 10:
			case 33:
			case 35:
			case 36:
			case 37:
			case 38:
			case 42:
			case 43:
			case 45:
			case 58:
			case 60:
			case 61:
			case 62:
			case 64:
			case 91:
			case 92:
			case 93:
			case 94:
			case 95:
			case 96:
			case 123:
			case 125:
			case 126: return true;
			default: return false;
		}
	}
	module.exports = function text2(state, silent) {
		var pos = state.pos;
		while (pos < state.posMax && !isTerminatorChar(state.src.charCodeAt(pos))) pos++;
		if (pos === state.pos) return false;
		if (!silent) state.pending += state.src.slice(state.pos, pos);
		state.pos = pos;
		return true;
	};
} });
var require_newline = __commonJS({ "node_modules/markdown-it/lib/rules_inline/newline.js"(exports, module) {
	"use strict";
	var isSpace = require_utils().isSpace;
	module.exports = function newline(state, silent) {
		var pmax, max2, ws, pos = state.pos;
		if (state.src.charCodeAt(pos) !== 10) return false;
		pmax = state.pending.length - 1;
		max2 = state.posMax;
		if (!silent) if (pmax >= 0 && state.pending.charCodeAt(pmax) === 32) if (pmax >= 1 && state.pending.charCodeAt(pmax - 1) === 32) {
			ws = pmax - 1;
			while (ws >= 1 && state.pending.charCodeAt(ws - 1) === 32) ws--;
			state.pending = state.pending.slice(0, ws);
			state.push("hardbreak", "br", 0);
		} else {
			state.pending = state.pending.slice(0, -1);
			state.push("softbreak", "br", 0);
		}
		else state.push("softbreak", "br", 0);
		pos++;
		while (pos < max2 && isSpace(state.src.charCodeAt(pos))) pos++;
		state.pos = pos;
		return true;
	};
} });
var require_escape = __commonJS({ "node_modules/markdown-it/lib/rules_inline/escape.js"(exports, module) {
	"use strict";
	var isSpace = require_utils().isSpace;
	var ESCAPED = [];
	for (i = 0; i < 256; i++) ESCAPED.push(0);
	var i;
	"\\!\"#$%&'()*+,./:;<=>?@[]^_`{|}~-".split("").forEach(function(ch) {
		ESCAPED[ch.charCodeAt(0)] = 1;
	});
	module.exports = function escape(state, silent) {
		var ch, pos = state.pos, max2 = state.posMax;
		if (state.src.charCodeAt(pos) !== 92) return false;
		pos++;
		if (pos < max2) {
			ch = state.src.charCodeAt(pos);
			if (ch < 256 && ESCAPED[ch] !== 0) {
				if (!silent) state.pending += state.src[pos];
				state.pos += 2;
				return true;
			}
			if (ch === 10) {
				if (!silent) state.push("hardbreak", "br", 0);
				pos++;
				while (pos < max2) {
					ch = state.src.charCodeAt(pos);
					if (!isSpace(ch)) break;
					pos++;
				}
				state.pos = pos;
				return true;
			}
		}
		if (!silent) state.pending += "\\";
		state.pos++;
		return true;
	};
} });
var require_backticks = __commonJS({ "node_modules/markdown-it/lib/rules_inline/backticks.js"(exports, module) {
	"use strict";
	module.exports = function backtick(state, silent) {
		var start, max2, marker, token, matchStart, matchEnd, openerLength, closerLength, pos = state.pos;
		if (state.src.charCodeAt(pos) !== 96) return false;
		start = pos;
		pos++;
		max2 = state.posMax;
		while (pos < max2 && state.src.charCodeAt(pos) === 96) pos++;
		marker = state.src.slice(start, pos);
		openerLength = marker.length;
		if (state.backticksScanned && (state.backticks[openerLength] || 0) <= start) {
			if (!silent) state.pending += marker;
			state.pos += openerLength;
			return true;
		}
		matchStart = matchEnd = pos;
		while ((matchStart = state.src.indexOf("`", matchEnd)) !== -1) {
			matchEnd = matchStart + 1;
			while (matchEnd < max2 && state.src.charCodeAt(matchEnd) === 96) matchEnd++;
			closerLength = matchEnd - matchStart;
			if (closerLength === openerLength) {
				if (!silent) {
					token = state.push("code_inline", "code", 0);
					token.markup = marker;
					token.content = state.src.slice(pos, matchStart).replace(/\n/g, " ").replace(/^ (.+) $/, "$1");
				}
				state.pos = matchEnd;
				return true;
			}
			state.backticks[closerLength] = matchStart;
		}
		state.backticksScanned = true;
		if (!silent) state.pending += marker;
		state.pos += openerLength;
		return true;
	};
} });
var require_strikethrough = __commonJS({ "node_modules/markdown-it/lib/rules_inline/strikethrough.js"(exports, module) {
	"use strict";
	module.exports.tokenize = function strikethrough(state, silent) {
		var i, scanned, token, len, ch, start = state.pos, marker = state.src.charCodeAt(start);
		if (silent) return false;
		if (marker !== 126) return false;
		scanned = state.scanDelims(state.pos, true);
		len = scanned.length;
		ch = String.fromCharCode(marker);
		if (len < 2) return false;
		if (len % 2) {
			token = state.push("text", "", 0);
			token.content = ch;
			len--;
		}
		for (i = 0; i < len; i += 2) {
			token = state.push("text", "", 0);
			token.content = ch + ch;
			state.delimiters.push({
				marker,
				length: 0,
				token: state.tokens.length - 1,
				end: -1,
				open: scanned.can_open,
				close: scanned.can_close
			});
		}
		state.pos += scanned.length;
		return true;
	};
	function postProcess(state, delimiters) {
		var i, j, startDelim, endDelim, token, loneMarkers = [], max2 = delimiters.length;
		for (i = 0; i < max2; i++) {
			startDelim = delimiters[i];
			if (startDelim.marker !== 126) continue;
			if (startDelim.end === -1) continue;
			endDelim = delimiters[startDelim.end];
			token = state.tokens[startDelim.token];
			token.type = "s_open";
			token.tag = "s";
			token.nesting = 1;
			token.markup = "~~";
			token.content = "";
			token = state.tokens[endDelim.token];
			token.type = "s_close";
			token.tag = "s";
			token.nesting = -1;
			token.markup = "~~";
			token.content = "";
			if (state.tokens[endDelim.token - 1].type === "text" && state.tokens[endDelim.token - 1].content === "~") loneMarkers.push(endDelim.token - 1);
		}
		while (loneMarkers.length) {
			i = loneMarkers.pop();
			j = i + 1;
			while (j < state.tokens.length && state.tokens[j].type === "s_close") j++;
			j--;
			if (i !== j) {
				token = state.tokens[j];
				state.tokens[j] = state.tokens[i];
				state.tokens[i] = token;
			}
		}
	}
	module.exports.postProcess = function strikethrough(state) {
		var curr, tokens_meta = state.tokens_meta, max2 = state.tokens_meta.length;
		postProcess(state, state.delimiters);
		for (curr = 0; curr < max2; curr++) if (tokens_meta[curr] && tokens_meta[curr].delimiters) postProcess(state, tokens_meta[curr].delimiters);
	};
} });
var require_emphasis = __commonJS({ "node_modules/markdown-it/lib/rules_inline/emphasis.js"(exports, module) {
	"use strict";
	module.exports.tokenize = function emphasis(state, silent) {
		var i, scanned, token, start = state.pos, marker = state.src.charCodeAt(start);
		if (silent) return false;
		if (marker !== 95 && marker !== 42) return false;
		scanned = state.scanDelims(state.pos, marker === 42);
		for (i = 0; i < scanned.length; i++) {
			token = state.push("text", "", 0);
			token.content = String.fromCharCode(marker);
			state.delimiters.push({
				marker,
				length: scanned.length,
				token: state.tokens.length - 1,
				end: -1,
				open: scanned.can_open,
				close: scanned.can_close
			});
		}
		state.pos += scanned.length;
		return true;
	};
	function postProcess(state, delimiters) {
		var i, startDelim, endDelim, token, ch, isStrong;
		for (i = delimiters.length - 1; i >= 0; i--) {
			startDelim = delimiters[i];
			if (startDelim.marker !== 95 && startDelim.marker !== 42) continue;
			if (startDelim.end === -1) continue;
			endDelim = delimiters[startDelim.end];
			isStrong = i > 0 && delimiters[i - 1].end === startDelim.end + 1 && delimiters[i - 1].marker === startDelim.marker && delimiters[i - 1].token === startDelim.token - 1 && delimiters[startDelim.end + 1].token === endDelim.token + 1;
			ch = String.fromCharCode(startDelim.marker);
			token = state.tokens[startDelim.token];
			token.type = isStrong ? "strong_open" : "em_open";
			token.tag = isStrong ? "strong" : "em";
			token.nesting = 1;
			token.markup = isStrong ? ch + ch : ch;
			token.content = "";
			token = state.tokens[endDelim.token];
			token.type = isStrong ? "strong_close" : "em_close";
			token.tag = isStrong ? "strong" : "em";
			token.nesting = -1;
			token.markup = isStrong ? ch + ch : ch;
			token.content = "";
			if (isStrong) {
				state.tokens[delimiters[i - 1].token].content = "";
				state.tokens[delimiters[startDelim.end + 1].token].content = "";
				i--;
			}
		}
	}
	module.exports.postProcess = function emphasis(state) {
		var curr, tokens_meta = state.tokens_meta, max2 = state.tokens_meta.length;
		postProcess(state, state.delimiters);
		for (curr = 0; curr < max2; curr++) if (tokens_meta[curr] && tokens_meta[curr].delimiters) postProcess(state, tokens_meta[curr].delimiters);
	};
} });
var require_link = __commonJS({ "node_modules/markdown-it/lib/rules_inline/link.js"(exports, module) {
	"use strict";
	var normalizeReference = require_utils().normalizeReference;
	var isSpace = require_utils().isSpace;
	module.exports = function link2(state, silent) {
		var attrs, code2, label, labelEnd, labelStart, pos, res, ref, token, href = "", title = "", oldPos = state.pos, max2 = state.posMax, start = state.pos, parseReference = true;
		if (state.src.charCodeAt(state.pos) !== 91) return false;
		labelStart = state.pos + 1;
		labelEnd = state.md.helpers.parseLinkLabel(state, state.pos, true);
		if (labelEnd < 0) return false;
		pos = labelEnd + 1;
		if (pos < max2 && state.src.charCodeAt(pos) === 40) {
			parseReference = false;
			pos++;
			for (; pos < max2; pos++) {
				code2 = state.src.charCodeAt(pos);
				if (!isSpace(code2) && code2 !== 10) break;
			}
			if (pos >= max2) return false;
			start = pos;
			res = state.md.helpers.parseLinkDestination(state.src, pos, state.posMax);
			if (res.ok) {
				href = state.md.normalizeLink(res.str);
				if (state.md.validateLink(href)) pos = res.pos;
				else href = "";
				start = pos;
				for (; pos < max2; pos++) {
					code2 = state.src.charCodeAt(pos);
					if (!isSpace(code2) && code2 !== 10) break;
				}
				res = state.md.helpers.parseLinkTitle(state.src, pos, state.posMax);
				if (pos < max2 && start !== pos && res.ok) {
					title = res.str;
					pos = res.pos;
					for (; pos < max2; pos++) {
						code2 = state.src.charCodeAt(pos);
						if (!isSpace(code2) && code2 !== 10) break;
					}
				}
			}
			if (pos >= max2 || state.src.charCodeAt(pos) !== 41) parseReference = true;
			pos++;
		}
		if (parseReference) {
			if (typeof state.env.references === "undefined") return false;
			if (pos < max2 && state.src.charCodeAt(pos) === 91) {
				start = pos + 1;
				pos = state.md.helpers.parseLinkLabel(state, pos);
				if (pos >= 0) label = state.src.slice(start, pos++);
				else pos = labelEnd + 1;
			} else pos = labelEnd + 1;
			if (!label) label = state.src.slice(labelStart, labelEnd);
			ref = state.env.references[normalizeReference(label)];
			if (!ref) {
				state.pos = oldPos;
				return false;
			}
			href = ref.href;
			title = ref.title;
		}
		if (!silent) {
			state.pos = labelStart;
			state.posMax = labelEnd;
			token = state.push("link_open", "a", 1);
			token.attrs = attrs = [["href", href]];
			if (title) attrs.push(["title", title]);
			state.md.inline.tokenize(state);
			token = state.push("link_close", "a", -1);
		}
		state.pos = pos;
		state.posMax = max2;
		return true;
	};
} });
var require_image = __commonJS({ "node_modules/markdown-it/lib/rules_inline/image.js"(exports, module) {
	"use strict";
	var normalizeReference = require_utils().normalizeReference;
	var isSpace = require_utils().isSpace;
	module.exports = function image2(state, silent) {
		var attrs, code2, content, label, labelEnd, labelStart, pos, ref, res, title, token, tokens, start, href = "", oldPos = state.pos, max2 = state.posMax;
		if (state.src.charCodeAt(state.pos) !== 33) return false;
		if (state.src.charCodeAt(state.pos + 1) !== 91) return false;
		labelStart = state.pos + 2;
		labelEnd = state.md.helpers.parseLinkLabel(state, state.pos + 1, false);
		if (labelEnd < 0) return false;
		pos = labelEnd + 1;
		if (pos < max2 && state.src.charCodeAt(pos) === 40) {
			pos++;
			for (; pos < max2; pos++) {
				code2 = state.src.charCodeAt(pos);
				if (!isSpace(code2) && code2 !== 10) break;
			}
			if (pos >= max2) return false;
			start = pos;
			res = state.md.helpers.parseLinkDestination(state.src, pos, state.posMax);
			if (res.ok) {
				href = state.md.normalizeLink(res.str);
				if (state.md.validateLink(href)) pos = res.pos;
				else href = "";
			}
			start = pos;
			for (; pos < max2; pos++) {
				code2 = state.src.charCodeAt(pos);
				if (!isSpace(code2) && code2 !== 10) break;
			}
			res = state.md.helpers.parseLinkTitle(state.src, pos, state.posMax);
			if (pos < max2 && start !== pos && res.ok) {
				title = res.str;
				pos = res.pos;
				for (; pos < max2; pos++) {
					code2 = state.src.charCodeAt(pos);
					if (!isSpace(code2) && code2 !== 10) break;
				}
			} else title = "";
			if (pos >= max2 || state.src.charCodeAt(pos) !== 41) {
				state.pos = oldPos;
				return false;
			}
			pos++;
		} else {
			if (typeof state.env.references === "undefined") return false;
			if (pos < max2 && state.src.charCodeAt(pos) === 91) {
				start = pos + 1;
				pos = state.md.helpers.parseLinkLabel(state, pos);
				if (pos >= 0) label = state.src.slice(start, pos++);
				else pos = labelEnd + 1;
			} else pos = labelEnd + 1;
			if (!label) label = state.src.slice(labelStart, labelEnd);
			ref = state.env.references[normalizeReference(label)];
			if (!ref) {
				state.pos = oldPos;
				return false;
			}
			href = ref.href;
			title = ref.title;
		}
		if (!silent) {
			content = state.src.slice(labelStart, labelEnd);
			state.md.inline.parse(content, state.md, state.env, tokens = []);
			token = state.push("image", "img", 0);
			token.attrs = attrs = [["src", href], ["alt", ""]];
			token.children = tokens;
			token.content = content;
			if (title) attrs.push(["title", title]);
		}
		state.pos = pos;
		state.posMax = max2;
		return true;
	};
} });
var require_autolink = __commonJS({ "node_modules/markdown-it/lib/rules_inline/autolink.js"(exports, module) {
	"use strict";
	var EMAIL_RE = /^([a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*)$/;
	var AUTOLINK_RE = /^([a-zA-Z][a-zA-Z0-9+.\-]{1,31}):([^<>\x00-\x20]*)$/;
	module.exports = function autolink(state, silent) {
		var url, fullUrl, token, ch, start, max2, pos = state.pos;
		if (state.src.charCodeAt(pos) !== 60) return false;
		start = state.pos;
		max2 = state.posMax;
		for (;;) {
			if (++pos >= max2) return false;
			ch = state.src.charCodeAt(pos);
			if (ch === 60) return false;
			if (ch === 62) break;
		}
		url = state.src.slice(start + 1, pos);
		if (AUTOLINK_RE.test(url)) {
			fullUrl = state.md.normalizeLink(url);
			if (!state.md.validateLink(fullUrl)) return false;
			if (!silent) {
				token = state.push("link_open", "a", 1);
				token.attrs = [["href", fullUrl]];
				token.markup = "autolink";
				token.info = "auto";
				token = state.push("text", "", 0);
				token.content = state.md.normalizeLinkText(url);
				token = state.push("link_close", "a", -1);
				token.markup = "autolink";
				token.info = "auto";
			}
			state.pos += url.length + 2;
			return true;
		}
		if (EMAIL_RE.test(url)) {
			fullUrl = state.md.normalizeLink("mailto:" + url);
			if (!state.md.validateLink(fullUrl)) return false;
			if (!silent) {
				token = state.push("link_open", "a", 1);
				token.attrs = [["href", fullUrl]];
				token.markup = "autolink";
				token.info = "auto";
				token = state.push("text", "", 0);
				token.content = state.md.normalizeLinkText(url);
				token = state.push("link_close", "a", -1);
				token.markup = "autolink";
				token.info = "auto";
			}
			state.pos += url.length + 2;
			return true;
		}
		return false;
	};
} });
var require_html_inline = __commonJS({ "node_modules/markdown-it/lib/rules_inline/html_inline.js"(exports, module) {
	"use strict";
	var HTML_TAG_RE = require_html_re().HTML_TAG_RE;
	function isLetter(ch) {
		var lc = ch | 32;
		return lc >= 97 && lc <= 122;
	}
	module.exports = function html_inline(state, silent) {
		var ch, match, max2, token, pos = state.pos;
		if (!state.md.options.html) return false;
		max2 = state.posMax;
		if (state.src.charCodeAt(pos) !== 60 || pos + 2 >= max2) return false;
		ch = state.src.charCodeAt(pos + 1);
		if (ch !== 33 && ch !== 63 && ch !== 47 && !isLetter(ch)) return false;
		match = state.src.slice(pos).match(HTML_TAG_RE);
		if (!match) return false;
		if (!silent) {
			token = state.push("html_inline", "", 0);
			token.content = state.src.slice(pos, pos + match[0].length);
		}
		state.pos += match[0].length;
		return true;
	};
} });
var require_entity = __commonJS({ "node_modules/markdown-it/lib/rules_inline/entity.js"(exports, module) {
	"use strict";
	var entities = require_entities2();
	var has = require_utils().has;
	var isValidEntityCode = require_utils().isValidEntityCode;
	var fromCodePoint = require_utils().fromCodePoint;
	var DIGITAL_RE = /^&#((?:x[a-f0-9]{1,6}|[0-9]{1,7}));/i;
	var NAMED_RE = /^&([a-z][a-z0-9]{1,31});/i;
	module.exports = function entity(state, silent) {
		var ch, code2, match, pos = state.pos, max2 = state.posMax;
		if (state.src.charCodeAt(pos) !== 38) return false;
		if (pos + 1 < max2) {
			ch = state.src.charCodeAt(pos + 1);
			if (ch === 35) {
				match = state.src.slice(pos).match(DIGITAL_RE);
				if (match) {
					if (!silent) {
						code2 = match[1][0].toLowerCase() === "x" ? parseInt(match[1].slice(1), 16) : parseInt(match[1], 10);
						state.pending += isValidEntityCode(code2) ? fromCodePoint(code2) : fromCodePoint(65533);
					}
					state.pos += match[0].length;
					return true;
				}
			} else {
				match = state.src.slice(pos).match(NAMED_RE);
				if (match) {
					if (has(entities, match[1])) {
						if (!silent) state.pending += entities[match[1]];
						state.pos += match[0].length;
						return true;
					}
				}
			}
		}
		if (!silent) state.pending += "&";
		state.pos++;
		return true;
	};
} });
var require_balance_pairs = __commonJS({ "node_modules/markdown-it/lib/rules_inline/balance_pairs.js"(exports, module) {
	"use strict";
	function processDelimiters(state, delimiters) {
		var closerIdx, openerIdx, closer, opener, minOpenerIdx, newMinOpenerIdx, isOddMatch, lastJump, openersBottom = {}, max2 = delimiters.length;
		if (!max2) return;
		var headerIdx = 0;
		var lastTokenIdx = -2;
		var jumps = [];
		for (closerIdx = 0; closerIdx < max2; closerIdx++) {
			closer = delimiters[closerIdx];
			jumps.push(0);
			if (delimiters[headerIdx].marker !== closer.marker || lastTokenIdx !== closer.token - 1) headerIdx = closerIdx;
			lastTokenIdx = closer.token;
			closer.length = closer.length || 0;
			if (!closer.close) continue;
			if (!openersBottom.hasOwnProperty(closer.marker)) openersBottom[closer.marker] = [
				-1,
				-1,
				-1,
				-1,
				-1,
				-1
			];
			minOpenerIdx = openersBottom[closer.marker][(closer.open ? 3 : 0) + closer.length % 3];
			openerIdx = headerIdx - jumps[headerIdx] - 1;
			newMinOpenerIdx = openerIdx;
			for (; openerIdx > minOpenerIdx; openerIdx -= jumps[openerIdx] + 1) {
				opener = delimiters[openerIdx];
				if (opener.marker !== closer.marker) continue;
				if (opener.open && opener.end < 0) {
					isOddMatch = false;
					if (opener.close || closer.open) {
						if ((opener.length + closer.length) % 3 === 0) {
							if (opener.length % 3 !== 0 || closer.length % 3 !== 0) isOddMatch = true;
						}
					}
					if (!isOddMatch) {
						lastJump = openerIdx > 0 && !delimiters[openerIdx - 1].open ? jumps[openerIdx - 1] + 1 : 0;
						jumps[closerIdx] = closerIdx - openerIdx + lastJump;
						jumps[openerIdx] = lastJump;
						closer.open = false;
						opener.end = closerIdx;
						opener.close = false;
						newMinOpenerIdx = -1;
						lastTokenIdx = -2;
						break;
					}
				}
			}
			if (newMinOpenerIdx !== -1) openersBottom[closer.marker][(closer.open ? 3 : 0) + (closer.length || 0) % 3] = newMinOpenerIdx;
		}
	}
	module.exports = function link_pairs(state) {
		var curr, tokens_meta = state.tokens_meta, max2 = state.tokens_meta.length;
		processDelimiters(state, state.delimiters);
		for (curr = 0; curr < max2; curr++) if (tokens_meta[curr] && tokens_meta[curr].delimiters) processDelimiters(state, tokens_meta[curr].delimiters);
	};
} });
var require_text_collapse = __commonJS({ "node_modules/markdown-it/lib/rules_inline/text_collapse.js"(exports, module) {
	"use strict";
	module.exports = function text_collapse(state) {
		var curr, last, level = 0, tokens = state.tokens, max2 = state.tokens.length;
		for (curr = last = 0; curr < max2; curr++) {
			if (tokens[curr].nesting < 0) level--;
			tokens[curr].level = level;
			if (tokens[curr].nesting > 0) level++;
			if (tokens[curr].type === "text" && curr + 1 < max2 && tokens[curr + 1].type === "text") tokens[curr + 1].content = tokens[curr].content + tokens[curr + 1].content;
			else {
				if (curr !== last) tokens[last] = tokens[curr];
				last++;
			}
		}
		if (curr !== last) tokens.length = last;
	};
} });
var require_state_inline = __commonJS({ "node_modules/markdown-it/lib/rules_inline/state_inline.js"(exports, module) {
	"use strict";
	var Token = require_token();
	var isWhiteSpace = require_utils().isWhiteSpace;
	var isPunctChar = require_utils().isPunctChar;
	var isMdAsciiPunct = require_utils().isMdAsciiPunct;
	function StateInline(src, md, env, outTokens) {
		this.src = src;
		this.env = env;
		this.md = md;
		this.tokens = outTokens;
		this.tokens_meta = Array(outTokens.length);
		this.pos = 0;
		this.posMax = this.src.length;
		this.level = 0;
		this.pending = "";
		this.pendingLevel = 0;
		this.cache = {};
		this.delimiters = [];
		this._prev_delimiters = [];
		this.backticks = {};
		this.backticksScanned = false;
	}
	StateInline.prototype.pushPending = function() {
		var token = new Token("text", "", 0);
		token.content = this.pending;
		token.level = this.pendingLevel;
		this.tokens.push(token);
		this.pending = "";
		return token;
	};
	StateInline.prototype.push = function(type, tag, nesting) {
		if (this.pending) this.pushPending();
		var token = new Token(type, tag, nesting);
		var token_meta = null;
		if (nesting < 0) {
			this.level--;
			this.delimiters = this._prev_delimiters.pop();
		}
		token.level = this.level;
		if (nesting > 0) {
			this.level++;
			this._prev_delimiters.push(this.delimiters);
			this.delimiters = [];
			token_meta = { delimiters: this.delimiters };
		}
		this.pendingLevel = this.level;
		this.tokens.push(token);
		this.tokens_meta.push(token_meta);
		return token;
	};
	StateInline.prototype.scanDelims = function(start, canSplitWord) {
		var pos = start, lastChar, nextChar, count, can_open, can_close, isLastWhiteSpace, isLastPunctChar, isNextWhiteSpace, isNextPunctChar, left_flanking = true, right_flanking = true, max2 = this.posMax, marker = this.src.charCodeAt(start);
		lastChar = start > 0 ? this.src.charCodeAt(start - 1) : 32;
		while (pos < max2 && this.src.charCodeAt(pos) === marker) pos++;
		count = pos - start;
		nextChar = pos < max2 ? this.src.charCodeAt(pos) : 32;
		isLastPunctChar = isMdAsciiPunct(lastChar) || isPunctChar(String.fromCharCode(lastChar));
		isNextPunctChar = isMdAsciiPunct(nextChar) || isPunctChar(String.fromCharCode(nextChar));
		isLastWhiteSpace = isWhiteSpace(lastChar);
		isNextWhiteSpace = isWhiteSpace(nextChar);
		if (isNextWhiteSpace) left_flanking = false;
		else if (isNextPunctChar) {
			if (!(isLastWhiteSpace || isLastPunctChar)) left_flanking = false;
		}
		if (isLastWhiteSpace) right_flanking = false;
		else if (isLastPunctChar) {
			if (!(isNextWhiteSpace || isNextPunctChar)) right_flanking = false;
		}
		if (!canSplitWord) {
			can_open = left_flanking && (!right_flanking || isLastPunctChar);
			can_close = right_flanking && (!left_flanking || isNextPunctChar);
		} else {
			can_open = left_flanking;
			can_close = right_flanking;
		}
		return {
			can_open,
			can_close,
			length: count
		};
	};
	StateInline.prototype.Token = Token;
	module.exports = StateInline;
} });
var require_parser_inline = __commonJS({ "node_modules/markdown-it/lib/parser_inline.js"(exports, module) {
	"use strict";
	var Ruler = require_ruler();
	var _rules = [
		["text", require_text()],
		["newline", require_newline()],
		["escape", require_escape()],
		["backticks", require_backticks()],
		["strikethrough", require_strikethrough().tokenize],
		["emphasis", require_emphasis().tokenize],
		["link", require_link()],
		["image", require_image()],
		["autolink", require_autolink()],
		["html_inline", require_html_inline()],
		["entity", require_entity()]
	];
	var _rules2 = [
		["balance_pairs", require_balance_pairs()],
		["strikethrough", require_strikethrough().postProcess],
		["emphasis", require_emphasis().postProcess],
		["text_collapse", require_text_collapse()]
	];
	function ParserInline() {
		var i;
		this.ruler = new Ruler();
		for (i = 0; i < _rules.length; i++) this.ruler.push(_rules[i][0], _rules[i][1]);
		this.ruler2 = new Ruler();
		for (i = 0; i < _rules2.length; i++) this.ruler2.push(_rules2[i][0], _rules2[i][1]);
	}
	ParserInline.prototype.skipToken = function(state) {
		var ok, i, pos = state.pos, rules = this.ruler.getRules(""), len = rules.length, maxNesting = state.md.options.maxNesting, cache = state.cache;
		if (typeof cache[pos] !== "undefined") {
			state.pos = cache[pos];
			return;
		}
		if (state.level < maxNesting) for (i = 0; i < len; i++) {
			state.level++;
			ok = rules[i](state, true);
			state.level--;
			if (ok) break;
		}
		else state.pos = state.posMax;
		if (!ok) state.pos++;
		cache[pos] = state.pos;
	};
	ParserInline.prototype.tokenize = function(state) {
		var ok, i, rules = this.ruler.getRules(""), len = rules.length, end = state.posMax, maxNesting = state.md.options.maxNesting;
		while (state.pos < end) {
			if (state.level < maxNesting) for (i = 0; i < len; i++) {
				ok = rules[i](state, false);
				if (ok) break;
			}
			if (ok) {
				if (state.pos >= end) break;
				continue;
			}
			state.pending += state.src[state.pos++];
		}
		if (state.pending) state.pushPending();
	};
	ParserInline.prototype.parse = function(str, md, env, outTokens) {
		var i, rules, len;
		var state = new this.State(str, md, env, outTokens);
		this.tokenize(state);
		rules = this.ruler2.getRules("");
		len = rules.length;
		for (i = 0; i < len; i++) rules[i](state);
	};
	ParserInline.prototype.State = require_state_inline();
	module.exports = ParserInline;
} });
var require_re = __commonJS({ "node_modules/linkify-it/lib/re.js"(exports, module) {
	"use strict";
	module.exports = function(opts) {
		var re = {};
		re.src_Any = require_regex2().source;
		re.src_Cc = require_regex3().source;
		re.src_Z = require_regex5().source;
		re.src_P = require_regex().source;
		re.src_ZPCc = [
			re.src_Z,
			re.src_P,
			re.src_Cc
		].join("|");
		re.src_ZCc = [re.src_Z, re.src_Cc].join("|");
		var text_separators = "[><｜]";
		re.src_pseudo_letter = "(?:(?!" + text_separators + "|" + re.src_ZPCc + ")" + re.src_Any + ")";
		re.src_ip4 = "(?:(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)";
		re.src_auth = "(?:(?:(?!" + re.src_ZCc + "|[@/\\[\\]()]).)+@)?";
		re.src_port = "(?::(?:6(?:[0-4]\\d{3}|5(?:[0-4]\\d{2}|5(?:[0-2]\\d|3[0-5])))|[1-5]?\\d{1,4}))?";
		re.src_host_terminator = "(?=$|" + text_separators + "|" + re.src_ZPCc + ")(?!-|_|:\\d|\\.-|\\.(?!$|" + re.src_ZPCc + "))";
		re.src_path = "(?:[/?#](?:(?!" + re.src_ZCc + "|" + text_separators + `|[()[\\]{}.,"'?!\\-;]).|\\[(?:(?!` + re.src_ZCc + "|\\]).)*\\]|\\((?:(?!" + re.src_ZCc + "|[)]).)*\\)|\\{(?:(?!" + re.src_ZCc + "|[}]).)*\\}|\\\"(?:(?!" + re.src_ZCc + `|["]).)+\\"|\\'(?:(?!` + re.src_ZCc + "|[']).)+\\'|\\'(?=" + re.src_pseudo_letter + "|[-]).|\\.{2,}[a-zA-Z0-9%/&]|\\.(?!" + re.src_ZCc + "|[.]).|" + (opts && opts["---"] ? "\\-(?!--(?:[^-]|$))(?:-*)|" : "\\-+|") + ",(?!" + re.src_ZCc + ").|;(?!" + re.src_ZCc + ").|\\!+(?!" + re.src_ZCc + "|[!]).|\\?(?!" + re.src_ZCc + "|[?]).)+|\\/)?";
		re.src_email_name = "[\\-;:&=\\+\\$,\\.a-zA-Z0-9_][\\-;:&=\\+\\$,\\\"\\.a-zA-Z0-9_]*";
		re.src_xn = "xn--[a-z0-9\\-]{1,59}";
		re.src_domain_root = "(?:" + re.src_xn + "|" + re.src_pseudo_letter + "{1,63})";
		re.src_domain = "(?:" + re.src_xn + "|(?:" + re.src_pseudo_letter + ")|(?:" + re.src_pseudo_letter + "(?:-|" + re.src_pseudo_letter + "){0,61}" + re.src_pseudo_letter + "))";
		re.src_host = "(?:(?:(?:(?:" + re.src_domain + ")\\.)*" + re.src_domain + "))";
		re.tpl_host_fuzzy = "(?:" + re.src_ip4 + "|(?:(?:(?:" + re.src_domain + ")\\.)+(?:%TLDS%)))";
		re.tpl_host_no_ip_fuzzy = "(?:(?:(?:" + re.src_domain + ")\\.)+(?:%TLDS%))";
		re.src_host_strict = re.src_host + re.src_host_terminator;
		re.tpl_host_fuzzy_strict = re.tpl_host_fuzzy + re.src_host_terminator;
		re.src_host_port_strict = re.src_host + re.src_port + re.src_host_terminator;
		re.tpl_host_port_fuzzy_strict = re.tpl_host_fuzzy + re.src_port + re.src_host_terminator;
		re.tpl_host_port_no_ip_fuzzy_strict = re.tpl_host_no_ip_fuzzy + re.src_port + re.src_host_terminator;
		re.tpl_host_fuzzy_test = "localhost|www\\.|\\.\\d{1,3}\\.|(?:\\.(?:%TLDS%)(?:" + re.src_ZPCc + "|>|$))";
		re.tpl_email_fuzzy = "(^|" + text_separators + "|\"|\\(|" + re.src_ZCc + ")(" + re.src_email_name + "@" + re.tpl_host_fuzzy_strict + ")";
		re.tpl_link_fuzzy = "(^|(?![.:/\\-_@])(?:[$+<=>^`|｜]|" + re.src_ZPCc + "))((?![$+<=>^`|｜])" + re.tpl_host_port_fuzzy_strict + re.src_path + ")";
		re.tpl_link_no_ip_fuzzy = "(^|(?![.:/\\-_@])(?:[$+<=>^`|｜]|" + re.src_ZPCc + "))((?![$+<=>^`|｜])" + re.tpl_host_port_no_ip_fuzzy_strict + re.src_path + ")";
		return re;
	};
} });
var require_linkify_it = __commonJS({ "node_modules/linkify-it/index.js"(exports, module) {
	"use strict";
	function assign(obj) {
		Array.prototype.slice.call(arguments, 1).forEach(function(source) {
			if (!source) return;
			Object.keys(source).forEach(function(key) {
				obj[key] = source[key];
			});
		});
		return obj;
	}
	function _class(obj) {
		return Object.prototype.toString.call(obj);
	}
	function isString(obj) {
		return _class(obj) === "[object String]";
	}
	function isObject(obj) {
		return _class(obj) === "[object Object]";
	}
	function isRegExp(obj) {
		return _class(obj) === "[object RegExp]";
	}
	function isFunction2(obj) {
		return _class(obj) === "[object Function]";
	}
	function escapeRE(str) {
		return str.replace(/[.?*+^$[\]\\(){}|-]/g, "\\$&");
	}
	var defaultOptions = {
		fuzzyLink: true,
		fuzzyEmail: true,
		fuzzyIP: false
	};
	function isOptionsObj(obj) {
		return Object.keys(obj || {}).reduce(function(acc, k) {
			return acc || defaultOptions.hasOwnProperty(k);
		}, false);
	}
	var defaultSchemas = {
		"http:": { validate: function(text2, pos, self) {
			var tail = text2.slice(pos);
			if (!self.re.http) self.re.http = new RegExp("^\\/\\/" + self.re.src_auth + self.re.src_host_port_strict + self.re.src_path, "i");
			if (self.re.http.test(tail)) return tail.match(self.re.http)[0].length;
			return 0;
		} },
		"https:": "http:",
		"ftp:": "http:",
		"//": { validate: function(text2, pos, self) {
			var tail = text2.slice(pos);
			if (!self.re.no_http) self.re.no_http = new RegExp("^" + self.re.src_auth + "(?:localhost|(?:(?:" + self.re.src_domain + ")\\.)+" + self.re.src_domain_root + ")" + self.re.src_port + self.re.src_host_terminator + self.re.src_path, "i");
			if (self.re.no_http.test(tail)) {
				if (pos >= 3 && text2[pos - 3] === ":") return 0;
				if (pos >= 3 && text2[pos - 3] === "/") return 0;
				return tail.match(self.re.no_http)[0].length;
			}
			return 0;
		} },
		"mailto:": { validate: function(text2, pos, self) {
			var tail = text2.slice(pos);
			if (!self.re.mailto) self.re.mailto = new RegExp("^" + self.re.src_email_name + "@" + self.re.src_host_strict, "i");
			if (self.re.mailto.test(tail)) return tail.match(self.re.mailto)[0].length;
			return 0;
		} }
	};
	var tlds_2ch_src_re = "a[cdefgilmnoqrstuwxz]|b[abdefghijmnorstvwyz]|c[acdfghiklmnoruvwxyz]|d[ejkmoz]|e[cegrstu]|f[ijkmor]|g[abdefghilmnpqrstuwy]|h[kmnrtu]|i[delmnoqrst]|j[emop]|k[eghimnprwyz]|l[abcikrstuvy]|m[acdeghklmnopqrstuvwxyz]|n[acefgilopruz]|om|p[aefghklmnrstwy]|qa|r[eosuw]|s[abcdeghijklmnortuvxyz]|t[cdfghjklmnortvwz]|u[agksyz]|v[aceginu]|w[fs]|y[et]|z[amw]";
	var tlds_default = "biz|com|edu|gov|net|org|pro|web|xxx|aero|asia|coop|info|museum|name|shop|рф".split("|");
	function resetScanCache(self) {
		self.__index__ = -1;
		self.__text_cache__ = "";
	}
	function createValidator(re) {
		return function(text2, pos) {
			var tail = text2.slice(pos);
			if (re.test(tail)) return tail.match(re)[0].length;
			return 0;
		};
	}
	function createNormalizer() {
		return function(match, self) {
			self.normalize(match);
		};
	}
	function compile(self) {
		var re = self.re = require_re()(self.__opts__);
		var tlds = self.__tlds__.slice();
		self.onCompile();
		if (!self.__tlds_replaced__) tlds.push(tlds_2ch_src_re);
		tlds.push(re.src_xn);
		re.src_tlds = tlds.join("|");
		function untpl(tpl) {
			return tpl.replace("%TLDS%", re.src_tlds);
		}
		re.email_fuzzy = RegExp(untpl(re.tpl_email_fuzzy), "i");
		re.link_fuzzy = RegExp(untpl(re.tpl_link_fuzzy), "i");
		re.link_no_ip_fuzzy = RegExp(untpl(re.tpl_link_no_ip_fuzzy), "i");
		re.host_fuzzy_test = RegExp(untpl(re.tpl_host_fuzzy_test), "i");
		var aliases = [];
		self.__compiled__ = {};
		function schemaError(name, val) {
			throw new Error("(LinkifyIt) Invalid schema \"" + name + "\": " + val);
		}
		Object.keys(self.__schemas__).forEach(function(name) {
			var val = self.__schemas__[name];
			if (val === null) return;
			var compiled = {
				validate: null,
				link: null
			};
			self.__compiled__[name] = compiled;
			if (isObject(val)) {
				if (isRegExp(val.validate)) compiled.validate = createValidator(val.validate);
				else if (isFunction2(val.validate)) compiled.validate = val.validate;
				else schemaError(name, val);
				if (isFunction2(val.normalize)) compiled.normalize = val.normalize;
				else if (!val.normalize) compiled.normalize = createNormalizer();
				else schemaError(name, val);
				return;
			}
			if (isString(val)) {
				aliases.push(name);
				return;
			}
			schemaError(name, val);
		});
		aliases.forEach(function(alias) {
			if (!self.__compiled__[self.__schemas__[alias]]) return;
			self.__compiled__[alias].validate = self.__compiled__[self.__schemas__[alias]].validate;
			self.__compiled__[alias].normalize = self.__compiled__[self.__schemas__[alias]].normalize;
		});
		self.__compiled__[""] = {
			validate: null,
			normalize: createNormalizer()
		};
		var slist = Object.keys(self.__compiled__).filter(function(name) {
			return name.length > 0 && self.__compiled__[name];
		}).map(escapeRE).join("|");
		self.re.schema_test = RegExp("(^|(?!_)(?:[><｜]|" + re.src_ZPCc + "))(" + slist + ")", "i");
		self.re.schema_search = RegExp("(^|(?!_)(?:[><｜]|" + re.src_ZPCc + "))(" + slist + ")", "ig");
		self.re.pretest = RegExp("(" + self.re.schema_test.source + ")|(" + self.re.host_fuzzy_test.source + ")|@", "i");
		resetScanCache(self);
	}
	function Match(self, shift) {
		var start = self.__index__, end = self.__last_index__, text2 = self.__text_cache__.slice(start, end);
		this.schema = self.__schema__.toLowerCase();
		this.index = start + shift;
		this.lastIndex = end + shift;
		this.raw = text2;
		this.text = text2;
		this.url = text2;
	}
	function createMatch(self, shift) {
		var match = new Match(self, shift);
		self.__compiled__[match.schema].normalize(match, self);
		return match;
	}
	function LinkifyIt(schemas, options) {
		if (!(this instanceof LinkifyIt)) return new LinkifyIt(schemas, options);
		if (!options) {
			if (isOptionsObj(schemas)) {
				options = schemas;
				schemas = {};
			}
		}
		this.__opts__ = assign({}, defaultOptions, options);
		this.__index__ = -1;
		this.__last_index__ = -1;
		this.__schema__ = "";
		this.__text_cache__ = "";
		this.__schemas__ = assign({}, defaultSchemas, schemas);
		this.__compiled__ = {};
		this.__tlds__ = tlds_default;
		this.__tlds_replaced__ = false;
		this.re = {};
		compile(this);
	}
	LinkifyIt.prototype.add = function add(schema, definition) {
		this.__schemas__[schema] = definition;
		compile(this);
		return this;
	};
	LinkifyIt.prototype.set = function set(options) {
		this.__opts__ = assign(this.__opts__, options);
		return this;
	};
	LinkifyIt.prototype.test = function test(text2) {
		this.__text_cache__ = text2;
		this.__index__ = -1;
		if (!text2.length) return false;
		var m, ml, me, len, shift, next, re, tld_pos, at_pos;
		if (this.re.schema_test.test(text2)) {
			re = this.re.schema_search;
			re.lastIndex = 0;
			while ((m = re.exec(text2)) !== null) {
				len = this.testSchemaAt(text2, m[2], re.lastIndex);
				if (len) {
					this.__schema__ = m[2];
					this.__index__ = m.index + m[1].length;
					this.__last_index__ = m.index + m[0].length + len;
					break;
				}
			}
		}
		if (this.__opts__.fuzzyLink && this.__compiled__["http:"]) {
			tld_pos = text2.search(this.re.host_fuzzy_test);
			if (tld_pos >= 0) {
				if (this.__index__ < 0 || tld_pos < this.__index__) {
					if ((ml = text2.match(this.__opts__.fuzzyIP ? this.re.link_fuzzy : this.re.link_no_ip_fuzzy)) !== null) {
						shift = ml.index + ml[1].length;
						if (this.__index__ < 0 || shift < this.__index__) {
							this.__schema__ = "";
							this.__index__ = shift;
							this.__last_index__ = ml.index + ml[0].length;
						}
					}
				}
			}
		}
		if (this.__opts__.fuzzyEmail && this.__compiled__["mailto:"]) {
			at_pos = text2.indexOf("@");
			if (at_pos >= 0) {
				if ((me = text2.match(this.re.email_fuzzy)) !== null) {
					shift = me.index + me[1].length;
					next = me.index + me[0].length;
					if (this.__index__ < 0 || shift < this.__index__ || shift === this.__index__ && next > this.__last_index__) {
						this.__schema__ = "mailto:";
						this.__index__ = shift;
						this.__last_index__ = next;
					}
				}
			}
		}
		return this.__index__ >= 0;
	};
	LinkifyIt.prototype.pretest = function pretest(text2) {
		return this.re.pretest.test(text2);
	};
	LinkifyIt.prototype.testSchemaAt = function testSchemaAt(text2, schema, pos) {
		if (!this.__compiled__[schema.toLowerCase()]) return 0;
		return this.__compiled__[schema.toLowerCase()].validate(text2, pos, this);
	};
	LinkifyIt.prototype.match = function match(text2) {
		var shift = 0, result = [];
		if (this.__index__ >= 0 && this.__text_cache__ === text2) {
			result.push(createMatch(this, shift));
			shift = this.__last_index__;
		}
		var tail = shift ? text2.slice(shift) : text2;
		while (this.test(tail)) {
			result.push(createMatch(this, shift));
			tail = tail.slice(this.__last_index__);
			shift += this.__last_index__;
		}
		if (result.length) return result;
		return null;
	};
	LinkifyIt.prototype.tlds = function tlds(list2, keepOld) {
		list2 = Array.isArray(list2) ? list2 : [list2];
		if (!keepOld) {
			this.__tlds__ = list2.slice();
			this.__tlds_replaced__ = true;
			compile(this);
			return this;
		}
		this.__tlds__ = this.__tlds__.concat(list2).sort().filter(function(el, idx, arr) {
			return el !== arr[idx - 1];
		}).reverse();
		compile(this);
		return this;
	};
	LinkifyIt.prototype.normalize = function normalize(match) {
		if (!match.schema) match.url = "http://" + match.url;
		if (match.schema === "mailto:" && !/^mailto:/i.test(match.url)) match.url = "mailto:" + match.url;
	};
	LinkifyIt.prototype.onCompile = function onCompile() {};
	module.exports = LinkifyIt;
} });
var require_punycode = __commonJS({ "node_modules/punycode/punycode.js"(exports, module) {
	"use strict";
	var maxInt = 2147483647;
	var base = 36;
	var tMin = 1;
	var tMax = 26;
	var skew = 38;
	var damp = 700;
	var initialBias = 72;
	var initialN = 128;
	var delimiter = "-";
	var regexPunycode = /^xn--/;
	var regexNonASCII = /[^\0-\x7F]/;
	var regexSeparators = /[\x2E\u3002\uFF0E\uFF61]/g;
	var errors = {
		"overflow": "Overflow: input needs wider integers to process",
		"not-basic": "Illegal input >= 0x80 (not a basic code point)",
		"invalid-input": "Invalid input"
	};
	var baseMinusTMin = base - tMin;
	var floor = Math.floor;
	var stringFromCharCode = String.fromCharCode;
	function error2(type) {
		throw new RangeError(errors[type]);
	}
	function map(array, callback) {
		const result = [];
		let length = array.length;
		while (length--) result[length] = callback(array[length]);
		return result;
	}
	function mapDomain(domain, callback) {
		const parts = domain.split("@");
		let result = "";
		if (parts.length > 1) {
			result = parts[0] + "@";
			domain = parts[1];
		}
		domain = domain.replace(regexSeparators, ".");
		const encoded = map(domain.split("."), callback).join(".");
		return result + encoded;
	}
	function ucs2decode(string) {
		const output = [];
		let counter = 0;
		const length = string.length;
		while (counter < length) {
			const value = string.charCodeAt(counter++);
			if (value >= 55296 && value <= 56319 && counter < length) {
				const extra = string.charCodeAt(counter++);
				if ((extra & 64512) == 56320) output.push(((value & 1023) << 10) + (extra & 1023) + 65536);
				else {
					output.push(value);
					counter--;
				}
			} else output.push(value);
		}
		return output;
	}
	var ucs2encode = (codePoints) => String.fromCodePoint(...codePoints);
	var basicToDigit = function(codePoint) {
		if (codePoint >= 48 && codePoint < 58) return 26 + (codePoint - 48);
		if (codePoint >= 65 && codePoint < 91) return codePoint - 65;
		if (codePoint >= 97 && codePoint < 123) return codePoint - 97;
		return base;
	};
	var digitToBasic = function(digit, flag) {
		return digit + 22 + 75 * (digit < 26) - ((flag != 0) << 5);
	};
	var adapt = function(delta, numPoints, firstTime) {
		let k = 0;
		delta = firstTime ? floor(delta / damp) : delta >> 1;
		delta += floor(delta / numPoints);
		for (; delta > baseMinusTMin * tMax >> 1; k += base) delta = floor(delta / baseMinusTMin);
		return floor(k + (baseMinusTMin + 1) * delta / (delta + skew));
	};
	var decode = function(input) {
		const output = [];
		const inputLength = input.length;
		let i = 0;
		let n = initialN;
		let bias = initialBias;
		let basic = input.lastIndexOf(delimiter);
		if (basic < 0) basic = 0;
		for (let j = 0; j < basic; ++j) {
			if (input.charCodeAt(j) >= 128) error2("not-basic");
			output.push(input.charCodeAt(j));
		}
		for (let index = basic > 0 ? basic + 1 : 0; index < inputLength;) {
			const oldi = i;
			for (let w = 1, k = base;; k += base) {
				if (index >= inputLength) error2("invalid-input");
				const digit = basicToDigit(input.charCodeAt(index++));
				if (digit >= base) error2("invalid-input");
				if (digit > floor((maxInt - i) / w)) error2("overflow");
				i += digit * w;
				const t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
				if (digit < t) break;
				const baseMinusT = base - t;
				if (w > floor(maxInt / baseMinusT)) error2("overflow");
				w *= baseMinusT;
			}
			const out = output.length + 1;
			bias = adapt(i - oldi, out, oldi == 0);
			if (floor(i / out) > maxInt - n) error2("overflow");
			n += floor(i / out);
			i %= out;
			output.splice(i++, 0, n);
		}
		return String.fromCodePoint(...output);
	};
	var encode = function(input) {
		const output = [];
		input = ucs2decode(input);
		const inputLength = input.length;
		let n = initialN;
		let delta = 0;
		let bias = initialBias;
		for (const currentValue of input) if (currentValue < 128) output.push(stringFromCharCode(currentValue));
		const basicLength = output.length;
		let handledCPCount = basicLength;
		if (basicLength) output.push(delimiter);
		while (handledCPCount < inputLength) {
			let m = maxInt;
			for (const currentValue of input) if (currentValue >= n && currentValue < m) m = currentValue;
			const handledCPCountPlusOne = handledCPCount + 1;
			if (m - n > floor((maxInt - delta) / handledCPCountPlusOne)) error2("overflow");
			delta += (m - n) * handledCPCountPlusOne;
			n = m;
			for (const currentValue of input) {
				if (currentValue < n && ++delta > maxInt) error2("overflow");
				if (currentValue === n) {
					let q = delta;
					for (let k = base;; k += base) {
						const t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
						if (q < t) break;
						const qMinusT = q - t;
						const baseMinusT = base - t;
						output.push(stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0)));
						q = floor(qMinusT / baseMinusT);
					}
					output.push(stringFromCharCode(digitToBasic(q, 0)));
					bias = adapt(delta, handledCPCountPlusOne, handledCPCount === basicLength);
					delta = 0;
					++handledCPCount;
				}
			}
			++delta;
			++n;
		}
		return output.join("");
	};
	var toUnicode = function(input) {
		return mapDomain(input, function(string) {
			return regexPunycode.test(string) ? decode(string.slice(4).toLowerCase()) : string;
		});
	};
	var toASCII = function(input) {
		return mapDomain(input, function(string) {
			return regexNonASCII.test(string) ? "xn--" + encode(string) : string;
		});
	};
	module.exports = {
		"version": "2.3.1",
		"ucs2": {
			"decode": ucs2decode,
			"encode": ucs2encode
		},
		"decode": decode,
		"encode": encode,
		"toASCII": toASCII,
		"toUnicode": toUnicode
	};
} });
var require_default = __commonJS({ "node_modules/markdown-it/lib/presets/default.js"(exports, module) {
	"use strict";
	module.exports = {
		options: {
			html: false,
			xhtmlOut: false,
			breaks: false,
			langPrefix: "language-",
			linkify: false,
			typographer: false,
			quotes: "“”‘’",
			highlight: null,
			maxNesting: 100
		},
		components: {
			core: {},
			block: {},
			inline: {}
		}
	};
} });
var require_zero = __commonJS({ "node_modules/markdown-it/lib/presets/zero.js"(exports, module) {
	"use strict";
	module.exports = {
		options: {
			html: false,
			xhtmlOut: false,
			breaks: false,
			langPrefix: "language-",
			linkify: false,
			typographer: false,
			quotes: "“”‘’",
			highlight: null,
			maxNesting: 20
		},
		components: {
			core: { rules: [
				"normalize",
				"block",
				"inline"
			] },
			block: { rules: ["paragraph"] },
			inline: {
				rules: ["text"],
				rules2: ["balance_pairs", "text_collapse"]
			}
		}
	};
} });
var require_commonmark = __commonJS({ "node_modules/markdown-it/lib/presets/commonmark.js"(exports, module) {
	"use strict";
	module.exports = {
		options: {
			html: true,
			xhtmlOut: true,
			breaks: false,
			langPrefix: "language-",
			linkify: false,
			typographer: false,
			quotes: "“”‘’",
			highlight: null,
			maxNesting: 20
		},
		components: {
			core: { rules: [
				"normalize",
				"block",
				"inline"
			] },
			block: { rules: [
				"blockquote",
				"code",
				"fence",
				"heading",
				"hr",
				"html_block",
				"lheading",
				"list",
				"reference",
				"paragraph"
			] },
			inline: {
				rules: [
					"autolink",
					"backticks",
					"emphasis",
					"entity",
					"escape",
					"html_inline",
					"image",
					"link",
					"newline",
					"text"
				],
				rules2: [
					"balance_pairs",
					"emphasis",
					"text_collapse"
				]
			}
		}
	};
} });
var require_lib = __commonJS({ "node_modules/markdown-it/lib/index.js"(exports, module) {
	"use strict";
	var utils = require_utils();
	var helpers = require_helpers();
	var Renderer = require_renderer();
	var ParserCore = require_parser_core();
	var ParserBlock = require_parser_block();
	var ParserInline = require_parser_inline();
	var LinkifyIt = require_linkify_it();
	var mdurl = require_mdurl();
	var punycode = require_punycode();
	var config = {
		default: require_default(),
		zero: require_zero(),
		commonmark: require_commonmark()
	};
	var BAD_PROTO_RE = /^(vbscript|javascript|file|data):/;
	var GOOD_DATA_RE = /^data:image\/(gif|png|jpeg|webp);/;
	function validateLink(url) {
		var str = url.trim().toLowerCase();
		return BAD_PROTO_RE.test(str) ? GOOD_DATA_RE.test(str) ? true : false : true;
	}
	var RECODE_HOSTNAME_FOR = [
		"http:",
		"https:",
		"mailto:"
	];
	function normalizeLink(url) {
		var parsed = mdurl.parse(url, true);
		if (parsed.hostname) {
			if (!parsed.protocol || RECODE_HOSTNAME_FOR.indexOf(parsed.protocol) >= 0) try {
				parsed.hostname = punycode.toASCII(parsed.hostname);
			} catch (er) {}
		}
		return mdurl.encode(mdurl.format(parsed));
	}
	function normalizeLinkText(url) {
		var parsed = mdurl.parse(url, true);
		if (parsed.hostname) {
			if (!parsed.protocol || RECODE_HOSTNAME_FOR.indexOf(parsed.protocol) >= 0) try {
				parsed.hostname = punycode.toUnicode(parsed.hostname);
			} catch (er) {}
		}
		return mdurl.decode(mdurl.format(parsed), mdurl.decode.defaultChars + "%");
	}
	function MarkdownIt3(presetName, options) {
		if (!(this instanceof MarkdownIt3)) return new MarkdownIt3(presetName, options);
		if (!options) {
			if (!utils.isString(presetName)) {
				options = presetName || {};
				presetName = "default";
			}
		}
		this.inline = new ParserInline();
		this.block = new ParserBlock();
		this.core = new ParserCore();
		this.renderer = new Renderer();
		this.linkify = new LinkifyIt();
		this.validateLink = validateLink;
		this.normalizeLink = normalizeLink;
		this.normalizeLinkText = normalizeLinkText;
		this.utils = utils;
		this.helpers = utils.assign({}, helpers);
		this.options = {};
		this.configure(presetName);
		if (options) this.set(options);
	}
	MarkdownIt3.prototype.set = function(options) {
		utils.assign(this.options, options);
		return this;
	};
	MarkdownIt3.prototype.configure = function(presets) {
		var self = this, presetName;
		if (utils.isString(presets)) {
			presetName = presets;
			presets = config[presetName];
			if (!presets) throw new Error("Wrong `markdown-it` preset \"" + presetName + "\", check name");
		}
		if (!presets) throw new Error("Wrong `markdown-it` preset, can't be empty");
		if (presets.options) self.set(presets.options);
		if (presets.components) Object.keys(presets.components).forEach(function(name) {
			if (presets.components[name].rules) self[name].ruler.enableOnly(presets.components[name].rules);
			if (presets.components[name].rules2) self[name].ruler2.enableOnly(presets.components[name].rules2);
		});
		return this;
	};
	MarkdownIt3.prototype.enable = function(list2, ignoreInvalid) {
		var result = [];
		if (!Array.isArray(list2)) list2 = [list2];
		[
			"core",
			"block",
			"inline"
		].forEach(function(chain) {
			result = result.concat(this[chain].ruler.enable(list2, true));
		}, this);
		result = result.concat(this.inline.ruler2.enable(list2, true));
		var missed = list2.filter(function(name) {
			return result.indexOf(name) < 0;
		});
		if (missed.length && !ignoreInvalid) throw new Error("MarkdownIt. Failed to enable unknown rule(s): " + missed);
		return this;
	};
	MarkdownIt3.prototype.disable = function(list2, ignoreInvalid) {
		var result = [];
		if (!Array.isArray(list2)) list2 = [list2];
		[
			"core",
			"block",
			"inline"
		].forEach(function(chain) {
			result = result.concat(this[chain].ruler.disable(list2, true));
		}, this);
		result = result.concat(this.inline.ruler2.disable(list2, true));
		var missed = list2.filter(function(name) {
			return result.indexOf(name) < 0;
		});
		if (missed.length && !ignoreInvalid) throw new Error("MarkdownIt. Failed to disable unknown rule(s): " + missed);
		return this;
	};
	MarkdownIt3.prototype.use = function(plugin4) {
		var args = [this].concat(Array.prototype.slice.call(arguments, 1));
		plugin4.apply(plugin4, args);
		return this;
	};
	MarkdownIt3.prototype.parse = function(src, env) {
		if (typeof src !== "string") throw new Error("Input data should be a String");
		var state = new this.core.State(src, this, env);
		this.core.process(state);
		return state.tokens;
	};
	MarkdownIt3.prototype.render = function(src, env) {
		env = env || {};
		return this.renderer.render(this.parse(src, env), this.options, env);
	};
	MarkdownIt3.prototype.parseInline = function(src, env) {
		var state = new this.core.State(src, this, env);
		state.inlineMode = true;
		this.core.process(state);
		return state.tokens;
	};
	MarkdownIt3.prototype.renderInline = function(src, env) {
		env = env || {};
		return this.renderer.render(this.parseInline(src, env), this.options, env);
	};
	module.exports = MarkdownIt3;
} });
var require_markdown_it = __commonJS({ "node_modules/markdown-it/index.js"(exports, module) {
	"use strict";
	module.exports = require_lib();
} });
var base_exports = {};
__export(base_exports, {
	getAstValues: () => getAstValues,
	isAst: () => isAst,
	isFunction: () => isFunction,
	isVariable: () => isVariable,
	resolve: () => resolve
});
function isAst(value) {
	return !!value?.$$mdtype;
}
function isFunction(value) {
	return !!(value?.$$mdtype === "Function");
}
function isVariable(value) {
	return !!(value?.$$mdtype === "Variable");
}
function* getAstValues(value) {
	if (value == null || typeof value !== "object") return;
	if (Array.isArray(value)) for (const v of value) yield* getAstValues(v);
	if (isAst(value)) yield value;
	if (Object.getPrototypeOf(value) !== Object.prototype) return;
	for (const v of Object.values(value)) yield* getAstValues(v);
}
function resolve(value, config = {}) {
	if (value == null || typeof value !== "object") return value;
	if (Array.isArray(value)) return value.map((item2) => resolve(item2, config));
	if (isAst(value) && value?.resolve instanceof Function) return value.resolve(config);
	if (Object.getPrototypeOf(value) !== Object.prototype) return value;
	const output = {};
	for (const [k, v] of Object.entries(value)) output[k] = resolve(v, config);
	return output;
}
var Tag = class {
	constructor(name = "div", attributes = {}, children = []) {
		this.$$mdtype = "Tag";
		this.name = name;
		this.attributes = attributes;
		this.children = children;
	}
	static {
		this.isTag = (tag) => {
			return !!(tag?.$$mdtype === "Tag");
		};
	}
};
var Class = class {
	validate(value, _config, key) {
		if (typeof value === "string" || typeof value === "object") return [];
		return [{
			id: "attribute-type-invalid",
			level: "error",
			message: `Attribute '${key}' must be type 'string | object'`
		}];
	}
	transform(value) {
		if (!value || typeof value === "string") return value;
		const classes = [];
		for (const [k, v] of Object.entries(value ?? {})) if (v) classes.push(k);
		return classes.join(" ");
	}
};
var Id = class {
	validate(value) {
		if (typeof value === "string" && value.match(/^[a-zA-Z]/)) return [];
		return [{
			id: "attribute-value-invalid",
			level: "error",
			message: "The 'id' attribute must start with a letter"
		}];
	}
};
var import_tag = __toESM(require_tag());
var Variable = class {
	constructor(path = []) {
		this.$$mdtype = "Variable";
		this.path = path;
	}
	resolve({ variables } = {}) {
		return variables instanceof Function ? variables(this.path) : this.path.reduce((obj = {}, key) => obj[key], variables);
	}
};
var Function2 = class {
	constructor(name, parameters) {
		this.$$mdtype = "Function";
		this.name = name;
		this.parameters = parameters;
	}
	resolve(config = {}) {
		const fn = config?.functions?.[this.name];
		if (!fn) return null;
		const parameters = resolve(this.parameters, config);
		return fn.transform?.(parameters, config);
	}
};
var OPEN = "{%";
var CLOSE = "%}";
var IDENTIFIER_REGEX = /^[a-zA-Z0-9_-]+$/;
function isIdentifier(s2) {
	return typeof s2 === "string" && IDENTIFIER_REGEX.test(s2);
}
function isPromise(a) {
	return a && typeof a === "object" && typeof a.then === "function";
}
function findTagEnd(content, start = 0) {
	let state = 0;
	for (let pos = start; pos < content.length; pos++) {
		const char = content[pos];
		switch (state) {
			case 1:
				switch (char) {
					case "\"":
						state = 0;
						break;
					case "\\":
						state = 2;
						break;
				}
				break;
			case 2:
				state = 1;
				break;
			case 0: if (char === "\"") state = 1;
			else if (content.startsWith(CLOSE, pos)) return pos;
		}
	}
	return null;
}
function parseTag(content, line, contentStart) {
	try {
		return (0, import_tag.parse)(content, {
			Variable,
			Function: Function2
		});
	} catch (error2) {
		if (!(error2 instanceof import_tag.SyntaxError)) throw error2;
		const { message, location: { start, end } } = error2;
		return {
			type: "error",
			meta: { error: {
				message,
				location: {
					start: {
						line,
						character: start.offset + contentStart
					},
					end: {
						line: line + 1,
						character: end.offset + contentStart
					}
				}
			} }
		};
	}
}
function parseTags(content, firstLine = 0) {
	let line = firstLine + 1;
	const output = [];
	let start = 0;
	for (let pos = 0; pos < content.length; pos++) {
		if (content[pos] === "\n") {
			line++;
			continue;
		}
		if (!content.startsWith(OPEN, pos)) continue;
		const end = findTagEnd(content, pos);
		if (end == null) {
			pos = pos + OPEN.length;
			continue;
		}
		const text2 = content.slice(pos, end + CLOSE.length);
		const inner = content.slice(pos + OPEN.length, end);
		const lineStart = content.lastIndexOf("\n", pos);
		const lineEnd = content.indexOf("\n", end);
		const lineContent = content.slice(lineStart, lineEnd);
		const tag = parseTag(inner.trim(), line, pos - lineStart);
		const precedingTextEnd = lineContent.trim() === text2 ? lineStart : pos;
		const precedingText = content.slice(start, precedingTextEnd);
		output.push({
			type: "text",
			start,
			end: pos - 1,
			content: precedingText
		});
		output.push({
			map: [line, line + 1],
			position: {
				start: pos - lineStart,
				end: pos - lineStart + text2.length
			},
			start: pos,
			end: pos + text2.length - 1,
			info: text2,
			...tag
		});
		start = end + CLOSE.length;
		pos = start - 1;
	}
	output.push({
		type: "text",
		start,
		end: content.length - 1,
		content: content.slice(start)
	});
	return output;
}
var globalAttributes = {
	class: {
		type: Class,
		render: true
	},
	id: {
		type: Id,
		render: true
	}
};
var transformer_default = {
	findSchema(node2, { nodes = {}, tags = {} } = {}) {
		return node2.tag ? tags[node2.tag] : nodes[node2.type];
	},
	attributes(node2, config = {}) {
		const schema = this.findSchema(node2, config) ?? {};
		const output = {};
		const attrs = {
			...globalAttributes,
			...schema.attributes
		};
		for (const [key, attr] of Object.entries(attrs)) {
			if (attr.render == false) continue;
			const name = typeof attr.render === "string" ? attr.render : key;
			let value = node2.attributes[key];
			if (typeof attr.type === "function") {
				const instance = new attr.type();
				if (instance.transform) value = instance.transform(value, config);
			}
			value = value === void 0 ? attr.default : value;
			if (value === void 0) continue;
			output[name] = value;
		}
		if (schema.slots) for (const [key, slot2] of Object.entries(schema.slots)) {
			if (slot2.render === false) continue;
			const name = typeof slot2.render === "string" ? slot2.render : key;
			if (node2.slots[key]) output[name] = this.node(node2.slots[key], config);
		}
		return output;
	},
	children(node2, config = {}) {
		const children = node2.children.flatMap((child) => this.node(child, config));
		if (children.some(isPromise)) return Promise.all(children);
		return children;
	},
	node(node2, config = {}) {
		const schema = this.findSchema(node2, config) ?? {};
		if (schema && schema.transform instanceof Function) return schema.transform(node2, config);
		const children = this.children(node2, config);
		if (!schema || !schema.render) return children;
		const attributes = this.attributes(node2, config);
		if (isPromise(attributes) || isPromise(children)) return Promise.all([attributes, children]).then((values) => new Tag(schema.render, ...values));
		return new Tag(schema.render, attributes, children);
	}
};
var Node$1 = class _Node {
	constructor(type = "node", attributes = {}, children = [], tag) {
		this.$$mdtype = "Node";
		this.errors = [];
		this.lines = [];
		this.inline = false;
		this.attributes = attributes;
		this.children = children;
		this.type = type;
		this.tag = tag;
		this.annotations = [];
		this.slots = {};
	}
	*walk() {
		for (const child of [...Object.values(this.slots), ...this.children]) {
			yield child;
			yield* child.walk();
		}
	}
	push(node2) {
		this.children.push(node2);
	}
	resolve(config = {}) {
		return Object.assign(new _Node(), this, {
			children: this.children.map((child) => child.resolve(config)),
			attributes: resolve(this.attributes, config),
			slots: Object.fromEntries(Object.entries(this.slots).map(([name, slot2]) => [name, slot2.resolve(config)]))
		});
	}
	findSchema(config = {}) {
		return transformer_default.findSchema(this, config);
	}
	transformAttributes(config = {}) {
		return transformer_default.attributes(this, config);
	}
	transformChildren(config) {
		return transformer_default.children(this, config);
	}
	transform(config) {
		return transformer_default.node(this, config);
	}
};
var AstTypes = {
	Function: Function2,
	Node: Node$1,
	Variable
};
function reviver(_, value) {
	if (!value) return value;
	const klass = AstTypes[value.$$mdtype];
	return klass ? Object.assign(new klass(), value) : value;
}
function fromJSON(text2) {
	return JSON.parse(text2, reviver);
}
var ast_default = {
	...AstTypes,
	...base_exports,
	fromJSON
};
var SPACE = " ";
var SEP = ", ";
var NL = "\n";
var OL = ".";
var UL = "-";
var MAX_TAG_OPENING_WIDTH = 80;
var WRAPPING_TYPES = [
	"strong",
	"em",
	"s"
];
var max = (a, b) => Math.max(a, b);
var increment = (o, n = 2) => ({
	...o,
	indent: (o.indent || 0) + n
});
function* formatChildren(a, options) {
	for (const child of a.children) yield* formatValue(child, options);
}
function* formatInline(g) {
	yield [...g].join("").trim();
}
function* formatTableRow(items) {
	yield `| ${items.join(" | ")} |`;
}
function formatScalar(v) {
	if (v === void 0) return;
	if (ast_default.isAst(v)) return format(v);
	if (v === null) return "null";
	if (Array.isArray(v)) return "[" + v.map(formatScalar).join(SEP) + "]";
	if (typeof v === "object") return "{" + Object.entries(v).map(([key, value]) => `${isIdentifier(key) ? key : `"${key}"`}: ${formatScalar(value)}`).join(SEP) + "}";
	return JSON.stringify(v);
}
function formatAnnotationValue(a) {
	const formattedValue = formatScalar(a.value);
	if (formattedValue === void 0) return void 0;
	if (a.name === "primary") return formattedValue;
	if (a.name === "id" && typeof a.value === "string" && isIdentifier(a.value)) return "#" + a.value;
	if (a.type === "class" && isIdentifier(a.name)) return "." + a.name;
	return `${a.name}=${formattedValue}`;
}
function* formatAttributes(n) {
	for (const [key, value] of Object.entries(n.attributes)) if (key === "class" && typeof value === "object" && !ast_default.isAst(value)) for (const name of Object.keys(value)) yield formatAnnotationValue({
		type: "class",
		name,
		value
	});
	else yield formatAnnotationValue({
		type: "attribute",
		name: key,
		value
	});
}
function* formatAnnotations(n) {
	if (n.annotations.length) {
		yield OPEN + SPACE;
		yield n.annotations.map(formatAnnotationValue).join(SPACE);
		yield SPACE + CLOSE;
	}
}
function* formatVariable(v) {
	yield "$";
	yield v.path.map((p, i) => {
		if (i === 0) return p;
		if (isIdentifier(p)) return "." + p;
		if (typeof p === "number") return `[${p}]`;
		return `["${p}"]`;
	}).join("");
}
function* formatFunction(f) {
	yield f.name;
	yield "(";
	yield Object.values(f.parameters).map(formatScalar).join(SEP);
	yield ")";
}
function* trimStart(g) {
	let n;
	do {
		const { value, done } = g.next();
		if (done) return;
		n = value.trimStart();
	} while (!n.length);
	yield n;
	yield* g;
}
function* escapeMarkdownCharacters(s2, characters) {
	yield s2.replace(characters, "\\$&").replace(/* @__PURE__ */ new RegExp("\xA0", "g"), "&nbsp;");
}
function* formatNode(n, o = {}) {
	const no = {
		...o,
		parent: n
	};
	const indent = SPACE.repeat(no.indent || 0);
	switch (n.type) {
		case "document":
			if (n.attributes.frontmatter && n.attributes.frontmatter.length) yield "---" + NL + n.attributes.frontmatter + NL + "---" + NL + NL;
			yield* trimStart(formatChildren(n, no));
			break;
		case "heading":
			yield NL;
			yield indent;
			yield "#".repeat(n.attributes.level || 1);
			yield SPACE;
			yield* trimStart(formatChildren(n, no));
			yield* formatAnnotations(n);
			yield NL;
			break;
		case "paragraph":
			yield NL;
			yield* formatChildren(n, no);
			yield* formatAnnotations(n);
			yield NL;
			break;
		case "inline":
			yield indent;
			yield* formatChildren(n, no);
			break;
		case "image":
			yield "!";
			yield "[";
			yield* formatValue(n.attributes.alt, no);
			yield "]";
			yield "(";
			yield* typeof n.attributes.src === "string" ? escapeMarkdownCharacters(n.attributes.src, /[()]/g) : formatValue(n.attributes.src, no);
			if (n.attributes.title) yield SPACE + `"${n.attributes.title}"`;
			yield ")";
			break;
		case "link": {
			const children = [...formatChildren(n, no)].join("");
			if (children === n.attributes.href && !n.attributes.title) {
				yield `<${n.attributes.href}>`;
				break;
			}
			yield "[";
			yield children;
			yield "]";
			yield "(";
			yield* typeof n.attributes.href === "string" ? escapeMarkdownCharacters(n.attributes.href, /[()]/g) : formatValue(n.attributes.href, no);
			if (n.attributes.title) yield SPACE + `"${n.attributes.title}"`;
			yield ")";
			break;
		}
		case "text": {
			const { content } = n.attributes;
			if (ast_default.isAst(content)) {
				yield OPEN + SPACE;
				yield* formatValue(content, no);
				yield SPACE + CLOSE;
			} else if (o.parent && WRAPPING_TYPES.includes(o.parent.type)) yield* escapeMarkdownCharacters(content, /[*_~]/g);
			else yield* escapeMarkdownCharacters(content, /^\*|#+\s|^>/);
			break;
		}
		case "blockquote": {
			const prefix = ">" + SPACE;
			yield n.children.map((child) => format(child, no).trimStart()).map((d) => NL + indent + prefix + d).join(indent + prefix);
			break;
		}
		case "hr":
			yield NL;
			yield indent;
			yield "---";
			yield NL;
			break;
		case "fence": {
			yield NL;
			yield indent;
			const innerFenceLength = (n.attributes.content.match(/`{3,}/g) || []).map((s2) => s2.length).reduce(max, 0);
			const boundary = "`".repeat(innerFenceLength ? innerFenceLength + 1 : 3);
			const needsNlBeforeEndBoundary = !n.attributes.content.endsWith(NL);
			yield boundary;
			if (n.attributes.language) yield n.attributes.language;
			if (n.annotations.length) yield SPACE;
			yield* formatAnnotations(n);
			yield NL;
			yield indent;
			yield n.attributes.content.split(NL).join(NL + indent);
			if (needsNlBeforeEndBoundary) yield NL;
			yield boundary;
			yield NL;
			break;
		}
		case "tag": {
			if (!n.inline) {
				yield NL;
				yield indent;
			}
			const open = OPEN + SPACE;
			const attributes = [...formatAttributes(n)].filter((v) => v !== void 0);
			const tag = [open + n.tag, ...attributes];
			const inlineTag = tag.join(SPACE);
			const isLongTagOpening = inlineTag.length + open.length * 2 > (o.maxTagOpeningWidth || MAX_TAG_OPENING_WIDTH);
			yield (!n.inline && isLongTagOpening ? tag.join(NL + SPACE.repeat(open.length) + indent) : inlineTag) + SPACE + (n.children.length ? "" : "/") + CLOSE;
			if (n.children.length) {
				yield* formatChildren(n, no.allowIndentation ? increment(no) : no);
				if (!n.inline) yield indent;
				yield OPEN + SPACE + "/" + n.tag + SPACE + CLOSE;
			}
			if (!n.inline) yield NL;
			break;
		}
		case "list": {
			const isLoose = n.children.some((n2) => n2.children.some((c) => c.type === "paragraph"));
			for (let i = 0; i < n.children.length; i++) {
				const prefix = (() => {
					if (!n.attributes.ordered) return n.attributes.marker ?? UL;
					let number = "1";
					const startNumber = n.attributes.start ?? 1;
					if (i === 0) number = startNumber.toString();
					if (o.orderedListMode === "increment") number = (parseInt(startNumber) + i).toString();
					return `${number}${n.attributes.marker ?? OL}`;
				})();
				let d = format(n.children[i], increment(no, prefix.length + 1));
				if (!isLoose || i === n.children.length - 1) d = d.trim();
				yield NL + indent + prefix + " " + d;
			}
			yield NL;
			break;
		}
		case "item":
			for (let i = 0; i < n.children.length; i++) {
				yield* formatValue(n.children[i], no);
				if (i === 0) yield* formatAnnotations(n);
			}
			break;
		case "strong":
			yield n.attributes.marker ?? "**";
			yield* formatInline(formatChildren(n, no));
			yield n.attributes.marker ?? "**";
			break;
		case "em":
			yield n.attributes.marker ?? "*";
			yield* formatInline(formatChildren(n, no));
			yield n.attributes.marker ?? "*";
			break;
		case "code":
			yield "`";
			yield* formatInline(formatValue(n.attributes.content, no));
			yield "`";
			break;
		case "s":
			yield "~~";
			yield* formatInline(formatChildren(n, no));
			yield "~~";
			break;
		case "hardbreak":
			yield "\\" + NL;
			yield indent;
			break;
		case "softbreak":
			yield NL;
			yield indent;
			break;
		case "table": {
			const table3 = [...formatChildren(n, increment(no))];
			if (o.parent && o.parent.type === "tag" && o.parent.tag === "table") {
				for (let i = 0; i < table3.length; i++) {
					const row = table3[i];
					if (typeof row === "string") {
						if (row.trim().length) {
							yield NL;
							yield row;
						}
					} else {
						if (i !== 0) {
							yield NL;
							yield indent + "---";
						}
						for (const d of row) yield NL + indent + UL + " " + d;
					}
				}
				yield NL;
			} else {
				const widths = [];
				for (const row of table3) for (let i = 0; i < row.length; i++) widths[i] = widths[i] ? Math.max(widths[i], row[i].length) : row[i].length;
				const [head, ...rows] = table3;
				yield NL;
				yield* formatTableRow(head.map((cell, i) => cell + SPACE.repeat(widths[i] - cell.length)));
				yield NL;
				yield* formatTableRow(head.map((cell, i) => "-".repeat(widths[i])));
				yield NL;
				for (const row of rows) {
					yield* formatTableRow(row.map((cell, i) => cell + SPACE.repeat(widths[i] - cell.length)));
					yield NL;
				}
			}
			break;
		}
		case "thead": {
			const [head] = [...formatChildren(n, no)];
			yield head || [];
			break;
		}
		case "tr":
			yield [...formatChildren(n, no)];
			break;
		case "td":
		case "th":
			yield [...formatChildren(n, no), ...formatAnnotations(n)].join("").trim();
			break;
		case "tbody":
			yield* formatChildren(n, no);
			break;
		case "comment":
			yield "<!-- " + n.attributes.content + " -->\n";
			break;
		case "error":
		case "node": break;
	}
}
function* formatValue(v, o = {}) {
	switch (typeof v) {
		case "undefined": break;
		case "boolean":
		case "number":
		case "string":
			yield v.toString();
			break;
		case "object":
			if (v === null) break;
			if (Array.isArray(v)) {
				for (const n of v) yield* formatValue(n, o);
				break;
			}
			switch (v.$$mdtype) {
				case "Function":
					yield* formatFunction(v);
					break;
				case "Node":
					yield* formatNode(v, o);
					break;
				case "Variable":
					yield* formatVariable(v);
					break;
				default: throw new Error(`Unimplemented: "${v.$$mdtype}"`);
			}
			break;
	}
}
function format(v, options) {
	let doc = "";
	for (const s2 of formatValue(v, options)) doc += s2;
	return doc.trimStart();
}
var ConditionalAttributeType = class {
	validate(value, _config, key) {
		if (typeof value === "boolean" || value === null || value === void 0 || typeof value === "object") return [];
		return [{
			id: "attribute-type-invalid",
			level: "error",
			message: `Attribute '${key}' must be type 'boolean | object' (null or undefined are also allowed)`
		}];
	}
};
function truthy(value) {
	return value !== false && value !== void 0 && value !== null;
}
function renderConditions(node2) {
	const conditions = [{
		condition: node2.attributes.primary,
		children: []
	}];
	for (const child of node2.children) if (child.type === "tag" && child.tag === "else") conditions.push({
		condition: "primary" in child.attributes ? child.attributes.primary : true,
		children: []
	});
	else conditions[conditions.length - 1].children.push(child);
	return conditions;
}
var tagIf = {
	attributes: { primary: {
		type: ConditionalAttributeType,
		render: false
	} },
	transform(node2, config) {
		const conditions = renderConditions(node2);
		for (const { condition, children } of conditions) if (truthy(condition)) {
			const nodes = children.flatMap((child) => child.transform(config));
			if (nodes.some(isPromise)) return Promise.all(nodes).then((nodes2) => nodes2.flat());
			return nodes;
		}
		return [];
	}
};
var tagElse = {
	selfClosing: true,
	attributes: { primary: {
		type: ConditionalAttributeType,
		render: false
	} }
};
var functions_default = {
	and: { transform(parameters) {
		return Object.values(parameters).every((x) => truthy(x));
	} },
	or: { transform(parameters) {
		return Object.values(parameters).find((x) => truthy(x)) !== void 0;
	} },
	not: {
		parameters: { 0: { required: true } },
		transform(parameters) {
			return !truthy(parameters[0]);
		}
	},
	equals: { transform(parameters) {
		const values = Object.values(parameters);
		return values.every((v) => v === values[0]);
	} },
	default: { transform(parameters) {
		return parameters[0] === void 0 ? parameters[1] : parameters[0];
	} },
	debug: { transform(parameters) {
		return JSON.stringify(parameters[0], null, 2);
	} }
};
function convertToRow(node2, cellType = "td") {
	node2.type = "tr";
	node2.attributes = {};
	for (const cell of node2.children) cell.type = cellType;
	return node2;
}
function isConditionalTag(node2, conditionalTags) {
	return node2.type === "tag" && !!node2.tag && conditionalTags.includes(node2.tag);
}
function isComment(node2) {
	return node2.type === "comment" || node2.type === "tag" && node2.tag === "comment";
}
function unexpectedNodeError(node2) {
	return {
		id: "table-syntax",
		level: "critical",
		message: `Found ${node2.type}${node2.tag ? ` ${node2.tag}` : ""} where a list was expected. Make sure all content inside table cells is indented.`,
		location: node2.location
	};
}
function transform(document2, conditionalTags = ["if"]) {
	for (const node2 of document2.walk()) {
		if (node2.type !== "tag" || node2.tag !== "table") continue;
		const [first, ...rest] = node2.children;
		if (!first || first.type === "table") continue;
		const table3 = new ast_default.Node("table", node2.attributes, [new ast_default.Node("thead"), new ast_default.Node("tbody")]);
		const [thead2, tbody2] = table3.children;
		if (first.type === "list") thead2.push(convertToRow(first, "th"));
		for (const row of rest) {
			if (row.type === "list") convertToRow(row);
			else if (isConditionalTag(row, conditionalTags)) {
				const children = [];
				for (const child of row.children) {
					if (child.type === "hr") continue;
					if (child.type === "list") convertToRow(child);
					else if (isComment(child) || child.tag === "else" || isConditionalTag(child, conditionalTags)) {} else {
						row.errors.push(unexpectedNodeError(child));
						continue;
					}
					children.push(child);
				}
				row.children = children;
			} else if (row.type !== "hr" && !isComment(row)) {
				node2.errors.push(unexpectedNodeError(row));
				continue;
			} else continue;
			tbody2.push(row);
		}
		node2.children = [table3];
	}
}
var transforms_default = [transform];
var mappings = {
	ordered_list: "list",
	bullet_list: "list",
	code_inline: "code",
	list_item: "item",
	variable: "text"
};
function annotate(node2, attributes) {
	for (const attribute of attributes) {
		node2.annotations.push(attribute);
		const { name, value, type } = attribute;
		if (type === "attribute") {
			if (node2.attributes[name] !== void 0) node2.errors.push({
				id: "duplicate-attribute",
				level: "warning",
				message: `Attribute '${name}' already set`
			});
			node2.attributes[name] = value;
		} else if (type === "class") if (node2.attributes.class) node2.attributes.class[name] = value;
		else node2.attributes.class = { [name]: value };
	}
}
function handleAttrs(token, type) {
	switch (type) {
		case "heading": return { level: Number(token.tag.replace("h", "")) };
		case "list": {
			const attrs = token.attrs ? Object.fromEntries(token.attrs) : void 0;
			const ordered = token.type.startsWith("ordered");
			return ordered && attrs?.start ? {
				ordered: true,
				start: attrs.start,
				marker: token.markup
			} : {
				ordered,
				marker: token.markup
			};
		}
		case "link": {
			const attrs = Object.fromEntries(token.attrs);
			return attrs.title ? {
				href: attrs.href,
				title: attrs.title
			} : { href: attrs.href };
		}
		case "image": {
			const attrs = Object.fromEntries(token.attrs);
			return attrs.title ? {
				alt: token.content,
				src: attrs.src,
				title: attrs.title
			} : {
				alt: token.content,
				src: attrs.src
			};
		}
		case "em":
		case "strong": return { marker: token.markup };
		case "text":
		case "code":
		case "comment": return { content: (token.meta || {}).variable || token.content };
		case "fence": {
			const [language] = token.info.split(" ", 1);
			return language === "" || language === OPEN ? { content: token.content } : {
				content: token.content,
				language
			};
		}
		case "td":
		case "th":
			if (token.attrs) {
				const attrs = Object.fromEntries(token.attrs);
				let align;
				if (attrs.style) {
					if (attrs.style.includes("left")) align = "left";
					else if (attrs.style.includes("center")) align = "center";
					else if (attrs.style.includes("right")) align = "right";
				}
				if (align) return { align };
			}
			return {};
		default: return {};
	}
}
function handleToken(token, nodes, file, handleSlots, addLocation, inlineParent) {
	if (token.type === "frontmatter") {
		nodes[0].attributes.frontmatter = token.content;
		return;
	}
	if (token.hidden || token.type === "text" && token.content === "") return;
	const errors = token.errors || [];
	const parent = nodes[nodes.length - 1];
	const { tag, attributes, error: error2 } = token.meta || {};
	if (token.type === "annotation") {
		if (inlineParent) return annotate(inlineParent, attributes);
		return parent.errors.push({
			id: "no-inline-annotations",
			level: "error",
			message: `Can't apply inline annotations to '${parent.type}'`
		});
	}
	let typeName = token.type.replace(/_(open|close)$/, "");
	if (mappings[typeName]) typeName = mappings[typeName];
	if (typeName === "error") {
		const { message, location } = error2;
		errors.push({
			id: "parse-error",
			level: "critical",
			message,
			location
		});
	}
	if (token.nesting < 0) {
		if (parent.type === typeName && parent.tag === tag) {
			if (parent.lines && token.map) parent.lines.push(...token.map);
			return nodes.pop();
		}
		errors.push({
			id: "missing-opening",
			level: "critical",
			message: `Node '${typeName}' is missing opening`
		});
	}
	const attrs = handleAttrs(token, typeName);
	const node2 = new Node$1(typeName, attrs, void 0, tag || void 0);
	const { position = {} } = token;
	node2.errors = errors;
	if (addLocation !== false) {
		node2.lines = token.map || parent.lines || [];
		node2.location = {
			file,
			start: {
				line: node2.lines[0],
				character: position.start
			},
			end: {
				line: node2.lines[1],
				character: position.end
			}
		};
	}
	if (inlineParent) node2.inline = true;
	if (attributes && [
		"tag",
		"fence",
		"image"
	].includes(typeName)) annotate(node2, attributes);
	if (handleSlots && tag === "slot" && typeof node2.attributes.primary === "string") parent.slots[node2.attributes.primary] = node2;
	else parent.push(node2);
	if (token.nesting > 0) nodes.push(node2);
	if (!Array.isArray(token.children)) return;
	if (node2.type === "inline") inlineParent = parent;
	nodes.push(node2);
	if (!(typeName === "image")) for (const child of token.children) handleToken(child, nodes, file, handleSlots, addLocation, inlineParent);
	nodes.pop();
}
function parser(tokens, args) {
	const doc = new Node$1("document");
	const nodes = [doc];
	if (typeof args === "string") args = { file: args };
	for (const token of tokens) handleToken(token, nodes, args?.file, args?.slots, args?.location);
	if (nodes.length > 1) for (const node2 of nodes.slice(1)) node2.errors.push({
		id: "missing-closing",
		level: "critical",
		message: `Node '${node2.tag || node2.type}' is missing closing`
	});
	for (const transform3 of transforms_default) transform3(doc, args?.conditionalTags);
	return doc;
}
var schema_exports = {};
__export(schema_exports, {
	blockquote: () => blockquote,
	code: () => code,
	comment: () => comment,
	document: () => document$1,
	em: () => em,
	error: () => error,
	fence: () => fence,
	hardbreak: () => hardbreak,
	heading: () => heading,
	hr: () => hr,
	image: () => image,
	inline: () => inline,
	item: () => item,
	link: () => link,
	list: () => list,
	node: () => node,
	paragraph: () => paragraph,
	s: () => s,
	softbreak: () => softbreak,
	strong: () => strong,
	table: () => table,
	tbody: () => tbody,
	td: () => td,
	text: () => text,
	th: () => th,
	thead: () => thead,
	tr: () => tr
});
var document$1 = {
	render: "article",
	children: [
		"heading",
		"paragraph",
		"image",
		"table",
		"tag",
		"fence",
		"blockquote",
		"comment",
		"list",
		"hr"
	],
	attributes: { frontmatter: { render: false } }
};
var heading = {
	children: ["inline"],
	attributes: { level: {
		type: Number,
		render: false,
		required: true
	} },
	transform(node2, config) {
		return new Tag(`h${node2.attributes["level"]}`, node2.transformAttributes(config), node2.transformChildren(config));
	}
};
var paragraph = {
	render: "p",
	children: ["inline"]
};
var image = {
	render: "img",
	attributes: {
		src: {
			type: String,
			required: true
		},
		alt: { type: String },
		title: { type: String }
	}
};
var fence = {
	render: "pre",
	attributes: {
		content: {
			type: String,
			render: false,
			required: true
		},
		language: {
			type: String,
			render: "data-language"
		},
		process: {
			type: Boolean,
			render: false,
			default: true
		}
	},
	transform(node2, config) {
		return new Tag("pre", node2.transformAttributes(config), node2.children.length ? node2.transformChildren(config) : [node2.attributes.content]);
	}
};
var blockquote = {
	render: "blockquote",
	children: [
		"heading",
		"paragraph",
		"image",
		"table",
		"tag",
		"fence",
		"blockquote",
		"list",
		"hr"
	]
};
var item = {
	render: "li",
	children: [
		"inline",
		"heading",
		"paragraph",
		"image",
		"table",
		"tag",
		"fence",
		"blockquote",
		"list",
		"hr"
	]
};
var list = {
	children: ["item"],
	attributes: {
		ordered: {
			type: Boolean,
			render: false,
			required: true
		},
		start: { type: Number },
		marker: {
			type: String,
			render: false
		}
	},
	transform(node2, config) {
		return new Tag(node2.attributes.ordered ? "ol" : "ul", node2.transformAttributes(config), node2.transformChildren(config));
	}
};
var hr = { render: "hr" };
var table = { render: "table" };
var td = {
	render: "td",
	children: [
		"inline",
		"heading",
		"paragraph",
		"image",
		"table",
		"tag",
		"fence",
		"blockquote",
		"list",
		"hr"
	],
	attributes: {
		align: { type: String },
		colspan: {
			type: Number,
			render: "colSpan"
		},
		rowspan: {
			type: Number,
			render: "rowSpan"
		}
	}
};
var th = {
	render: "th",
	attributes: {
		width: { type: String },
		align: { type: String },
		colspan: {
			type: Number,
			render: "colSpan"
		},
		rowspan: {
			type: Number,
			render: "rowSpan"
		}
	}
};
var tr = {
	render: "tr",
	children: ["th", "td"]
};
var tbody = {
	render: "tbody",
	children: ["tr", "tag"]
};
var thead = {
	render: "thead",
	children: ["tr"]
};
var strong = {
	render: "strong",
	children: [
		"em",
		"s",
		"link",
		"code",
		"text",
		"tag"
	],
	attributes: { marker: {
		type: String,
		render: false
	} }
};
var em = {
	render: "em",
	children: [
		"strong",
		"s",
		"link",
		"code",
		"text",
		"tag"
	],
	attributes: { marker: {
		type: String,
		render: false
	} }
};
var s = {
	render: "s",
	children: [
		"strong",
		"em",
		"link",
		"code",
		"text",
		"tag"
	]
};
var inline = { children: [
	"strong",
	"em",
	"s",
	"code",
	"text",
	"tag",
	"link",
	"image",
	"hardbreak",
	"softbreak",
	"comment"
] };
var link = {
	render: "a",
	children: [
		"strong",
		"em",
		"s",
		"code",
		"text",
		"tag"
	],
	attributes: {
		href: {
			type: String,
			required: true
		},
		title: { type: String }
	}
};
var code = {
	render: "code",
	attributes: { content: {
		type: String,
		render: false,
		required: true
	} },
	transform(node2, config) {
		return new Tag("code", node2.transformAttributes(config), [node2.attributes.content]);
	}
};
var text = {
	attributes: { content: {
		type: String,
		required: true
	} },
	transform(node2) {
		return node2.attributes.content;
	}
};
var hardbreak = { render: "br" };
var softbreak = { transform() {
	return " ";
} };
var comment = { attributes: { content: {
	type: String,
	required: true
} } };
var error = {};
var node = {};
var { escapeHtml } = (0, __toESM(require_markdown_it()).default)().utils;
var voidElements = /* @__PURE__ */ new Set([
	"area",
	"base",
	"br",
	"col",
	"embed",
	"hr",
	"img",
	"input",
	"link",
	"meta",
	"param",
	"source",
	"track",
	"wbr"
]);
function render(node2) {
	if (typeof node2 === "string" || typeof node2 === "number") return escapeHtml(String(node2));
	if (Array.isArray(node2)) return node2.map(render).join("");
	if (node2 === null || typeof node2 !== "object" || !Tag.isTag(node2)) return "";
	const { name, attributes, children = [] } = node2;
	if (!name) return render(children);
	let output = `<${name}`;
	for (const [k, v] of Object.entries(attributes ?? {})) output += ` ${k.toLowerCase()}="${escapeHtml(String(v))}"`;
	output += ">";
	if (voidElements.has(name)) return output;
	if (children.length) output += render(children);
	output += `</${name}>`;
	return output;
}
function tagName(name, components) {
	return typeof name !== "string" ? name : name[0] !== name[0].toUpperCase() ? name : components instanceof Function ? components(name) : components[name];
}
function dynamic(node2, React, { components = {}, resolveTagName = tagName } = {}) {
	function deepRender2(value) {
		if (value == null || typeof value !== "object") return value;
		if (Array.isArray(value)) return value.map((item2) => deepRender2(item2));
		if (value.$$mdtype === "Tag") return render3(value);
		if (typeof value !== "object") return value;
		const output = {};
		for (const [k, v] of Object.entries(value)) output[k] = deepRender2(v);
		return output;
	}
	function render3(node3) {
		if (Array.isArray(node3)) return React.createElement(React.Fragment, null, ...node3.map(render3));
		if (node3 === null || typeof node3 !== "object" || !Tag.isTag(node3)) return node3;
		const { name, attributes: { class: className, ...attrs } = {}, children = [] } = node3;
		if (className) attrs.className = className;
		return React.createElement(resolveTagName(name, components), Object.keys(attrs).length == 0 ? null : deepRender2(attrs), ...children.map(render3));
	}
	return render3(node2);
}
function tagName2(name, components) {
	return typeof name !== "string" ? "Fragment" : name[0] !== name[0].toUpperCase() ? name : components instanceof Function ? components(name) : components[name];
}
function renderArray(children) {
	return children.map(render2).join(", ");
}
function deepRender(value) {
	if (value == null || typeof value !== "object") return JSON.stringify(value);
	if (Array.isArray(value)) return `[${value.map((item2) => deepRender(item2)).join(", ")}]`;
	if (value.$$mdtype === "Tag") return render2(value);
	if (typeof value !== "object") return JSON.stringify(value);
	return `{${Object.entries(value).map(([k, v]) => [JSON.stringify(k), deepRender(v)].join(": ")).join(", ")}}`;
}
function render2(node2) {
	if (Array.isArray(node2)) return `React.createElement(React.Fragment, null, ${renderArray(node2)})`;
	if (node2 === null || typeof node2 !== "object" || !Tag.isTag(node2)) return JSON.stringify(node2);
	const { name, attributes: { class: className, ...attrs } = {}, children = [] } = node2;
	if (className) attrs.className = className;
	return `React.createElement(
    tagName(${JSON.stringify(name)}, components),
    ${Object.keys(attrs).length == 0 ? "null" : deepRender(attrs)},
    ${renderArray(children)})`;
}
function reactStatic(node2, { resolveTagName = tagName2 } = {}) {
	if (resolveTagName.name !== "tagName") throw new Error("resolveTagName must be named tagName");
	return `
  (({components = {}} = {}) => {
    ${resolveTagName}
    return ${render2(node2)};
  })
`;
}
var renderers_default = {
	html: render,
	react: dynamic,
	reactStatic
};
var PartialFile = class {
	validate(file, config) {
		const { partials = {} } = config;
		if (!partials[file]) return [{
			id: "attribute-value-invalid",
			level: "error",
			message: `Partial \`${file}\` not found. The 'file' attribute must be set in \`config.partials\``
		}];
		return [];
	}
};
var tags_default = {
	else: tagElse,
	if: tagIf,
	partial: {
		inline: false,
		selfClosing: true,
		attributes: {
			file: {
				type: PartialFile,
				render: false,
				required: true
			},
			variables: {
				type: Object,
				render: false
			}
		},
		transform(node2, config) {
			const { partials = {} } = config;
			const { file, variables } = node2.attributes;
			const partial2 = partials[file];
			if (!partial2) return null;
			const scopedConfig = {
				...config,
				variables: {
					...config.variables,
					...variables,
					["$$partial:filename"]: file
				}
			};
			const transformChildren = (part) => part.resolve(scopedConfig).transformChildren(scopedConfig);
			return Array.isArray(partial2) ? partial2.flatMap(transformChildren) : transformChildren(partial2);
		}
	},
	slot: { attributes: { primary: {
		type: String,
		required: true
	} } },
	table: {
		children: ["table"],
		inline: false
	}
};
var import_lib = __toESM(require_lib());
var import_tag7 = __toESM(require_tag());
function createToken(state, content, contentStart) {
	try {
		const { type, meta, nesting = 0 } = (0, import_tag7.parse)(content, {
			Variable,
			Function: Function2
		});
		const token = state.push(type, "", nesting);
		token.info = content;
		token.meta = meta;
		if (!state.delimiters) state.delimiters = [];
		return token;
	} catch (error2) {
		if (!(error2 instanceof import_tag7.SyntaxError)) throw error2;
		const { message, location: { start, end } } = error2;
		const location = contentStart ? {
			start: { offset: start.offset + contentStart },
			end: { offset: end.offset + contentStart }
		} : null;
		const token = state.push("error", "", 0);
		token.meta = { error: {
			message,
			location
		} };
		return token;
	}
}
function block(state, startLine, endLine, silent) {
	const start = state.bMarks[startLine] + state.tShift[startLine];
	const finish = state.eMarks[startLine];
	if (!state.src.startsWith(OPEN, start)) return false;
	const tagEnd = findTagEnd(state.src, start);
	const lastPossible = state.src.slice(0, finish).trim().length;
	if (!tagEnd || tagEnd < lastPossible - CLOSE.length) return false;
	const contentStart = start + OPEN.length;
	const content = state.src.slice(contentStart, tagEnd).trim();
	const lines = state.src.slice(start, tagEnd + CLOSE.length).split("\n").length;
	if (content[0] === "$") return false;
	if (silent) return true;
	const token = createToken(state, content, contentStart);
	token.map = [startLine, startLine + lines];
	state.line += lines;
	return true;
}
function inline2(state, silent) {
	if (!state.src.startsWith(OPEN, state.pos)) return false;
	const tagEnd = findTagEnd(state.src, state.pos);
	if (!tagEnd) return false;
	const content = state.src.slice(state.pos + OPEN.length, tagEnd);
	if (!silent) createToken(state, content.trim());
	state.pos = tagEnd + CLOSE.length;
	return true;
}
function core(state) {
	let token;
	for (token of state.tokens) {
		if (token.type !== "fence") continue;
		if (token.info.includes(OPEN)) {
			const start = token.info.indexOf(OPEN);
			const end = findTagEnd(token.info, start);
			const content = token.info.slice(start + OPEN.length, end);
			try {
				const { meta } = (0, import_tag7.parse)(content.trim(), {
					Variable,
					Function: Function2
				});
				token.meta = meta;
			} catch (error2) {
				if (!(error2 instanceof import_tag7.SyntaxError)) throw error2;
				if (!token.errors) token.errors = [];
				token.errors.push({
					id: "fence-tag-error",
					level: "error",
					message: `Syntax error in fence tag: ${error2.message}`
				});
			}
		}
		if (token?.meta?.attributes?.find((attr) => attr.name === "process" && !attr.value)) continue;
		token.children = parseTags(token.content, token.map[0]);
	}
}
function plugin(md) {
	md.block.ruler.before("paragraph", "annotations", block, { alt: ["paragraph", "blockquote"] });
	md.inline.ruler.push("containers", inline2);
	md.core.ruler.push("annotations", core);
}
var fence2 = "---";
function getLine(state, n) {
	return state.src.slice(state.bMarks[n], state.eMarks[n]).trim();
}
function findClose(state, endLine) {
	for (let line = 1; line < endLine; line++) if (getLine(state, line) === fence2) return line;
}
function block2(state, startLine, endLine, silent) {
	if (startLine != 0 || getLine(state, 0) != fence2) return false;
	const close = findClose(state, endLine);
	if (!close) return false;
	if (silent) return true;
	const token = state.push("frontmatter", "", 0);
	token.content = state.src.slice(state.eMarks[0], state.bMarks[close]).trim();
	token.map = [0, close];
	token.hidden = true;
	state.line = close + 1;
	return true;
}
function plugin2(md) {
	md.block.ruler.before("hr", "frontmatter", block2);
}
var OPEN2 = "<!--";
var CLOSE2 = "-->";
function block3(state, startLine, endLine, silent) {
	const start = state.bMarks[startLine] + state.tShift[startLine];
	if (!state.src.startsWith(OPEN2, start)) return false;
	const close = state.src.indexOf(CLOSE2, start);
	if (close === -1) return false;
	if (silent) return true;
	const content = state.src.slice(start + OPEN2.length, close);
	const lines = content.split("\n").length;
	const token = state.push("comment", "", 0);
	token.content = content.trim();
	token.map = [startLine, startLine + lines];
	state.line += lines;
	return true;
}
function inline3(state, silent) {
	if (!state.src.startsWith(OPEN2, state.pos)) return false;
	const close = state.src.indexOf(CLOSE2, state.pos);
	if (close === -1) return false;
	if (silent) return true;
	const content = state.src.slice(state.pos + OPEN2.length, close);
	const token = state.push("comment", "", 0);
	token.content = content.trim();
	state.pos = close + CLOSE2.length;
	return true;
}
function plugin3(md) {
	md.block.ruler.before("table", "comment", block3, { alt: ["paragraph"] });
	md.inline.ruler.push("comment", inline3);
}
var Tokenizer = class {
	constructor(config = {}) {
		this.parser = new import_lib.default(config);
		this.parser.use(plugin, "annotations", {});
		this.parser.use(plugin2, "frontmatter", {});
		this.parser.disable(["lheading", "code"]);
		if (config.allowComments) this.parser.use(plugin3, "comments", {});
	}
	tokenize(content) {
		return this.parser.parse(content.toString(), {});
	}
};
var TypeMappings = {
	String,
	Number,
	Array,
	Object,
	Boolean
};
function validateType(type, value, config, key) {
	if (!type) return true;
	if (ast_default.isFunction(value) && config.validation?.validateFunctions) {
		const schema = config.functions?.[value.name];
		return !schema?.returns ? true : Array.isArray(schema.returns) ? schema.returns.find((t) => t === type) !== void 0 : schema.returns === type;
	}
	if (ast_default.isAst(value)) return true;
	if (Array.isArray(type)) return type.some((t) => validateType(t, value, config, key));
	if (typeof type === "string") type = TypeMappings[type];
	if (typeof type === "function") {
		const instance = new type();
		if (instance.validate) return instance.validate(value, config, key);
	}
	return value != null && value.constructor === type;
}
function typeToString(type) {
	if (typeof type === "string") return type;
	if (Array.isArray(type)) return type.map(typeToString).join(" | ");
	return type.name;
}
function validateFunction(fn, config) {
	const schema = config.functions?.[fn.name];
	const errors = [];
	if (!schema) return [{
		id: "function-undefined",
		level: "critical",
		message: `Undefined function: '${fn.name}'`
	}];
	if (schema.validate) errors.push(...schema.validate(fn, config));
	if (schema.parameters) for (const [key, value] of Object.entries(fn.parameters)) {
		const param = schema.parameters?.[key];
		if (!param) {
			errors.push({
				id: "parameter-undefined",
				level: "error",
				message: `Invalid parameter: '${key}'`
			});
			continue;
		}
		if (ast_default.isAst(value) && !ast_default.isFunction(value)) continue;
		if (param.type) {
			const valid = validateType(param.type, value, config, key);
			if (valid === false) errors.push({
				id: "parameter-type-invalid",
				level: "error",
				message: `Parameter '${key}' of '${fn.name}' must be type of '${typeToString(param.type)}'`
			});
			else if (Array.isArray(valid)) errors.push(...valid);
		}
	}
	for (const [key, { required }] of Object.entries(schema.parameters ?? {})) if (required && fn.parameters[key] === void 0) errors.push({
		id: "parameter-missing-required",
		level: "error",
		message: `Missing required parameter: '${key}'`
	});
	return errors;
}
function displayMatches(matches, n) {
	if (matches.length <= n) return JSON.stringify(matches);
	return `[${matches.slice(0, n).map((item2) => JSON.stringify(item2)).join(",")}, ... ${matches.length - n} more]`;
}
function validator(node2, config) {
	const schema = node2.findSchema(config);
	const errors = [...node2.errors || []];
	if (!schema) {
		errors.push({
			id: node2.tag ? "tag-undefined" : "node-undefined",
			level: "critical",
			message: node2.tag ? `Undefined tag: '${node2.tag}'` : `Undefined node: '${node2.type}'`
		});
		return errors;
	}
	if (schema.inline != void 0 && node2.inline !== schema.inline) errors.push({
		id: "tag-placement-invalid",
		level: "critical",
		message: `'${node2.tag}' tag should be ${schema.inline ? "inline" : "block"}`
	});
	if (schema.selfClosing && node2.children.length > 0) errors.push({
		id: "tag-selfclosing-has-children",
		level: "critical",
		message: `'${node2.tag}' tag should be self-closing`
	});
	const attributes = {
		...globalAttributes,
		...schema.attributes
	};
	for (const key of Object.keys(node2.slots)) if (!schema.slots?.[key]) errors.push({
		id: "slot-undefined",
		level: "error",
		message: `Invalid slot: '${key}'`
	});
	for (let [key, value] of Object.entries(node2.attributes)) {
		const attrib = attributes[key];
		if (!attrib) {
			errors.push({
				id: "attribute-undefined",
				level: "error",
				message: `Invalid attribute: '${key}'`
			});
			continue;
		}
		let { type, matches, errorLevel } = attrib;
		if (ast_default.isAst(value)) if (ast_default.isFunction(value) && config.validation?.validateFunctions) errors.push(...validateFunction(value, config));
		else if (ast_default.isVariable(value) && config.variables) {
			let missing = false;
			let variables = config.variables;
			for (const key2 of value.path) {
				if (!Object.prototype.hasOwnProperty.call(variables, key2)) {
					missing = true;
					break;
				}
				variables = variables[key2];
			}
			if (missing) errors.push({
				id: "variable-undefined",
				level: "error",
				message: `Undefined variable: '${value.path.join(".")}'`
			});
		} else continue;
		value = value;
		if (type) {
			const valid = validateType(type, value, config, key);
			if (valid === false) errors.push({
				id: "attribute-type-invalid",
				level: errorLevel || "error",
				message: `Attribute '${key}' must be type of '${typeToString(type)}'`
			});
			if (Array.isArray(valid)) errors.push(...valid);
		}
		if (typeof matches === "function") matches = matches(config);
		if (Array.isArray(matches) && !matches.includes(value)) errors.push({
			id: "attribute-value-invalid",
			level: errorLevel || "error",
			message: `Attribute '${key}' must match one of ${displayMatches(matches, 8)}. Got '${value}' instead.`
		});
		if (matches instanceof RegExp && !matches.test(value)) errors.push({
			id: "attribute-value-invalid",
			level: errorLevel || "error",
			message: `Attribute '${key}' must match ${matches}. Got '${value}' instead.`
		});
		if (typeof attrib.validate === "function") {
			const attribErrors = attrib.validate(value, config, key);
			if (Array.isArray(attribErrors)) errors.push(...attribErrors);
		}
	}
	for (const [key, { required }] of Object.entries(attributes)) if (required && node2.attributes[key] === void 0) errors.push({
		id: "attribute-missing-required",
		level: "error",
		message: `Missing required attribute: '${key}'`
	});
	if (schema.slots) {
		for (const [key, { required }] of Object.entries(schema.slots)) if (required && node2.slots[key] === void 0) errors.push({
			id: "slot-missing-required",
			level: "error",
			message: `Missing required slot: '${key}'`
		});
	}
	for (const { type } of node2.children) if (schema.children && type !== "error" && !schema.children.includes(type)) errors.push({
		id: "child-invalid",
		level: "warning",
		message: `Can't nest '${type}' in '${node2.tag || node2.type}'`
	});
	if (schema.validate) {
		const schemaErrors = schema.validate(node2, config);
		if (isPromise(schemaErrors)) return schemaErrors.then((e) => errors.concat(e));
		errors.push(...schemaErrors);
	}
	return errors;
}
function* walkWithParents(node2, parents = []) {
	yield [node2, parents];
	for (const child of [...Object.values(node2.slots), ...node2.children]) yield* walkWithParents(child, [...parents, node2]);
}
function hasValidLocation(error2) {
	const loc = error2.location;
	return loc != null && typeof loc.start?.line === "number" && typeof loc.end?.line === "number" && (loc.file === void 0 || typeof loc.file === "string");
}
function toValidateError(node2, error2) {
	if (hasValidLocation(error2)) return {
		type: node2.type,
		lines: [error2.location.start.line, error2.location.end.line],
		location: {
			file: node2.location?.file,
			...error2.location
		},
		error: error2
	};
	return {
		type: node2.type,
		lines: node2.lines,
		location: node2.location,
		error: error2
	};
}
function validateTree(content, config) {
	const output = [...walkWithParents(content)].map(([node2, parents]) => {
		const errors = validator(node2, {
			...config,
			validation: {
				...config.validation,
				parents
			}
		});
		if (isPromise(errors)) return errors.then((e) => e.map((error2) => toValidateError(node2, error2)));
		return errors.map((error2) => toValidateError(node2, error2));
	});
	if (output.some(isPromise)) return Promise.all(output).then((o) => o.flat());
	return output.flat();
}
var tokenizer = new Tokenizer();
function mergeConfig(config = {}) {
	return {
		...config,
		tags: {
			...tags_default,
			...config.tags
		},
		nodes: {
			...schema_exports,
			...config.nodes
		},
		functions: {
			...functions_default,
			...config.functions
		}
	};
}
function parse3(content, args) {
	if (typeof content === "string") content = tokenizer.tokenize(content);
	return parser(content, args);
}
function resolve2(content, config) {
	if (Array.isArray(content)) return content.flatMap((child) => child.resolve(config));
	return content.resolve(config);
}
function transform2(nodes, options) {
	const config = mergeConfig(options);
	const content = resolve2(nodes, config);
	if (Array.isArray(content)) return content.flatMap((child) => child.transform(config));
	return content.transform(config);
}
function validate(content, options) {
	return validateTree(content, mergeConfig(options));
}
function createElement(name, attributes = {}, ...children) {
	return {
		name,
		attributes,
		children
	};
}
var Markdoc = class {
	constructor(config) {
		this.parse = parse3;
		this.resolve = (content) => resolve2(content, this.config);
		this.transform = (content) => transform2(content, this.config);
		this.validate = (content) => validate(content, this.config);
		this.config = config;
	}
	static {
		this.nodes = schema_exports;
	}
	static {
		this.tags = tags_default;
	}
	static {
		this.functions = functions_default;
	}
	static {
		this.globalAttributes = globalAttributes;
	}
	static {
		this.renderers = renderers_default;
	}
	static {
		this.transforms = transforms_default;
	}
	static {
		this.Ast = ast_default;
	}
	static {
		this.Tag = Tag;
	}
	static {
		this.Tokenizer = Tokenizer;
	}
	static {
		this.parseTags = parseTags;
	}
	static {
		this.transformer = transformer_default;
	}
	static {
		this.validator = validator;
	}
	static {
		this.parse = parse3;
	}
	static {
		this.transform = transform2;
	}
	static {
		this.validate = validate;
	}
	static {
		this.createElement = createElement;
	}
	static {
		this.truthy = truthy;
	}
	static {
		this.format = format;
	}
};
//#endregion
//#region app/routes/blog.post.tsx
var blog_post_exports = /* @__PURE__ */ __exportAll({
	default: () => blog_post_default,
	loader: () => loader$2,
	meta: () => meta$1
});
var blogSources = /* @__PURE__ */ Object.assign({
	"../blog/ar/otp-email-not-arriving-fixes.md": () => import("./otp-email-not-arriving-fixes-DZ84ueSL.js").then((m) => m["default"]),
	"../blog/ar/temporary-email-best-practices.md": () => import("./temporary-email-best-practices-B8N0z9ji.js").then((m) => m["default"]),
	"../blog/ar/temporary-email-vs-email-alias.md": () => import("./temporary-email-vs-email-alias-Bqe8lfjb.js").then((m) => m["default"]),
	"../blog/de/otp-email-not-arriving-fixes.md": () => import("./otp-email-not-arriving-fixes-BCqTpRdw.js").then((m) => m["default"]),
	"../blog/de/temporary-email-best-practices.md": () => import("./temporary-email-best-practices-BOzplXBb.js").then((m) => m["default"]),
	"../blog/de/temporary-email-vs-email-alias.md": () => import("./temporary-email-vs-email-alias-DoSNrmdm.js").then((m) => m["default"]),
	"../blog/en/otp-email-not-arriving-fixes.md": () => import("./otp-email-not-arriving-fixes-BlwONaar.js").then((m) => m["default"]),
	"../blog/en/temporary-email-best-practices.md": () => import("./temporary-email-best-practices-BQEs6c4y.js").then((m) => m["default"]),
	"../blog/en/temporary-email-vs-email-alias.md": () => import("./temporary-email-vs-email-alias-rgUBAoBr.js").then((m) => m["default"]),
	"../blog/es/otp-email-not-arriving-fixes.md": () => import("./otp-email-not-arriving-fixes-DLcrH4Au.js").then((m) => m["default"]),
	"../blog/es/temporary-email-best-practices.md": () => import("./temporary-email-best-practices-nPI-gb0m.js").then((m) => m["default"]),
	"../blog/es/temporary-email-vs-email-alias.md": () => import("./temporary-email-vs-email-alias-CyQLubwP.js").then((m) => m["default"]),
	"../blog/fr/otp-email-not-arriving-fixes.md": () => import("./otp-email-not-arriving-fixes-ByaZkRxp.js").then((m) => m["default"]),
	"../blog/fr/temporary-email-best-practices.md": () => import("./temporary-email-best-practices-CFk40lcL.js").then((m) => m["default"]),
	"../blog/fr/temporary-email-vs-email-alias.md": () => import("./temporary-email-vs-email-alias-CNWmBZLD.js").then((m) => m["default"]),
	"../blog/ja/otp-email-not-arriving-fixes.md": () => import("./otp-email-not-arriving-fixes-BE4o6e0N.js").then((m) => m["default"]),
	"../blog/ja/temporary-email-best-practices.md": () => import("./temporary-email-best-practices-Dr92R322.js").then((m) => m["default"]),
	"../blog/ja/temporary-email-vs-email-alias.md": () => import("./temporary-email-vs-email-alias-D7YeZ3m1.js").then((m) => m["default"]),
	"../blog/ko/otp-email-not-arriving-fixes.md": () => import("./otp-email-not-arriving-fixes-CfNHjTCK.js").then((m) => m["default"]),
	"../blog/ko/temporary-email-best-practices.md": () => import("./temporary-email-best-practices-B7KFaHYJ.js").then((m) => m["default"]),
	"../blog/ko/temporary-email-vs-email-alias.md": () => import("./temporary-email-vs-email-alias-DFiwjaAG.js").then((m) => m["default"]),
	"../blog/pt/otp-email-not-arriving-fixes.md": () => import("./otp-email-not-arriving-fixes-Bauhz59z.js").then((m) => m["default"]),
	"../blog/pt/temporary-email-best-practices.md": () => import("./temporary-email-best-practices-DAviw2wA.js").then((m) => m["default"]),
	"../blog/pt/temporary-email-vs-email-alias.md": () => import("./temporary-email-vs-email-alias-CfuhPpzt.js").then((m) => m["default"]),
	"../blog/ru/otp-email-not-arriving-fixes.md": () => import("./otp-email-not-arriving-fixes-BZEYkRNI.js").then((m) => m["default"]),
	"../blog/ru/temporary-email-best-practices.md": () => import("./temporary-email-best-practices-CTlzpbx7.js").then((m) => m["default"]),
	"../blog/ru/temporary-email-vs-email-alias.md": () => import("./temporary-email-vs-email-alias-DuvbN_75.js").then((m) => m["default"]),
	"../blog/zh/otp-email-not-arriving-fixes.md": () => import("./otp-email-not-arriving-fixes-IswJVcJ3.js").then((m) => m["default"]),
	"../blog/zh/temporary-email-best-practices.md": () => import("./temporary-email-best-practices-CeJJiTS2.js").then((m) => m["default"]),
	"../blog/zh/temporary-email-vs-email-alias.md": () => import("./temporary-email-vs-email-alias-CqEw412w.js").then((m) => m["default"])
});
function getLocaleFromParams(lang) {
	const { locale } = resolveLocaleParam(lang);
	return locale;
}
function meta$1({ params, matches }) {
	const locale = getLocaleFromParams(params.lang);
	const post = getBlogPostMeta(locale, params.slug ?? "");
	if (!post) return mergeRouteMeta(matches, [{ title: getBlogNotFoundMetaTitle(locale) }, {
		name: "robots",
		content: "noindex, nofollow"
	}]);
	return mergeRouteMeta(matches, [
		{ title: getBlogPostMetaTitle(locale, post.title) },
		{
			name: "description",
			content: post.description
		},
		{
			name: "robots",
			content: isBlogLocaleIndexable(locale) ? "index, follow" : "noindex, follow"
		}
	]);
}
async function loader$2({ params, request }) {
	const { locale, shouldRedirectToDefault, isInvalid } = resolveLocaleParam(params.lang);
	if (isInvalid) throw new Response("Not Found", { status: 404 });
	if (shouldRedirectToDefault) {
		const url = new URL(request.url);
		throw redirect(`${stripDefaultLocalePrefix(url.pathname)}${url.search}`, 301);
	}
	const slug = params.slug ?? "";
	const post = getBlogPostMeta(locale, slug);
	if (!post) throw new Response("Not Found", { status: 404 });
	const preferredPath = `../blog/${toBlogLocale(locale)}/${slug}.md`;
	const fallbackPath = `../blog/en/${slug}.md`;
	const sourceLoader = blogSources[preferredPath] ?? blogSources[fallbackPath];
	const source = sourceLoader ? await sourceLoader().catch(() => null) : null;
	if (!source) throw new Response("Not Found", { status: 404 });
	const ast = Markdoc.parse(source);
	const content = Markdoc.transform(ast);
	return {
		locale,
		post,
		html: Markdoc.renderers.html(content),
		related: listBlogPosts(locale).filter((item) => item.slug !== slug).slice(0, 3)
	};
}
var blog_post_default = withComponentProps(function BlogPostPage({ loaderData }) {
	const locale = loaderData.locale || "en";
	const uiCopy = getBlogUiCopy(locale);
	const postPath = `/blog/${loaderData.post.slug}`;
	const articleUrl = `${BASE_URL}${toLocalePath(postPath, locale)}`;
	const articleJsonLd = {
		"@context": "https://schema.org",
		"@type": "BlogPosting",
		headline: loaderData.post.title,
		description: loaderData.post.description,
		datePublished: loaderData.post.publishedAt,
		dateModified: loaderData.post.updatedAt ?? loaderData.post.publishedAt,
		inLanguage: toLanguageTag(locale),
		mainEntityOfPage: {
			"@type": "WebPage",
			"@id": articleUrl
		},
		author: {
			"@type": "Organization",
			name: "smail.pw"
		},
		publisher: {
			"@type": "Organization",
			name: "smail.pw",
			logo: {
				"@type": "ImageObject",
				url: `${BASE_URL}/favicon.ico`
			}
		},
		url: articleUrl
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 py-3 sm:py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
			type: "application/ld+json",
			dangerouslySetInnerHTML: { __html: JSON.stringify(articleJsonLd) }
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid w-full gap-4 lg:grid-cols-[1fr,280px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "markdown-shell",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-5 flex flex-wrap items-center gap-2 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: toLocalePath("/blog", locale),
						prefetch: "viewport",
						className: "theme-badge px-3 py-1",
						children: uiCopy.backToBlog
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-theme-faint",
						children: [
							formatBlogPublishedDate(loaderData.post.publishedAt, locale),
							" ",
							"· ",
							loaderData.post.readingMinutes,
							" min"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
					className: "prose prose-sm sm:prose-base max-w-none",
					dangerouslySetInnerHTML: { __html: loaderData.html }
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "glass-panel h-fit p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-theme-faint text-[11px] font-semibold uppercase tracking-[0.16em]",
						children: uiCopy.relatedPosts
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 space-y-2.5",
						children: loaderData.related.map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: toLocalePath(`/blog/${post.slug}`, locale),
							prefetch: "viewport",
							className: "theme-card block p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-theme-primary line-clamp-2 text-sm font-semibold",
								children: post.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-theme-faint mt-1 text-[11px]",
								children: formatBlogPublishedDate(post.publishedAt, locale)
							})]
						}, post.slug))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 border-t border-theme-soft pt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: toLocalePath(postPath, locale),
							className: "text-theme-faint text-[11px]",
							children: uiCopy.currentArticle
						})
					})
				]
			})]
		})]
	});
});
//#endregion
//#region app/routes/md.tsx
var md_exports = /* @__PURE__ */ __exportAll({
	default: () => md_default,
	loader: () => loader$1,
	meta: () => meta
});
var KNOWN_MD_PAGES = [
	"about",
	"faq",
	"privacy",
	"terms",
	"temporary-email-24-hours",
	"temporary-email-no-registration",
	"disposable-email-for-verification",
	"temporary-email-for-registration",
	"online-temporary-email",
	"domestic-temporary-email",
	"can-temporary-email-send",
	"smail-vs-smailpro"
];
var INFO_MD_PAGES = [
	"about",
	"faq",
	"privacy",
	"terms"
];
var ARTICLE_MD_PAGES = [
	"temporary-email-24-hours",
	"temporary-email-no-registration",
	"disposable-email-for-verification",
	"temporary-email-for-registration",
	"online-temporary-email",
	"domestic-temporary-email",
	"can-temporary-email-send",
	"smail-vs-smailpro"
];
var markdownSources = /* @__PURE__ */ Object.assign({
	"../md/about.md": () => import("./about-B_gOfCyH.js").then((m) => m["default"]),
	"../md/ar/about.md": () => import("./about-CQQH9Jo8.js").then((m) => m["default"]),
	"../md/ar/can-temporary-email-send.md": () => import("./can-temporary-email-send-CdH-osg1.js").then((m) => m["default"]),
	"../md/ar/disposable-email-for-verification.md": () => import("./disposable-email-for-verification-BanC6GTT.js").then((m) => m["default"]),
	"../md/ar/domestic-temporary-email.md": () => import("./domestic-temporary-email-DRBOKjOq.js").then((m) => m["default"]),
	"../md/ar/faq.md": () => import("./faq-SjwQQ6OY.js").then((m) => m["default"]),
	"../md/ar/online-temporary-email.md": () => import("./online-temporary-email-DgO_KF-J.js").then((m) => m["default"]),
	"../md/ar/privacy.md": () => import("./privacy-CoIt104g.js").then((m) => m["default"]),
	"../md/ar/smail-vs-smailpro.md": () => import("./smail-vs-smailpro-B5w-EnYa.js").then((m) => m["default"]),
	"../md/ar/temporary-email-24-hours.md": () => import("./temporary-email-24-hours-D0hzbkt-.js").then((m) => m["default"]),
	"../md/ar/temporary-email-for-registration.md": () => import("./temporary-email-for-registration-Blzs1CsQ.js").then((m) => m["default"]),
	"../md/ar/temporary-email-no-registration.md": () => import("./temporary-email-no-registration-jXfvyM-U.js").then((m) => m["default"]),
	"../md/ar/terms.md": () => import("./terms-BJbFadqS.js").then((m) => m["default"]),
	"../md/de/about.md": () => import("./about-DAB8fzsr.js").then((m) => m["default"]),
	"../md/de/can-temporary-email-send.md": () => import("./can-temporary-email-send-B7eO2bel.js").then((m) => m["default"]),
	"../md/de/disposable-email-for-verification.md": () => import("./disposable-email-for-verification-c01X17ob.js").then((m) => m["default"]),
	"../md/de/domestic-temporary-email.md": () => import("./domestic-temporary-email-C9z6AZH4.js").then((m) => m["default"]),
	"../md/de/faq.md": () => import("./faq-1yOgwqtn.js").then((m) => m["default"]),
	"../md/de/online-temporary-email.md": () => import("./online-temporary-email-C6ghvG_r.js").then((m) => m["default"]),
	"../md/de/privacy.md": () => import("./privacy-BINRhC78.js").then((m) => m["default"]),
	"../md/de/smail-vs-smailpro.md": () => import("./smail-vs-smailpro-CYF-b_VX.js").then((m) => m["default"]),
	"../md/de/temporary-email-24-hours.md": () => import("./temporary-email-24-hours-3ZJF9We0.js").then((m) => m["default"]),
	"../md/de/temporary-email-for-registration.md": () => import("./temporary-email-for-registration-DpDrs5PM.js").then((m) => m["default"]),
	"../md/de/temporary-email-no-registration.md": () => import("./temporary-email-no-registration-BVH9gWsx.js").then((m) => m["default"]),
	"../md/de/terms.md": () => import("./terms-8T1s4SMB.js").then((m) => m["default"]),
	"../md/en/about.md": () => import("./about-xzJPRqym.js").then((m) => m["default"]),
	"../md/en/can-temporary-email-send.md": () => import("./can-temporary-email-send-3vRaU_Ra.js").then((m) => m["default"]),
	"../md/en/disposable-email-for-verification.md": () => import("./disposable-email-for-verification-DcbAwrEA.js").then((m) => m["default"]),
	"../md/en/domestic-temporary-email.md": () => import("./domestic-temporary-email-Bmqod69X.js").then((m) => m["default"]),
	"../md/en/faq.md": () => import("./faq-B8z5X5kh.js").then((m) => m["default"]),
	"../md/en/online-temporary-email.md": () => import("./online-temporary-email-Cvp6nQpV.js").then((m) => m["default"]),
	"../md/en/privacy.md": () => import("./privacy-BxksIzZ3.js").then((m) => m["default"]),
	"../md/en/smail-vs-smailpro.md": () => import("./smail-vs-smailpro-8yXYTYe0.js").then((m) => m["default"]),
	"../md/en/temporary-email-24-hours.md": () => import("./temporary-email-24-hours-CtXtJjGU.js").then((m) => m["default"]),
	"../md/en/temporary-email-for-registration.md": () => import("./temporary-email-for-registration-BDvpk67I.js").then((m) => m["default"]),
	"../md/en/temporary-email-no-registration.md": () => import("./temporary-email-no-registration-hyuAtovN.js").then((m) => m["default"]),
	"../md/en/terms.md": () => import("./terms-bSFJcpE3.js").then((m) => m["default"]),
	"../md/es/about.md": () => import("./about-3ciAJGvw.js").then((m) => m["default"]),
	"../md/es/can-temporary-email-send.md": () => import("./can-temporary-email-send-CePrkL0X.js").then((m) => m["default"]),
	"../md/es/disposable-email-for-verification.md": () => import("./disposable-email-for-verification-CyNTgvuz.js").then((m) => m["default"]),
	"../md/es/domestic-temporary-email.md": () => import("./domestic-temporary-email-Dmi-8Sep.js").then((m) => m["default"]),
	"../md/es/faq.md": () => import("./faq-BoxN6MyO.js").then((m) => m["default"]),
	"../md/es/online-temporary-email.md": () => import("./online-temporary-email-Cz8mR5fW.js").then((m) => m["default"]),
	"../md/es/privacy.md": () => import("./privacy-CuilJkI7.js").then((m) => m["default"]),
	"../md/es/smail-vs-smailpro.md": () => import("./smail-vs-smailpro-CRaGG47j.js").then((m) => m["default"]),
	"../md/es/temporary-email-24-hours.md": () => import("./temporary-email-24-hours-BLo5wOg3.js").then((m) => m["default"]),
	"../md/es/temporary-email-for-registration.md": () => import("./temporary-email-for-registration-CkjuSMgt.js").then((m) => m["default"]),
	"../md/es/temporary-email-no-registration.md": () => import("./temporary-email-no-registration-D0aw9ZY4.js").then((m) => m["default"]),
	"../md/es/terms.md": () => import("./terms-BwbzMgkz.js").then((m) => m["default"]),
	"../md/faq.md": () => import("./faq-B1JLvy3L.js").then((m) => m["default"]),
	"../md/fr/about.md": () => import("./about-nHoQsuxt.js").then((m) => m["default"]),
	"../md/fr/can-temporary-email-send.md": () => import("./can-temporary-email-send-DnLsbcIx.js").then((m) => m["default"]),
	"../md/fr/disposable-email-for-verification.md": () => import("./disposable-email-for-verification-B5LaoXEF.js").then((m) => m["default"]),
	"../md/fr/domestic-temporary-email.md": () => import("./domestic-temporary-email-oUfO3QNO.js").then((m) => m["default"]),
	"../md/fr/faq.md": () => import("./faq-DiyECSgS.js").then((m) => m["default"]),
	"../md/fr/online-temporary-email.md": () => import("./online-temporary-email-B77fuqfF.js").then((m) => m["default"]),
	"../md/fr/privacy.md": () => import("./privacy-DPcN9v6C.js").then((m) => m["default"]),
	"../md/fr/smail-vs-smailpro.md": () => import("./smail-vs-smailpro-DmqemeAv.js").then((m) => m["default"]),
	"../md/fr/temporary-email-24-hours.md": () => import("./temporary-email-24-hours-B6PvO-u7.js").then((m) => m["default"]),
	"../md/fr/temporary-email-for-registration.md": () => import("./temporary-email-for-registration-BdOVAsic.js").then((m) => m["default"]),
	"../md/fr/temporary-email-no-registration.md": () => import("./temporary-email-no-registration-DBmIqr6x.js").then((m) => m["default"]),
	"../md/fr/terms.md": () => import("./terms-DtEW63IE.js").then((m) => m["default"]),
	"../md/ja/about.md": () => import("./about-Bd-zBPW5.js").then((m) => m["default"]),
	"../md/ja/can-temporary-email-send.md": () => import("./can-temporary-email-send-UYclnHXJ.js").then((m) => m["default"]),
	"../md/ja/disposable-email-for-verification.md": () => import("./disposable-email-for-verification-Jrn4HAGL.js").then((m) => m["default"]),
	"../md/ja/domestic-temporary-email.md": () => import("./domestic-temporary-email-CsWjFAnM.js").then((m) => m["default"]),
	"../md/ja/faq.md": () => import("./faq-KoWhp1jZ.js").then((m) => m["default"]),
	"../md/ja/online-temporary-email.md": () => import("./online-temporary-email-C6SFOVkz.js").then((m) => m["default"]),
	"../md/ja/privacy.md": () => import("./privacy-7xPcz95b.js").then((m) => m["default"]),
	"../md/ja/smail-vs-smailpro.md": () => import("./smail-vs-smailpro-C3u5TlZ6.js").then((m) => m["default"]),
	"../md/ja/temporary-email-24-hours.md": () => import("./temporary-email-24-hours-xjcfCA-5.js").then((m) => m["default"]),
	"../md/ja/temporary-email-for-registration.md": () => import("./temporary-email-for-registration-DC6y3JtO.js").then((m) => m["default"]),
	"../md/ja/temporary-email-no-registration.md": () => import("./temporary-email-no-registration-D1zfhKcV.js").then((m) => m["default"]),
	"../md/ja/terms.md": () => import("./terms-DDbVKiEJ.js").then((m) => m["default"]),
	"../md/ko/about.md": () => import("./about-DnsmVnhz.js").then((m) => m["default"]),
	"../md/ko/can-temporary-email-send.md": () => import("./can-temporary-email-send-DB64tDWC.js").then((m) => m["default"]),
	"../md/ko/disposable-email-for-verification.md": () => import("./disposable-email-for-verification-D0NTIuEM.js").then((m) => m["default"]),
	"../md/ko/domestic-temporary-email.md": () => import("./domestic-temporary-email-k_jX_TfD.js").then((m) => m["default"]),
	"../md/ko/faq.md": () => import("./faq-DMqQ42-G.js").then((m) => m["default"]),
	"../md/ko/online-temporary-email.md": () => import("./online-temporary-email-Bh7RPfcK.js").then((m) => m["default"]),
	"../md/ko/privacy.md": () => import("./privacy-DstBKbno.js").then((m) => m["default"]),
	"../md/ko/smail-vs-smailpro.md": () => import("./smail-vs-smailpro-C4Syj_6o.js").then((m) => m["default"]),
	"../md/ko/temporary-email-24-hours.md": () => import("./temporary-email-24-hours-CTn5K8tX.js").then((m) => m["default"]),
	"../md/ko/temporary-email-for-registration.md": () => import("./temporary-email-for-registration-DsOPsL6y.js").then((m) => m["default"]),
	"../md/ko/temporary-email-no-registration.md": () => import("./temporary-email-no-registration-Bdtr7inn.js").then((m) => m["default"]),
	"../md/ko/terms.md": () => import("./terms-B7EykpAt.js").then((m) => m["default"]),
	"../md/privacy.md": () => import("./privacy-DOHLZ1dL.js").then((m) => m["default"]),
	"../md/pt/about.md": () => import("./about-BznBh_pZ.js").then((m) => m["default"]),
	"../md/pt/can-temporary-email-send.md": () => import("./can-temporary-email-send-DK3N72ZB.js").then((m) => m["default"]),
	"../md/pt/disposable-email-for-verification.md": () => import("./disposable-email-for-verification-HswZmuJA.js").then((m) => m["default"]),
	"../md/pt/domestic-temporary-email.md": () => import("./domestic-temporary-email-CSV4MiLD.js").then((m) => m["default"]),
	"../md/pt/faq.md": () => import("./faq-DrXOq9cI.js").then((m) => m["default"]),
	"../md/pt/online-temporary-email.md": () => import("./online-temporary-email-CG6_xGK9.js").then((m) => m["default"]),
	"../md/pt/privacy.md": () => import("./privacy-B0Y-gEsT.js").then((m) => m["default"]),
	"../md/pt/smail-vs-smailpro.md": () => import("./smail-vs-smailpro-CGHxGGH_.js").then((m) => m["default"]),
	"../md/pt/temporary-email-24-hours.md": () => import("./temporary-email-24-hours-ra8togAf.js").then((m) => m["default"]),
	"../md/pt/temporary-email-for-registration.md": () => import("./temporary-email-for-registration-sztBV4ea.js").then((m) => m["default"]),
	"../md/pt/temporary-email-no-registration.md": () => import("./temporary-email-no-registration-C0_OUPCE.js").then((m) => m["default"]),
	"../md/pt/terms.md": () => import("./terms-BCTdnIZv.js").then((m) => m["default"]),
	"../md/ru/about.md": () => import("./about-KRHVKFqo.js").then((m) => m["default"]),
	"../md/ru/can-temporary-email-send.md": () => import("./can-temporary-email-send-CDzHvkY-.js").then((m) => m["default"]),
	"../md/ru/disposable-email-for-verification.md": () => import("./disposable-email-for-verification-31ZFabf0.js").then((m) => m["default"]),
	"../md/ru/domestic-temporary-email.md": () => import("./domestic-temporary-email-QbIzIaX3.js").then((m) => m["default"]),
	"../md/ru/faq.md": () => import("./faq-BYihebsB.js").then((m) => m["default"]),
	"../md/ru/online-temporary-email.md": () => import("./online-temporary-email-Cnkm9b_R.js").then((m) => m["default"]),
	"../md/ru/privacy.md": () => import("./privacy-C1-zsTX7.js").then((m) => m["default"]),
	"../md/ru/smail-vs-smailpro.md": () => import("./smail-vs-smailpro-CtwTVnk6.js").then((m) => m["default"]),
	"../md/ru/temporary-email-24-hours.md": () => import("./temporary-email-24-hours-DSlAYy35.js").then((m) => m["default"]),
	"../md/ru/temporary-email-for-registration.md": () => import("./temporary-email-for-registration-CuUyP8LK.js").then((m) => m["default"]),
	"../md/ru/temporary-email-no-registration.md": () => import("./temporary-email-no-registration-CRHiG1oO.js").then((m) => m["default"]),
	"../md/ru/terms.md": () => import("./terms-CFpK9T91.js").then((m) => m["default"]),
	"../md/terms.md": () => import("./terms-DbcSiQ9W.js").then((m) => m["default"]),
	"../md/zh/about.md": () => import("./about-XE9YHiDr.js").then((m) => m["default"]),
	"../md/zh/can-temporary-email-send.md": () => import("./can-temporary-email-send-etD4g-hK.js").then((m) => m["default"]),
	"../md/zh/disposable-email-for-verification.md": () => import("./disposable-email-for-verification-IcmocV_k.js").then((m) => m["default"]),
	"../md/zh/domestic-temporary-email.md": () => import("./domestic-temporary-email-BE8mvUHX.js").then((m) => m["default"]),
	"../md/zh/faq.md": () => import("./faq-BkGfwSgK.js").then((m) => m["default"]),
	"../md/zh/online-temporary-email.md": () => import("./online-temporary-email-DXPkPuKK.js").then((m) => m["default"]),
	"../md/zh/privacy.md": () => import("./privacy-DHxeCtjm.js").then((m) => m["default"]),
	"../md/zh/smail-vs-smailpro.md": () => import("./smail-vs-smailpro-qU2wcXSl.js").then((m) => m["default"]),
	"../md/zh/temporary-email-24-hours.md": () => import("./temporary-email-24-hours-DLiFmmKM.js").then((m) => m["default"]),
	"../md/zh/temporary-email-for-registration.md": () => import("./temporary-email-for-registration-Dd9t8hp4.js").then((m) => m["default"]),
	"../md/zh/temporary-email-no-registration.md": () => import("./temporary-email-no-registration-CBGvDVPv.js").then((m) => m["default"]),
	"../md/zh/terms.md": () => import("./terms-xaVoLzsV.js").then((m) => m["default"])
});
var FAQ_JSON_LD_COPY = {
	en: [
		{
			question: "What is smail.pw?",
			answer: "smail.pw is a temporary email service for disposable inboxes used in low-risk sign-ups and verifications."
		},
		{
			question: "How long are emails kept?",
			answer: "Emails are retained for up to 24 hours and then automatically removed."
		},
		{
			question: "Do I need to register?",
			answer: "No account, password, or profile setup is required."
		},
		{
			question: "Can I use it for banking or critical accounts?",
			answer: "No. Use a permanent secure mailbox for banking, work, legal, and recovery-critical services."
		},
		{
			question: "Is smail.pw the same as smail pro or smailpro?",
			answer: "No. smail.pw is an independent temporary email service and is not affiliated with other similarly named sites."
		}
	],
	zh: [
		{
			question: "smail.pw 是什么？",
			answer: "smail.pw 是临时邮箱服务，可用于低风险注册和验证码接收。"
		},
		{
			question: "邮件会保留多久？",
			answer: "邮件内容最多保留 24 小时，之后会自动清理。"
		},
		{
			question: "需要注册账号吗？",
			answer: "不需要账号、密码或个人资料即可使用。"
		},
		{
			question: "能用于银行或重要账号吗？",
			answer: "不建议。银行、工作、法律和账号找回等重要场景请使用长期邮箱。"
		},
		{
			question: "smail.pw 和 smail pro / smailpro 是同一个吗？",
			answer: "不是。smail.pw 是独立站点，与其他同名或近似名称服务没有关联。"
		},
		{
			question: "国内临时邮箱收不到验证码怎么办？",
			answer: "常见原因是发件方延迟或平台限制临时邮箱域名。建议先确认地址无误，再重发并刷新收件箱。"
		}
	],
	es: [
		{
			question: "¿Qué es smail.pw?",
			answer: "smail.pw es un servicio de correo temporal para registros y verificación de bajo riesgo."
		},
		{
			question: "¿Cuánto tiempo se guardan los correos?",
			answer: "Los mensajes se conservan hasta 24 horas y luego se eliminan automáticamente."
		},
		{
			question: "¿Necesito registrarme?",
			answer: "No. Puedes usarlo sin cuenta, contraseña ni perfil."
		},
		{
			question: "¿Puedo usarlo para banca o cuentas críticas?",
			answer: "No. Para banca, trabajo y recuperación de cuentas usa un correo permanente."
		},
		{
			question: "¿Puede el correo temporal enviar mensajes?",
			answer: "Normalmente no. En la mayoría de casos es un buzón de recepción para OTP y verificación."
		},
		{
			question: "¿smail.pw es lo mismo que smailpro?",
			answer: "No. smail.pw es un servicio independiente y no está afiliado con marcas similares."
		}
	],
	fr: [
		{
			question: "Qu'est-ce que smail.pw ?",
			answer: "smail.pw est un service d'email temporaire pour inscriptions et vérifications à faible risque."
		},
		{
			question: "Combien de temps les emails sont-ils conservés ?",
			answer: "Les emails sont conservés jusqu'à 24 heures puis supprimés automatiquement."
		},
		{
			question: "Faut-il créer un compte ?",
			answer: "Non. Aucun compte, mot de passe ou profil n'est requis."
		},
		{
			question: "Puis-je l'utiliser pour des comptes sensibles ?",
			answer: "Non. Pour banque, travail et récupération de compte, utilisez une boîte permanente."
		},
		{
			question: "Un email temporaire peut-il envoyer des messages ?",
			answer: "En général non. La plupart des boîtes temporaires sont conçues pour la réception OTP et vérification."
		},
		{
			question: "smail.pw est-il identique à smailpro ?",
			answer: "Non. smail.pw est un service indépendant sans affiliation avec des marques au nom proche."
		}
	],
	de: [
		{
			question: "Was ist smail.pw?",
			answer: "smail.pw ist ein Dienst für temporäre E-Mails bei risikoarmen Registrierungen und Verifizierungen."
		},
		{
			question: "Wie lange werden Nachrichten gespeichert?",
			answer: "Nachrichten bleiben bis zu 24 Stunden erhalten und werden danach automatisch gelöscht."
		},
		{
			question: "Muss ich mich registrieren?",
			answer: "Nein. Kein Konto, Passwort oder Profil ist erforderlich."
		},
		{
			question: "Ist das für Banking oder wichtige Konten geeignet?",
			answer: "Nein. Für Banking, Arbeit und Wiederherstellung nutze eine dauerhafte Mailbox."
		},
		{
			question: "Kann temporäre E-Mail Nachrichten senden?",
			answer: "Meist nicht. In der Regel ist Temp-Mail für Empfang von OTP- und Bestätigungsnachrichten gedacht."
		},
		{
			question: "Ist smail.pw dasselbe wie smailpro?",
			answer: "Nein. smail.pw ist ein unabhängiger Dienst ohne Zugehörigkeit zu ähnlich benannten Marken."
		}
	],
	ja: [
		{
			question: "smail.pw とは？",
			answer: "smail.pw は低リスクな登録や認証向けの一時メールサービスです。"
		},
		{
			question: "メールはどれくらい保存されますか？",
			answer: "メールは最大24時間保持され、その後自動削除されます。"
		},
		{
			question: "登録は必要ですか？",
			answer: "不要です。アカウントやパスワードなしで利用できます。"
		},
		{
			question: "銀行や重要アカウントに使えますか？",
			answer: "いいえ。銀行・業務・アカウント復旧には恒久的なメールを使ってください。"
		},
		{
			question: "一時メールは送信できますか？",
			answer: "通常はできません。多くの一時メールはOTPや確認メールの受信専用です。"
		},
		{
			question: "smail.pw は smailpro と同じですか？",
			answer: "いいえ。smail.pw は独立サービスで、類似名称サービスとの提携はありません。"
		}
	],
	ko: [
		{
			question: "smail.pw는 무엇인가요?",
			answer: "smail.pw는 저위험 가입과 인증을 위한 임시 이메일 서비스입니다."
		},
		{
			question: "메일은 얼마나 보관되나요?",
			answer: "메일은 최대 24시간 보관되며 이후 자동 삭제됩니다."
		},
		{
			question: "회원가입이 필요한가요?",
			answer: "아니요. 계정, 비밀번호, 프로필 없이 사용할 수 있습니다."
		},
		{
			question: "은행이나 중요한 계정에 써도 되나요?",
			answer: "권장하지 않습니다. 은행, 업무, 계정 복구에는 장기 메일함을 사용하세요."
		},
		{
			question: "임시 이메일로 발신할 수 있나요?",
			answer: "보통 불가능합니다. 대부분 OTP와 확인 메일 수신 전용으로 설계됩니다."
		},
		{
			question: "smail.pw는 smailpro와 같은 서비스인가요?",
			answer: "아니요. smail.pw는 독립 서비스이며 유사 명칭 브랜드와 제휴되어 있지 않습니다."
		}
	],
	ru: [
		{
			question: "Что такое smail.pw?",
			answer: "smail.pw — сервис временной почты для низкорисковых регистраций и подтверждений."
		},
		{
			question: "Сколько хранятся письма?",
			answer: "Письма хранятся до 24 часов, затем удаляются автоматически."
		},
		{
			question: "Нужна регистрация?",
			answer: "Нет. Аккаунт, пароль и профиль не требуются."
		},
		{
			question: "Можно использовать для банковских и важных аккаунтов?",
			answer: "Нет. Для банка, работы и восстановления аккаунта используйте постоянную почту."
		},
		{
			question: "Можно ли отправлять письма с временной почты?",
			answer: "Обычно нет. Временные ящики чаще всего работают только для приема OTP и подтверждений."
		},
		{
			question: "smail.pw это то же самое, что smailpro?",
			answer: "Нет. smail.pw — независимый сервис и не связан с похожими брендами."
		}
	],
	pt: [
		{
			question: "O que é o smail.pw?",
			answer: "smail.pw é um serviço de email temporário para cadastro e verificação de baixo risco."
		},
		{
			question: "Por quanto tempo os emails ficam disponíveis?",
			answer: "As mensagens ficam disponíveis por até 24 horas e depois são removidas automaticamente."
		},
		{
			question: "Preciso criar conta?",
			answer: "Não. Não exige conta, senha nem perfil."
		},
		{
			question: "Posso usar para banco ou contas críticas?",
			answer: "Não. Para banco, trabalho e recuperação de conta use um email permanente."
		},
		{
			question: "Email temporário pode enviar mensagens?",
			answer: "Normalmente não. Em geral ele é voltado ao recebimento de OTP e emails de confirmação."
		},
		{
			question: "smail.pw é o mesmo serviço que smailpro?",
			answer: "Não. smail.pw é independente e não possui afiliação com marcas de nome parecido."
		}
	],
	ar: [
		{
			question: "ما هو smail.pw؟",
			answer: "smail.pw خدمة بريد مؤقت لعمليات التسجيل والتحقق منخفضة المخاطر."
		},
		{
			question: "كم مدة الاحتفاظ بالرسائل؟",
			answer: "يتم الاحتفاظ بالرسائل حتى 24 ساعة ثم تُحذف تلقائيًا."
		},
		{
			question: "هل أحتاج إلى تسجيل حساب؟",
			answer: "لا. لا حاجة إلى حساب أو كلمة مرور أو ملف شخصي."
		},
		{
			question: "هل يصلح للحسابات البنكية أو المهمة؟",
			answer: "لا. للحسابات البنكية والعمل واستعادة الحساب استخدم بريدًا دائمًا وآمنًا."
		},
		{
			question: "هل يمكن للبريد المؤقت إرسال الرسائل؟",
			answer: "غالبًا لا. معظم خدمات البريد المؤقت مخصصة لاستقبال OTP ورسائل التحقق فقط."
		},
		{
			question: "هل smail.pw هو نفسه smailpro؟",
			answer: "لا. smail.pw خدمة مستقلة وغير تابعة لخدمات أخرى ذات أسماء مشابهة."
		}
	]
};
var mdMetaCopy = {
	about: {
		en: {
			title: "About smail.pw | Temporary Email & Temp Mail Generator",
			description: "Learn how smail.pw temporary email works, when to use temp mail, and important limits for disposable inbox workflows."
		},
		zh: {
			title: "关于 smail.pw | 临时邮箱生成器",
			description: "了解 smail.pw 临时邮箱生成器的用途、适用场景与一次性邮箱使用边界。"
		},
		es: {
			title: "Acerca de smail.pw | Correo temporal",
			description: "Conoce qué es smail.pw, cuándo usar correo temporal y qué límites tiene un buzón desechable."
		},
		fr: {
			title: "À propos de smail.pw | Email temporaire",
			description: "Découvrez ce qu'est smail.pw, quand utiliser un email temporaire et ses limites importantes."
		},
		de: {
			title: "Über smail.pw | Temporäre E-Mail",
			description: "Erfahre, was smail.pw ist, wann temporäre E-Mails sinnvoll sind und welche Grenzen gelten."
		},
		ja: {
			title: "smail.pw について | 一時メール",
			description: "smail.pw の用途、一時メールが有効な場面、利用上の重要な制約を確認できます。"
		},
		ko: {
			title: "smail.pw 소개 | 임시 이메일",
			description: "smail.pw의 목적, 임시 이메일 사용이 적합한 상황, 이용 시 한계를 확인하세요."
		},
		ru: {
			title: "О smail.pw | Временная почта",
			description: "Узнайте, что такое smail.pw, когда использовать временную почту и какие есть ограничения."
		},
		pt: {
			title: "Sobre o smail.pw | Email temporário",
			description: "Entenda o que é o smail.pw, quando usar email temporário e quais limites você deve considerar."
		},
		ar: {
			title: "حول smail.pw | بريد مؤقت",
			description: "تعرّف على smail.pw ومتى تستخدم البريد المؤقت وما الحدود المهمة التي يجب الانتباه لها."
		}
	},
	faq: {
		en: {
			title: "Temporary Email FAQ (OTP, Temp Mail, Delivery) | smail.pw",
			description: "Temporary email FAQ covering temp mail setup, 24-hour retention, OTP delivery issues, and disposable inbox safety limits on smail.pw."
		},
		zh: {
			title: "临时邮箱常见问题（验证码/收信/注册）| smail.pw",
			description: "临时邮箱与一次性邮箱常见问题：24小时保留、验证码收信异常、临时邮箱注册场景、使用限制与安全建议。"
		},
		es: {
			title: "Preguntas frecuentes | smail.pw",
			description: "Consulta dudas comunes sobre uso del correo temporal, retención, entrega de mensajes y límites del servicio."
		},
		fr: {
			title: "FAQ | smail.pw email temporaire",
			description: "Retrouvez les questions courantes sur l'usage, la rétention, la livraison des emails et les limites du service."
		},
		de: {
			title: "FAQ | smail.pw temporäre E-Mail",
			description: "Häufige Fragen zu Nutzung, Aufbewahrung, Zustellproblemen und Servicegrenzen der temporären E-Mail."
		},
		ja: {
			title: "よくある質問 | smail.pw 一時メール",
			description: "一時メールの使い方、保持期間、受信トラブル、サービス制限に関する主な質問をまとめています。"
		},
		ko: {
			title: "자주 묻는 질문 | smail.pw 임시 이메일",
			description: "임시 이메일 사용법, 보관 기간, 수신 문제, 서비스 제한에 대한 주요 질문을 확인하세요."
		},
		ru: {
			title: "FAQ | smail.pw временная почта",
			description: "Частые вопросы о временной почте: использование, срок хранения, доставка писем и ограничения сервиса."
		},
		pt: {
			title: "Perguntas frequentes | smail.pw",
			description: "Veja dúvidas comuns sobre uso do email temporário, retenção de mensagens, entrega e limites do serviço."
		},
		ar: {
			title: "الأسئلة الشائعة | smail.pw",
			description: "اطّلع على الأسئلة الشائعة حول استخدام البريد المؤقت ومدة الاحتفاظ ومشكلات الاستلام وحدود الخدمة."
		}
	},
	privacy: {
		en: {
			title: "Privacy Policy | smail.pw",
			description: "See what data smail.pw may process, how long temporary data is retained, and how privacy is handled."
		},
		zh: {
			title: "隐私政策 | smail.pw",
			description: "查看 smail.pw 可能处理的数据类型、保留周期与隐私处理方式。"
		},
		es: {
			title: "Política de privacidad | smail.pw",
			description: "Consulta qué datos puede tratar smail.pw, cuánto tiempo se conservan y cómo se protege la privacidad."
		},
		fr: {
			title: "Politique de confidentialité | smail.pw",
			description: "Découvrez quelles données smail.pw peut traiter, leur durée de conservation et la gestion de la confidentialité."
		},
		de: {
			title: "Datenschutzrichtlinie | smail.pw",
			description: "Sieh, welche Daten smail.pw verarbeiten kann, wie lange sie gespeichert werden und wie Datenschutz umgesetzt wird."
		},
		ja: {
			title: "プライバシーポリシー | smail.pw",
			description: "smail.pw が扱う可能性のあるデータ、保持期間、プライバシー保護の方針を確認できます。"
		},
		ko: {
			title: "개인정보 처리방침 | smail.pw",
			description: "smail.pw에서 처리할 수 있는 데이터 유형, 보관 기간, 개인정보 보호 방식에 대해 확인하세요."
		},
		ru: {
			title: "Политика конфиденциальности | smail.pw",
			description: "Узнайте, какие данные может обрабатывать smail.pw, сроки хранения и подход к конфиденциальности."
		},
		pt: {
			title: "Política de privacidade | smail.pw",
			description: "Veja quais dados o smail.pw pode processar, por quanto tempo são mantidos e como a privacidade é tratada."
		},
		ar: {
			title: "سياسة الخصوصية | smail.pw",
			description: "تعرّف على البيانات التي قد يعالجها smail.pw ومدة الاحتفاظ بها وكيفية التعامل مع الخصوصية."
		}
	},
	terms: {
		en: {
			title: "Terms of Use | smail.pw",
			description: "Review the terms for using smail.pw, including acceptable use, disclaimers, and service limitations."
		},
		zh: {
			title: "使用条款 | smail.pw",
			description: "了解 smail.pw 的使用规则、服务边界与免责声明。"
		},
		es: {
			title: "Términos de uso | smail.pw",
			description: "Revisa las reglas de uso de smail.pw, incluyendo usos permitidos, avisos legales y límites del servicio."
		},
		fr: {
			title: "Conditions d'utilisation | smail.pw",
			description: "Consultez les conditions d'usage de smail.pw, y compris l'usage autorisé, les exclusions et limites du service."
		},
		de: {
			title: "Nutzungsbedingungen | smail.pw",
			description: "Prüfe die Nutzungsregeln von smail.pw inklusive zulässiger Nutzung, Haftungsausschlüssen und Servicegrenzen."
		},
		ja: {
			title: "利用規約 | smail.pw",
			description: "smail.pw の利用条件、許容される利用、免責事項、サービス範囲の制限を確認できます。"
		},
		ko: {
			title: "이용약관 | smail.pw",
			description: "smail.pw 이용 규정, 허용 범위, 면책 고지, 서비스 제한 사항을 확인하세요."
		},
		ru: {
			title: "Условия использования | smail.pw",
			description: "Ознакомьтесь с правилами использования smail.pw, допустимым применением, отказом от ответственности и ограничениями."
		},
		pt: {
			title: "Termos de uso | smail.pw",
			description: "Revise os termos do smail.pw, incluindo uso aceitável, avisos legais e limitações do serviço."
		},
		ar: {
			title: "شروط الاستخدام | smail.pw",
			description: "راجع شروط استخدام smail.pw بما يشمل الاستخدام المقبول وإخلاء المسؤولية وحدود الخدمة."
		}
	},
	"temporary-email-24-hours": {
		en: {
			title: "24 Hour Temporary Email (Temp Mail) | smail.pw",
			description: "Create a 24 hour email temp mail inbox for sign-ups and OTP verification codes without exposing your primary mailbox."
		},
		zh: {
			title: "24小时临时邮箱（24小时邮箱）| smail.pw",
			description: "获取 24 小时临时邮箱（一次性邮箱），用于临时邮箱注册、验证码与短期收信，自动过期更省心。"
		},
		es: {
			title: "Correo temporal 24 horas (email desechable) | smail.pw",
			description: "Usa un correo temporal de 24 horas para registros y códigos OTP sin exponer tu email principal."
		},
		fr: {
			title: "Email temporaire 24 heures (boîte jetable) | smail.pw",
			description: "Créez une boîte temporaire 24h pour inscription et codes OTP sans exposer votre email principal."
		},
		de: {
			title: "24-Stunden-Temporäre E-Mail | smail.pw",
			description: "Nutze eine temporäre 24h-Adresse für Registrierung und OTP-Verifizierung ohne deine Hauptadresse offenzulegen."
		},
		ja: {
			title: "24時間一時メール（使い捨てメール）| smail.pw",
			description: "登録やOTP認証に使える24時間の一時受信箱。メインアドレスを公開せず利用できます。"
		},
		ko: {
			title: "24시간 임시 이메일(일회용 메일) | smail.pw",
			description: "가입과 OTP 인증에 쓰는 24시간 임시 메일함으로 기본 주소 노출을 줄이세요."
		},
		ru: {
			title: "Временная почта на 24 часа | smail.pw",
			description: "Используйте временный ящик на 24 часа для регистрации и OTP-кодов, не раскрывая основной адрес."
		},
		pt: {
			title: "Email temporário de 24 horas | smail.pw",
			description: "Crie um inbox temporário de 24h para cadastro e códigos OTP sem expor seu email principal."
		},
		ar: {
			title: "بريد مؤقت لمدة 24 ساعة | smail.pw",
			description: "أنشئ صندوقًا مؤقتًا لمدة 24 ساعة للتسجيل ورموز OTP دون كشف بريدك الأساسي."
		}
	},
	"temporary-email-no-registration": {
		en: {
			title: "Temporary Email No Registration (No Signup Temp Mail) | smail.pw",
			description: "Use no registration temp mail with no password or personal details. Generate a temporary inbox instantly and receive email in seconds."
		},
		zh: {
			title: "免注册临时邮箱（无需注册）| smail.pw",
			description: "免注册临时邮箱，无需账号和密码即可快速生成一次性邮箱，适合临时邮箱注册与验证码收信。"
		},
		es: {
			title: "Correo temporal sin registro (sin cuenta) | smail.pw",
			description: "Recibe emails en segundos sin crear cuenta ni contraseña con un buzón temporal para registro y verificación."
		},
		fr: {
			title: "Email temporaire sans inscription | smail.pw",
			description: "Recevez des emails sans compte ni mot de passe avec une boîte temporaire immédiate pour inscription et vérification."
		},
		de: {
			title: "Temporäre E-Mail ohne Registrierung | smail.pw",
			description: "Empfange E-Mails ohne Konto und Passwort mit einem sofort nutzbaren temporären Postfach für Anmeldung und Verifizierung."
		},
		ja: {
			title: "登録不要の一時メール | smail.pw",
			description: "アカウント作成やパスワード不要で、登録・認証に使える一時メール受信箱をすぐ利用できます。"
		},
		ko: {
			title: "가입 없는 임시 이메일 | smail.pw",
			description: "회원가입과 비밀번호 없이 즉시 사용 가능한 임시 메일함으로 가입/인증 메일을 빠르게 수신하세요."
		},
		ru: {
			title: "Временная почта без регистрации | smail.pw",
			description: "Получайте письма мгновенно без аккаунта и пароля через временный ящик для регистрации и подтверждения."
		},
		pt: {
			title: "Email temporário sem cadastro | smail.pw",
			description: "Receba emails rapidamente sem criar conta ou senha com uma caixa temporária imediata para cadastro e verificação."
		},
		ar: {
			title: "بريد مؤقت بدون تسجيل | smail.pw",
			description: "استقبل الرسائل فورًا بدون إنشاء حساب أو كلمة مرور عبر صندوق بريد مؤقت سريع للتسجيل والتحقق."
		}
	},
	"disposable-email-for-verification": {
		en: {
			title: "Disposable Email for Verification & OTP | smail.pw",
			description: "Receive OTP and verification emails in a disposable email inbox while keeping your personal mailbox private and spam-free."
		},
		zh: {
			title: "验证码一次性邮箱（OTP临时邮箱）| smail.pw",
			description: "使用验证码一次性邮箱接收 OTP 与确认邮件，适合临时邮箱注册场景，减少垃圾邮件并保护真实邮箱隐私。"
		},
		es: {
			title: "Correo desechable para verificación y OTP | smail.pw",
			description: "Recibe OTP y enlaces de confirmación en un buzón desechable sin llenar tu correo personal de spam."
		},
		fr: {
			title: "Email jetable pour vérification et OTP | smail.pw",
			description: "Recevez OTP et liens de confirmation dans une boîte jetable sans encombrer votre adresse personnelle."
		},
		de: {
			title: "Wegwerf-E-Mail für Verifizierung und OTP | smail.pw",
			description: "Empfange OTP-Codes und Bestätigungslinks im Wegwerf-Postfach und halte dein Hauptpostfach sauber."
		},
		ja: {
			title: "認証コード用の使い捨てメール（OTP）| smail.pw",
			description: "OTPや確認リンクを使い捨て受信箱で受け取り、個人メールのノイズと露出を減らせます。"
		},
		ko: {
			title: "인증용 일회용 이메일(OTP) | smail.pw",
			description: "OTP와 확인 링크를 일회용 메일함으로 받아 기본 메일함의 노출과 스팸을 줄이세요."
		},
		ru: {
			title: "Одноразовая почта для верификации и OTP | smail.pw",
			description: "Получайте OTP и письма подтверждения в одноразовом ящике, не засоряя основной почтовый адрес."
		},
		pt: {
			title: "Email descartável para verificação e OTP | smail.pw",
			description: "Receba OTP e links de confirmação em inbox descartável sem expor nem lotar seu email principal."
		},
		ar: {
			title: "بريد مؤقت للتحقق ورموز OTP | smail.pw",
			description: "استقبل رموز OTP وروابط التأكيد في بريد مؤقت دون إزعاج أو كشف بريدك الشخصي الأساسي."
		}
	},
	"temporary-email-for-registration": {
		en: {
			title: "Temporary Email for Registration (Signup Temp Mail) | smail.pw",
			description: "Use temporary email for registration flows, trial sign-ups, and one-off onboarding without exposing your long-term mailbox."
		},
		zh: {
			title: "临时邮箱注册专用（注册临时邮箱）| smail.pw",
			description: "用于临时邮箱注册、试用账号和低风险平台注册，快速收验证码并减少真实邮箱暴露。"
		},
		es: {
			title: "Correo temporal para registro | smail.pw",
			description: "Usa un correo temporal para registros y pruebas sin exponer tu bandeja principal a spam futuro."
		},
		fr: {
			title: "Email temporaire pour inscription | smail.pw",
			description: "Utilisez un email temporaire pour l'inscription et les essais sans exposer votre boîte principale."
		},
		de: {
			title: "Temporäre E-Mail für Registrierung | smail.pw",
			description: "Nutze temporäre E-Mail für Registrierungen und Testaccounts, ohne dein Hauptpostfach preiszugeben."
		},
		ja: {
			title: "登録向け一時メール | smail.pw",
			description: "登録やトライアル開始時に使える一時メール。メインアドレスの露出を抑えられます。"
		},
		ko: {
			title: "가입용 임시 이메일 | smail.pw",
			description: "회원가입과 체험 등록에 쓰는 임시 이메일로 기본 메일함 노출과 스팸 유입을 줄이세요."
		},
		ru: {
			title: "Временная почта для регистрации | smail.pw",
			description: "Используйте временную почту для регистраций и тестовых аккаунтов без риска для основного адреса."
		},
		pt: {
			title: "Email temporário para cadastro | smail.pw",
			description: "Use email temporário em cadastros e testes sem expor sua caixa principal a spam recorrente."
		},
		ar: {
			title: "بريد مؤقت للتسجيل | smail.pw",
			description: "استخدم بريدًا مؤقتًا لعمليات التسجيل والتجربة دون كشف صندوق بريدك الأساسي على المدى الطويل."
		}
	},
	"online-temporary-email": {
		en: {
			title: "Online Temporary Email Inbox (Instant Temp Mail) | smail.pw",
			description: "Get an online temporary email inbox instantly for verification links, OTP messages, and short-term email reception."
		},
		zh: {
			title: "在线临时邮箱（即时收信）| smail.pw",
			description: "在线临时邮箱即时可用，适合验证码、确认链接和短期收信场景，支持快速刷新。"
		},
		es: {
			title: "Correo temporal online inmediato | smail.pw",
			description: "Obtén una bandeja temporal online al instante para OTP, enlaces de verificación y correos de uso corto."
		},
		fr: {
			title: "Email temporaire en ligne immédiat | smail.pw",
			description: "Obtenez une boîte temporaire en ligne pour OTP, liens de vérification et réception courte durée."
		},
		de: {
			title: "Online-Temporäre E-Mail sofort | smail.pw",
			description: "Erhalte sofort ein Online-Temp-Postfach für OTP-Codes, Bestätigungslinks und Kurzzeit-Empfang."
		},
		ja: {
			title: "オンライン一時メール（即時受信）| smail.pw",
			description: "OTPや確認リンクの受信に使えるオンライン一時メールをすぐ利用できます。"
		},
		ko: {
			title: "온라인 임시 이메일 즉시 사용 | smail.pw",
			description: "OTP와 확인 링크 수신에 적합한 온라인 임시 메일함을 즉시 생성해 사용하세요."
		},
		ru: {
			title: "Онлайн временная почта мгновенно | smail.pw",
			description: "Мгновенно получите онлайн-временный ящик для OTP, ссылок подтверждения и коротких сценариев."
		},
		pt: {
			title: "Email temporário online imediato | smail.pw",
			description: "Gere inbox temporário online na hora para OTP, links de confirmação e recebimento de curto prazo."
		},
		ar: {
			title: "بريد مؤقت أونلاين فوري | smail.pw",
			description: "احصل على صندوق بريد مؤقت عبر الإنترنت فورًا لاستقبال OTP وروابط التحقق والرسائل قصيرة المدة."
		}
	},
	"domestic-temporary-email": {
		en: {
			title: "Domestic Temporary Email Guide (Regional Delivery Tips) | smail.pw",
			description: "Read domestic temporary email delivery tips, common verification issues, and retry steps when OTP messages are delayed."
		},
		zh: {
			title: "国内临时邮箱收信指南 | smail.pw",
			description: "国内临时邮箱场景下的验证码接收建议：常见延迟原因、重发步骤和收信排查方法。"
		},
		es: {
			title: "Guía de correo temporal local | smail.pw",
			description: "Consulta recomendaciones de entrega local para correo temporal y cómo resolver retrasos de OTP."
		},
		fr: {
			title: "Guide d'email temporaire local | smail.pw",
			description: "Conseils de délivrabilité locale pour email temporaire et résolution des retards de code OTP."
		},
		de: {
			title: "Leitfaden für lokale temporäre E-Mail | smail.pw",
			description: "Tipps zur lokalen Zustellung bei temporärer E-Mail und zur Fehlerbehebung bei verzögerten OTP-Codes."
		},
		ja: {
			title: "国内向け一時メール受信ガイド | smail.pw",
			description: "地域内サービスで一時メールを使う際の受信遅延対策やOTP再送手順をまとめています。"
		},
		ko: {
			title: "국내 임시 이메일 수신 가이드 | smail.pw",
			description: "국내 서비스에서 임시 메일 사용 시 OTP 지연 원인과 재전송/새로고침 대응법을 확인하세요."
		},
		ru: {
			title: "Локальная временная почта: гайд | smail.pw",
			description: "Советы по локальной доставке временной почты и действия при задержке OTP-сообщений."
		},
		pt: {
			title: "Guia de email temporário local | smail.pw",
			description: "Veja dicas de entrega local para email temporário e etapas para corrigir atrasos de OTP."
		},
		ar: {
			title: "دليل البريد المؤقت المحلي | smail.pw",
			description: "تعرف على نصائح التسليم المحلي للبريد المؤقت وخطوات معالجة تأخر رسائل OTP."
		}
	},
	"can-temporary-email-send": {
		en: {
			title: "Can Temporary Email Send Messages? (Receive-Only Explained) | smail.pw",
			description: "Understand whether temporary email can send messages, why many temp inboxes are receive-only, and when to use a permanent mailbox instead."
		},
		zh: {
			title: "临时邮箱可以发送邮件吗？| smail.pw",
			description: "解释临时邮箱发送能力与限制：为什么多数临时邮箱仅收信，以及何时应切换到长期邮箱。"
		},
		es: {
			title: "¿El correo temporal puede enviar mensajes? | smail.pw",
			description: "Conoce por qué muchos buzones temporales son solo de recepción y cuándo debes usar correo permanente."
		},
		fr: {
			title: "Un email temporaire peut-il envoyer des messages ? | smail.pw",
			description: "Comprenez pourquoi de nombreuses boîtes temporaires sont en réception seule et quand utiliser un email permanent."
		},
		de: {
			title: "Kann temporäre E-Mail Nachrichten senden? | smail.pw",
			description: "Erfahre, warum viele Temp-Mail-Postfächer nur empfangen und wann ein dauerhaftes Postfach nötig ist."
		},
		ja: {
			title: "一時メールは送信できる？ | smail.pw",
			description: "多くの一時メールが受信専用である理由と、恒久メールへ切り替えるべき場面を解説します。"
		},
		ko: {
			title: "임시 이메일로 발신할 수 있나요? | smail.pw",
			description: "임시 메일함이 수신 전용인 이유와, 언제 장기 메일 서비스로 전환해야 하는지 설명합니다."
		},
		ru: {
			title: "Можно ли отправлять письма с временной почты? | smail.pw",
			description: "Разбираем, почему временные ящики часто только для приема и когда нужен постоянный адрес."
		},
		pt: {
			title: "Email temporário pode enviar mensagens? | smail.pw",
			description: "Entenda por que muitas caixas temporárias são só para receber e quando usar um email permanente."
		},
		ar: {
			title: "هل يمكن للبريد المؤقت إرسال رسائل؟ | smail.pw",
			description: "تعرف لماذا تكون معظم صناديق البريد المؤقت للاستقبال فقط ومتى تحتاج إلى بريد دائم للإرسال."
		}
	},
	"smail-vs-smailpro": {
		en: {
			title: "smail.pw vs smailpro / smail pro | Brand Clarification",
			description: "Official clarification: smail.pw is an independent temporary email service and is not affiliated with smailpro or similarly named products."
		},
		zh: {
			title: "smail.pw 与 smailpro / smail pro 关系说明",
			description: "官方说明：smail.pw 是独立临时邮箱服务，与 smailpro 或同名近似产品无隶属关系。"
		},
		es: {
			title: "smail.pw vs smailpro | Aclaración de marca",
			description: "Aclaración oficial: smail.pw es un servicio independiente y no está afiliado con smailpro."
		},
		fr: {
			title: "smail.pw vs smailpro | Clarification de marque",
			description: "Clarification officielle: smail.pw est un service indépendant non affilié à smailpro."
		},
		de: {
			title: "smail.pw vs smailpro | Markenhinweis",
			description: "Offizieller Hinweis: smail.pw ist ein unabhängiger Dienst ohne Verbindung zu smailpro."
		},
		ja: {
			title: "smail.pw と smailpro の違い | 公式説明",
			description: "公式説明: smail.pw は独立した一時メールサービスで、smailpro との提携はありません。"
		},
		ko: {
			title: "smail.pw vs smailpro | 브랜드 안내",
			description: "공식 안내: smail.pw는 독립 서비스이며 smailpro와 제휴 또는 동일 서비스가 아닙니다."
		},
		ru: {
			title: "smail.pw и smailpro | Разъяснение бренда",
			description: "Официально: smail.pw — независимый сервис и не связан со smailpro."
		},
		pt: {
			title: "smail.pw vs smailpro | Esclarecimento de marca",
			description: "Esclarecimento oficial: smail.pw é um serviço independente e não afiliado ao smailpro."
		},
		ar: {
			title: "smail.pw مقابل smailpro | توضيح العلامة",
			description: "توضيح رسمي: smail.pw خدمة مستقلة وليست تابعة لـ smailpro أو لخدمات مشابهة الاسم."
		}
	}
};
var HOME_BREADCRUMB_LABEL = {
	en: "Home",
	zh: "首页",
	es: "Inicio",
	fr: "Accueil",
	de: "Startseite",
	ja: "ホーム",
	ko: "홈",
	ru: "Главная",
	pt: "Início",
	ar: "الرئيسية"
};
var INTERNAL_CTA_COPY = {
	en: {
		title: "Start your temporary inbox now",
		description: "Create a disposable address in one tap, then open the most common registration and OTP guides below.",
		links: [
			{
				label: "Generate temporary email",
				path: "/"
			},
			{
				label: "Temporary email for registration",
				path: "/temporary-email-for-registration"
			},
			{
				label: "Disposable email for verification",
				path: "/disposable-email-for-verification"
			}
		]
	},
	zh: {
		title: "立即开始使用临时邮箱",
		description: "一键生成一次性邮箱，再查看常用的临时邮箱注册与验证码指南。",
		links: [
			{
				label: "生成临时邮箱",
				path: "/"
			},
			{
				label: "临时邮箱注册指南",
				path: "/temporary-email-for-registration"
			},
			{
				label: "验证码一次性邮箱",
				path: "/disposable-email-for-verification"
			}
		]
	},
	es: {
		title: "Empieza ahora con correo temporal",
		description: "Genera una dirección desechable en un clic y revisa las guías clave para registro y OTP.",
		links: [
			{
				label: "Generar correo temporal",
				path: "/"
			},
			{
				label: "Correo temporal para registro",
				path: "/temporary-email-for-registration"
			},
			{
				label: "Correo para verificación OTP",
				path: "/disposable-email-for-verification"
			}
		]
	},
	fr: {
		title: "Démarrez votre boîte temporaire",
		description: "Créez une adresse jetable en un clic puis consultez les guides essentiels inscription et OTP.",
		links: [
			{
				label: "Générer un email temporaire",
				path: "/"
			},
			{
				label: "Email temporaire pour inscription",
				path: "/temporary-email-for-registration"
			},
			{
				label: "Email pour vérification OTP",
				path: "/disposable-email-for-verification"
			}
		]
	},
	de: {
		title: "Temporäres Postfach sofort starten",
		description: "Erstelle eine Wegwerfadresse mit einem Klick und nutze die wichtigsten Guides zu Anmeldung und OTP.",
		links: [
			{
				label: "Temporäre E-Mail erzeugen",
				path: "/"
			},
			{
				label: "Temporäre E-Mail für Registrierung",
				path: "/temporary-email-for-registration"
			},
			{
				label: "Wegwerf-E-Mail für OTP",
				path: "/disposable-email-for-verification"
			}
		]
	},
	ja: {
		title: "今すぐ一時メールを開始",
		description: "ワンタップで使い捨てアドレスを作成し、登録とOTPの主要ガイドを確認できます。",
		links: [
			{
				label: "一時メールを生成",
				path: "/"
			},
			{
				label: "登録向け一時メール",
				path: "/temporary-email-for-registration"
			},
			{
				label: "OTP認証向け使い捨てメール",
				path: "/disposable-email-for-verification"
			}
		]
	},
	ko: {
		title: "지금 임시 이메일 시작하기",
		description: "한 번에 일회용 주소를 만들고 가입/OTP 핵심 가이드를 바로 확인하세요.",
		links: [
			{
				label: "임시 이메일 생성",
				path: "/"
			},
			{
				label: "가입용 임시 이메일",
				path: "/temporary-email-for-registration"
			},
			{
				label: "OTP 인증용 일회용 이메일",
				path: "/disposable-email-for-verification"
			}
		]
	},
	ru: {
		title: "Запустите временный ящик сейчас",
		description: "Создайте одноразовый адрес в один клик и изучите ключевые гайды по регистрации и OTP.",
		links: [
			{
				label: "Создать временную почту",
				path: "/"
			},
			{
				label: "Временная почта для регистрации",
				path: "/temporary-email-for-registration"
			},
			{
				label: "Одноразовая почта для OTP",
				path: "/disposable-email-for-verification"
			}
		]
	},
	pt: {
		title: "Comece sua caixa temporária agora",
		description: "Gere um endereço descartável em um clique e acesse os guias mais úteis para cadastro e OTP.",
		links: [
			{
				label: "Gerar email temporário",
				path: "/"
			},
			{
				label: "Email temporário para cadastro",
				path: "/temporary-email-for-registration"
			},
			{
				label: "Email para verificação OTP",
				path: "/disposable-email-for-verification"
			}
		]
	},
	ar: {
		title: "ابدأ صندوق البريد المؤقت الآن",
		description: "أنشئ عنوانًا مؤقتًا بنقرة واحدة ثم راجع أهم أدلة التسجيل والتحقق عبر OTP.",
		links: [
			{
				label: "إنشاء بريد مؤقت",
				path: "/"
			},
			{
				label: "بريد مؤقت للتسجيل",
				path: "/temporary-email-for-registration"
			},
			{
				label: "بريد مؤقت لرموز OTP",
				path: "/disposable-email-for-verification"
			}
		]
	}
};
function isKnownMarkdownSlug(value) {
	return KNOWN_MD_PAGES.includes(value);
}
function isInfoMarkdownSlug(value) {
	return INFO_MD_PAGES.includes(value);
}
function isArticleMarkdownSlug(value) {
	return ARTICLE_MD_PAGES.includes(value);
}
function getMarkdownSeoCopy(locale, slug) {
	return mdMetaCopy[slug][locale] ?? mdMetaCopy[slug]["en"];
}
function getMarkdownSlugFromPathname(pathname) {
	const slug = stripLocalePrefix(normalizePathname(pathname)).replace(/^\//, "");
	if (!isKnownMarkdownSlug(slug)) return null;
	return slug;
}
function getFaqJsonLd(locale, pageUrl) {
	return {
		"@context": "https://schema.org",
		"@type": "FAQPage",
		mainEntity: (FAQ_JSON_LD_COPY[locale] ?? FAQ_JSON_LD_COPY["en"] ?? []).map((entry) => ({
			"@type": "Question",
			name: entry.question,
			acceptedAnswer: {
				"@type": "Answer",
				text: entry.answer
			}
		})),
		url: pageUrl
	};
}
function getHeadlineFromMetaTitle(title) {
	const [headline] = title.split("|");
	return headline?.trim() || title;
}
function getArticleJsonLd(locale, slug, pageUrl) {
	const pageMeta = getMarkdownSeoCopy(locale, slug);
	return {
		"@context": "https://schema.org",
		"@type": "Article",
		headline: getHeadlineFromMetaTitle(pageMeta.title),
		description: pageMeta.description,
		inLanguage: locale,
		mainEntityOfPage: pageUrl,
		datePublished: "2026-03-01",
		dateModified: "2026-03-01",
		author: {
			"@type": "Organization",
			name: "smail.pw"
		},
		publisher: {
			"@type": "Organization",
			name: "smail.pw",
			url: BASE_URL
		}
	};
}
function getBreadcrumbJsonLd(locale, slug, pageUrl) {
	const pageMeta = getMarkdownSeoCopy(locale, slug);
	return {
		"@context": "https://schema.org",
		"@type": "BreadcrumbList",
		itemListElement: [{
			"@type": "ListItem",
			position: 1,
			name: HOME_BREADCRUMB_LABEL[locale] ?? HOME_BREADCRUMB_LABEL["en"],
			item: `${BASE_URL}${toLocalePath("/", locale)}`
		}, {
			"@type": "ListItem",
			position: 2,
			name: getHeadlineFromMetaTitle(pageMeta.title),
			item: pageUrl
		}]
	};
}
function getInternalCtaCopy(locale) {
	return INTERNAL_CTA_COPY[locale] ?? INTERNAL_CTA_COPY["en"];
}
function meta({ params, location, matches }) {
	const { locale } = resolveLocaleParam(params.lang);
	const slug = getMarkdownSlugFromPathname(location.pathname);
	if (!slug) return mergeRouteMeta(matches, []);
	const pageMeta = getMarkdownSeoCopy(locale, slug);
	return mergeRouteMeta(matches, [
		{ title: pageMeta.title },
		{
			name: "description",
			content: pageMeta.description
		},
		{
			name: "robots",
			content: isMarkdownLocaleIndexable(locale) ? "index, follow" : "noindex, follow"
		}
	]);
}
async function loader$1({ params, request }) {
	const { locale, shouldRedirectToDefault, isInvalid } = resolveLocaleParam(params.lang);
	if (isInvalid) throw new Response("Not Found", { status: 404 });
	const url = new URL(request.url);
	if (shouldRedirectToDefault) throw redirect(`${stripDefaultLocalePrefix(url.pathname)}${url.search}`, 301);
	const segments = (url.pathname.endsWith("/") && url.pathname.length > 1 ? url.pathname.slice(0, -1) : url.pathname).split("/").filter(Boolean);
	const slug = segments[segments.length - 1] ?? "";
	if (!slug || slug === locale || slug === "en") throw new Response("Not Found", { status: 404 });
	if (!isKnownMarkdownSlug(slug)) throw new Response("Not Found", { status: 404 });
	const preferredPath = `../md/${locale}/${slug}.md`;
	const fallbackPath = `../md/en/${slug}.md`;
	const sourceLoader = markdownSources[preferredPath] ?? (locale !== "en" ? markdownSources[fallbackPath] : void 0);
	const source = sourceLoader ? await sourceLoader().catch(() => null) : null;
	if (!source) throw new Response("Not Found", { status: 404 });
	const ast = Markdoc.parse(source);
	const content = Markdoc.transform(ast);
	return {
		html: Markdoc.renderers.html(content),
		locale,
		slug
	};
}
var md_default = withComponentProps(function MarkdownPage({ loaderData }) {
	const pageUrl = `${BASE_URL}${toLocalePath(`/${loaderData.slug}`, loaderData.locale)}`;
	const faqJsonLd = loaderData.slug === "faq" ? getFaqJsonLd(loaderData.locale, pageUrl) : null;
	const articleJsonLd = isArticleMarkdownSlug(loaderData.slug) ? getArticleJsonLd(loaderData.locale, loaderData.slug, pageUrl) : null;
	const breadcrumbJsonLd = isArticleMarkdownSlug(loaderData.slug) ? getBreadcrumbJsonLd(loaderData.locale, loaderData.slug, pageUrl) : null;
	const infoCta = isInfoMarkdownSlug(loaderData.slug) ? getInternalCtaCopy(loaderData.locale) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 py-3 sm:py-4",
		children: [
			faqJsonLd && faqJsonLd.mainEntity.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
				type: "application/ld+json",
				dangerouslySetInnerHTML: { __html: JSON.stringify(faqJsonLd) }
			}),
			articleJsonLd && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
				type: "application/ld+json",
				dangerouslySetInnerHTML: { __html: JSON.stringify(articleJsonLd) }
			}),
			breadcrumbJsonLd && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
				type: "application/ld+json",
				dangerouslySetInnerHTML: { __html: JSON.stringify(breadcrumbJsonLd) }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "markdown-shell w-full",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
					className: "prose prose-sm sm:prose-base max-w-none",
					dangerouslySetInnerHTML: { __html: loaderData.html }
				}), infoCta && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "theme-card mt-6 space-y-3 p-4 sm:p-5",
					"aria-label": "Related temporary email pages",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-theme-primary font-display text-lg font-semibold",
							children: infoCta.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-theme-secondary text-sm leading-relaxed",
							children: infoCta.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-2 sm:grid-cols-3",
							children: infoCta.links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: toLocalePath(link.path, loaderData.locale),
								prefetch: "viewport",
								className: "theme-badge flex items-center justify-between px-3 py-2 text-xs font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: link.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-hidden": "true",
									children: "->"
								})]
							}, link.path))
						})
					]
				})]
			})
		]
	});
});
//#endregion
//#region app/routes/api.email.ts
var api_email_exports = /* @__PURE__ */ __exportAll({ loader: () => loader });
function wrapEmailContent(content) {
	return `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            margin: 16px;
            color: #333;
            background: white;
        }
        .email-content {
            max-width: 100%;
            word-wrap: break-word;
        }
        img {
            max-width: 100%;
            height: auto;
        }
        a {
            color: #2563eb;
        }
        blockquote {
            border-left: 4px solid #e5e7eb;
            margin: 1em 0;
            padding: 0 1em;
            color: #6b7280;
        }
        pre {
            background: #f3f4f6;
            padding: 1em;
            border-radius: 6px;
            overflow-x: auto;
            white-space: pre-wrap;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin: 1em 0;
        }
        th, td {
            border: 1px solid #e5e7eb;
            padding: 8px 12px;
            text-align: left;
        }
        th {
            background: #f9fafb;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="email-content">${content}</div>
</body>
</html>`;
}
async function loader({ request, params, context }) {
	const { id } = params;
	if (!id) throw new Response("Not found", { status: 404 });
	const d1 = context.cloudflare.env.D1;
	const r2 = context.cloudflare.env.R2;
	const mail = await d1.prepare("SELECT * FROM emails WHERE id = ?").bind(id).first();
	if (!mail) throw new Response("Not found", { status: 404 });
	const session = await getSession(request.headers.get("Cookie"));
	const addresses = session.get("addresses") || [];
	const addressIssuedAt = session.get("addressIssuedAt");
	if (typeof addressIssuedAt === "number" && Date.now() - addressIssuedAt >= 864e5 || !addresses.includes(mail.to_address)) throw new Response("Unauthorized", { status: 403 });
	const object = await r2.get(id);
	if (!object) throw new Response("Not found", { status: 404 });
	const message = await new PostalMime().parse(object.body);
	return { body: wrapEmailContent(message.html || message.text || "") };
}
//#endregion
//#region \0virtual:react-router/server-manifest
var server_manifest_default = {
	"entry": {
		"module": "/assets/entry.client-Dc6HBxi9.js",
		"imports": ["/assets/chunk-OE4NN4TA-C4Gje-eu.js", "/assets/jsx-runtime-NUIDFP3K.js"],
		"css": []
	},
	"routes": {
		"root": {
			"id": "root",
			"parentId": void 0,
			"path": "",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": true,
			"module": "/assets/root-wnvIFQkr.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/jsx-runtime-NUIDFP3K.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/theme-BHq3CFwF.js"
			],
			"css": ["/assets/root-CXg3nJqs.css"],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"locale-zh-CN-root": {
			"id": "locale-zh-CN-root",
			"parentId": "root",
			"path": "/zh-CN",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/locale-zh-cn-redirect-IIKX5QiG.js",
			"imports": ["/assets/chunk-OE4NN4TA-C4Gje-eu.js"],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"locale-zh-CN-splat": {
			"id": "locale-zh-CN-splat",
			"parentId": "root",
			"path": "/zh-CN/*",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/locale-zh-cn-redirect-IIKX5QiG.js",
			"imports": ["/assets/chunk-OE4NN4TA-C4Gje-eu.js"],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"locale-zh-cn-root": {
			"id": "locale-zh-cn-root",
			"parentId": "root",
			"path": "/zh-cn",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/locale-zh-cn-redirect-IIKX5QiG.js",
			"imports": ["/assets/chunk-OE4NN4TA-C4Gje-eu.js"],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"locale-zh-cn-splat": {
			"id": "locale-zh-cn-splat",
			"parentId": "root",
			"path": "/zh-cn/*",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/locale-zh-cn-redirect-IIKX5QiG.js",
			"imports": ["/assets/chunk-OE4NN4TA-C4Gje-eu.js"],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"routes/robots.txt": {
			"id": "routes/robots.txt",
			"parentId": "root",
			"path": "/robots.txt",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": false,
			"hasErrorBoundary": false,
			"module": "/assets/robots.txt-_92p09BK.js",
			"imports": [],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"routes/sitemap.xml": {
			"id": "routes/sitemap.xml",
			"parentId": "root",
			"path": "/sitemap.xml",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": false,
			"hasErrorBoundary": false,
			"module": "/assets/sitemap.xml-BN9NJK2I.js",
			"imports": [],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"rss-default": {
			"id": "rss-default",
			"parentId": "root",
			"path": "/rss.xml",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": false,
			"hasErrorBoundary": false,
			"module": "/assets/rss.xml-BYsxXO3p.js",
			"imports": [],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"rss-locale": {
			"id": "rss-locale",
			"parentId": "root",
			"path": ":lang/rss.xml",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": false,
			"hasErrorBoundary": false,
			"module": "/assets/rss.xml-BYsxXO3p.js",
			"imports": [],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"routes/layout": {
			"id": "routes/layout",
			"parentId": "root",
			"path": void 0,
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/layout-CBBvKB3k.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/messages-YT27uIYf.js",
				"/assets/theme-BHq3CFwF.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"home": {
			"id": "home",
			"parentId": "routes/layout",
			"path": ":lang?",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": true,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/home-BkY4eqMR.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/messages-YT27uIYf.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"contact": {
			"id": "contact",
			"parentId": "routes/layout",
			"path": ":lang?/contact",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": false,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/contact-Bl2un5A_.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"blog-list": {
			"id": "blog-list",
			"parentId": "routes/layout",
			"path": ":lang?/blog",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/blog-4Ml6e8eY.js",
			"imports": [
				"/assets/blog-BXt-La-G.js",
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"blog-page": {
			"id": "blog-page",
			"parentId": "routes/layout",
			"path": ":lang?/blog/page/:page",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/blog.page-uFuhNDTN.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/blog-BXt-La-G.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"blog-post": {
			"id": "blog-post",
			"parentId": "routes/layout",
			"path": ":lang?/blog/:slug",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/blog.post-DEcKf68M.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/blog-BXt-La-G.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"md-about": {
			"id": "md-about",
			"parentId": "routes/layout",
			"path": ":lang?/about",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/md-BJu89fA3.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"md-faq": {
			"id": "md-faq",
			"parentId": "routes/layout",
			"path": ":lang?/faq",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/md-BJu89fA3.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"md-privacy": {
			"id": "md-privacy",
			"parentId": "routes/layout",
			"path": ":lang?/privacy",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/md-BJu89fA3.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"md-terms": {
			"id": "md-terms",
			"parentId": "routes/layout",
			"path": ":lang?/terms",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/md-BJu89fA3.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"md-temporary-email-24-hours": {
			"id": "md-temporary-email-24-hours",
			"parentId": "routes/layout",
			"path": ":lang?/temporary-email-24-hours",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/md-BJu89fA3.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"md-temporary-email-no-registration": {
			"id": "md-temporary-email-no-registration",
			"parentId": "routes/layout",
			"path": ":lang?/temporary-email-no-registration",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/md-BJu89fA3.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"md-disposable-email-for-verification": {
			"id": "md-disposable-email-for-verification",
			"parentId": "routes/layout",
			"path": ":lang?/disposable-email-for-verification",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/md-BJu89fA3.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"md-temporary-email-for-registration": {
			"id": "md-temporary-email-for-registration",
			"parentId": "routes/layout",
			"path": ":lang?/temporary-email-for-registration",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/md-BJu89fA3.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"md-online-temporary-email": {
			"id": "md-online-temporary-email",
			"parentId": "routes/layout",
			"path": ":lang?/online-temporary-email",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/md-BJu89fA3.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"md-domestic-temporary-email": {
			"id": "md-domestic-temporary-email",
			"parentId": "routes/layout",
			"path": ":lang?/domestic-temporary-email",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/md-BJu89fA3.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"md-can-temporary-email-send": {
			"id": "md-can-temporary-email-send",
			"parentId": "routes/layout",
			"path": ":lang?/can-temporary-email-send",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/md-BJu89fA3.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"md-smail-vs-smailpro": {
			"id": "md-smail-vs-smailpro",
			"parentId": "routes/layout",
			"path": ":lang?/smail-vs-smailpro",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": true,
			"hasErrorBoundary": false,
			"module": "/assets/md-BJu89fA3.js",
			"imports": [
				"/assets/chunk-OE4NN4TA-C4Gje-eu.js",
				"/assets/seo.config-nReq77Fz.js",
				"/assets/config-DYcJAGQQ.js",
				"/assets/meta-B31fyNQS.js",
				"/assets/jsx-runtime-NUIDFP3K.js"
			],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		},
		"routes/api.email": {
			"id": "routes/api.email",
			"parentId": "root",
			"path": "/api/email/:id",
			"index": void 0,
			"caseSensitive": void 0,
			"hasAction": false,
			"hasLoader": true,
			"hasClientAction": false,
			"hasClientLoader": false,
			"hasClientMiddleware": false,
			"hasDefaultExport": false,
			"hasErrorBoundary": false,
			"module": "/assets/api.email-BnNyBDGy.js",
			"imports": [],
			"css": [],
			"clientActionModule": void 0,
			"clientLoaderModule": void 0,
			"clientMiddlewareModule": void 0,
			"hydrateFallbackModule": void 0
		}
	},
	"url": "/assets/manifest-61f7c28d.js",
	"version": "61f7c28d",
	"sri": void 0
};
//#endregion
//#region \0virtual:react-router/server-build
var assetsBuildDirectory = "build/client";
var basename = "/";
var future = {
	"unstable_optimizeDeps": false,
	"unstable_passThroughRequests": false,
	"unstable_subResourceIntegrity": false,
	"unstable_trailingSlashAwareDataRequests": false,
	"unstable_previewServerPrerendering": false,
	"v8_middleware": false,
	"v8_splitRouteModules": false,
	"v8_viteEnvironmentApi": true
};
var ssr = true;
var isSpaMode = false;
var prerender = [];
var routeDiscovery = {
	"mode": "lazy",
	"manifestPath": "/__manifest"
};
var publicPath = "/";
var entry = { module: entry_server_exports };
var routes = {
	"root": {
		id: "root",
		parentId: void 0,
		path: "",
		index: void 0,
		caseSensitive: void 0,
		module: root_exports
	},
	"locale-zh-CN-root": {
		id: "locale-zh-CN-root",
		parentId: "root",
		path: "/zh-CN",
		index: void 0,
		caseSensitive: void 0,
		module: locale_zh_cn_redirect_exports
	},
	"locale-zh-CN-splat": {
		id: "locale-zh-CN-splat",
		parentId: "root",
		path: "/zh-CN/*",
		index: void 0,
		caseSensitive: void 0,
		module: locale_zh_cn_redirect_exports
	},
	"locale-zh-cn-root": {
		id: "locale-zh-cn-root",
		parentId: "root",
		path: "/zh-cn",
		index: void 0,
		caseSensitive: void 0,
		module: locale_zh_cn_redirect_exports
	},
	"locale-zh-cn-splat": {
		id: "locale-zh-cn-splat",
		parentId: "root",
		path: "/zh-cn/*",
		index: void 0,
		caseSensitive: void 0,
		module: locale_zh_cn_redirect_exports
	},
	"routes/robots.txt": {
		id: "routes/robots.txt",
		parentId: "root",
		path: "/robots.txt",
		index: void 0,
		caseSensitive: void 0,
		module: robots_txt_exports
	},
	"routes/sitemap.xml": {
		id: "routes/sitemap.xml",
		parentId: "root",
		path: "/sitemap.xml",
		index: void 0,
		caseSensitive: void 0,
		module: sitemap_xml_exports
	},
	"rss-default": {
		id: "rss-default",
		parentId: "root",
		path: "/rss.xml",
		index: void 0,
		caseSensitive: void 0,
		module: rss_xml_exports
	},
	"rss-locale": {
		id: "rss-locale",
		parentId: "root",
		path: ":lang/rss.xml",
		index: void 0,
		caseSensitive: void 0,
		module: rss_xml_exports
	},
	"routes/layout": {
		id: "routes/layout",
		parentId: "root",
		path: void 0,
		index: void 0,
		caseSensitive: void 0,
		module: layout_exports
	},
	"home": {
		id: "home",
		parentId: "routes/layout",
		path: ":lang?",
		index: void 0,
		caseSensitive: void 0,
		module: home_exports
	},
	"contact": {
		id: "contact",
		parentId: "routes/layout",
		path: ":lang?/contact",
		index: void 0,
		caseSensitive: void 0,
		module: contact_exports
	},
	"blog-list": {
		id: "blog-list",
		parentId: "routes/layout",
		path: ":lang?/blog",
		index: void 0,
		caseSensitive: void 0,
		module: blog_exports
	},
	"blog-page": {
		id: "blog-page",
		parentId: "routes/layout",
		path: ":lang?/blog/page/:page",
		index: void 0,
		caseSensitive: void 0,
		module: blog_page_exports
	},
	"blog-post": {
		id: "blog-post",
		parentId: "routes/layout",
		path: ":lang?/blog/:slug",
		index: void 0,
		caseSensitive: void 0,
		module: blog_post_exports
	},
	"md-about": {
		id: "md-about",
		parentId: "routes/layout",
		path: ":lang?/about",
		index: void 0,
		caseSensitive: void 0,
		module: md_exports
	},
	"md-faq": {
		id: "md-faq",
		parentId: "routes/layout",
		path: ":lang?/faq",
		index: void 0,
		caseSensitive: void 0,
		module: md_exports
	},
	"md-privacy": {
		id: "md-privacy",
		parentId: "routes/layout",
		path: ":lang?/privacy",
		index: void 0,
		caseSensitive: void 0,
		module: md_exports
	},
	"md-terms": {
		id: "md-terms",
		parentId: "routes/layout",
		path: ":lang?/terms",
		index: void 0,
		caseSensitive: void 0,
		module: md_exports
	},
	"md-temporary-email-24-hours": {
		id: "md-temporary-email-24-hours",
		parentId: "routes/layout",
		path: ":lang?/temporary-email-24-hours",
		index: void 0,
		caseSensitive: void 0,
		module: md_exports
	},
	"md-temporary-email-no-registration": {
		id: "md-temporary-email-no-registration",
		parentId: "routes/layout",
		path: ":lang?/temporary-email-no-registration",
		index: void 0,
		caseSensitive: void 0,
		module: md_exports
	},
	"md-disposable-email-for-verification": {
		id: "md-disposable-email-for-verification",
		parentId: "routes/layout",
		path: ":lang?/disposable-email-for-verification",
		index: void 0,
		caseSensitive: void 0,
		module: md_exports
	},
	"md-temporary-email-for-registration": {
		id: "md-temporary-email-for-registration",
		parentId: "routes/layout",
		path: ":lang?/temporary-email-for-registration",
		index: void 0,
		caseSensitive: void 0,
		module: md_exports
	},
	"md-online-temporary-email": {
		id: "md-online-temporary-email",
		parentId: "routes/layout",
		path: ":lang?/online-temporary-email",
		index: void 0,
		caseSensitive: void 0,
		module: md_exports
	},
	"md-domestic-temporary-email": {
		id: "md-domestic-temporary-email",
		parentId: "routes/layout",
		path: ":lang?/domestic-temporary-email",
		index: void 0,
		caseSensitive: void 0,
		module: md_exports
	},
	"md-can-temporary-email-send": {
		id: "md-can-temporary-email-send",
		parentId: "routes/layout",
		path: ":lang?/can-temporary-email-send",
		index: void 0,
		caseSensitive: void 0,
		module: md_exports
	},
	"md-smail-vs-smailpro": {
		id: "md-smail-vs-smailpro",
		parentId: "routes/layout",
		path: ":lang?/smail-vs-smailpro",
		index: void 0,
		caseSensitive: void 0,
		module: md_exports
	},
	"routes/api.email": {
		id: "routes/api.email",
		parentId: "root",
		path: "/api/email/:id",
		index: void 0,
		caseSensitive: void 0,
		module: api_email_exports
	}
};
var allowedActionOrigins = false;
//#endregion
export { allowedActionOrigins, server_manifest_default as assets, assetsBuildDirectory, basename, entry, future, isSpaMode, prerender, publicPath, routeDiscovery, routes, ssr };

//#region app/md/ko/temporary-email-no-registration.md?raw
var temporary_email_no_registration_default = "## 가입 없는 임시 이메일\n\nsmail.pw에서는 계정 생성 없이 임시 메일을 바로 사용할 수 있습니다.\n\n### 적합한 사용 장면\n\n- 빠른 서비스 체험\n- 이메일 인증이 필요한 일회성 다운로드\n- 단기 커뮤니티 가입\n\n### 장점\n\n- 개인정보 노출 감소\n- 가입 절차 생략\n- 본 메일함 정리 효과\n\n### 안내\n\n장기 운영 또는 민감한 계정에는 사용하지 마세요.\n\n### 관련 페이지\n\n- [24시간 임시 이메일](/temporary-email-24-hours)\n- [인증용 일회용 이메일](/disposable-email-for-verification)\n- [개인정보 처리방침](/privacy)\n\n### 추천 사용 방식\n\n빠른 가입이 목적이라면 [가입용 임시 이메일](/temporary-email-for-registration), [온라인 임시 이메일](/online-temporary-email)도 참고하세요.\n";
//#endregion
export { temporary_email_no_registration_default as default };

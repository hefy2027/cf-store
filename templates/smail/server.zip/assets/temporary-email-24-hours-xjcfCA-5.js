//#region app/md/ja/temporary-email-24-hours.md?raw
var temporary_email_24_hours_default = "## 24時間 一時メール\n\nsmail.pw の 24時間一時メールは、確認メールが遅れて届くケースに向いた構成です。\n\n### 24時間のメリット\n\n- 10分メールより余裕がある\n- 複数ステップの登録に対応しやすい\n- 数時間後でも確認しやすい\n\n### 使い方\n\n1. 一時アドレスを生成\n2. 対象サイトに入力\n3. smail.pw で受信確認\n4. 必要情報を期限前に保存\n\n### 関連ページ\n\n- [登録不要の一時メール](/temporary-email-no-registration)\n- [認証コード用使い捨てメール](/disposable-email-for-verification)\n- [FAQ](/faq)\n\n### 追加で役立つガイド\n\nこの流れは [登録向け一時メール](/temporary-email-for-registration) と [オンライン一時メール](/online-temporary-email) と組み合わせると効果的です。\n";
//#endregion
export { temporary_email_24_hours_default as default };

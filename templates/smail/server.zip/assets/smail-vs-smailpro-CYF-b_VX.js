//#region app/md/de/smail-vs-smailpro.md?raw
var smail_vs_smailpro_default = "## smail.pw vs smailpro\n\nOffizielle Klarstellung: **smail.pw ist ein unabhängiger Dienst**.\n\n### Wichtig\n\n- smail.pw ist nicht identisch mit smail pro oder smailpro\n- Keine Zugehörigkeit zu ähnlich benannten Diensten\n- Funktionen und Richtlinien werden separat betrieben\n\n### Verwandte Seiten\n\n- [Über smail.pw](/about)\n- [FAQ](/faq)\n- [Datenschutzrichtlinie](/privacy)\n";
//#endregion
export { smail_vs_smailpro_default as default };

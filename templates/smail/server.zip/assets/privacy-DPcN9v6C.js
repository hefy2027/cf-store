//#region app/md/fr/privacy.md?raw
var privacy_default = "## Politique de confidentialité\n\nsmail.pw est un service d'email temporaire. Nous traitons un minimum de données pour assurer la réception des messages et la sécurité du service.\n\n### Données possibles\n\n- Adresse temporaire et emails reçus\n- Données techniques de base (IP, navigateur, horodatage)\n\n### Conservation\n\nLe contenu des emails est conservé jusqu'à 24 heures puis supprimé automatiquement.\n\n### Important\n\nN'utilisez pas ce service pour des informations sensibles ou des comptes critiques.\n";
//#endregion
export { privacy_default as default };

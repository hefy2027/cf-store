//#region app/md/ja/disposable-email-for-verification.md?raw
var disposable_email_for_verification_default = "## 認証コード用 使い捨てメール\n\nOTP や確認リンクを受け取りたいが、個人アドレスは出したくない場合に使えます。\n\n### 受信できる内容\n\n- OTP コード\n- 確認リンク\n- アクティベーション通知\n\n### 受信改善のコツ\n\n- 生成アドレスを正確にコピー\n- 元サイトから再送\n- 数分待って更新\n\n### セキュリティ注意\n\n銀行・業務・行政・重要復旧には使用しないでください。\n\n### 関連ページ\n\n- [24時間 一時メール](/temporary-email-24-hours)\n- [登録不要の一時メール](/temporary-email-no-registration)\n- [利用規約](/terms)\n\n### 関連ガイド\n\n- [登録向け一時メール](/temporary-email-for-registration)\n- [一時メールは送信できる？](/can-temporary-email-send)\n";
//#endregion
export { disposable_email_for_verification_default as default };

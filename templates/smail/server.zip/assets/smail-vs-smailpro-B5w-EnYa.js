//#region app/md/ar/smail-vs-smailpro.md?raw
var smail_vs_smailpro_default = "## smail.pw مقابل smailpro\n\nتوضيح رسمي: **smail.pw خدمة مستقلة**.\n\n### نقاط مهمة\n\n- smail.pw ليس نفس منتج smail pro / smailpro\n- لا توجد علاقة تبعية مع خدمات مشابهة الاسم\n- الميزات والسياسات تُدار بشكل مستقل\n\n### صفحات مرتبطة\n\n- [حول smail.pw](/about)\n- [الأسئلة الشائعة](/faq)\n- [سياسة الخصوصية](/privacy)\n";
//#endregion
export { smail_vs_smailpro_default as default };

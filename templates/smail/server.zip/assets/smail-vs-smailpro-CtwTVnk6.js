//#region app/md/ru/smail-vs-smailpro.md?raw
var smail_vs_smailpro_default = "## smail.pw и smailpro\n\nОфициальное разъяснение: **smail.pw — независимый сервис**.\n\n### Важно\n\n- smail.pw не является тем же продуктом, что smail pro / smailpro\n- Нет аффилированности с похожими названиями\n- Функции и политика управляются отдельно\n\n### Связанные страницы\n\n- [О smail.pw](/about)\n- [FAQ](/faq)\n- [Политика конфиденциальности](/privacy)\n";
//#endregion
export { smail_vs_smailpro_default as default };

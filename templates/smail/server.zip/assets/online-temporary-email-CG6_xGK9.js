//#region app/md/pt/online-temporary-email.md?raw
var online_temporary_email_default = "## Email temporário online\n\nCom **email temporário online**, você recebe mensagens de verificação na hora direto no navegador.\n\n### Benefícios\n\n- Uso imediato sem instalar app\n- Atualização rápida da caixa de entrada\n- Menor exposição do email principal\n\n### Se o OTP atrasar\n\n- Verifique o endereço copiado\n- Solicite reenvio no serviço de origem\n- Aguarde alguns minutos e atualize\n\n### Páginas relacionadas\n\n- [Email temporário de 24 horas](/temporary-email-24-hours)\n- [Email temporário para cadastro](/temporary-email-for-registration)\n- [Email descartável para verificação](/disposable-email-for-verification)\n";
//#endregion
export { online_temporary_email_default as default };

//#region app/md/de/about.md?raw
var about_default = "## Über smail.pw (Temporäre E-Mail)\n\nsmail.pw ist ein Dienst für **temporäre E-Mail** bei risikoarmen Registrierungen, OTP-Codes und einmaligen Verifizierungen.\n\n### Wofür es gedacht ist\n\n- Dienste testen ohne Hauptadresse preiszugeben\n- Einmalige Bestätigungslinks empfangen\n- Spam im privaten Postfach reduzieren\n\n### Wichtige Grenzen\n\nTemporäre Postfächer sind nicht für kritische Konten geeignet (Bank, Arbeit, Behörden, wichtige Recovery-Prozesse).\n\n### Kontakt\n\nFeedback kannst du über den Kontaktkanal der Website senden.\n";
//#endregion
export { about_default as default };

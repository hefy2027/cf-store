//#region app/md/ko/domestic-temporary-email.md?raw
var domestic_temporary_email_default = "## 국내 임시 이메일 수신 가이드\n\n이 **국내 임시 이메일 가이드**는 지역 서비스에서 OTP 지연 시 점검할 항목을 정리합니다.\n\n### 지연 원인\n\n- 발신 서버 지연\n- 임시 도메인 차단\n- 주소 입력 오류\n\n### 해결 순서\n\n1. 주소를 정확히 확인\n2. 코드 재전송 요청\n3. 1~3분 후 새로고침\n4. 필요 시 다른 주소로 재시도\n\n### 관련 페이지\n\n- [온라인 임시 이메일](/online-temporary-email)\n- [인증용 일회용 이메일](/disposable-email-for-verification)\n- [자주 묻는 질문](/faq)\n";
//#endregion
export { domestic_temporary_email_default as default };

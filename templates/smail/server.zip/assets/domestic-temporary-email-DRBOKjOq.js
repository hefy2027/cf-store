//#region app/md/ar/domestic-temporary-email.md?raw
var domestic_temporary_email_default = "## دليل البريد المؤقت المحلي\n\nيشرح **دليل البريد المؤقت المحلي** كيفية التعامل مع تأخر الاستلام في المنصات الإقليمية.\n\n### أسباب التأخر الشائعة\n\n- تأخر جهة الإرسال\n- حظر نطاقات البريد المؤقت\n- خطأ في كتابة العنوان\n\n### خطوات الحل\n\n1. تأكد من العنوان بدقة.\n2. أعد طلب إرسال الرمز.\n3. انتظر من 1 إلى 3 دقائق ثم حدّث.\n4. جرّب عنوانًا مؤقتًا جديدًا عند الحاجة.\n\n### صفحات مرتبطة\n\n- [بريد مؤقت أونلاين](/online-temporary-email)\n- [بريد مؤقت للتحقق ورموز OTP](/disposable-email-for-verification)\n- [الأسئلة الشائعة](/faq)\n";
//#endregion
export { domestic_temporary_email_default as default };

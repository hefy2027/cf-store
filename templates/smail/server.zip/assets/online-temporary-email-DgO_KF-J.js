//#region app/md/ar/online-temporary-email.md?raw
var online_temporary_email_default = "## بريد مؤقت أونلاين\n\nيوفر **البريد المؤقت الأونلاين** استقبالًا فوريًا لرسائل التحقق مباشرة من المتصفح.\n\n### المزايا\n\n- استخدام فوري بدون تثبيت\n- تحديث سريع لصندوق الوارد\n- تقليل كشف البريد الأساسي\n\n### إذا تأخر OTP\n\n- تحقق من صحة العنوان\n- أعد الإرسال من المنصة الأصلية\n- انتظر بضع دقائق ثم حدّث الوارد\n\n### صفحات مرتبطة\n\n- [بريد مؤقت لمدة 24 ساعة](/temporary-email-24-hours)\n- [بريد مؤقت للتسجيل](/temporary-email-for-registration)\n- [بريد مؤقت للتحقق ورموز OTP](/disposable-email-for-verification)\n";
//#endregion
export { online_temporary_email_default as default };

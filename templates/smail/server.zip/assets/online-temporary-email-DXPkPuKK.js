//#region app/md/zh/online-temporary-email.md?raw
var online_temporary_email_default = "## 在线临时邮箱\n\n需要马上收验证码？**在线临时邮箱**可以直接在网页里即时生成和收信，适合 OTP、确认链接和短期验证场景。\n\n### 为什么很多人用在线临时邮箱\n\n- 打开即用，无需安装\n- 收件箱可即时刷新\n- 将一次性收信与真实邮箱隔离\n\n### 收信建议\n\n- 复制邮箱地址时不要多空格或少字符\n- 如果未收到邮件，先在来源站点点击重发\n- 等待 1-3 分钟后再刷新，避免发件方延迟\n\n### 保留周期\n\n邮件最多保留 24 小时，之后自动清理。\n\n### 相关阅读\n\n- [24 小时临时邮箱](/temporary-email-24-hours)\n- [临时邮箱注册指南](/temporary-email-for-registration)\n- [验证码一次性邮箱](/disposable-email-for-verification)\n";
//#endregion
export { online_temporary_email_default as default };

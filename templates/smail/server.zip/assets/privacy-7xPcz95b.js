//#region app/md/ja/privacy.md?raw
var privacy_default = "## プライバシーポリシー\n\nsmail.pw は一時メールサービスです。配信と不正対策のために必要最小限のデータを扱います。\n\n### 取り扱う可能性のある情報\n\n- 一時アドレスと受信メール\n- 基本的な技術情報（IP、ブラウザ、時刻）\n\n### 保持期間\n\nメール内容は最大 24 時間保持され、その後自動削除されます。\n\n### 注意\n\n機密情報や重要アカウント用途には使用しないでください。\n";
//#endregion
export { privacy_default as default };

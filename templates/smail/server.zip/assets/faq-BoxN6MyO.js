//#region app/md/es/faq.md?raw
var faq_default = "## Preguntas frecuentes de smail.pw\n\n### ¿Qué es smail.pw?\nEs un servicio de correo temporal para recibir mensajes de uso corto.\n\n### ¿Necesito crear cuenta?\nNo, funciona sin registro.\n\n### ¿Cuánto tiempo se guardan los correos?\nHasta 24 horas; luego se eliminan automáticamente.\n\n### ¿Sirve para OTP y verificación?\nSí, es un uso común.\n\n### ¿Por qué no llegó mi correo?\nPuede haber retraso del remitente, bloqueo de dominios temporales o error al copiar la dirección.\n\n### ¿Puedo enviar correos?\nGeneralmente no. El servicio está orientado a recepción.\n\n### ¿Es apto para cuentas importantes?\nNo. Usa un proveedor permanente para cuentas críticas.\n";
//#endregion
export { faq_default as default };

//#region app/md/fr/smail-vs-smailpro.md?raw
var smail_vs_smailpro_default = "## smail.pw vs smailpro\n\nClarification officielle : **smail.pw est un service indépendant**.\n\n### Informations clés\n\n- smail.pw n'est pas le même produit que smail pro ou smailpro\n- Aucune affiliation avec des services au nom similaire\n- Politiques et fonctionnalités gérées séparément\n\n### Pages liées\n\n- [À propos de smail.pw](/about)\n- [FAQ](/faq)\n- [Politique de confidentialité](/privacy)\n";
//#endregion
export { smail_vs_smailpro_default as default };

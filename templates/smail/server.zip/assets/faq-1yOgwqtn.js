//#region app/md/de/faq.md?raw
var faq_default = "## smail.pw FAQ\n\n### Was ist smail.pw?\nEin Dienst für temporäre Postfächer und kurzlebige E-Mails.\n\n### Brauche ich ein Konto?\nNein, keine Registrierung erforderlich.\n\n### Wie lange bleiben E-Mails erhalten?\nBis zu 24 Stunden, danach automatische Löschung.\n\n### Funktioniert OTP-Verifizierung?\nJa, das ist ein typischer Anwendungsfall.\n\n### Warum kam keine E-Mail an?\nMögliche Gründe: Absenderverzögerung, Blockierung temporärer Domains, Tippfehler.\n\n### Kann ich E-Mails senden?\nIn der Regel nein; der Dienst ist auf Empfang ausgelegt.\n\n### Für wichtige Konten geeignet?\nNein. Für kritische Konten bitte dauerhafte E-Mail nutzen.\n";
//#endregion
export { faq_default as default };

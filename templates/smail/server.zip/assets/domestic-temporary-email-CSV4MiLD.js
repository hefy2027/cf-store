//#region app/md/pt/domestic-temporary-email.md?raw
var domestic_temporary_email_default = "## Guia de email temporário local\n\nEste **guia de email temporário local** mostra como lidar com atrasos de entrega em plataformas regionais.\n\n### Causas comuns\n\n- Fila do remetente\n- Bloqueio de domínios temporários\n- Erro de digitação no endereço\n\n### O que fazer\n\n1. Confirme o endereço com atenção.\n2. Peça reenvio do código.\n3. Espere 1 a 3 minutos e atualize.\n4. Se necessário, teste outro endereço temporário.\n\n### Páginas relacionadas\n\n- [Email temporário online](/online-temporary-email)\n- [Email descartável para verificação](/disposable-email-for-verification)\n- [Perguntas frequentes](/faq)\n";
//#endregion
export { domestic_temporary_email_default as default };

//#region app/md/pt/terms.md?raw
var terms_default = "## Termos de uso\n\nAo usar o smail.pw, você concorda com estes termos.\n\n### Uso permitido\n\n- Cadastro e verificação de baixo risco\n- Recebimento temporário de emails\n\n### Uso proibido\n\n- Spam, fraude, phishing\n- Atividades ilegais ou maliciosas\n\n### Limitação\n\nNão há garantia de entrega permanente nem retenção acima de 24 horas.\n";
//#endregion
export { terms_default as default };

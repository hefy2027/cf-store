//#region app/md/ko/about.md?raw
var about_default = "## smail.pw 소개 (임시 이메일)\n\nsmail.pw는 저위험 가입, OTP 수신, 일회성 인증을 위한 **임시 이메일** 서비스입니다.\n\n### 이런 상황에 유용합니다\n\n- 본 메일 주소를 공개하지 않고 서비스 체험\n- 1회성 확인 링크 수신\n- 개인 메일함 스팸 감소\n\n### 중요한 제한\n\n임시 메일은 장기 계정용이 아닙니다. 은행/업무/정부/중요 복구 계정에는 사용하지 마세요.\n\n### 문의\n\n피드백은 사이트 내 연락 채널을 이용해 주세요.\n";
//#endregion
export { about_default as default };

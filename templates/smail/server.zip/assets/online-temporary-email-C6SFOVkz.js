//#region app/md/ja/online-temporary-email.md?raw
var online_temporary_email_default = "## オンライン一時メール\n\n**オンライン一時メール**なら、ブラウザですぐに認証メールを受信できます。\n\n### メリット\n\n- インストール不要ですぐ使える\n- 受信箱を即時更新できる\n- 個人メールの露出を減らせる\n\n### 受信できないとき\n\n- アドレスの入力ミスを確認\n- 送信元で再送を実行\n- 数分待ってから再更新\n\n### 関連ページ\n\n- [24時間一時メール](/temporary-email-24-hours)\n- [登録向け一時メール](/temporary-email-for-registration)\n- [認証用使い捨てメール](/disposable-email-for-verification)\n";
//#endregion
export { online_temporary_email_default as default };

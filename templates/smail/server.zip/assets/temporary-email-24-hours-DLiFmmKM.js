//#region app/md/zh/temporary-email-24-hours.md?raw
var temporary_email_24_hours_default = "## 24 小时临时邮箱\n\n如果你觉得 10 分钟邮箱不够用，smail.pw 提供 **24 小时临时邮箱**（24小时邮箱），更适合真实注册流程中的延迟邮件场景。\n\n### 为什么 24 小时更实用\n\n- 验证链接可能延迟到达\n- 注册流程可能分多步完成\n- 二次验证码可能在数小时后发送\n\n### 使用方法\n\n1. 在 smail.pw 生成临时邮箱地址\n2. 在目标网站填写该地址\n3. 返回收件箱查看邮件\n4. 及时保存你需要的关键信息\n\n邮件内容会在 24 小时后自动清理。\n\n如果你在找“免费临时邮箱”且希望保留时间更长，这类 24 小时一次性邮箱更适合分步骤注册与延迟验证码场景。\n\n### 相关阅读\n\n- [免注册临时邮箱](/temporary-email-no-registration)\n- [验证码一次性邮箱](/disposable-email-for-verification)\n- [常见问题](/faq)\n\n### 进阶用法\n\n这类流程可结合 [临时邮箱注册指南](/temporary-email-for-registration) 和 [在线临时邮箱](/online-temporary-email) 一起使用。\n";
//#endregion
export { temporary_email_24_hours_default as default };

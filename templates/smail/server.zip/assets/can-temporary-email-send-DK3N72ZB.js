//#region app/md/pt/can-temporary-email-send.md?raw
var can_temporary_email_send_default = "## Email temporário pode enviar mensagens?\n\nNa maioria dos casos, **email temporário é apenas para receber** OTP e links de confirmação.\n\n### Por que costuma ser só recebimento\n\n- Menor risco de spam e abuso\n- Segurança operacional mais simples\n- Melhor estabilidade da caixa descartável\n\n### Quando usar email permanente\n\nSe você precisa enviar, responder e manter histórico, use um provedor de email permanente.\n\n### Páginas relacionadas\n\n- [Email descartável para verificação](/disposable-email-for-verification)\n- [Email temporário sem cadastro](/temporary-email-no-registration)\n- [Termos de uso](/terms)\n";
//#endregion
export { can_temporary_email_send_default as default };

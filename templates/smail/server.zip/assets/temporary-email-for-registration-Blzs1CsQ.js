//#region app/md/ar/temporary-email-for-registration.md?raw
var temporary_email_for_registration_default = "## بريد مؤقت للتسجيل\n\nاستخدم **البريد المؤقت للتسجيل** عندما تحتاج إلى تفعيل حساب بدون كشف بريدك الأساسي.\n\n### الحالات المناسبة\n\n- إنشاء حسابات تجريبية\n- نماذج القسائم أو التحميل\n- تسجيلات منخفضة المخاطر\n\n### طريقة الاستخدام\n\n1. أنشئ عنوانًا مؤقتًا في smail.pw.\n2. أدخله في نموذج التسجيل.\n3. استقبل رمز OTP أو رابط التأكيد.\n4. أكمل التسجيل دون تعريض بريدك الشخصي.\n\n### صفحات مرتبطة\n\n- [بريد مؤقت بدون تسجيل](/temporary-email-no-registration)\n- [بريد مؤقت للتحقق ورموز OTP](/disposable-email-for-verification)\n- [الأسئلة الشائعة](/faq)\n";
//#endregion
export { temporary_email_for_registration_default as default };

//#region app/md/ja/about.md?raw
var about_default = "## smail.pw について（一時メール）\n\nsmail.pw は、低リスク登録や OTP 受信用の **一時メール** サービスです。メインのメールアドレスを公開せずに短期利用できます。\n\n### 主な用途\n\n- 新しいサービスの試用登録\n- ワンタイム確認リンクの受信\n- 個人受信箱のスパム削減\n\n### 注意点\n\n一時メールは恒久利用向けではありません。銀行・仕事・行政・重要な復旧用途には使用しないでください。\n\n### 連絡\n\nご意見はサイト内の問い合わせ手段をご利用ください。\n";
//#endregion
export { about_default as default };

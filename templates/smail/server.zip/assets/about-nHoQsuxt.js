//#region app/md/fr/about.md?raw
var about_default = "## À propos de smail.pw (Email temporaire)\n\nsmail.pw est un service d'**email temporaire** pour les inscriptions à faible risque, les OTP et les vérifications ponctuelles.\n\n### Cas d'usage\n\n- Tester un service sans exposer votre adresse principale\n- Recevoir des liens de confirmation à usage unique\n- Réduire le spam dans votre boîte personnelle\n\n### Limites importantes\n\nLes boîtes sont temporaires. N'utilisez pas ce service pour la banque, le travail, l'administration ou la récupération de comptes critiques.\n\n### Contact\n\nPour toute suggestion, utilisez le canal de contact du site.\n";
//#endregion
export { about_default as default };

//#region app/md/ja/smail-vs-smailpro.md?raw
var smail_vs_smailpro_default = "## smail.pw と smailpro の違い\n\n公式説明: **smail.pw は独立したサービス**です。\n\n### 重要ポイント\n\n- smail.pw は smail pro / smailpro と同一製品ではありません\n- 類似名称サービスとの提携はありません\n- 機能とポリシーは独立して運用されています\n\n### 関連ページ\n\n- [smail.pw について](/about)\n- [よくある質問](/faq)\n- [プライバシーポリシー](/privacy)\n";
//#endregion
export { smail_vs_smailpro_default as default };

//#region app/md/ko/disposable-email-for-verification.md?raw
var disposable_email_for_verification_default = "## 인증 코드용 일회용 이메일\n\nOTP 또는 확인 링크를 받을 때 개인 주소 노출을 줄이고 싶다면 일회용 메일이 유용합니다.\n\n### 수신 가능한 내용\n\n- 이메일 OTP 코드\n- 가입 확인 링크\n- 활성화 메시지\n\n### 수신 팁\n\n- 주소를 정확히 복사\n- 원본 서비스에서 재전송\n- 몇 분 대기 후 새로고침\n\n### 보안 안내\n\n은행, 업무, 정부, 중요한 복구 계정에는 사용하지 마세요.\n\n### 관련 페이지\n\n- [24시간 임시 이메일](/temporary-email-24-hours)\n- [가입 없는 임시 이메일](/temporary-email-no-registration)\n- [이용약관](/terms)\n\n### 추가 가이드\n\n- [가입용 임시 이메일](/temporary-email-for-registration)\n- [임시 이메일로 발신할 수 있나요?](/can-temporary-email-send)\n";
//#endregion
export { disposable_email_for_verification_default as default };

//#region app/md/es/about.md?raw
var about_default = "## Sobre smail.pw (Correo temporal)\n\nsmail.pw es un servicio de **correo temporal** para registros de bajo riesgo, códigos OTP y verificaciones rápidas.\n\n### Para qué sirve\n\n- Probar servicios sin exponer tu correo principal\n- Recibir enlaces de confirmación de uso único\n- Reducir spam y ruido en tu bandeja personal\n\n### Lo que debes saber\n\nLos buzones son temporales y no deben usarse para cuentas críticas (banca, trabajo, gobierno o recuperación importante).\n\n### Contacto\n\nSi tienes sugerencias, usa el canal de contacto disponible en el sitio.\n";
//#endregion
export { about_default as default };

//#region app/md/zh/smail-vs-smailpro.md?raw
var smail_vs_smailpro_default = "## smail.pw 与 smailpro 关系说明\n\n针对用户常见搜索，这里做官方说明：**smail.pw 是独立临时邮箱服务**。\n\n### 关键信息\n\n- smail.pw 与 smail pro / smailpro 不是同一产品\n- 与同名或近似名称站点无隶属关系\n- 功能、策略与基础设施均独立维护\n\n### 为什么需要这个说明\n\n在注册和验证码场景中，用户常会先搜索品牌词。该页面用于减少品牌混淆，帮助用户进入正确的网站与政策页面。\n\n### 相关阅读\n\n- [关于 smail.pw](/about)\n- [常见问题](/faq)\n- [隐私政策](/privacy)\n";
//#endregion
export { smail_vs_smailpro_default as default };

//#region app/md/fr/faq.md?raw
var faq_default = "## FAQ smail.pw\n\n### Qu'est-ce que smail.pw ?\nUn service d'email temporaire pour recevoir des messages de courte durée.\n\n### Faut-il créer un compte ?\nNon, aucune inscription n'est requise.\n\n### Combien de temps les emails sont conservés ?\nJusqu'à 24 heures, puis suppression automatique.\n\n### Peut-on recevoir des OTP ?\nOui, c'est un usage principal.\n\n### Pourquoi un email n'arrive pas ?\nRetard côté expéditeur, blocage des domaines temporaires, ou erreur d'adresse.\n\n### Peut-on envoyer des emails ?\nEn général non. Le service est orienté réception.\n\n### Convient-il aux comptes importants ?\nNon. Utilisez une adresse permanente pour les comptes critiques.\n";
//#endregion
export { faq_default as default };

//#region app/md/zh/can-temporary-email-send.md?raw
var can_temporary_email_send_default = "## 临时邮箱可以发送邮件吗？\n\n很多用户会问：临时邮箱能不能发信？多数情况下，**临时邮箱以收信为主**，主要用于接收验证码和确认链接。\n\n### 为什么常见为“仅接收”\n\n- 降低垃圾邮件和滥用风险\n- 简化风控与审计压力\n- 提高一次性收件箱的可用性和稳定性\n\n### 什么时候该用长期邮箱\n\n如果你需要以下能力，请使用长期邮箱服务：\n\n- 主动发送和回复邮件\n- 长期身份绑定与账户管理\n- 邮件归档与关键信息留存\n\n### 结论\n\nsmail.pw 适合快速收验证码；需要发信时，请切换到长期邮箱。\n\n### 相关阅读\n\n- [验证码一次性邮箱](/disposable-email-for-verification)\n- [免注册临时邮箱](/temporary-email-no-registration)\n- [使用条款](/terms)\n";
//#endregion
export { can_temporary_email_send_default as default };

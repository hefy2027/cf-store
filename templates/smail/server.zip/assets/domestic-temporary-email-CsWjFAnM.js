//#region app/md/ja/domestic-temporary-email.md?raw
var domestic_temporary_email_default = "## 国内向け一時メール受信ガイド\n\nこの**国内向け一時メールガイド**では、地域サービスでの受信遅延対策をまとめています。\n\n### 遅延の主な理由\n\n- 送信側キューの遅延\n- 一時メールドメインの制限\n- アドレス入力ミス\n\n### 対処手順\n\n1. アドレスを正確に確認。\n2. コード再送を実行。\n3. 1〜3分待って更新。\n4. 必要なら別アドレスで再試行。\n\n### 関連ページ\n\n- [オンライン一時メール](/online-temporary-email)\n- [認証用使い捨てメール](/disposable-email-for-verification)\n- [よくある質問](/faq)\n";
//#endregion
export { domestic_temporary_email_default as default };

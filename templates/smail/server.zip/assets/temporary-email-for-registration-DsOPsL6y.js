//#region app/md/ko/temporary-email-for-registration.md?raw
var temporary_email_for_registration_default = "## 가입용 임시 이메일\n\n**가입용 임시 이메일**은 회원가입 시 기본 메일 주소를 노출하고 싶지 않을 때 유용합니다.\n\n### 적합한 상황\n\n- 체험 계정 생성\n- 다운로드/쿠폰 인증\n- 저위험 서비스 가입\n\n### 사용 방법\n\n1. smail.pw에서 일회용 주소 생성\n2. 가입 폼에 주소 입력\n3. OTP 또는 확인 링크 수신\n4. 기본 메일 노출 없이 가입 완료\n\n### 관련 페이지\n\n- [가입 없는 임시 이메일](/temporary-email-no-registration)\n- [인증용 일회용 이메일](/disposable-email-for-verification)\n- [자주 묻는 질문](/faq)\n";
//#endregion
export { temporary_email_for_registration_default as default };

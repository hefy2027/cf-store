//#region app/md/es/privacy.md?raw
var privacy_default = "## Política de privacidad\n\nsmail.pw es un servicio de correo temporal. Procesamos datos mínimos para entregar mensajes y proteger la plataforma frente a abuso.\n\n### Datos que pueden procesarse\n\n- Dirección temporal e emails recibidos\n- Datos técnicos básicos (IP, navegador, hora)\n\n### Retención\n\nEl contenido del correo se conserva hasta 24 horas y luego se elimina automáticamente.\n\n### Aviso importante\n\nNo uses correo temporal para información sensible ni cuentas críticas.\n";
//#endregion
export { privacy_default as default };

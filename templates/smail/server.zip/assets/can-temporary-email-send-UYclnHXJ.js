//#region app/md/ja/can-temporary-email-send.md?raw
var can_temporary_email_send_default = "## 一時メールは送信できる？\n\n多くのケースで、**一時メールは受信専用**です。主な用途は OTP と確認リンクの受信です。\n\n### 受信専用が多い理由\n\n- スパムや不正利用の抑制\n- 不正対策の運用を簡素化\n- 使い捨て用途で安定運用しやすい\n\n### 送信が必要な場合\n\n送信・返信・長期保存が必要なら、恒久メールサービスを利用してください。\n\n### 関連ページ\n\n- [認証用使い捨てメール](/disposable-email-for-verification)\n- [登録不要の一時メール](/temporary-email-no-registration)\n- [利用規約](/terms)\n";
//#endregion
export { can_temporary_email_send_default as default };

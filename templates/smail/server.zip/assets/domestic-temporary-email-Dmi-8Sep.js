//#region app/md/es/domestic-temporary-email.md?raw
var domestic_temporary_email_default = "## Guía de correo temporal local\n\nEsta guía de **correo temporal local** resume cómo mejorar la entrega en plataformas regionales.\n\n### Causas frecuentes de retraso\n\n- Cola del remitente\n- Bloqueo de dominios temporales\n- Error al escribir la dirección\n\n### Qué hacer\n\n1. Confirma la dirección exacta.\n2. Reenvía el código desde la plataforma.\n3. Espera 1-3 minutos y actualiza.\n4. Si falla, prueba otra dirección temporal.\n\n### Páginas relacionadas\n\n- [Correo temporal online](/online-temporary-email)\n- [Correo desechable para verificación](/disposable-email-for-verification)\n- [Preguntas frecuentes](/faq)\n";
//#endregion
export { domestic_temporary_email_default as default };

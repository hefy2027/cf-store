//#region app/md/zh/domestic-temporary-email.md?raw
var domestic_temporary_email_default = "## 国内临时邮箱收信指南\n\n搜索“**国内临时邮箱**”通常是为了在本地平台更稳定地收验证码。这个页面汇总常见延迟原因与排查步骤。\n\n### 常见收信延迟原因\n\n- 发件方队列延迟\n- 平台限制临时邮箱域名\n- 地址复制错误\n\n### 验证码收不到怎么办\n\n1. 先确认邮箱地址完全正确。\n2. 在来源平台重新发送验证码。\n3. 等待 1-3 分钟后刷新收件箱。\n4. 如仍失败，可更换新临时邮箱地址再试。\n\n### 相关阅读\n\n- [在线临时邮箱](/online-temporary-email)\n- [验证码一次性邮箱](/disposable-email-for-verification)\n- [常见问题](/faq)\n";
//#endregion
export { domestic_temporary_email_default as default };

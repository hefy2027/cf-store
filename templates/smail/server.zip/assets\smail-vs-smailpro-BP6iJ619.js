//#region app/md/fr/smail-vs-smailpro.md?raw
var smail_vs_smailpro_default = "## smail.pw vs smailpro\r\n\r\nClarification officielle : **smail.pw est un service indépendant**.\r\n\r\n### Informations clés\r\n\r\n- smail.pw n'est pas le même produit que smail pro ou smailpro\r\n- Aucune affiliation avec des services au nom similaire\r\n- Politiques et fonctionnalités gérées séparément\r\n\r\n### Pages liées\r\n\r\n- [À propos de smail.pw](/about)\r\n- [FAQ](/faq)\r\n- [Politique de confidentialité](/privacy)\r\n";
//#endregion
export { smail_vs_smailpro_default as default };

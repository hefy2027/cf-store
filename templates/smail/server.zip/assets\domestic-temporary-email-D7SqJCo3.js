//#region app/md/ja/domestic-temporary-email.md?raw
var domestic_temporary_email_default = "## 国内向け一時メール受信ガイド\r\n\r\nこの**国内向け一時メールガイド**では、地域サービスでの受信遅延対策をまとめています。\r\n\r\n### 遅延の主な理由\r\n\r\n- 送信側キューの遅延\r\n- 一時メールドメインの制限\r\n- アドレス入力ミス\r\n\r\n### 対処手順\r\n\r\n1. アドレスを正確に確認。\r\n2. コード再送を実行。\r\n3. 1〜3分待って更新。\r\n4. 必要なら別アドレスで再試行。\r\n\r\n### 関連ページ\r\n\r\n- [オンライン一時メール](/online-temporary-email)\r\n- [認証用使い捨てメール](/disposable-email-for-verification)\r\n- [よくある質問](/faq)\r\n";
//#endregion
export { domestic_temporary_email_default as default };

//#region app/md/ja/can-temporary-email-send.md?raw
var can_temporary_email_send_default = "## 一時メールは送信できる？\r\n\r\n多くのケースで、**一時メールは受信専用**です。主な用途は OTP と確認リンクの受信です。\r\n\r\n### 受信専用が多い理由\r\n\r\n- スパムや不正利用の抑制\r\n- 不正対策の運用を簡素化\r\n- 使い捨て用途で安定運用しやすい\r\n\r\n### 送信が必要な場合\r\n\r\n送信・返信・長期保存が必要なら、恒久メールサービスを利用してください。\r\n\r\n### 関連ページ\r\n\r\n- [認証用使い捨てメール](/disposable-email-for-verification)\r\n- [登録不要の一時メール](/temporary-email-no-registration)\r\n- [利用規約](/terms)\r\n";
//#endregion
export { can_temporary_email_send_default as default };

//#region app/md/fr/terms.md?raw
var terms_default = "## Conditions d'utilisation\r\n\r\nEn utilisant smail.pw, vous acceptez ces conditions.\r\n\r\n### Usage autorisé\r\n\r\n- Inscriptions et vérifications à faible risque\r\n- Réception temporaire de messages\r\n\r\n### Usage interdit\r\n\r\n- Spam, fraude, phishing\r\n- Activité illégale ou malveillante\r\n\r\n### Limitation\r\n\r\nAucune garantie de livraison permanente ni de conservation au-delà de 24 heures.\r\n";
//#endregion
export { terms_default as default };

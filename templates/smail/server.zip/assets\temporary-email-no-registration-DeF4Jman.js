//#region app/md/ja/temporary-email-no-registration.md?raw
var temporary_email_no_registration_default = "## 登録不要の一時メール\r\n\r\nsmail.pw では、アカウント作成なしで一時メールをすぐ利用できます。\r\n\r\n### 向いている場面\r\n\r\n- ツールの短時間試用\r\n- メール必須の一回限りダウンロード\r\n- 一時的なコミュニティ登録\r\n\r\n### 利点\r\n\r\n- 個人情報の露出を抑える\r\n- オンボーディング不要\r\n- メイン受信箱を汚さない\r\n\r\n### 注意\r\n\r\n長期運用や重要アカウントには使用しないでください。\r\n\r\n### 関連ページ\r\n\r\n- [24時間 一時メール](/temporary-email-24-hours)\r\n- [認証コード用使い捨てメール](/disposable-email-for-verification)\r\n- [プライバシーポリシー](/privacy)\r\n\r\n### おすすめの使い方\r\n\r\n登録を素早く進めたい場合は [登録向け一時メール](/temporary-email-for-registration) と [オンライン一時メール](/online-temporary-email) も確認してください。\r\n";
//#endregion
export { temporary_email_no_registration_default as default };

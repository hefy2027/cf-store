//#region app/md/ko/domestic-temporary-email.md?raw
var domestic_temporary_email_default = "## 국내 임시 이메일 수신 가이드\r\n\r\n이 **국내 임시 이메일 가이드**는 지역 서비스에서 OTP 지연 시 점검할 항목을 정리합니다.\r\n\r\n### 지연 원인\r\n\r\n- 발신 서버 지연\r\n- 임시 도메인 차단\r\n- 주소 입력 오류\r\n\r\n### 해결 순서\r\n\r\n1. 주소를 정확히 확인\r\n2. 코드 재전송 요청\r\n3. 1~3분 후 새로고침\r\n4. 필요 시 다른 주소로 재시도\r\n\r\n### 관련 페이지\r\n\r\n- [온라인 임시 이메일](/online-temporary-email)\r\n- [인증용 일회용 이메일](/disposable-email-for-verification)\r\n- [자주 묻는 질문](/faq)\r\n";
//#endregion
export { domestic_temporary_email_default as default };

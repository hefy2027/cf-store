//#region app/md/ko/terms.md?raw
var terms_default = "## 이용약관\r\n\r\nsmail.pw를 사용하면 본 약관에 동의한 것으로 간주됩니다.\r\n\r\n### 허용되는 사용\r\n\r\n- 저위험 가입/인증\r\n- 임시 수신 목적 사용\r\n\r\n### 금지되는 사용\r\n\r\n- 스팸, 사기, 피싱\r\n- 불법 또는 악성 활동\r\n\r\n### 제한\r\n\r\n24시간 이후 보관 및 영구 전달은 보장되지 않습니다.\r\n";
//#endregion
export { terms_default as default };

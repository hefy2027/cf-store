//#region app/md/ja/terms.md?raw
var terms_default = "## 利用規約\r\n\r\nsmail.pw を利用することで本規約に同意したものとみなします。\r\n\r\n### 許可される利用\r\n\r\n- 低リスクの登録・認証\r\n- 一時的なメール受信\r\n\r\n### 禁止される利用\r\n\r\n- スパム、詐欺、フィッシング\r\n- 違法・有害な行為\r\n\r\n### 免責\r\n\r\n24時間を超える保持や恒久的な配信は保証されません。\r\n";
//#endregion
export { terms_default as default };

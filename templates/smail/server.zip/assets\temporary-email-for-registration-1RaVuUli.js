//#region app/md/ar/temporary-email-for-registration.md?raw
var temporary_email_for_registration_default = "## بريد مؤقت للتسجيل\r\n\r\nاستخدم **البريد المؤقت للتسجيل** عندما تحتاج إلى تفعيل حساب بدون كشف بريدك الأساسي.\r\n\r\n### الحالات المناسبة\r\n\r\n- إنشاء حسابات تجريبية\r\n- نماذج القسائم أو التحميل\r\n- تسجيلات منخفضة المخاطر\r\n\r\n### طريقة الاستخدام\r\n\r\n1. أنشئ عنوانًا مؤقتًا في smail.pw.\r\n2. أدخله في نموذج التسجيل.\r\n3. استقبل رمز OTP أو رابط التأكيد.\r\n4. أكمل التسجيل دون تعريض بريدك الشخصي.\r\n\r\n### صفحات مرتبطة\r\n\r\n- [بريد مؤقت بدون تسجيل](/temporary-email-no-registration)\r\n- [بريد مؤقت للتحقق ورموز OTP](/disposable-email-for-verification)\r\n- [الأسئلة الشائعة](/faq)\r\n";
//#endregion
export { temporary_email_for_registration_default as default };

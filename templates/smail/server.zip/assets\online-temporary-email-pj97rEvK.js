//#region app/md/ja/online-temporary-email.md?raw
var online_temporary_email_default = "## オンライン一時メール\r\n\r\n**オンライン一時メール**なら、ブラウザですぐに認証メールを受信できます。\r\n\r\n### メリット\r\n\r\n- インストール不要ですぐ使える\r\n- 受信箱を即時更新できる\r\n- 個人メールの露出を減らせる\r\n\r\n### 受信できないとき\r\n\r\n- アドレスの入力ミスを確認\r\n- 送信元で再送を実行\r\n- 数分待ってから再更新\r\n\r\n### 関連ページ\r\n\r\n- [24時間一時メール](/temporary-email-24-hours)\r\n- [登録向け一時メール](/temporary-email-for-registration)\r\n- [認証用使い捨てメール](/disposable-email-for-verification)\r\n";
//#endregion
export { online_temporary_email_default as default };

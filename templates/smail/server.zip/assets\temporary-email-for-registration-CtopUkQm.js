//#region app/md/ja/temporary-email-for-registration.md?raw
var temporary_email_for_registration_default = "## 登録向け一時メール\r\n\r\n**登録向け一時メール**は、アカウント作成時にメインアドレスを公開したくない場合に有効です。\r\n\r\n### 向いている場面\r\n\r\n- トライアル登録\r\n- ダウンロード前の確認メール\r\n- 低リスクなサービス登録\r\n\r\n### 手順\r\n\r\n1. smail.pw で使い捨てアドレスを生成。\r\n2. 登録フォームに入力。\r\n3. OTP または確認リンクを受信。\r\n4. メインメールを公開せず登録完了。\r\n\r\n### 関連ページ\r\n\r\n- [登録不要の一時メール](/temporary-email-no-registration)\r\n- [認証用使い捨てメール](/disposable-email-for-verification)\r\n- [よくある質問](/faq)\r\n";
//#endregion
export { temporary_email_for_registration_default as default };

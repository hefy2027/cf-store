//#region app/md/ru/domestic-temporary-email.md?raw
var domestic_temporary_email_default = "## Локальная временная почта: гайд\r\n\r\nЭтот **гайд по локальной временной почте** помогает при задержках доставки на региональных сервисах.\r\n\r\n### Частые причины задержек\r\n\r\n- Очередь у отправителя\r\n- Блокировка временных доменов\r\n- Ошибка в адресе\r\n\r\n### Что делать\r\n\r\n1. Проверьте адрес посимвольно.\r\n2. Запросите код повторно.\r\n3. Подождите 1-3 минуты и обновите.\r\n4. При необходимости используйте другой адрес.\r\n\r\n### Связанные страницы\r\n\r\n- [Онлайн временная почта](/online-temporary-email)\r\n- [Одноразовая почта для верификации](/disposable-email-for-verification)\r\n- [FAQ](/faq)\r\n";
//#endregion
export { domestic_temporary_email_default as default };

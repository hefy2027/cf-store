//#region app/md/fr/privacy.md?raw
var privacy_default = "## Politique de confidentialité\r\n\r\nsmail.pw est un service d'email temporaire. Nous traitons un minimum de données pour assurer la réception des messages et la sécurité du service.\r\n\r\n### Données possibles\r\n\r\n- Adresse temporaire et emails reçus\r\n- Données techniques de base (IP, navigateur, horodatage)\r\n\r\n### Conservation\r\n\r\nLe contenu des emails est conservé jusqu'à 24 heures puis supprimé automatiquement.\r\n\r\n### Important\r\n\r\nN'utilisez pas ce service pour des informations sensibles ou des comptes critiques.\r\n";
//#endregion
export { privacy_default as default };
